$(document).ready(function() {
	LOAD_DASH.productSummary.getData();
	LOAD_DASH.leadHistory.getData();
	LOAD_DASH.leadSummary.getData();
	LOAD_DASH.campaignUnitMap.getData();
	LOAD_DASH.leadOwner.getData();			
});

/*==================================================*/

var LOAD_DASH = {};
//-------------------------------
LOAD_DASH.productSummary = {
	URL : '/lms/get-product-summary-ajax',
	getData : function() {
		if($('#chartContainer3').length) {
			$('.productSummaryLoader').show();
			var self = this;
			$.getJSON(this.URL, function(data) {
			  var preparedData = self.prepareData(data);
			  LOAD_DASH.commonMethod.displayGraph('chartContainer3', preparedData);
			  self.displayTable(preparedData);
			  $('.productSummaryLoader').hide();
			});
		}
	},
	prepareData : function (jsonData) {
		var returnData = [];
		$.each(jsonData, function(key, summary) {
			returnData.push({
				name: summary.p_name,
				y: parseInt(summary.p_count),
				sliced: true,
				selected: true
			});				
		});
		return returnData;
	},
	displayTable : function (tableData) {
		if($('#G_p_table').length) {
			var html = '<table class="table">';
				html +=		'<thead>';
				html +=  		'<tr>';
				html +=				'<th>Product</th>';
				html +=				'<th>Leads</th>';
				html +=				'<th>&nbsp;</th>';
				html +=			'</tr>';
				html +=		'</thead>';
				html +=		'<tbody>';
				$.each(tableData, function(key, data) {
					html +=  		'<tr>';
					html +=				'<td>'+data.name+'</td>';
					html +=				'<td>'+data.y+'</th>';
					html +=				'<td>';
					html +=					'<a href="javascript:void(0);" onclick="LOAD_DASH.productSummary.formSubmission(\''+data.name+'\')">View</a>';
					html +=				'</td>';
					html +=			'</tr>';
				});                
				html +=		'</tbody>';
				html +=		'</table>';
				$('#G_p_table').html(html);			
		}
	},
	formSubmission : function (name) { 
		$("#all_src").val(name);
     	$("#hdn_flg").val(4);
		frmdetails.submit();
	},
	
}

//-------------------------------

LOAD_DASH.leadHistory = {
	URL : '/lms/get-lead-history-ajax',
	getData : function() {
		if($('#leadsHistroy').length) {
			$('.leadHistoryAjaxLoader').show();
			var self = this;
			$.getJSON(this.URL, function(data) {			
			  self.displayGraph(data);
			  self.displayTable(data);
			  $('.leadHistoryAjaxLoader').hide();
			});
		}
	},
	displayTable : function (data) {
		if($('#G_h_table').length) {				
			var tableData = data.monthsData;
			var html = '<table class="table">';
			html +=		'<thead>';
			html +=  		'<tr>';
			html +=				'<th>Date</th>';
			html +=				'<th>Count</th>';
			html +=				'<th>&nbsp;</th>';
			html +=			'</tr>';
			html +=		'</thead>';
			html +=		'<tbody>';
			$.each(tableData, function(key, data) {
				html +=  		'<tr>';
				html +=				'<td>'+data.name+'</td>';
				html +=				'<td>'+data.y+'</th>';
				html +=				'<td>';
				html +=					'<a href="javascript:void(0);" onclick="LOAD_DASH.leadHistory.formSubmission(\''+data.start_date+'\',\''+data.end_date+'\')">View</a>';
				html +=				'</td>';
				html +=			'</tr>';
			});                
			html +=		'</tbody>';
			html +=		'</table>';
			$('#G_h_table').html(html);
		}
	},
	formSubmission : function (start_date, end_date) {
		$("#sViewDate").val(start_date);
        $("#eViewDate").val(end_date);
        formdate.submit();        
	},
	displayGraph : function(data) {
		var brandsData = data.monthsData;
		var drilldownSeries = data.daysData;
		$('#leadsHistroy').highcharts({
			chart: {
					type: 'column'
			},
			title: {
					text: ''
			},
			subtitle: {
					text: 'Click the columns to view more details.'
			},
			xAxis: {
					type: 'category'
			},
			yAxis: {
					title: {
							text: 'Leads'
					}
			},
			legend: {
					enabled: false
			},
			plotOptions: {
					series: {
							borderWidth: 0,
							dataLabels: {
									enabled: true,
									format: '{point.y: .0f} leads'
							}
					}
			},

			tooltip: {
					headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
					pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f} Leads</b><br/><a href="javascript:void(0);" onclick="viewHistoryList(cdate);">View</a>'
			},

			series: [{
					name: 'Leads',
					colorByPoint: true,
					data: brandsData
			}],
			drilldown: {
					series: drilldownSeries
			}
		});
	}
}

//-------------------------------

LOAD_DASH.leadOwner = {
	URL : '/lms/get-lead-owner-ajax',
	getData : function() {
		if($('#chartContainer2').length) {
			$('.leadOwnerAjaxLoader').show();
			var self = this;
			$.getJSON(this.URL, function(data) {
			  var preparedData = self.prepareData(data);
			  LOAD_DASH.commonMethod.displayGraph('chartContainer2', preparedData);
			  self.displayTable(preparedData);
			  $('.leadOwnerAjaxLoader').hide();
			});
		}
	},
	prepareData : function (jsonData) {
		var returnData = [];
		$.each(jsonData, function(key, summary) {
			returnData.push({
				id: parseInt(summary.id),
				webform_id: parseInt(summary.webform_id),
				name: summary.user_name,
				y: parseInt(summary.cnt),
				owner_id: parseInt(summary.owner_id),
				sliced: true,
				selected: true
			});
		});		
		return returnData;
	},
	displayTable : function (tableData) {
		if($('#G_o_table').length) {				
			var html = '<table class="table">';
				html +=		'<thead>';
				html +=  		'<tr>';
				html +=				'<th>Lead Owner</th>';
				html +=				'<th>Leads</th>';
				html +=				'<th>&nbsp;</th>';
				html +=			'</tr>';
				html +=		'</thead>';
				html +=		'<tbody>';
				$.each(tableData, function(key, data) {
					html +=  		'<tr>';
					html +=				'<td>'+data.name+'</td>';
					html +=				'<td>'+data.y+'</th>';
					html +=				'<td>';
					html +=					'<a href="javascript:void(0);" onclick="LOAD_DASH.leadOwner.formSubmission('+data.owner_id+')">View</a>';
					html +=				'</td>';
					html +=			'</tr>';
				});                
				html +=		'</tbody>';
				html +=		'</table>';
				$('#G_o_table').html(html);
		}
	},
	formSubmission : function (ownerId) {		
		$("#owner_id").val(ownerId);	  
		$('#hdn_webformdata_id, #hdn_webform_id, #hdn_lp_id').val('');
		$('#owner_id').val(ownerId)
		$('#hdn_flg').val(3);
		frmdetails.submit();
	},
}

//-------------------------------

LOAD_DASH.campaignUnitMap = {
	URL : '/lms/get-campaign-unit-ajax',
	getData : function() {
		if($('#chartContainer').length) {
			$('.campaignUnitAjaxLoader').show();
			var self = this;
			$.getJSON(this.URL, function(data) {
			  var preparedData = self.prepareData(data);
			  LOAD_DASH.commonMethod.displayGraph('chartContainer', preparedData);
			  self.displayTable(preparedData);
			  $('.campaignUnitAjaxLoader').hide();
			});
		}
	},
	prepareData : function (jsonData) {
		var returnData = [];
		$.each(jsonData, function(key, summary) {
			returnData.push({
				id: parseInt(summary.id),
				business_unit_id: parseInt(summary.business_unit_id),
				webform_data_id: parseInt(summary.webform_data_id),
				webform_id: parseInt(summary.webform_id),
				name: summary.business_unit_name,
				y: parseInt(summary.COUNT),
				sliced: true,
				selected: true
			});
		});		
		return returnData;
	},
	displayTable : function (tableData) {
		if($('#G_c_table').length) {				
			var html = '<table class="table">';
				html +=		'<thead>';
				html +=  		'<tr>';
				html +=				'<th>CU Name</th>';
				html +=				'<th>Count</th>';
				html +=				'<th>&nbsp;</th>';
				html +=			'</tr>';
				html +=		'</thead>';
				html +=		'<tbody>';
				$.each(tableData, function(key, data) {
					html +=  		'<tr>';
					html +=				'<td>'+data.name+'</td>';
					html +=				'<td>'+data.y+'</th>';
					html +=				'<td>';
					html +=					'<a href="javascript:void(0);" onclick="LOAD_DASH.campaignUnitMap.formSubmission('+data.business_unit_id+')">View</a>';
					html +=				'</td>';
					html +=			'</tr>';
				});                
				html +=		'</tbody>';
				html +=		'</table>';
				$('#G_c_table').html(html);
		}
	},
	formSubmission : function (businessUnitId) {
		$('#hdn_webformdata_id, #hdn_webform_id, #hdn_lp_id').val('');
		$('#hdn_unit_id').val(businessUnitId)
		$('#hdn_flg').val(1);
		frmdetails.submit();
	},
}

//-------------------------------

LOAD_DASH.leadSummary = {
	URL : '/lms/get-lead-status-ajax',
	getData : function() {
		if($('#chartContainer1').length) {
			$('.leadStatusLoader').show();
			var self = this;
			$.getJSON(this.URL, function(data) {				
			  var preparedData = self.prepareData(data);
			  LOAD_DASH.commonMethod.displayGraph('chartContainer1', preparedData);
			  self.displayTable(preparedData);
			  $('.leadStatusLoader').hide();
			});
		}	
	},
	prepareData : function (jsonData) {
		var returnData = [];
		$.each(jsonData, function(key, summary) {
			returnData.push({
				id: parseInt(summary.id),
				webform_data_id: parseInt(summary.webform_data_id),
				webform_id: parseInt(summary.webform_id),
				name: summary.status_label,
				y: parseInt(summary.cnt),
				info_status: parseInt(summary.info_status),
				sliced: true,
				selected: true
			});				
		});
		return returnData;
	},
	displayTable : function (tableData) {
		if($('#G_s_table').length) {
			var html = '<table class="table">';
				html +=		'<thead>';
				html +=  		'<tr>';
				html +=				'<th>Status</th>';
				html +=				'<th>Leads</th>';
				html +=				'<th>&nbsp;</th>';
				html +=			'</tr>';
				html +=		'</thead>';
				html +=		'<tbody>';
				$.each(tableData, function(key, data) {
					html +=  		'<tr>';
					html +=				'<td>'+data.name+'</td>';
					html +=				'<td>'+data.y+'</th>';
					html +=				'<td>';
					html +=					'<a href="javascript:void(0);" onclick="LOAD_DASH.leadSummary.formSubmission('+data.info_status+')">View</a>';
					html +=				'</td>';
					html +=			'</tr>';
				});                
				html +=		'</tbody>';
				html +=		'</table>';
				$('#G_s_table').html(html);			
		}
	},
	formSubmission : function (status) { 
		$('#hdn_webformdata_id, #hdn_webform_id, #hdn_lp_id').val('');
		$('#info_status').val(status)
		$('#hdn_flg').val(2);
		frmdetails.submit();
	},
	
}

//-------------------------------

LOAD_DASH.commonMethod = {
	displayGraph : function (id, graphData) {
		if($('#' + id).length) {
			var name = 'Lead Count';
			if(id == 'chartContainer3') {
				name = 'Product share';
			}
			$('#' + id).highcharts({
				chart: {
					type: 'pie',
					options3d: {
						enabled: true,
						alpha: 45,
						beta: 0
					}
				},
				title: {
					text: ''
				},
				tooltip: {
					pointFormat: '{series.name}: <b>{point.y}</b>'
				},
				plotOptions: {
					pie: {
						allowPointSelect: true,
						cursor: 'pointer',
						depth: 35,
						dataLabels: {
							enabled: false,
							format: '{point.name}'
						}
					}
				},
				series: [{
					type: 'pie',
					name: name,
					data: graphData,
					 point:{
					  events:{
						  click: function (event) {
							  switch(id) {
								  case 'chartContainer' :
										$("#hdn_webformdata_id").val(this.webform_data_id);
										$("#hdn_webform_id").val(this.webform_id);
										$("#hdn_unit_id").val(this.id);
										$("#hdn_flg").val(1);
										frmdetails.submit();
								  break;
								  case 'chartContainer1' :
										$("#hdn_webformdata_id").val(this.webform_data_id);
										$("#hdn_webform_id").val(this.webform_id);
										$("#info_status").val(this.info_status)
										$("#hdn_flg").val(2);
										frmdetails.submit();							  
								  break;
								  case 'chartContainer2' :
										$("#hdn_webform_id").val(this.webform_id);
										$("#owner_id").val(this.owner_id);
										$("#hdn_flg").val(3);
										frmdetails.submit();							  
								  break;
								  case 'chartContainer3' :
										$("#all_src").val(this.name);
										$("#hdn_flg").val(4);
										frmdetails.submit();							  
								  break;								  
							  }
							  
						  }
					  }
					}

				}]
			});
		}			
	}
}



/*==================================================*/

function show_hide(flag) {
	var obj1=$("#G_"+flag+"_graph");
	var obj2=$("#G_"+flag+"_table");
	if(obj1.css('display')=="none") {
		 obj1.show();
		 obj2.hide();
	 } else {
		 obj1.hide();
		 obj2.show();
	}
}
$('#drop1 a').click(function(){
	$('#dropText').text($(this).text());
	$('#hdn_acl_role').val($(this).attr('val'));
	frmaclrole.submit();
});
$('.dataView').click(function() {
	if($(this).hasClass('fa fa-table')) {
		$(this).removeClass('fa fa-table');
		$(this).addClass('fa fa-bar-chart-o');
	} else {
		$(this).removeClass('fa fa-bar-chart-o');
		$(this).addClass('fa fa-table');
	}
});
function viewHistoryList(cdate){
	$("#sdate").val(this.webform_data_id);
	$("#edate").val(this.webform_id);
	frmacldate.submit();
}

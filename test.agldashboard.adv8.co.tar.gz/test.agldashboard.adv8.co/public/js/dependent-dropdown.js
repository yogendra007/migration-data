function load_activity(field_3,field_2,selected){
	$(field_3).empty();
	if (field_2.value=='Marketing'){
		if(field_3=='DirectMarketing'){
			$(field_3).append("<option value='DirectMarketing' selected='selected'>DirectMarketing</option>");
		}else{
			$(field_3).append("<option value='DirectMarketing'>DirectMarketing</option>");
		}
		if(field_3=='Events'){
			$(field_3).append("<option value='Events' selected='selected'>Events</option>");
		}else{
			$(field_3).append("<option value='Events'>Events</option>");
		}
		if(field_3=='OnlineMarketing'){
			$(field_3).append("<option value='OnlineMarketing' selected='selected'>OnlineMarketing</option>");
		}else{
			$(field_3).append("<option value='OnlineMarketing'>OnlineMarketing</option>");
		}
		if(field_3=='Outdoor'){
			$(field_3).append("<option value='Outdoor' selected='selected'>Outdoor</option>");
		}else{
			$(field_3).append("<option value='Outdoor'>Outdoor</option>");
		}
		if(field_3=='Print Dialies'){
			$(field_3).append("<option value='Print Dialies' selected='selected'>Print Dialies</option>");
		}else{
			$(field_3).append("<option value='Print Dialies'>Print Dialies</option>");
		}
		if(field_3=='PrintMagazines'){
			$(field_3).append("<option value='PrintMagazines' selected='selected'>PrintMagazines</option>");
		}else{
			$(field_3).append("<option value='PrintMagazines'>PrintMagazines</option>");
		}
		if(field_3=='Sponsorship'){
			$(field_3).append("<option value='Sponsorship' selected='selected'>Sponsorship</option>");
		}else{
			$(field_3).append("<option value='Sponsorship'>Sponsorship</option>");
		}
		if(field_3=='Cold calling'){
			$(field_3).append("<option value='Cold calling' selected='selected'>Cold calling</option>");
		}else{
			$(field_3).append("<option value='Cold calling'>Cold calling</option>");
		}
		if(field_3=='Other'){
			$(field_3).append("<option value='Other' selected='selected'>Other</option>");
		}else{
			$(field_3).append("<option value='Other'>Other</option>");
		}
	}
	if (field_2.value=='B Spoke'){
		if(field_3=='sales consultant referral'){
			$(field_3).append("<option value='sales consultant referral' selected='selected'>sales consultant referral</option>");
		}else{
			$(field_3).append("<option value='sales consultant referral'>sales consultant referral</option>");
		}
		if(field_3=='Spot offer'){
			$(field_3).append("<option value='Spot offer' selected='selected'>Spot offer</option>");
		}else{
			$(field_3).append("<option value='Spot offer'>Spot offer</option>");
		}
	}
	if (field_2.value=='Corporate'){
		if(field_3=='Account Manager Introduction'){
			$(field_3).append("<option value='Account Manager Introduction' selected='selected'>Account Manager Introduction</option>");
		}else{
			$(field_3).append("<option value='Account Manager Introduction'>Account Manager Introduction</option>");
		}
		if(field_3=='Coorporate Offers'){
			$(field_3).append("<option value='Coorporate Offers' selected='selected'>Coorporate Offers</option>");
		}else{
			$(field_3).append("<option value='Coorporate Offers'>Coorporate Offers</option>");
		}
		if(field_3=='Date/Weekend with audi'){
			$(field_3).append("<option value='Date/Weekend with audi' selected='selected'>Date/Weekend with audi</option>");
		}else{
			$(field_3).append("<option value='Date/Weekend with audi'>Date/Weekend with audi</option>");
		}
		if(field_3=='DM'){
			$(field_3).append("<option value='DM' selected='selected'>DM</option>");
		}else{
			$(field_3).append("<option value='DM'>DM</option>");
		}
		if(field_3=='EDM'){
			$(field_3).append("<option value='EDM' selected='selected'>EDM</option>");
		}else{
			$(field_3).append("<option value='EDM'>EDM</option>");
		}
		if(field_3=='Key contacts/Gatekeepers Engagement programs'){
			$(field_3).append("<option value='Key contacts/Gatekeepers Engagement programs' selected='selected'>Key contacts/Gatekeepers Engagement programs</option>");
		}else{
			$(field_3).append("<option value='Key contacts/Gatekeepers Engagement programs'>Key contacts/Gatekeepers Engagement programs</option>");
		}
		if(field_3=='Red carpet events'){
			$(field_3).append("<option value='Red carpet events' selected='selected'>Red carpet events</option>");
		}else{
			$(field_3).append("<option value='Red carpet events'>Red carpet events</option>");
		}
		if(field_3=='Test drive'){
			$(field_3).append("<option value='Test drive' selected='selected'>Test drive</option>");
		}else{
			$(field_3).append("<option value='Test drive'>Test drive</option>");
		}
		if(field_3=='Thought Leadership'){
			$(field_3).append("<option value='Thought Leadership' selected='selected'>Thought Leadership</option>");
		}else{
			$(field_3).append("<option value='Thought Leadership'>Thought Leadership</option>");
		}
		if(field_3=='Trade association sponsorship'){
			$(field_3).append("<option value='Trade association sponsorship' selected='selected'>Trade association sponsorship</option>");
		}else{
			$(field_3).append("<option value='Trade association sponsorship'>Trade association sponsorship</option>");
		}
		if(field_3=='Trade in offers'){
			$(field_3).append("<option value='Trade in offers' selected='selected'>Trade in offers</option>");
		}else{
			$(field_3).append("<option value='Trade in offers'>Trade in offers</option>");
		}
	}
	if (field_2.value=='Finance'){
		if(field_3=='Bank activation'){
			$(field_3).append("<option value='Bank activation' selected='selected'>Bank activation</option>");
		}else{
			$(field_3).append("<option value='Bank activation'>Bank activation</option>");
		}
		if(field_3=='Customer meet'){
			$(field_3).append("<option value='Customer meet' selected='selected'>Customer meet</option>");
		}else{
			$(field_3).append("<option value='Customer meet'>Customer meet</option>");
		}
		if(field_3=='DSA meet'){
			$(field_3).append("<option value='DSA meet' selected='selected'>DSA meet</option>");
		}else{
			$(field_3).append("<option value='DSA meet'>DSA meet</option>");
		}
	}
	if (field_2.value=='Retail'){
		if(field_3=='sales consultant referral'){
			$(field_3).append("<option value='sales consultant referral' selected='selected'>sales consultant referral</option>");
		}else{
			$(field_3).append("<option value='sales consultant referral'>sales consultant referral</option>");
		}
		if(field_3=='Spot offer'){
			$(field_3).append("<option value='Spot offer' selected='selected'>Spot offer</option>");
		}else{
			$(field_3).append("<option value='Spot offer'>Spot offer</option>");
		}
	}
	if (field_2.value=='Used Car/Exchange'){
		if(field_3=='Exchange event'){
			$(field_3).append("<option value='Exchange event' selected='selected'>Exchange event</option>");
		}else{
			$(field_3).append("<option value='Exchange event'>Exchange event</option>");
		}
	}
	/*$(field_3).append("<option value=''>--Select--</option>");
	$(field_3).append("<option value='DirectMarketing'>DirectMarketing</option>");
	$(field_3).append("<option value='Events'>Events</option>");
	$(field_3).append("<option value='OnlineMarketing'>OnlineMarketing</option>");
	$(field_3).append("<option value='Outdoor'>Outdoor</option>");
	$(field_3).append("<option value='Print Dialies'>Print Dialies</option>");
	$(field_3).append("<option value='PrintMagazines'>PrintMagazines</option>");
	$(field_3).append("<option value='Sponsorship'>Sponsorship</option>");
	$(field_3).append("<option value='Cold calling'>Cold calling</option>");
	$(field_3).append("<option value='Other'>Other</option>");
	$(field_3).append("<option value='Cold calling'>Cold calling</option>");
	$(field_3).append("<option value='sales consultant referral'>sales consultant referral</option>");
	$(field_3).append("<option value='Spot offer'>Spot offer</option>");
	$(field_3).append("<option value='Account Manager Introduction'>Account Manager Introduction</option>");
	$(field_3).append("<option value='Coorporate Offers'>Coorporate Offers</option>");
	$(field_3).append("<option value='Date/Weekend with audi'>Date/Weekend with audi</option>");
	$(field_3).append("<option value='DM'>DM</option>");
	$(field_3).append("<option value='EDM'>EDM</option>");
	$(field_3).append("<option value='Key contacts/Gatekeepers Engagement programs'>Key contacts/Gatekeepers Engagement programs</option>");
	$(field_3).append("<option value='Red carpet events'>Red carpet events</option>");
	$(field_3).append("<option value='Test drive'>Test drive</option>");
	$(field_3).append("<option value='Thought Leadership'>Thought Leadership</option>");
	$(field_3).append("<option value='Trade association sponsorship'>Trade association sponsorship</option>");
	$(field_3).append("<option value='Trade in offers'>Trade in offers</option>");
	$(field_3).append("<option value='Bank activation'>Bank activation</option>");
	$(field_3).append("<option value='Customer meet'>Customer meet</option>");
	$(field_3).append("<option value='DSA meet'>DSA meet</option>");
	$(field_3).append("<option value='sales consultant referral'>sales consultant referral</option>");
	$(field_3).append("<option value='Spot offer'>Spot offer</option>");
	$(field_3).append("<option value='Exchange event'>Exchange event</option>");*/
	
	if(selected !='') $(field_3).val(selected);
}

function load_subActivity(field_4,field_3,selected,selectedpub){
	$(field_4).empty();
	if(field_3.value == 'Print Dialies' || field_3.value == 'PrintMagazines') { 
		$('#pubHide').show();
		$('#sizeHide').show();
	} else { 
		$('#pubHide').hide();
		$('#sizeHide').hide();
	}
	if (field_3.value=='DirectMarketing'){
		if(field_4=='Database Marketing'){
			$(field_4).append("<option value='Database Marketing' selected='selected'>Database Marketing</option>");
		}else{
			$(field_4).append("<option value='Database Marketing'>Database Marketing</option>");
		}
		if(field_4=='DM'){
			$(field_4).append("<option value='DM' selected='selected'>DM</option>");
		}else{
			$(field_4).append("<option value='DM'>DM</option>");
		}
		if(field_4=='Just Dial'){
			$(field_4).append("<option value='Just Dial' selected='selected'>Just Dial</option>");
		}else{
			$(field_4).append("<option value='Just Dial'>Just Dial</option>");
		}
		if(field_4=='SMS Blast'){
			$(field_4).append("<option value='SMS Blast' selected='selected'>SMS Blast</option>");
		}else{
			$(field_4).append("<option value='SMS Blast'>SMS Blast</option>");
		}
		if(field_4=='Sulekha'){
			$(field_4).append("<option value='Sulekha' selected='selected'>Sulekha</option>");
		}else{
			$(field_4).append("<option value='Sulekha'>Sulekha</option>");
		}
		if(field_4=='News letters'){
			$(field_4).append("<option value='News letters' selected='selected'>News letters</option>");
		}else{
			$(field_4).append("<option value='News letters'>News letters</option>");
		}
	}
	if (field_3.value=='Events'){
		if(field_4=='Auto Expo'){
			$(field_4).append("<option value='Auto Expo' selected='selected'>Auto Expo</option>");
		}else{
			$(field_4).append("<option value='Auto Expo'>Auto Expo</option>");
		}
		if(field_4=='Customer Meet'){
			$(field_4).append("<option value='Customer Meet' selected='selected'>Customer Meet</option>");
		}else{
			$(field_4).append("<option value='Customer Meet'>Customer Meet</option>");
		}
		if(field_4=='Dealership Opening'){
			$(field_4).append("<option value='Dealership Opening' selected='selected'>Dealership Opening</option>");
		}else{
			$(field_4).append("<option value='Dealership Opening'>Dealership Opening</option>");
		}
		if(field_4=='Mall Activation'){
			$(field_4).append("<option value='Mall Activation' selected='selected'>Mall Activation</option>");
		}else{
			$(field_4).append("<option value='Mall Activation'>Mall Activation</option>");
		}
		if(field_4=='Open House'){
			$(field_4).append("<option value='Open House' selected='selected'>Open House</option>");
		}else{
			$(field_4).append("<option value='Open House'>Open House</option>");
		}
		if(field_4=='Product Launch'){
			$(field_4).append("<option value='Product Launch' selected='selected'>Product Launch</option>");
		}else{
			$(field_4).append("<option value='Product Launch'>Product Launch</option>");
		}
		if(field_4=='Quattro Cup'){
			$(field_4).append("<option value='Quattro Cup' selected='selected'>Quattro Cup</option>");
		}else{
			$(field_4).append("<option value='Quattro Cup'>Quattro Cup</option>");
		}
		if(field_4=='Road Show'){
			$(field_4).append("<option value='Road Show' selected='selected'>Road Show</option>");
		}else{
			$(field_4).append("<option value='Road Show'>Road Show</option>");
		}
		if(field_4=='BDE'){
			$(field_4).append("<option value='BDE' selected='selected'>BDE</option>");
		}else{
			$(field_4).append("<option value='BDE'>BDE</option>");
		}
		if(field_4=='RWA'){
			$(field_4).append("<option value='RWA' selected='selected'>RWA</option>");
		}else{
			$(field_4).append("<option value='RWA'>RWA</option>");
		}
		if(field_4=='Bank event'){
			$(field_4).append("<option value='Bank event' selected='selected'>Bank event</option>");
		}else{
			$(field_4).append("<option value='Bank event'>Bank event</option>");
		}
		if(field_4=='Club'){
			$(field_4).append("<option value='Club' selected='selected'>Club</option>");
		}else{
			$(field_4).append("<option value='Club'>Club</option>");
		}
		
	}
	if (field_3.value=='OnlineMarketing'){
		if(field_4=='Banner'){
			$(field_4).append("<option value='Banner' selected='selected'>Banner</option>");
		}else{
			$(field_4).append("<option value='Banner'>Banner</option>");
		}
		if(field_4=='Cardekho'){
			$(field_4).append("<option value='Cardekho' selected='selected'>Cardekho</option>");
		}else{
			$(field_4).append("<option value='Cardekho'>Cardekho</option>");
		}
		if(field_4=='Car Wale'){
			$(field_4).append("<option value='Car Wale' selected='selected'>Car Wale</option>");
		}else{
			$(field_4).append("<option value='Car Wale'>Car Wale</option>");
		}
		if(field_4=='EDM'){
			$(field_4).append("<option value='EDM' selected='selected'>EDM</option>");
		}else{
			$(field_4).append("<option value='EDM'>EDM</option>");
		}
		if(field_4=='FB'){
			$(field_4).append("<option value='FB' selected='selected'>FB</option>");
		}else{
			$(field_4).append("<option value='FB'>FB</option>");
		}
		if(field_4=='Linkedin'){
			$(field_4).append("<option value='Linkedin' selected='selected'>Linkedin</option>");
		}else{
			$(field_4).append("<option value='Linkedin'>Linkedin</option>");
		}
		if(field_4=='Mobile Marketing'){
			$(field_4).append("<option value='Mobile Marketing' selected='selected'>Mobile Marketing</option>");
		}else{
			$(field_4).append("<option value='Mobile Marketing'>Mobile Marketing</option>");
		}
		if(field_4=='SEM'){
			$(field_4).append("<option value='SEM' selected='selected'>SEM</option>");
		}else{
			$(field_4).append("<option value='SEM'>SEM</option>");
		}
		if(field_4=='SEO'){
			$(field_4).append("<option value='SEO' selected='selected'>SEO</option>");
		}else{
			$(field_4).append("<option value='SEO'>SEO</option>");
		}
		if(field_4=='Twitter'){
			$(field_4).append("<option value='Twitter' selected='selected'>Twitter</option>");
		}else{
			$(field_4).append("<option value='Twitter'>Twitter</option>");
		}
		if(field_4=='Quikr'){
			$(field_4).append("<option value='Quikr' selected='selected'>Quikr</option>");
		}else{
			$(field_4).append("<option value='Quikr'>Quikr</option>");
		}
		if(field_4=='Auto portal'){
			$(field_4).append("<option value='Auto portal' selected='selected'>Auto portal</option>");
		}else{
			$(field_4).append("<option value='Auto portal'>Auto portal</option>");
		}
		if(field_4=='Other'){
			$(field_4).append("<option value='Other' selected='selected'>Other</option>");
		}else{
			$(field_4).append("<option value='Other'>Other</option>");
		}
	}
	if (field_3.value=='Outdoor'){
		if(field_4=='Bus Shelter'){
			$(field_4).append("<option value='Bus Shelter' selected='selected'>Bus Shelter</option>");
		}else{
			$(field_4).append("<option value='Bus Shelter'>Bus Shelter</option>");
		}
		if(field_4=='Hoarding'){
			$(field_4).append("<option value='Hoarding' selected='selected'>Hoarding</option>");
		}else{
			$(field_4).append("<option value='Hoarding'>Hoarding</option>");
		}
		if(field_4=='Kiosk'){
			$(field_4).append("<option value='Kiosk' selected='selected'>Kiosk</option>");
		}else{
			$(field_4).append("<option value='Kiosk'>Kiosk</option>");
		}
		if(field_4=='OOH'){
			$(field_4).append("<option value='OOH' selected='selected'>OOH</option>");
		}else{
			$(field_4).append("<option value='OOH'>OOH</option>");
		}
		if(field_4=='Other'){
			$(field_4).append("<option value='Other' selected='selected'>Other</option>");
		}else{
			$(field_4).append("<option value='Other'>Other</option>");
		}
	}
	if (field_3.value=='Print Dialies'){
		if(field_4=='Print Dialies'){
			$(field_4).append("<option value='Print Dialies' selected='selected'>Print Dialies</option>");
		}else{
			$(field_4).append("<option value='Print Dialies'>Print Dialies</option>");
		}
		if(field_5=='Bangalore Times'){
			$(field_5).append("<option value='Bangalore Times' selected='selected'>Bangalore Times</option>");
		}else{
			$(field_5).append("<option value='Bangalore Times'>Bangalore Times</option>");
		}
		if(field_5=='Dainik Jagran'){
			$(field_5).append("<option value='Dainik Jagran' selected='selected'>Dainik Jagran</option>");
		}else{
			$(field_5).append("<option value='Dainik Jagran'>Dainik Jagran</option>");
		}
		if(field_5=='Delhi Cafe'){
			$(field_5).append("<option value='Delhi Cafe' selected='selected'>Delhi Cafe</option>");
		}else{
			$(field_5).append("<option value='Delhi Cafe'>Delhi Cafe</option>");
		}
		if(field_5=='Delhi times'){
			$(field_5).append("<option value='Delhi times' selected='selected'>Delhi times</option>");
		}else{
			$(field_5).append("<option value='Delhi times'>Delhi times</option>");
		}
		if(field_5=='Hindustan'){
			$(field_5).append("<option value='Hindustan' selected='selected'>Hindustan</option>");
		}else{
			$(field_5).append("<option value='Hindustan'>Hindustan</option>");
		}
		if(field_5=='HT city'){
			$(field_5).append("<option value='HT city' selected='selected'>HT city</option>");
		}else{
			$(field_5).append("<option value='HT city'>HT city</option>");
		}
		if(field_5=='Times of India'){
			$(field_5).append("<option value='Times of India' selected='selected'>Times of India</option>");
		}else{
			$(field_5).append("<option value='Times of India'>Times of India</option>");
		}
		if(field_5=='Navbharat Times'){
			$(field_5).append("<option value='Navbharat Times' selected='selected'>Navbharat Times</option>");
		}else{
			$(field_5).append("<option value='Navbharat Times'>Navbharat Times</option>");
		}
		if(field_5=='Navodaya times'){
			$(field_5).append("<option value='Navodaya times' selected='selected'>Navodaya times</option>");
		}else{
			$(field_5).append("<option value='Navodaya times'>Navodaya times</option>");
		}
	}
	if (field_3.value=='PrintMagazines'){
		if(field_4=='PrintMagazines'){
			$(field_4).append("<option value='PrintMagazines' selected='selected'>PrintMagazines</option>");
		}else{
			$(field_4).append("<option value='PrintMagazines'>PrintMagazines</option>");
		}
		if(field_5=='Aapnu Gujarat'){
			$(field_5).append("<option value='Aapnu Gujarat' selected='selected'>Aapnu Gujarat</option>");
		}else{
			$(field_5).append("<option value='Aapnu Gujarat'>Aapnu Gujarat</option>");
		}
		if(field_5=='APAC Boating - India'){
			$(field_5).append("<option value='APAC Boating - India' selected='selected'>APAC Boating - India</option>");
		}else{
			$(field_5).append("<option value='APAC Boating - India'>APAC Boating - India</option>");
		}
		if(field_5=='ASB Year Book'){
			$(field_5).append("<option value='ASB Year Book' selected='selected'>ASB Year Book</option>");
		}else{
			$(field_5).append("<option value='ASB Year Book'>ASB Year Book</option>");
		}
		if(field_5=='Asia SPA - India'){
			$(field_5).append("<option value='Asia SPA - India' selected='selected'>Asia SPA - India</option>");
		}else{
			$(field_5).append("<option value='Asia SPA - India'>Asia SPA - India</option>");
		}
		if(field_5=='Auto Bild'){
			$(field_5).append("<option value='Auto Bild' selected='selected'>Auto Bild</option>");
		}else{
			$(field_5).append("<option value='Auto Bild'>Auto Bild</option>");
		}
		if(field_5=='Auto Bild India'){
			$(field_5).append("<option value='Auto Bild India' selected='selected'>Auto Bild India</option>");
		}else{
			$(field_5).append("<option value='Auto Bild India'>Auto Bild India</option>");
		}
		if(field_5=='Auto Car'){
			$(field_5).append("<option value='Auto Car' selected='selected'>Auto Car</option>");
		}else{
			$(field_5).append("<option value='Auto Car'>Auto Car</option>");
		}
		if(field_5=='Auto India'){
			$(field_5).append("<option value='Auto India' selected='selected'>Auto India</option>");
		}else{
			$(field_5).append("<option value='Auto India'>Auto India</option>");
		}
		if(field_5=='Auto X'){
			$(field_5).append("<option value='Auto X' selected='selected'>Auto X</option>");
		}else{
			$(field_5).append("<option value='Auto X'>Auto X</option>");
		}
		if(field_5=='BBC Good - Food'){
			$(field_5).append("<option value='BBC Good - Food' selected='selected'>BBC Good - Food</option>");
		}else{
			$(field_5).append("<option value='BBC Good - Food'>BBC Good - Food</option>");
		}
		if(field_5=='Black book'){
			$(field_5).append("<option value='Black book' selected='selected'>Black book</option>");
		}else{
			$(field_5).append("<option value='Black book'>Black book</option>");
		}
		if(field_5=='BS motoring'){
			$(field_5).append("<option value='BS motoring' selected='selected'>BS motoring</option>");
		}else{
			$(field_5).append("<option value='BS motoring'>BS motoring</option>");
		}
		if(field_5=='Busi World White Book mkt'){
			$(field_5).append("<option value='Busi World White Book mkt' selected='selected'>Busi World White Book mkt</option>");
		}else{
			$(field_5).append("<option value='Busi World White Book mkt'>Busi World White Book mkt</option>");
		}
		if(field_5=='Car India'){
			$(field_5).append("<option value='Car India' selected='selected'>Car India</option>");
		}else{
			$(field_5).append("<option value='Car India'>Car India</option>");
		}
		if(field_5=='Ceo lifestyle'){
			$(field_5).append("<option value='Ceo lifestyle' selected='selected'>Ceo lifestyle</option>");
		}else{
			$(field_5).append("<option value='Ceo lifestyle'>Ceo lifestyle</option>");
		}
		if(field_5=='Conde nast traveller'){
			$(field_5).append("<option value='Conde nast traveller' selected='selected'>Conde nast traveller</option>");
		}else{
			$(field_5).append("<option value='Conde nast traveller'>Conde nast traveller</option>");
		}
		if(field_5=='Cosmopolitan'){
			$(field_5).append("<option value='Cosmopolitan' selected='selected'>Cosmopolitan</option>");
		}else{
			$(field_5).append("<option value='Cosmopolitan'>Cosmopolitan</option>");
		}
		if(field_5=='Desh- Puja special'){
			$(field_5).append("<option value='Desh- Puja special' selected='selected'>Desh- Puja special</option>");
		}else{
			$(field_5).append("<option value='Desh- Puja special'>Desh- Puja special</option>");
		}
		if(field_5=='Diplomatist'){
			$(field_5).append("<option value='Diplomatist' selected='selected'>Diplomatist</option>");
		}else{
			$(field_5).append("<option value='Diplomatist'>Diplomatist</option>");
		}
		if(field_5=='DLF emporio'){
			$(field_5).append("<option value='DLF emporio' selected='selected'>DLF emporio</option>");
		}else{
			$(field_5).append("<option value='DLF emporio'>DLF emporio</option>");
		}
		if(field_5=='Elle'){
			$(field_5).append("<option value='Elle' selected='selected'>Elle</option>");
		}else{
			$(field_5).append("<option value='Elle'>Elle</option>");
		}
		if(field_5=='Entrepreuner'){
			$(field_5).append("<option value='Entrepreuner' selected='selected'>Entrepreuner</option>");
		}else{
			$(field_5).append("<option value='Entrepreuner'>Entrepreuner</option>");
		}
		if(field_5=='European business group India'){
			$(field_5).append("<option value='European business group India' selected='selected'>European business group India</option>");
		}else{
			$(field_5).append("<option value='European business group India'>European business group India</option>");
		}
		if(field_5=='Femina'){
			$(field_5).append("<option value='Femina' selected='selected'>Femina</option>");
		}else{
			$(field_5).append("<option value='Femina'>Femina</option>");
		}
		if(field_5=='Filmfare'){
			$(field_5).append("<option value='Filmfare' selected='selected'>Filmfare</option>");
		}else{
			$(field_5).append("<option value='Filmfare'>Filmfare</option>");
		}
		if(field_5=='Forbes'){
			$(field_5).append("<option value='Forbes' selected='selected'>Forbes</option>");
		}else{
			$(field_5).append("<option value='Forbes'>Forbes</option>");
		}
		if(field_5=='Forbes India'){
			$(field_5).append("<option value='Forbes India' selected='selected'>Forbes India</option>");
		}else{
			$(field_5).append("<option value='Forbes India'>Forbes India</option>");
		}
		if(field_5=='Forbes Life'){
			$(field_5).append("<option value='Forbes Life' selected='selected'>Forbes Life</option>");
		}else{
			$(field_5).append("<option value='Forbes Life'>Forbes Life</option>");
		}
		if(field_5=='Fortune India'){
			$(field_5).append("<option value='Fortune India' selected='selected'>Fortune India</option>");
		}else{
			$(field_5).append("<option value='Fortune India'>Fortune India</option>");
		}
		if(field_5=='GQ'){
			$(field_5).append("<option value='GQ' selected='selected'>GQ</option>");
		}else{
			$(field_5).append("<option value='GQ'>GQ</option>");
		}
		if(field_5=='Grazia'){
			$(field_5).append("<option value='Grazia' selected='selected'>Grazia</option>");
		}else{
			$(field_5).append("<option value='Grazia'>Grazia</option>");
		}
		if(field_5=='Harvard business review'){
			$(field_5).append("<option value='Harvard business review' selected='selected'>Harvard business review</option>");
		}else{
			$(field_5).append("<option value='Harvard business review'>Harvard business review</option>");
		}
		if(field_5=='Hello'){
			$(field_5).append("<option value='Hello' selected='selected'>Hello</option>");
		}else{
			$(field_5).append("<option value='Hello'>Hello</option>");
		}
		if(field_5=='India Boating'){
			$(field_5).append("<option value='India Boating' selected='selected'>India Boating</option>");
		}else{
			$(field_5).append("<option value='India Boating'>India Boating</option>");
		}
		if(field_5=='India Today'){
			$(field_5).append("<option value='India Today' selected='selected'>India Today</option>");
		}else{
			$(field_5).append("<option value='India Today'>India Today</option>");
		}
		if(field_5=='Jade'){
			$(field_5).append("<option value='Jade' selected='selected'>Jade</option>");
		}else{
			$(field_5).append("<option value='Jade'>Jade</option>");
		}
		if(field_5=='Jazz utsav'){
			$(field_5).append("<option value='Jazz utsav' selected='selected'>Jazz utsav</option>");
		}else{
			$(field_5).append("<option value='Jazz utsav'>Jazz utsav</option>");
		}
		if(field_5=='Jetwings'){
			$(field_5).append("<option value='Jetwings' selected='selected'>Jetwings</option>");
		}else{
			$(field_5).append("<option value='Jetwings'>Jetwings</option>");
		}
		if(field_5=='Lovely planet'){
			$(field_5).append("<option value='Lovely planet' selected='selected'>Lovely planet</option>");
		}else{
			$(field_5).append("<option value='Lovely planet'>Lovely planet</option>");
		}
		if(field_5=='Mans World'){
			$(field_5).append("<option value='Mans World' selected='selected'>Man's World</option>");
		}else{
			$(field_5).append("<option value='Mans World'>Man's World</option>");
		}
		if(field_5=='Mandate'){
			$(field_5).append("<option value='Mandate' selected='selected'>Mandate</option>");
		}else{
			$(field_5).append("<option value='Mandate'>Mandate</option>");
		}
		if(field_5=='Marie Claire'){
			$(field_5).append("<option value='Marie Claire' selected='selected'>Marie Claire</option>");
		}else{
			$(field_5).append("<option value='Marie Claire'>Marie Claire</option>");
		}
		if(field_5=='Marwar'){
			$(field_5).append("<option value='Marwar' selected='selected'>Marwar</option>");
		}else{
			$(field_5).append("<option value='Marwar'>Marwar</option>");
		}
		if(field_5=='Millionaire Asia'){
			$(field_5).append("<option value='Millionaire Asia' selected='selected'>Millionaire Asia</option>");
		}else{
			$(field_5).append("<option value='Millionaire Asia'>Millionaire Asia</option>");
		}
		if(field_5=='Motor Vikatan'){
			$(field_5).append("<option value='Motor Vikatan' selected='selected'>Motor Vikatan</option>");
		}else{
			$(field_5).append("<option value='Motor Vikatan'>Motor Vikatan</option>");
		}
		if(field_5=='National geographic traveller'){
			$(field_5).append("<option value='National geographic traveller' selected='selected'>National geographic traveller</option>");
		}else{
			$(field_5).append("<option value='National geographic traveller'>National geographic traveller</option>");
		}
		if(field_5=='Newsweek'){
			$(field_5).append("<option value='Newsweek' selected='selected'>Newsweek</option>");
		}else{
			$(field_5).append("<option value='Newsweek'>Newsweek</option>");
		}
		if(field_5=='Oberoi Magazine'){
			$(field_5).append("<option value='Oberoi Magazine' selected='selected'>Oberoi Magazine</option>");
		}else{
			$(field_5).append("<option value='Oberoi Magazine'>Oberoi Magazine</option>");
		}
		if(field_5=='Open'){
			$(field_5).append("<option value='Open' selected='selected'>Open</option>");
		}else{
			$(field_5).append("<option value='Open'>Open</option>");
		}
		if(field_5=='Outlook'){
			$(field_5).append("<option value='Outlook' selected='selected'>Outlook</option>");
		}else{
			$(field_5).append("<option value='Outlook'>Outlook</option>");
		}
		if(field_5=='Outlook business'){
			$(field_5).append("<option value='Outlook business' selected='selected'>Outlook business</option>");
		}else{
			$(field_5).append("<option value='Outlook business'>Outlook business</option>");
		}
		if(field_5=='Outlook traveller'){
			$(field_5).append("<option value='Outlook traveller' selected='selected'>Outlook traveller</option>");
		}else{
			$(field_5).append("<option value='Outlook traveller'>Outlook traveller</option>");
		}
		if(field_5=='Overdrive'){
			$(field_5).append("<option value='Overdrive' selected='selected'>Overdrive</option>");
		}else{
			$(field_5).append("<option value='Overdrive'>Overdrive</option>");
		}
		if(field_5=='Overdrive - Hindi'){
			$(field_5).append("<option value='Overdrive - Hindi' selected='selected'>Overdrive - Hindi</option>");
		}else{
			$(field_5).append("<option value='Overdrive - Hindi'>Overdrive - Hindi</option>");
		}
		if(field_5=='People'){
			$(field_5).append("<option value='People' selected='selected'>People</option>");
		}else{
			$(field_5).append("<option value='People'>People</option>");
		}
		if(field_5=='Robbar'){
			$(field_5).append("<option value='Robbar' selected='selected'>Robbar</option>");
		}else{
			$(field_5).append("<option value='Robbar'>Robbar</option>");
		}
		if(field_5=='Society'){
			$(field_5).append("<option value='Society' selected='selected'>Society</option>");
		}else{
			$(field_5).append("<option value='Society'>Society</option>");
		}
		if(field_5=='Sports illustrated'){
			$(field_5).append("<option value='Sports illustrated' selected='selected'>Sports illustrated</option>");
		}else{
			$(field_5).append("<option value='Sports illustrated'>Sports illustrated</option>");
		}
		if(field_5=='Stuff'){
			$(field_5).append("<option value='Stuff' selected='selected'>Stuff</option>");
		}else{
			$(field_5).append("<option value='Stuff'>Stuff</option>");
		}
		if(field_5=='T3'){
			$(field_5).append("<option value='T3' selected='selected'>T3</option>");
		}else{
			$(field_5).append("<option value='T3'>T3</option>");
		}
		if(field_5=='Tehelka'){
			$(field_5).append("<option value='Tehelka' selected='selected'>Tehelka</option>");
		}else{
			$(field_5).append("<option value='Tehelka'>Tehelka</option>");
		}
		if(field_5=='The Economist'){
			$(field_5).append("<option value='The Economist' selected='selected'>The Economist</option>");
		}else{
			$(field_5).append("<option value='The Economist'>The Economist</option>");
		}
		if(field_5=='The Leela Magazine'){
			$(field_5).append("<option value='The Leela Magazine' selected='selected'>The Leela Magazine</option>");
		}else{
			$(field_5).append("<option value='The Leela Magazine'>The Leela Magazine</option>");
		}
		if(field_5=='The Taj - Coffee Table book'){
			$(field_5).append("<option value='The Taj - Coffee Table book' selected='selected'>The Taj - Coffee Table book</option>");
		}else{
			$(field_5).append("<option value='The Taj - Coffee Table book'>The Taj - Coffee Table book</option>");
		}
		if(field_5=='The Week'){
			$(field_5).append("<option value='The Week' selected='selected'>The Week</option>");
		}else{
			$(field_5).append("<option value='The Week'>The Week</option>");
		}
		if(field_5=='Time'){
			$(field_5).append("<option value='Time' selected='selected'>Time</option>");
		}else{
			$(field_5).append("<option value='Time'>Time</option>");
		}
		if(field_5=='Top Gear'){
			$(field_5).append("<option value='Top Gear' selected='selected'>Top Gear</option>");
		}else{
			$(field_5).append("<option value='Top Gear'>Top Gear</option>");
		}
		if(field_5=='Travel & Leisure'){
			$(field_5).append("<option value='Travel & Leisure' selected='selected'>Travel & Leisure</option>");
		}else{
			$(field_5).append("<option value='Travel & Leisure'>Travel & Leisure</option>");
		}
		if(field_5=='Verve'){
			$(field_5).append("<option value='Verve' selected='selected'>Verve</option>");
		}else{
			$(field_5).append("<option value='Verve'>Verve</option>");
		}
		if(field_5=='Vogue'){
			$(field_5).append("<option value='Vogue' selected='selected'>Vogue</option>");
		}else{
			$(field_5).append("<option value='Vogue'>Vogue</option>");
		}
		if(field_5=='What Car'){
			$(field_5).append("<option value='What Car' selected='selected'>What Car</option>");
		}else{
			$(field_5).append("<option value='What Car'>What Car</option>");
		}
		if(field_5=='Zigwheels'){
			$(field_5).append("<option value='Zigwheels' selected='selected'>Zigwheels</option>");
		}else{
			$(field_5).append("<option value='Zigwheels'>Zigwheels</option>");
		}
	}
	if (field_3.value=='Sponsorship'){
		if(field_4=='Sponsorship'){
			$(field_4).append("<option value='Sponsorship' selected='selected'>Sponsorship</option>");
		}else{
			$(field_4).append("<option value='Sponsorship'>Sponsorship</option>");
		}
	}
	if (field_3.value=='Cold calling'){
		if(field_4=='Cold calling'){
			$(field_4).append("<option value='Cold calling' selected='selected'>Cold calling</option>");
		}else{
			$(field_4).append("<option value='Cold calling'>Cold calling</option>");
		}
	}
	if (field_3.value=='Other'){
		if(field_4=='Other'){
			$(field_4).append("<option value='Other' selected='selected'>Other</option>");
		}else{
			$(field_4).append("<option value='Other'>Other</option>");
		}
	}
	
	
	if(selected !='') $(field_4).val(selected);
	if(selectedpub !='') $(field_5).val(selectedpub);
}

function load_models(field_11,field_10,selected){
	$(field_11).empty();
	if (field_10.value=='Yes'){
		if(field_11=='A range'){
			$(field_11).append("<option value='A range' selected='selected'>A range</option>");
		}else{
			$(field_11).append("<option value='A range'>A range</option>");
		}
		if(field_11=='Q range'){
			$(field_11).append("<option value='Q range' selected='selected'>Q range</option>");
		}else{
			$(field_11).append("<option value='Q range'>Q range</option>");
		}
		if(field_11=='Sports car'){
			$(field_11).append("<option value='Sports car' selected='selected'>Sports car</option>");
		}else{
			$(field_11).append("<option value='Sports car'>Sports car</option>");
		}
		if(field_11=='A4'){
			$(field_11).append("<option value='A4' selected='selected'>A4</option>");
		}else{
			$(field_11).append("<option value='A4'>A4</option>");
		}
		if(field_11=='A6'){
			$(field_11).append("<option value='A6' selected='selected'>A6</option>");
		}else{
			$(field_11).append("<option value='A6'>A6</option>");
		}
		if(field_11=='A7'){
			$(field_11).append("<option value='A7' selected='selected'>A7</option>");
		}else{
			$(field_11).append("<option value='A7'>A7</option>");
		}
		if(field_11=='A8L'){
			$(field_11).append("<option value='A8L' selected='selected'>A8L</option>");
		}else{
			$(field_11).append("<option value='A8L'>A8L</option>");
		}
		if(field_11=='Q5'){
			$(field_11).append("<option value='Q5' selected='selected'>Q5</option>");
		}else{
			$(field_11).append("<option value='Q5'>Q5</option>");
		}
		if(field_11=='TT'){
			$(field_11).append("<option value='TT' selected='selected'>TT</option>");
		}else{
			$(field_11).append("<option value='TT'>TT</option>");
		}
		if(field_11=='R8'){
			$(field_11).append("<option value='R8' selected='selected'>R8</option>");
		}else{
			$(field_11).append("<option value='R8'>R8</option>");
		}
		if(field_11=='RS5'){
			$(field_11).append("<option value='RS5' selected='selected'>RS5</option>");
		}else{
			$(field_11).append("<option value='RS5'>RS5</option>");
		}
		if(field_11=='Q3'){
			$(field_11).append("<option value='Q3' selected='selected'>Q3</option>");
		}else{
			$(field_11).append("<option value='Q3'>Q3</option>");
		}
		if(field_11=='Q7'){
			$(field_11).append("<option value='Q7' selected='selected'>Q7</option>");
		}else{
			$(field_11).append("<option value='Q7'>Q7</option>");
		}
		if(field_11=='S4'){
			$(field_11).append("<option value='S4' selected='selected'>S4</option>");
		}else{
			$(field_11).append("<option value='S4'>S4</option>");
		}
		if(field_11=='S5'){
			$(field_11).append("<option value='S5' selected='selected'>S5</option>");
		}else{
			$(field_11).append("<option value='S5'>S5</option>");
		}
		if(field_11=='RS6'){
			$(field_11).append("<option value='RS6' selected='selected'>RS6</option>");
		}else{
			$(field_11).append("<option value='RS6'>RS6</option>");
		}
		if(field_11=='A3'){
			$(field_11).append("<option value='A3' selected='selected'>A3</option>");
		}else{
			$(field_11).append("<option value='A3'>A3</option>");
		}
	}
	if(selected !='') $(field_11).val(selected);
}

function load_states(field_6,selected){
	$(field_6).empty();
	$(field_6).append("<option value=''>--Select--</option>");
	$(field_6).append("<option value='Delhi-Ncr'>Delhi-Ncr</option>");
	$(field_6).append("<option value='Uttar Pradesh'>Uttar Pradesh</option>");
	
	if(selected !='') $(field_6).val(selected);
}

function load_cities(field_7,field_6,selected){
	console.log(selected);
	$(field_7).empty();
	if (field_6.value=='Delhi-Ncr'){
		if(field_7=='Delhi'){
			$(field_7).append("<option value='Delhi' selected='selected'>Delhi</option>");
		}else{
			$(field_7).append("<option value='Delhi'>Delhi</option>");
		}
		if(field_7=='Greater Noida'){
			$(field_7).append("<option value='Greater Noida' selected='selected'>Greater Noida</option>");
		}else{
			$(field_7).append("<option value='Greater Noida'>Greater Noida</option>");
		}
		if(field_7=='Faridabad'){
			$(field_7).append("<option value='Faridabad' selected='selected'>Faridabad</option>");
		}else{
			$(field_7).append("<option value='Faridabad'>Faridabad</option>");
		}
		if(field_7=='Ghaziabad'){
			$(field_7).append("<option value='Ghaziabad' selected='selected'>Ghaziabad</option>");
		}else{
			$(field_7).append("<option value='Ghaziabad'>Ghaziabad</option>");
		}
		if(field_7=='Noida'){
			$(field_7).append("<option value='Noida' selected='selected'>Noida</option>");
		}else{
			$(field_7).append("<option value='Noida'>Noida</option>");
		} 
		if(field_7=='Gurgaon'){
			$(field_7).append("<option value='Gurgaon' selected='selected'>Gurgaon</option>");
		}else{
			$(field_7).append("<option value='Gurgaon'>Gurgaon</option>");
		}
	}
	if (field_6.value=='Uttar Pradesh'){
		if(field_7=='Aligarh'){
			$(field_7).append("<option value='Aligarh' selected='selected'>Aligarh</option>");
		}else{
			$(field_7).append("<option value='Aligarh'>Aligarh</option>");
		}
		if(field_7=='Moradabad'){
			$(field_7).append("<option value='Moradabad' selected='selected'>Moradabad</option>");
		}else{
			$(field_7).append("<option value='Moradabad'>Moradabad</option>");
		}
	}
	
	if(selected) {
	//alert(selected);
		var obj = jQuery.parseJSON(selected);
		$.each(obj, function(i, item) {
			$("#field_7 option[value='" + item + "']").attr("selected", 1);
		});
	}
}

function load_lsource(lSource){
	$(lSource).empty();
	$(lSource).append("<option value=''>--Select--</option>");
	$(lSource).append("<option value='DirectMarketing'>DirectMarketing</option>");
	$(lSource).append("<option value='Events'>Events</option>");
	$(lSource).append("<option value='OnlineMarketing'>OnlineMarketing</option>");
	$(lSource).append("<option value='Other'>Others</option>");
}

function load_subSource(sSource,lSource){
	$(sSource).empty();
	if (lSource.value=='DirectMarketing'){
		if(sSource=='Database Marketing'){
			$(sSource).append("<option value='Database Marketing' selected='selected'>Database Marketing</option>");
		}else{
			$(sSource).append("<option value='Database Marketing'>Database Marketing</option>");
		}
		if(sSource=='DM'){
			$(sSource).append("<option value='DM' selected='selected'>DM</option>");
		}else{
			$(sSource).append("<option value='DM'>DM</option>");
		}
		if(sSource=='Just Dial'){
			$(sSource).append("<option value='Just Dial' selected='selected'>Just Dial</option>");
		}else{
			$(sSource).append("<option value='Just Dial'>Just Dial</option>");
		}
		if(sSource=='SMS Blast'){
			$(sSource).append("<option value='SMS Blast' selected='selected'>SMS Blast</option>");
		}else{
			$(sSource).append("<option value='SMS Blast'>SMS Blast</option>");
		}
		if(sSource=='Sulekha'){
			$(sSource).append("<option value='Sulekha' selected='selected'>Sulekha</option>");
		}else{
			$(sSource).append("<option value='Sulekha'>Sulekha</option>");
		}
		if(sSource=='News letters'){
			$(sSource).append("<option value='News letters' selected='selected'>News letters</option>");
		}else{
			$(sSource).append("<option value='News letters'>News letters</option>");
		}
		if(sSource=='Other'){
			$(sSource).append("<option value='Other' selected='selected'>Other</option>");
		}else{
			$(sSource).append("<option value='Other'>Other</option>");
		}
	}
	if (lSource.value=='Events'){
		/*if(sSource=='Events'){
			$(sSource).append("<option value='Events' selected='selected'>Events</option>");
		}else{
			$(sSource).append("<option value='Events'>Events</option>");
		}*/
		if(sSource=='Auto Expo'){
			$(sSource).append("<option value='Auto Expo' selected='selected'>Auto Expo</option>");
		}else{
			$(sSource).append("<option value='Auto Expo'>Auto Expo</option>");
		}
		if(sSource=='Customer Meet'){
			$(sSource).append("<option value='Customer Meet' selected='selected'>Customer Meet</option>");
		}else{
			$(sSource).append("<option value='Customer Meet'>Customer Meet</option>");
		}
		if(sSource=='Dealership Opening'){
			$(sSource).append("<option value='Dealership Opening' selected='selected'>Dealership Opening</option>");
		}else{
			$(sSource).append("<option value='Dealership Opening'>Dealership Opening</option>");
		}
		if(sSource=='Mall Activation'){
			$(sSource).append("<option value='Mall Activation' selected='selected'>Mall Activation</option>");
		}else{
			$(sSource).append("<option value='Mall Activation'>Mall Activation</option>");
		}
		if(sSource=='Open House'){
			$(sSource).append("<option value='Open House' selected='selected'>Open House</option>");
		}else{
			$(sSource).append("<option value='Open House'>Open House</option>");
		}
		if(sSource=='Product Launch'){
			$(sSource).append("<option value='Product Launch' selected='selected'>Product Launch</option>");
		}else{
			$(sSource).append("<option value='Product Launch'>Product Launch</option>");
		}
		if(sSource=='Quattro Cup'){
			$(sSource).append("<option value='Quattro Cup' selected='selected'>Quattro Cup</option>");
		}else{
			$(sSource).append("<option value='Quattro Cup'>Quattro Cup</option>");
		}
		if(sSource=='Road Show'){
			$(sSource).append("<option value='Road Show' selected='selected'>Road Show</option>");
		}else{
			$(sSource).append("<option value='Road Show'>Road Show</option>");
		}
		if(sSource=='BDE'){
			$(sSource).append("<option value='BDE' selected='selected'>BDE</option>");
		}else{
			$(sSource).append("<option value='BDE'>BDE</option>");
		}
		if(sSource=='RWA'){
			$(sSource).append("<option value='RWA' selected='selected'>RWA</option>");
		}else{
			$(sSource).append("<option value='RWA'>RWA</option>");
		}
		if(sSource=='Bank event'){
			$(sSource).append("<option value='Bank event' selected='selected'>Bank event</option>");
		}else{
			$(sSource).append("<option value='Bank event'>Bank event</option>");
		}
		if(sSource=='Club'){
			$(sSource).append("<option value='Club' selected='selected'>Club</option>");
		}else{
			$(sSource).append("<option value='Club'>Club</option>");
		}
		if(sSource=='Other'){
			$(sSource).append("<option value='Other' selected='selected'>Other</option>");
		}else{
			$(sSource).append("<option value='Other'>Other</option>");
		}
	}
	if (lSource.value=='OnlineMarketing'){
		if(sSource=='Banner'){
			$(sSource).append("<option value='Banner' selected='selected'>Banner</option>");
		}else{
			$(sSource).append("<option value='Banner'>Banner</option>");
		}
		if(sSource=='Cardekho'){
			$(sSource).append("<option value='Cardekho' selected='selected'>Cardekho</option>");
		}else{
			$(sSource).append("<option value='Cardekho'>Cardekho</option>");
		}
		if(sSource=='Car Wale'){
			$(sSource).append("<option value='Car Wale' selected='selected'>Car Wale</option>");
		}else{
			$(sSource).append("<option value='Car Wale'>Car Wale</option>");
		}
		if(sSource=='EDM'){
			$(sSource).append("<option value='EDM' selected='selected'>EDM</option>");
		}else{
			$(sSource).append("<option value='EDM'>EDM</option>");
		}
		if(sSource=='FB'){
			$(sSource).append("<option value='FB' selected='selected'>FB</option>");
		}else{
			$(sSource).append("<option value='FB'>FB</option>");
		}
		if(sSource=='Linkedin'){
			$(sSource).append("<option value='Linkedin' selected='selected'>Linkedin</option>");
		}else{
			$(sSource).append("<option value='Linkedin'>Linkedin</option>");
		}
		if(sSource=='Mobile Marketing'){
			$(sSource).append("<option value='Mobile Marketing' selected='selected'>Mobile Marketing</option>");
		}else{
			$(sSource).append("<option value='Mobile Marketing'>Mobile Marketing</option>");
		}
		if(sSource=='SEM'){
			$(sSource).append("<option value='SEM' selected='selected'>SEM</option>");
		}else{
			$(sSource).append("<option value='SEM'>SEM</option>");
		}
		if(sSource=='SEO'){
			$(sSource).append("<option value='SEO' selected='selected'>SEO</option>");
		}else{
			$(sSource).append("<option value='SEO'>SEO</option>");
		}
		if(sSource=='Twitter'){
			$(sSource).append("<option value='Twitter' selected='selected'>Twitter</option>");
		}else{
			$(sSource).append("<option value='Twitter'>Twitter</option>");
		}
		if(sSource=='Quikr'){
			$(sSource).append("<option value='Quikr' selected='selected'>Quikr</option>");
		}else{
			$(sSource).append("<option value='Quikr'>Quikr</option>");
		}
		if(sSource=='Auto portal'){
			$(sSource).append("<option value='Auto portal' selected='selected'>Auto portal</option>");
		}else{
			$(sSource).append("<option value='Auto portal'>Auto portal</option>");
		}
		if(sSource=='Other'){
			$(sSource).append("<option value='Other' selected='selected'>Other</option>");
		}else{
			$(sSource).append("<option value='Other'>Other</option>");
		}
	}
	if (lSource.value=='Others'){
		if(sSource=='Print Dailies'){
			$(sSource).append("<option value='Print Dailies' selected='selected'>Print Dailies</option>");
		}else{
			$(sSource).append("<option value='Print Dailies'>Print Dailies</option>");
		}
		if(sSource=='PrintMagazines'){
			$(sSource).append("<option value='PrintMagazines' selected='selected'>PrintMagazines</option>");
		}else{
			$(sSource).append("<option value='PrintMagazines'>PrintMagazines</option>");
		}
		if(sSource=='Sponsorship'){
			$(sSource).append("<option value='Sponsorship' selected='selected'>Sponsorship</option>");
		}else{
			$(sSource).append("<option value='Sponsorship'>Sponsorship</option>");
		}
		if(sSource=='Cold calling'){
			$(sSource).append("<option value='Cold calling' selected='selected'>Cold calling</option>");
		}else{
			$(sSource).append("<option value='Cold calling'>Cold calling</option>");
		}
		if(sSource=='walkin'){
			$(sSource).append("<option value='walkin' selected='selected'>walkin</option>");
		}else{
			$(sSource).append("<option value='walkin'>walkin</option>");
		}
		if(sSource=='Tele in'){
			$(sSource).append("<option value='Tele in' selected='selected'>Tele in</option>");
		}else{
			$(sSource).append("<option value='Tele in'>Tele in</option>");
		}
	}
}
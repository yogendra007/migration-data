/*
 Custom Javascript/Jquery code
 */

jQuery(document).ready(function() {
	
	//jQuery("#lgn_frm").show();
		//jQuery(".forgot-pwd").click(function() {
/*	jQuery(document).on('click','.forgot-pwd',function(){
		jQuery(".login_form").slideToggle();
	});
*/
	jQuery("#agencyUser").click(function() {
		jQuery("#hideClientList").hide();
	});

	jQuery("#clientUser").click(function() {
		jQuery("#hideClientList").show();
	});

	jQuery( "#clientSelectList" ).change(function() {
		var clientId = this.value;
		jQuery.ajax({
			url: "/user/get-User-By-Client-List",
			type: "post",
			dataType: "html",
			data: "clientId="+clientId,
			success: function(data){
				data = jQuery.parseJSON(data);
				html = '';
				if(data.error == 0){
					//$.each(data.data,function
					jQuery.each(data.data, function(index){

					html = html + '<tr class="odd gradeX">';
					 	html = html + '<td>'+ this.user_name + '</td>';
					 	html = html + '<td>'+ this.user_email + '</td>';
					 	html = html + '<td>'+ this.role_name + '</td>';
					 	html = html + '<td>'+ this.user_name + '</td>';
						html = html + '<td>';
							html = html + '<div class="col-sm-3">';
								html = html + '<div class="make-switch" data-on-label="<i class=entypo-check></i>" data-off-label="<i class=entypo-cancel></i>" data-text-label="<i class=entypo-user icon-bck-colr></i>">';
								html = html + '<input type="checkbox" checked />';
								html = html + '</div>';
							html = html + '</div>';
						html = html + '</td>';
							html = html + '<td class="center">';
								html = html + '<a class="btn btn-default btn-sm btn-icon1 icon-left1 globalBtn" data-toggle="tooltip" data-placement="top" title="Edit User" href="javascript:;" onClick="jQuery("#modal-1").modal("show", {backdrop: "static"});">';
								html = html + '<i class="entypo-user"></i>	<i class="entypo-pencil"></i>';					
								html = html + '</a>';	
								html = html + '<a class="btn btn-info btn-sm btn-icon1 icon-left1" data-toggle="tooltip" data-placement="top" title="Add Associates" href="javascript:;" onClick="jQuery("#modal-2").modal("show", {backdrop: "static"});">';
								html = html + '<i class="entypo-user-add"></i>';
								html = html + '</a>';
						html = html + '</td>';
					html = html + '</tr>';

					});

				} else {
					html = html + '<tr class="odd gradeX"><td>Data Is Empty</td></tr>';
				}
				


				jQuery(".clientListData").empty();
				jQuery(".clientListData").html(html);
			}	
		});
	});



	jQuery(document).on('focusout','.userEmail',function(){
		//console.log(jQuery(this).val());
		var userName = jQuery(this).val();
		var thisIs = jQuery(this);
			if(userName==""){
				jQuery(".userNameCheck").text("");
				return false;
			}
		jQuery.ajax({
			url: "/user/get-Check-User",
			type: "post",
			data: {user_name:userName},
			success: function(data){
				data = jQuery.parseJSON(data);
				if(data.error == 0){
					jQuery(".userNameCheck").html('User Email Already Exist! ').css('color','#cc2424');
					jQuery(".userSubmitbut").prop('disabled', true);
					jQuery(".userSubmitbut").addClass("btn-default").removeClass("btn-success");
					setTimeout(function(){ jQuery(".userNameCheck").text(""); }, 5000);
					return false;
				} else if(data.error == 1) {
					jQuery(".userNameCheck").html('User Email is Avilable! ').css('color','green');
					jQuery(".userSubmitbut").prop('disabled', false);
					jQuery(".userSubmitbut").addClass("btn-success").removeClass("btn-default");
					setTimeout(function(){ jQuery(".userNameCheck").text(""); }, 5000);
				}

			}
		});

	});


// campaign list 

	// jQuery( "#clientSelectForCampaign" ).change(function() {

	// 	var clientId = this.value;
	// 	jQuery.ajax({
	// 		url: "/Campaign/get-Campaign-By-Client-List",
	// 		type: "post",
	// 		dataType: "html",
	// 		data: "clientId="+clientId,
	// 		success: function(data){
	// 			console.log(data);
	// 			data = jQuery.parseJSON(data);
				
	// 			html = '';
	// 			if(data.error == '0'){
	// 				//$.each(data.data,function
	// 				jQuery.each(data.data, function(index){

	// 				html = html + '<tr class="odd gradeX">';
	// 				 	html = html + '<td>'+ this.business_unit_name + '</td>';
					 	
	// 					html = html + '<td>';
	// 						html = html + '<div class="col-sm-3">';
	// 							html = html + '<div class="make-switch" data-on-label="<i class=entypo-check></i>" data-off-label="<i class=entypo-cancel></i>" data-text-label="<i class=entypo-user icon-bck-colr></i>">';
	// 							html = html + '<input type="checkbox" checked />';
	// 							html = html + '</div>';
	// 						html = html + '</div>';
	// 					html = html + '</td>';
	// 						html = html + '<td class="center">';
	// 							html = html + '<a class="btn btn-default btn-sm btn-icon1 icon-left1 globalBtn" data-toggle="tooltip" data-placement="top" title="Edit User" href="javascript:;" onClick="jQuery("#modal-1").modal("show", {backdrop: "static"});">';
	// 							html = html + '<i class="entypo-user"></i>	<i class="entypo-pencil"></i>';					
	// 							html = html + '</a>';	
	// 							html = html + '<a class="btn btn-info btn-sm btn-icon1 icon-left1" data-toggle="tooltip" data-placement="top" title="Add Associates" href="javascript:;" onClick="jQuery("#modal-2").modal("show", {backdrop: "static"});">';
	// 							html = html + '<i class="entypo-user-add"></i>';
	// 							html = html + '</a>';
	// 					html = html + '</td>';
	// 				html = html + '</tr>';

	// 				});

	// 			} else {
	// 				html = html + '<tr class="odd gradeX"><td>Data Is Empty</td></tr>';
	// 			}
				


	// 			jQuery(".clientListData").empty();
	// 			jQuery(".clientListData").html(html);
	// 		}	
	// 	});
	// });


});
function writeUserDetailHidden(userId, agencyId, clientId, departId, userRole)
{
	jQuery("#asctClientId").attr("value", clientId);
	jQuery("#asctAgencyId").attr("value", agencyId);
	jQuery("#asctUserId").attr("value", userId);
	jQuery("#asctDepartmentId").attr("value", departId);
	jQuery("#asctUserRole").attr("value", userRole);
	jQuery('#modal-2').modal('show', {backdrop: 'static'}); 
	
	}
function editClientById(clientId)
{
	 var clientId  = clientId;
	 alert(clientId);
       jQuery.ajax({
            url: "/client/get-client-detail-by-id",
            type: "post",
            dataType: "html",
            data: "ClientId="+clientId,
            success: function(data){
                jQuery("#projectlist").html(data);
            }
        });
}
				


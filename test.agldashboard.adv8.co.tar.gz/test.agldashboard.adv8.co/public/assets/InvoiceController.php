<?php
//error_reporting("1");
//ini_set('display_errors', 1);
require_once 'Zend/Auth.php';
require_once 'Zend/Auth/Adapter/DbTable.php';
require_once 'application/models/Common.php';
require_once 'application/models/wkhtml.class.php';

class InvoiceController extends Zend_Controller_Action {

    public function init() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->view->controller = $this->getRequest()->getControllerName();
        if ($ns->USER_ID == '') {
            $this->_redirect("/Login/ulogin");
        }
    }


    public function indexAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        $Id = $this->view->Id = $ns->USER_ID;
        $role = $ns->ROLE;
        $userId = $ns->USER_ID;
        if (!$userId) {
            $this->_redirect('Login/index');
        } else {
            if ($role == '1' || $role == '3' || $role == '13' || $role == '4') {
                $this->_redirect('Invoice/super');
            } else {
                $this->_redirect('Invoice/cm');
            }
        }
    }

    public function superAction() {

        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('invoice_list');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;


        $userNameFromEmail = substr($userName, 0, strpos($userName, '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $this->view->userName = $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);



        /**
         * Call Invoice Functions
         */
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-List-By-Client/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
	
        $invoices = json_decode($Common->cUrlCall($cClient));

        //$this->view->invoices = $invoices;

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Client-Name-By-Role-Idand-User-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $responseClient = json_decode($Common->cUrlCall($cClient));
        $this->view->clientDataMappingWithUser = $responseClient;


		$page = $this->_getParam('page', 1);
        $paginator = Zend_Paginator::factory($invoices);
        $paginator->setItemCountPerPage(12);
        $paginator->setCurrentPageNumber($page);
        $this->view->invoices = $paginator;

    }


	public function gethtmldataAction() {
        $I = $this->_request->getparam('I');
        $S = $this->_request->getparam('s');

        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('invoice_list');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $Id = $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;


        $userNameFromEmail = substr($userName, 0, strpos($userName, '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $this->view->userName = $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);



        if ($S == 'c') {

            $cC = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-List-Client-Serach-C/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/Id/'.$Id.'/I/'.$I;
            $invoices = json_decode($Common->cUrlCall($cC),true);
        } elseif ($S == 's') {

            $cS = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-List-Client-Serach-S/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId. '/Id/'.$Id.'/I/'.$I;
            $invoices = json_decode($Common->cUrlCall($cS),true);

          } elseif ($S == 'd') {
        }




        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Client-Name-By-Role-Idand-User-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $ClientDataMappingWithUser = json_decode($Common->cUrlCall($cClient),true);



        $this->view->action = $action = $this->getRequest()->getActionName();
        $this->view->ClientDataMappingWithUser = $ClientDataMappingWithUser;

        $htmlTPL = '';
        $htmlTPL .= '<table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr class="first">
                          <td width="20%" align="center"><strong>Client Name</strong></td>
                          <td width="10%" align="center"><strong>User Name</strong></td>
                          <td width="11%" align="center"><strong>Invoice Amount&nbsp;(INR)</strong></td>
                          <td width="14%" align="center"><strong>Created Date</strong></td>
                          <td width="12%" align="center"><strong>Invoice Number</strong></td>
                          <td width="8%" align="center"><strong>Invoice Status</strong></td>
                          <td width="13%" class="last" align="center"><strong>Action</strong></td>
                        </tr>';

        if (@$invoices['CODE'] != 'C-103') {
            for ($In = 0; $In < count($invoices); $In++) {
                $htmlTPL .= '<tr>
                                <td>' . $invoices[$In]['COMPANY_NAME'] . '</td>
                                <td align="center">' . $invoices[$In]['USER_NAME'] . '</td>
                                <td align="center">&#8377; &nbsp;' . $invoices[$In]['AMOUNT']. '</td>
                                <td align="center">' . date('jS F Y', strtotime($invoices[$In]['CREATED_AT'])) . '</td>
                                <td align="center">' . $invoices[$In]['PROFORMA_INVOICE_ID'] . '</td>
                                <td align="center">' . $invoices[$In]['INVOICE_STATUS_WORD'] . '</td>
                                <td class="last" align="center">';

                if ($invoices[$In]['INVOICE_STATUS'] == '0') {
                    $pai = 'Please approve it';
                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/edit/qs/' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '"><img src="' . IMAGE_PATH . 'edit_icon.gif" title="Edit Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="javascript:void(0);" onClick="alert(' . $pai . ');" class="pdficon"></a><img src="' . IMAGE_PATH . 'pdf_icon.gif" title="Edit Invoice" /></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="javascript:void(0);" onClick="alert(' . $pai . ');" class="payicon"><img src="' . IMAGE_PATH . 'pay.gif" title="Payment Request" /></a></div>';
                }



                if ($invoices[$In]['INVOICE_STATUS'] == '1' || $invoices[$In]['INVOICE_STATUS'] == '5' || $invoices[$In]['INVOICE_STATUS'] == '3' || $invoices[$In]['INVOICE_STATUS'] == '4') {

                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/edit/qs/' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '"><img src="' . IMAGE_PATH . 'edit_icon.gif" title="Edit Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/preview/qs/' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '/sP/' . $invoices[$In]['INVOICE_STATUS'] . '"><img src="' . IMAGE_PATH . 'pdf_icon.gif" title="Pdf Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/action/payreq/qs' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '"><img  src="' . IMAGE_PATH . 'pay.gif" title="Payment Request" /></a></div>';
                }




                if ($invoices[$In]['INVOICE_STATUS'] == '2') {
                    $ap = 'Already Paid';
                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/edit/qs/' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '"><img src="' . IMAGE_PATH . 'edit_icon.gif" title="Edit Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="javascript:void(0);" onClick="alert(' . $ap . ');"><img src="' . IMAGE_PATH . 'pdf_icon.gif" title="Edit Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="javascript:void(0);" onClick="alert(' . $ap . ');"><img src="' . IMAGE_PATH . 'pay.gif" title="Payment Request" /></a></div>';
                }
                $htmlTPL .= '
				<div class="action_icons"><a href="/Invoice/ledgerlist/qs/'.$invoices[$In]['cId'].'/I/'.$invoices[$In]['ID'].'"><img src="' . IMAGE_PATH . 'payment_icon.gif" title="Payment Invoice" /></a></div>
                <div class="action_icons"><a href="/Invoice/delete/qs' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '" ><img src="' . IMAGE_PATH . 'delete_icon.gif" title="Delete Invoice" /></a></div>
						 </td>
						 </tr>';
            }
        } else {
            $htmlTPL .= '<tr>
                        <td align="center" colspan="8">No Invoice with that search</td>
                </tr>';
        }
        $htmlTPL .= '</table>';

        echo $htmlTPL;






        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }



    public function gethtmldatacustomeAction() {
        $valueSelected = $this->_request->getparam('valueSelected');
        $fromDate = strtotime($this->_request->getparam('fromDate'));
        $toDate = strtotime($this->_request->getparam('toDate'));
        $ststus = $this->_request->getparam('ststus');
        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('invoice_list');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $Id = $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;


        $userNameFromEmail = substr($userName, 0, strpos($userName, '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $this->view->userName = $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);

        $cS = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-List-Client-Serach-Custome/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId. '/Id/'.$Id.'/valueSelected/'.$valueSelected.'/fromDate/'.$fromDate.'/toDate/'.$toDate.'/ststus/'.$ststus;
        $invoices = json_decode($Common->cUrlCall($cS),true);



        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Client-Name-By-Role-Idand-User-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $ClientDataMappingWithUser = json_decode($Common->cUrlCall($cClient),true);



        $this->view->action = $action = $this->getRequest()->getActionName();
        $this->view->ClientDataMappingWithUser = $ClientDataMappingWithUser;

        $htmlTPL = '';
        $htmlTPL .= '<table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr class="first">
                          <td width="20%" align="center"><strong>Client Name</strong></td>
                          <td width="10%" align="center"><strong>User Name</strong></td>
                          <td width="11%" align="center"><strong>Invoice Amount&nbsp;(INR)</strong></td>
                          <td width="14%" align="center"><strong>Created Date</strong></td>
                          <td width="12%" align="center"><strong>Invoice Number</strong></td>
                          <td width="8%" align="center"><strong>Invoice Status</strong></td>
                          <td width="15%" class="last" align="center"><strong>Action</strong></td>
                        </tr>';

        if (@$invoices['CODE'] != 'C-103') {
            for ($In = 0; $In < count($invoices); $In++) {
                $htmlTPL .= '<tr>
                                <td>' . $invoices[$In]['COMPANY_NAME'] . '</td>
                                <td align="center">' . $invoices[$In]['USER_NAME'] . '</td>
                                <td align="center">&#8377; &nbsp;' . $invoices[$In]['AMOUNT']. '</td>
                                <td align="center">' . date('jS F Y', strtotime($invoices[$In]['CREATED_AT'])) . '</td>
                                <td align="center">' . $invoices[$In]['PROFORMA_INVOICE_ID'] . '</td>
                                <td align="center">' . $invoices[$In]['INVOICE_STATUS_WORD'] . '</td>
                                <td class="last" align="center">';

                if ($invoices[$In]['INVOICE_STATUS'] == '0') {
                    $pai = 'Please approve it';
                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/edit/qs/' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '"><img src="' . IMAGE_PATH . 'edit_icon.gif" title="Edit Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="javascript:void(0);" onClick="alert(' . $pai . ');" class="pdficon"></a><img src="' . IMAGE_PATH . 'pdf_icon.gif" title="Edit Invoice" /></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="javascript:void(0);" onClick="alert(' . $pai . ');" class="payicon"><img src="' . IMAGE_PATH . 'pay.gif" title="Payment Request" /></a></div>';
                }



                if ($invoices[$In]['INVOICE_STATUS'] == '1' || $invoices[$In]['INVOICE_STATUS'] == '5' || $invoices[$In]['INVOICE_STATUS'] == '3' || $invoices[$In]['INVOICE_STATUS'] == '4') {

                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/edit/qs/' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '"><img src="' . IMAGE_PATH . 'edit_icon.gif" title="Edit Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/preview/qs/' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '/sP/' . $invoices[$In]['INVOICE_STATUS'] . '"><img src="' . IMAGE_PATH . 'pdf_icon.gif" title="Pdf Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/action/payreq/qs' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '"><img  src="' . IMAGE_PATH . 'pay.gif" title="Payment Request" /></a></div>';
                }




                if ($invoices[$In]['INVOICE_STATUS'] == '2') {
                    $ap = 'Already Paid';
                    $htmlTPL .= '<div class="action_icons"><a href="/Invoice/edit/qs/' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '"><img src="' . IMAGE_PATH . 'edit_icon.gif" title="Edit Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="javascript:void(0);" onClick="alert(' . $ap . ');"><img src="' . IMAGE_PATH . 'pdf_icon.gif" title="Edit Invoice" /></a></div>';
                    $htmlTPL .= '<div class="action_icons"><a href="javascript:void(0);" onClick="alert(' . $ap . ');"><img src="' . IMAGE_PATH . 'pay.gif" title="Payment Request" /></a></div>';
                }
                $htmlTPL .= '
				<div class="action_icons"><a href="/Invoice/ledgerlist/qs/'.$invoices[$In]['cId'].'/I/'.$invoices[$In]['ID'].'"><img src="' . IMAGE_PATH . 'payment_icon.gif" title="Payment Invoice" /></a></div>
                <div class="action_icons"><a href="/Invoice/delete/qs' . $invoices[$In]['cId'] . '/I/' . $invoices[$In]['ID'] . '/u/' . $invoices[$In]['CREATED_BY'] . '" ><img src="' . IMAGE_PATH . 'delete_icon.gif" title="Delete Invoice" /></a></div>
			    <div class="action_icons"><a title="View Payment" href="javascript:void(0);" onClick="getPaymentDetails('.$invoices->ID.');"><img src="'.IMAGE_PATH.'preview_icon.jpg"/></a></div>

						 </td>
						 </tr>';
            }
        } else {
            $htmlTPL .= '<tr>
                        <td align="center" colspan="8">No Invoice with that search</td>
                </tr>';
        }
        $htmlTPL .= '</table>';

        echo $htmlTPL;






        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }


    public function getselectAction() {

        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('invoice_list');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;


        $userNameFromEmail = substr($userName, 0, strpos($userName, '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $this->view->userName = $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);


        /**
         * Call Invoice Functions
         */
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-List-By-Client/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $invoices = json_decode($Common->cUrlCall($cClient));

        $this->view->invoices = $invoices;

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Client-Name-By-Role-Idand-User-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $responseClient = json_decode($Common->cUrlCall($cClient),true);
        $this->view->clientDataMappingWithUser = $ClientDataMappingWithUser = $responseClient;

        $incId = $this->_request->getparam('I');

        $HTML = '';
        if ($incId == '1') {
            $s = '';
            $s .= "'";
            $s .= 'c';
            $s .= "'";
            $HTML .= '<select name="client_Name" onchange="getSatatusResult(this.value,' . $s . ');">
				<option value="">---Select Client---</option>';
            for ($i = 0; $i < count($ClientDataMappingWithUser['COMPANY_NAME']); $i++) {
                $HTML .= '<option title="' . $ClientDataMappingWithUser['COMPANY_NAME'][$i] . '"  value="' . $ClientDataMappingWithUser['CLIENT_ID'][$i] . '">' . $ClientDataMappingWithUser['COMPANY_NAME'][$i] . '</option>';
            }
            $HTML .= '</select>';
        } elseif ($incId == '2') {
            $s = '';
            $s .= "'";
            $s .= 's';
            $s .= "'";
            $HTML .= '<select name="status" onchange="getSatatusResult(this.value,' . $s . ');">
                        <option value="">---Select Status---</option>
                                <option title="0"  value="0">Created</option>
                                <option title="1"  value="1">Sent</option>
                                <option title="2"  value="2">Paid</option>
                                <option title="3"  value="3">Credited</option>
                                <option title="4"  value="4">Request Payment</option>
                                <option title="6"  value="6">Cancel</option>
			</select>';
        } elseif ($incId == '3') {
            $HTML .= '<div class="custom_date" id ="custom_date">
                  <form name="custoe" method="post" >
                  	<input type="text" name="date1" readonly="readonly" id="date1" class="inputbg" /><small class="dash">-</small>
                  	<input type="text" name="date2"  id="date2" readonly="readonly" class="inputbg" />
                  	<input type="button" name="" value="" class="btn_go" onclick = "customeDate();"/>
               	  </form>
             </div>';
        }

        echo $HTML;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }




    public function cmAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;


        $userNameFromEmail = substr($userName, 0, strpos($userName, '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $this->view->userName = $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);


        /**
         * Call Invoice Functions
         */
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-List-By-Client/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $invoices = json_decode($Common->cUrlCall($cClient));

        //$this->view->invoices = $invoices;

        $cClient1 = $Common->getBrodcasterUrl() . 'Invoice/get-Client-Name-By-Role-Idand-User-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $responseClient = json_decode($Common->cUrlCall($cClient1));

        $this->view->clientDataMappingWithUser = $responseClient;
        $this->_helper->layout->setLayout('invoice_list');

		if($invoices->CODE != 'C-103'){

		$page = $this->_getParam('page', 1);
        $paginator = Zend_Paginator::factory($invoices);
        $paginator->setItemCountPerPage(12);
        $paginator->setCurrentPageNumber($page);
        $this->view->invoices = $paginator;

		}else{
		    $invoices->CODE = 'C-103';
			$this->view->invoices = $invoices->CODE;
		}

    }

    public function publishersAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $netRows = json_decode($Common->cUrlCall($cClient));

        $array_count = count($netRows);
        $client_combo = '';
        $client_combo .= '<div id="services_0">
									<input type="hidden" value="2" name="ppc"/>Pay Per Click &nbsp;(PPC)
							   </div>
							   <div id="publishers_0">
								   <select id="publisher_0" name="publisher_0" onchange="selectDisableItems(0,this.value);">
									   <option value="">>--Select Publishers--<</option>';
        for ($i = 0; $i < $array_count; $i++) {
            $client_combo .= '<option value="' . $netRows[$i]->ID . '">' . $netRows[$i]->PUBLISHER_NAME . '</option>';
        }

        $client_combo .= '</select>
							   </div>
                                                           <div id="descpub_0" class="width112">
								<input type="text" value="" autocomplete="off" id="descpub_0" name="descpub_0"  class="width100" />
							   </div>
							   <div id="adBamts_0">
									<input type="text" value="" autocomplete="off" id="adBamt_0" name="adBamt_0" onkeydown="javascript:maskInput(); notCopy(this.id);" />
							   </div>
							   <div id="prss_0">
									<select class="width60" id="pr_0" name="pr_0">
										 <option value="pr">%</option>

									</select>
									<input type="text" value="" autocomplete="off" id="prs_0" name="prs_0" class="width100" onkeyup="doCalculationUpRow(0);  notCopy(this.id);"  onkeydown="javascript:maskInput();"  />
							   </div>



							   <div id="amounts_0">
									<input type="hidden" value="" id="agl_charge_publisher_0"  name="agl_charge_publisher_0" readonly="readonly"/>
									<input type="text" value="" autocomplete="off" id="amount_0"  name="amount_0" readonly="readonly"/>
							   </div>
							   <div class="iconblock" id="p_0">
								<a href="javascript:void(0);" id="p_0" class="moreicon" onClick="appendNewEntryUp();">
									<img src="' . IMAGE_PATH . 'plus.gif" alt="more" /></a>
							   </div>';
        echo $client_combo;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function appendsupAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;
        $incId = $this->_request->getparam('I');
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $netRows = json_decode($Common->cUrlCall($cClient));
        $array_count = count($netRows);
        $client_combo = '';
        $client_combo .= '<div id="services_' . $incId . '">
                                &nbsp;
                           </div>
                           <div id="publishers_' . $incId . '">
                               <select id="publisher_' . $incId . '" name="publisher_' . $incId . '" onchange="selectDisableItems('.$incId.',this.value);">
                                   <option value="">>--Select Publishers--<</option>';
        for ($i = 0; $i < $array_count; $i++) {
            $client_combo .= '<option value="' . $netRows[$i]->ID . '">' . $netRows[$i]->PUBLISHER_NAME . '</option>';
        }

        $client_combo .= '</select>
                           </div>
                           <div id="descpub_' . $incId . '" class="width112">
								<input type="text" value="" autocomplete="off" id="descpub_' . $incId . '" name="descpub_' . $incId . '" class="width100" />
							   </div>
                           <div id="adBamts_' . $incId . '">
                                <input type="text" value="" autocomplete="off" id="adBamt_' . $incId . '" name="adBamt_' . $incId . '" onkeydown="javascript:maskInput();  notCopy(this.id);" />
                           </div>
                           <div id="prss_' . $incId . '">
                                <select class="width60" id="pr_' . $incId . '" name="pr_' . $incId . '">
                                     <option value="pr">%</option>

                                </select>
                                <input type="text" autocomplete="off" value="" id="prs_' . $incId . '" name="prs_' . $incId . '" class="width100" onkeyup="doCalculationInLoop(' . $incId . ');  notCopy(this.id);"  onkeydown="javascript:maskInput();" />
                           </div>
                           <div id="amounts_' . $incId . '">
						         <input type="hidden" value="" id="agl_charge_publisher_' . $incId . '"  name="agl_charge_publisher_' . $incId . '"  readonly="readonly"/>
                                <input type="text" value="" autocomplete="off" id="amount_' . $incId . '"  name="amount_' . $incId . '" readonly="readonly" onkeyup=" notCopy(this.id);"/>
                           </div>
                           <div class="iconblock" id="ps_' . $incId . '">
                            <a href="javascript:void(0);" id="p_' . $incId . '" class="moreicon" onClick="appendNewEntryUp();">
                                <img src="' . IMAGE_PATH . 'plus.gif" alt="more" /></a>
                            <a href="javascript:void(0);" id="d_' . $incId . '" class="moreicon" onClick="removeNewEntryUp(' . $incId . ');">
                                <img src="' . IMAGE_PATH . 'minus.gif" alt="more" /></a>
                           </div>';
        echo $client_combo;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function doinsertAction() {
	//echo "Under maintenance";exit;
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        if (isset($_POST)) {
            $oData = $_POST;

            $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Last-Inserted-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/table/cust_invoices/';
            $netRows = json_decode($Common->cUrlCall($cClient));

            $Lid = $netRows;
            $oData['Lid'] = $Lid + 1;
            $oData['created_at'] = date('Y-m-d h:i:s');
            $oData['updated_at'] = date('Y-m-d h:i:s');
            $oData['updated_by'] = $userId = $ns->USER_ID;
            $oData['created_by'] = $userId = $ns->USER_ID;

            $arraySubPPC = $this->calculateSubNewTotal($oData);
			
			//$oData['totalLevyAmount'] = $arraySubPPC['totalLevyAmount'];
			

			$subTotal = $arraySubPPC['totalSubTotal'] + $arraySubPPC['totalLevyAmount'];

            /*if ($oData['checkService'] == '1') {
                $subTotal = $arraySubPPC['totalPPCAmount'];
            }

            if ($oData['checkService'] == '2') {
                $subTotal = $arraySubPPC['totalSubTotal'];
            }

            if ($oData['checkService'] == '3') {
                $subTotal = $arraySubPPC['totalSubTotal'] + $arraySubPPC['totalPPCAmount'];
            } */

            $taxAmount = $this->calculateTax($subTotal);
			$taxSwachhBharatCessAmount = $this->calculateSwachhBharatCessTax($subTotal);
	    //echo "<br/>";
			$taxKrishiKalyanCessAmount = $this->calculateKrishiKalyanCessTax($subTotal);
			
			
			
            $subTotal = $this->calculateSubTotal($oData);
			$subTotal  = $subTotal + $arraySubPPC['totalLevyAmount'];
            $total = $this->grandTotal($subTotal, $taxAmount, $taxSwachhBharatCessAmount, $taxKrishiKalyanCessAmount);
           
			$clientIdInvoice = $oData['client'];


            $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-All-Request-Data/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/';
            $response = $Common->cUrlCallWithPost($cUrl, $oData);



            $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $clientIdInvoice;
            $clientInfoById = json_decode($Common->cUrlCall($cUrl));


            $emailUser = $ns->USER_EMAIL;
            $role = $ns->ROLE;
	    
	    
		    
            if ($role == '1' || $role == '3' || $role == '4' || $role == '13') {
                $html = $this->view->partial('invoice/ceamail.phtml', array('eData' => $oData, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'subTotal' => $subTotal, 'total' => $total, 'taxAmount' => $taxAmount, 'taxSwachhBharatCessAmount' => $taxSwachhBharatCessAmount, 'taxKrishiKalyanCessAmount' => $taxKrishiKalyanCessAmount));
            } else {
                $html = $this->view->partial('invoice/ceumail.phtml', array('eData' => $oData, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'subTotal' => $subTotal, 'total' => $total, 'taxAmount' => $taxAmount, 'taxSwachhBharatCessAmount' => $taxSwachhBharatCessAmount, 'taxKrishiKalyanCessAmount' => $taxKrishiKalyanCessAmount));
            }




            $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Pmo-Admin-Account-Emails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType;
            $Emails = json_decode($Common->cUrlCall($cUrl));


            $emailUser = $ns->USER_EMAIL;
            for ($i = 0; $i < count($Emails); $i++) {
                $aapc[$i] = $Emails[$i]->USER_EMAIL;
            }
            $mail = new Zend_Mail();
            $mail->setType(Zend_Mime::MULTIPART_RELATED);
            $mail->setBodyHtml($html);
            $mail->setFrom($emailUser);


            for ($m = 0; $m < count($aapc); $m++) {
                $mail->addTo($aapc[$m]);
            }
            $mail->addTo($emailUser);
            $mail->setSubject('Invoice Created');
            //$mail->send();
			
			$aapc[] = $emailUser;
			$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($html);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = 'Invoice Created';
			$arrEmail['from'] = $emailUser;
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = implode(",", $aapc);
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			
			

            $this->_redirect('Invoice/index');
        }
    }

    public function calculateSubNewTotal($oData) {
        $netArray = array();
		$totalLevyAmount = 0;
        if (@$oData['checkService'] == '1') {
            if ($oData['cUp'] == '0') {
                $totalAmount = $oData['amount_0'];
				$publisher = $oData['publisher_0'];
				$adBamt = $oData['adBamt_0'];
				
				
				if($publisher == 1){
					$totalLevyAmount = (int) round($adBamt * 6) / 100;
				}
                $totalPPCAmount = $oData['agl_charge_publisher_0'];
            } else {
                $totalAmount = 0;
                $totalPPCAmount = 0;
                for ($i = 0; $i <= $oData['cUp']; $i++) {
                    $totalAmount += $oData['amount_' . $i];
					$publisher = $oData['publisher_'.$i];
					$totalUpLevy = $oData['adBamt_' . $i];
					if($publisher == 1){
						$totalLevyAmount = (int) round($totalUpLevy * 6) / 100;
					}
                    $totalPPCAmount += $oData['agl_charge_publisher_' . $i];
                }
            }
            $netArray['totalSubTotal'] = $totalAmount;
            $netArray['totalPPCAmount'] = $totalPPCAmount;
			$netArray['totalLevyAmount'] = $totalLevyAmount;
            return $netArray;
        }

        if (@$oData['checkService'] == '2') {
            if ($oData['cDn'] == '0') {
                $totalAmount = $oData['amount_n_0'];
            } else {
                $totalAmount = 0;
                for ($i = 0; $i <= $oData['cDn']; $i++) {
                    $totalAmount += $oData['amount_n_' . $i];
                }
            }
            $netArray['totalSubTotal'] = $totalAmount;
            $netArray['totalPPCAmount'] = '0';
			$netArray['totalLevyAmount'] = '0';
            return $netArray;
        }

        if (@$oData['checkService'] == '3') {

            if ($oData['cUp'] == '0') {
                $totalUp = $oData['amount_0'];
				
				$publisher = $oData['publisher_0'];
				$adBamt = $oData['adBamt_0'];
				if($publisher == 1){
					$totalLevyAmount = (int) round($adBamt * 6) / 100;
				}
				
                $totalPPCAmount = $oData['agl_charge_publisher_0'];
            } else {
                $totalUp = 0;
                $totalPPCAmount = 0;
                for ($i = 0; $i <= $oData['cUp']; $i++) {
                    $totalUp += $oData['amount_' . $i];
					
					$publisher = $oData['publisher_'.$i];
					$totalUpLevy = $oData['adBamt_' . $i];
					if($publisher == 1){
						$totalLevyAmount = (int) round($totalUpLevy * 6) / 100;
					}
				
                    $totalPPCAmount += $oData['agl_charge_publisher_' . $i];
                }
            }

            if ($oData['cDn'] == '0') {
                $totalDn = $oData['amount_n_0'];
            } else {
                $totalDn = 0;
                for ($i = 0; $i <= $oData['cDn']; $i++) {
                    $totalDn += $oData['amount_n_' . $i];
                }
            }

            //$totalAmount = (int) $totalDn;
            $totalAmountPartial = (int) $totalDn;
            $totalAmount = $totalAmountPartial + $totalUp;
            $netArray['totalSubTotal'] = $totalAmount;
            $netArray['totalPPCAmount'] = $totalPPCAmount;
			$netArray['totalLevyAmount'] = $totalLevyAmount;
            return $netArray;
        }
    }

    public function calculateTax($subTotal) {
        //$serviceTax = 10.3;
        $serviceTax = 14;
        $taxAmount = (int) round($subTotal * $serviceTax / 100);
        return (int) $taxAmount;
    }
    
    public function calculateSwachhBharatCessTax($subTotal) {
        //$serviceTax = 10.3;
        $tax = 0.5;
        $taxAmount = (int) round($subTotal * $tax / 100);
        return (int) $taxAmount;
    }

	public function calculateKrishiKalyanCessTax($subTotal) {
        //$serviceTax = 10.3;
        $tax = 0.5;
        $taxAmount = (int) round($subTotal * $tax / 100);
        return (int) $taxAmount;
    }
	
    public function calculateSubTotal($oData) {
        if (@$oData['checkService'] == '1') {
            if ($oData['cUp'] == '0') {
                $totalAmount = $oData['amount_0'];
            } else {
                $totalAmount = 0;
                for ($i = 0; $i <= $oData['cUp']; $i++) {
                    $totalAmount += $oData['amount_' . $i];
                }
            }

            return $totalAmount;
        }
        if (@$oData['checkService'] == '2') {
            if ($oData['cDn'] == '0') {
                $totalAmount = $oData['amount_n_0'];
            } else {
                $totalAmount = 0;
                for ($i = 0; $i <= $oData['cDn']; $i++) {
                    $totalAmount += $oData['amount_n_' . $i];
                }
            }
            return $totalAmount;
        }

        if (@$oData['checkService'] == '3') {

            if ($oData['cUp'] == '0') {
                $totalUp = $oData['amount_0'];
            } else {
                $totalUp = 0;
                for ($i = 0; $i <= $oData['cUp']; $i++) {
                    $totalUp += $oData['amount_' . $i];
                }
            }

            if ($oData['cDn'] == '0') {
                $totalDn = $oData['amount_n_0'];
            } else {
                $totalDn = 0;
                for ($i = 0; $i <= $oData['cDn']; $i++) {
                    $totalDn += $oData['amount_n_' . $i];
                }
            }
            return $totalAmount = (int) $totalUp + (int) $totalDn;
        }
    }

    public function grandTotal($subTotal, $taxAmount, $taxSwachhBharatCessAmount, $taxKrishiKalyanCessAmount) {
        return (int) $subTotal + (int) $taxAmount + (int) $taxSwachhBharatCessAmount + (int) $taxKrishiKalyanCessAmount;
    }

    public function editAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $Id = $this->view->Id = $ns->USER_ID;
        $userId = $ns->USER_ID;

        if (!$userId) {
            $this->redirect('Login/index');
        }
        $this->view->uRole = $roleId = $role = $ns->ROLE;
        $userId = $ns->USER_ID;
        $userEmail = $ns->USER_EMAIL;

        $userNameFromEmail = substr($userEmail, 0, strpos($userEmail, '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);
        $this->view->sTuserName = $sUserName;
        $this->_helper->layout->setLayout('invoice_edit');
        $invoiceId = $this->_request->getparam('I');
        $clientId = $this->_request->getparam('qs');
        $uId = $this->_request->getparam('u');

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId;
        $invoices = json_decode($Common->cUrlCall($cClient));


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-User-Info-Array/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/createdBy/' . $invoices[0]->CREATED_BY;
        $userInfo = (array) json_decode($Common->cUrlCall($cClient));
        $userInfo = explode('~', $userInfo[0]);
        $userNameFromEmail = substr($userInfo[1], 0, strpos($userInfo[1], '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);
        $invoices[0]->USER_NAME = $userName1 = $this->view->userName = $sUserName;
        $invoices[0]->USER_BY = $userInfo[0];




        $this->view->eInvoices = $invoices;
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->publishers = json_decode($Common->cUrlCall($cClient));


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->services = json_decode($Common->cUrlCall($cClient));


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Details-Byi-Cu/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/clientId/' . $clientId . '/uId/' . $uId;
        $rows = $this->view->dInvoices = json_decode($Common->cUrlCall($cClient));

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Client-For-Index/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->clients = json_decode($Common->cUrlCall($cClient));

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Status-Array/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $status = json_decode($Common->cUrlCall($cClient));

        if (array_key_exists($invoices[0]->INVOICE_STATUS, $status)) {
            $invoices[0]->INVOICE_STATUS_WORD = $status[$invoices[0]->INVOICE_STATUS];
        }

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Client-Name-By-Role-Idand-User-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $UserClientMapping = json_decode($Common->cUrlCall($cClient));



        $this->view->action = $action = $this->getRequest()->getActionName();
        $this->view->ClientDataMappingWithUser = $UserClientMapping;
    }

    public function editrequestAction() {

        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $userId = $ns->USER_ID;
        if (!$userId) {
            $this->redirect('Login/index');
        }
        if (isset($_POST)) {
            $eData = $_POST;

            $eData['created_at'] = date('Y-m-d h:i:s');
            $eData['updated_at'] = date('Y-m-d h:i:s');
            $eData['updated_by'] = $ns->USER_ID;
            $eData['pstatus'];
//print_R($eData);exit;

            switch ($eData['pstatus']) {
                case '0':
                    $uId = $eData['uId'];
                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $uId;
                    $EmailCreater = json_decode($Common->cUrlCall($cClient));

                    $cLid = $Common->getBrodcasterUrl() . 'Invoice/get-Last-Inserted-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/table/cust_invoices';
                    $Lid = json_decode($Common->cUrlCall($cLid));
                    $eData['Lid'] = $Lid + 1;
                    if ($eData['pstatus'] == '0') {

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/edit-Data/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/';
                        $response = $Common->cUrlCallWithPost($cUrl, $eData);
						
						$cLid = $Common->getBrodcasterUrl() . 'Invoice/get-Last-Inserted-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/table/cust_invoices';
						$Lid = json_decode($Common->cUrlCall($cLid));
						$eData['InvoiceId'] = $Lid;
						
;

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $eData['client'];
                        $clientInfoById = json_decode($Common->cUrlCall($cUrl));

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Pmo-Admin-Account-Emails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType;
                        $Emails = json_decode($Common->cUrlCall($cUrl));

                        $emailUser = $ns->USER_EMAIL;

                        for ($i = 0; $i < count($Emails); $i++) {
                            $aapc[$i] = $Emails[$i]->USER_EMAIL;
                        }

                        $aapc[] = $emailUser;
                        $aapc[] = $EmailCreater[0]->USER_EMAIL;

                        $custMessage = $Common->custMessage();

                        $role = $this->role = $ns->ROLE;

                        $sPath = $this->sPath = $this->getRootDocumentPath();

			
			
			
			$cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $eData['InvoiceId'];
			$eInvoices = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient));
		    //print_R($eInvoices);exit;
		    
                        if ($role == '1' || $role == '3' || $role == '4' || $role == '13') {
                            $html = $this->view->partial('invoice/eamail.phtml', array('eData' => $eData, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'custMessage' => $custMessage, 'sPath' => $sPath,"eInvoices"=>$eInvoices));
                        } else {
                            $html = $this->view->partial('invoice/eumail.phtml', array('eData' => $eData, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'custMessage' => $custMessage, 'sPath' => $sPath,"eInvoices"=>$eInvoices));
                        }



                        $mail = new Zend_Mail();
                        $mail->setType(Zend_Mime::MULTIPART_RELATED);
                        $mail->setBodyHtml($html);
                        //$mail->setFrom($emailUser);
                        $mail->setFrom('invoice@adv8.co');
                        for ($m = 0; $m < count($aapc); $m++) {
                            $mail->addTo($aapc[$m]);
                        }

                        $mail->setSubject('Invoice Edited');
                        //$mail->send();
						
						
			$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($html);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = 'Invoice Edited';
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = implode(",", $aapc);
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			
			

                        $this->_redirect('Invoice/index');
                    } else {
                        $this->_redirect('Invoice/index');
                    }
                    break;
                case '1':
                    $this->redirect('Invoice/index');
                    break;
                case '3':
                    if ($_POST) {
                        if ($eData['Invoice_Actual_Id'] == "") {
                            $this->redirect('Invoice/index');
                        }
                        $statusMode = $eData['pstatus'];
                        $uId = $eData['created_by'];

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $uId;
                        $EmailCreater = json_decode($Common->cUrlCall($cClient));

                        //$EmailCreater = $Invoice->getEmailIdOfCreaterById($uId);

                        $oriPerformaId = 'AGL-' . $eData['Invoice_Actual_Id'];
                        $userId = $eData['created_by'];
                        $invoiceId = $eData['InvoiceId'];
                        $clientId = $client_Id = $eData['cId'];

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/insert-Into-Payment-Table/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId;
                        $Common->cUrlCallWithPost($cClient, $eData);
                        //$Invoice->insertIntoPaymentTable($eData);

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId;
                        $eInvoices = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient), true);


                        //$eInvoices = $this->view->eInvoices = $Invoice->getInvoiceInfoByInvoiceId($invoiceId);
                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Details-Byi-Cu/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/clientId/' . $clientId . '/uId/' . $uId;
                        $dInvoices = $this->view->dInvoices = json_decode($Common->cUrlCall($cClient), true);



                        //$dInvoices = $this->view->dInvoices = $Invoice->getInvoiceDetailsByiCu($invoiceId, $clientId, $userId);


                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
                        $publishers = $this->view->publishers = json_decode($Common->cUrlCall($cClient));

                        //$publishers = $Invoice->getPublisherList();

                        foreach ($publishers as $publisherm) {
                            $publisher[$publisherm->ID] = $publisherm->PUBLISHER_DESC;
                        }

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/change-Status-Of-Invoice-Credit/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $ $cClient = $Common->getBrodcasterUrl() . 'Invoice/change-Status-Of-Invoice-Credit/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                        $Common->cUrlCallWithPost($cClient, $eData);


                        //$Invoice->changeStatusOfInvoiceCredit($statusMode, $eData);

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/see-Date/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                        $rowsTest = $Common->cUrlCallWithPost($cClient, $eData);

                        //$rowsTest = $Invoice->seeDate($eData);

                        if ((@$rowsTest[0]->ORIGINAL_APPROVAL_DATE < "0000-00-00 00:00:00") || (@$rowsTest[0]->ORIGINAL_APPROVAL_DATE == "0000-00-00 00:00:00")) {
                            $cClient = $Common->getBrodcasterUrl() . 'Invoice/insert-Date-O/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                            $rowsTest = $Common->cUrlCallWithPost($cClient, $eData);
                            //$Invoice->insertDateO($eData);
                        }

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/add-Actual-Id-To-Agl/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                        $Common->cUrlCallWithPost($cClient, $eData);


                        //$Invoice->addActualIdToAgl($statusMode, $eData);
                        $sPath = $this->view->sPath = $this->getRootDocumentPath();

                        $html = $this->view->partial('invoice/originalinvoice.phtml', array('eInvoices' => $eInvoices, 'dInvoices' => $dInvoices, 'publisher' => $publisher, 'oPiId' => $oriPerformaId, 'sPath' => $sPath));
                        $tmphtml = $this->getPdfOriginal($html, $client_Id);

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Pmo-Admin-Account-Emails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType;
                        $Emails = json_decode($Common->cUrlCall($cUrl));


                        //$Emails = $Invoice->getPmoAdminAccountEmails();
                        $emailUser = $ns->USER_EMAIL;
                        for ($i = 0; $i < count($Emails); $i++) {
                            $aapc[$i] = $Emails[$i]->USER_EMAIL;
                        }


                        $aapc[] = $emailUser;
                        $aapc[] = @$EmailCreater[0]->USER_USERID;
                        $custMessage = $Common->custMessage();

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $eData['cId'];
                        $clientInfoById = json_decode($Common->cUrlCall($cUrl));

                        //$clientInfoById = $Invoice->getClientIdById($eData['cId']);
                        $html = $this->view->partial('invoice/oemail.phtml', array('eData' => $eData, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'custMessage' => $custMessage, 'sPath' => $sPath));

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Id-By-Ag-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/invoiceId/' . $eData['InvoiceId'];
                        $serviceId = json_decode($Common->cUrlCall($cUrl));


                        //$serviceId = $Invoice->getServiceIdByAgId($eData['InvoiceId']);


                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Short-Service-Name-By-Service-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/serviceId/' . $serviceId;
                        $shortName = json_decode($Common->cUrlCall($cUrl));

                        //$shortName = $Invoice->getShortServiceNameByServiceId($serviceId);


                        /**

                        $iData[0] = $clientInfoById[0]->COMPANY_NAME;
                        $iData[1] = $eData['Invoice_Actual_Id'];
                        $iData[2] = $shortName;
                        $iData[3] = '1';
                        $iData[4] = $eData['gTotal'];





                        //echo
                        //Quick Book
                        //require_once 'application/models/quickbook/docs/example_app_web_connector/config.php';

                        $this->quickbookInvoice($iData, $eData, $eInvoices, $dInvoices);

                        //$InvoiceLocal->quickbookInvoice();
                        //$InvoiceLocal->quickbookInvoice($iData);
                        $Table = 'my_invoice_table';

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Last-Insert-Id-Invoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/table/' . $Table;
                        $id = json_decode($Common->cUrlCall($cUrl));


                        //$id = $Invoice->getLastInsertIdInvoice($Table);
                        $Queue = new QuickBooks_WebConnector_Queue($dsn);
                        $Queue->enqueue(QUICKBOOKS_ADD_INVOICE, $id);
                        //QuickBook End
                        **/

                          $mail = new Zend_Mail();
                          $mail->setType(Zend_Mime::MULTIPART_RELATED);
                          $mail->setBodyHtml($html);
                          //$mail->setFrom($emailUser);
                          $mail->setFrom('invoice@adv8.co');
                          for ($m = 0; $m < count($aapc); $m++) {
                          $mail->addTo($aapc[$m]);
                          }
                          $mail->addTo('ashish.jain@adglobal360.com');
                          $mail->addTo('vishnu.dass@adglobal360.com');
                          //$mail->addTo('shruti.kakkar@adglobal360.com');
                          $mail->setSubject('Invoice Credited');
                          $test = file_get_contents($tmphtml);
                          $file = $mail->createAttachment($test);
                          $file->filename = $clientInfoById[0]->COMPANY_NAME . '.pdf';
                          $mail->send();
						  


                        $this->_redirect('Invoice/index');
                    }

                    break;
                case '2':
                    if ($_POST) {
                        if ($eData['Invoice_Actual_Id'] == "") {
                            $this->redirect('Invoice/index');
                        }


                        $statusMode = $eData['pstatus'];
                        $uId = $eData['created_by'];

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $uId;
                        $EmailCreater = json_decode($Common->cUrlCall($cClient));


                        //$EmailCreater = $Invoice->getEmailIdOfCreaterById($uId);

                        $oriPerformaId = 'AGL-' . $eData['Invoice_Actual_Id'];
                        $userId = $eData['created_by'];
                        $invoiceId = $eData['InvoiceId'];
                        $clientId = $client_Id = $eData['cId'];


                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/insert-Into-Payment-Table/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId;
                        $Common->cUrlCallWithPost($cClient, $eData);

                        //$Invoice->insertIntoPaymentTable($eData);


                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId;
                        $eInvoices = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient),true);


                        //$eInvoices = $this->view->eInvoices = $Invoice->getInvoiceInfoByInvoiceId($invoiceId);
                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Details-Byi-Cu/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/clientId/' . $clientId . '/uId/' . $uId;
                        $dInvoices = $this->view->dInvoices = json_decode($Common->cUrlCall($cClient),true);




                        //$eInvoices = $this->view->eInvoices = $Invoice->getInvoiceInfoByInvoiceId($invoiceId);
                        //$dInvoices = $this->view->dInvoices = $Invoice->getInvoiceDetailsByiCu($invoiceId, $clientId, $userId);


                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
                        $publishers = $this->view->publishers = json_decode($Common->cUrlCall($cClient));


                        ///$publishers = $Invoice->getPublisherList();


                        foreach ($publishers as $publisherm) {
                            $publisher[$publisherm->ID] = $publisherm->PUBLISHER_DESC;
                        }

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/change-Status-Of-Invoice-Credit/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $ $cClient = $Common->getBrodcasterUrl() . 'Invoice/change-Status-Of-Invoice-Credit/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                        $Common->cUrlCallWithPost($cClient, $eData);

                        //$Invoice->changeStatusOfInvoiceCredit($statusMode, $eData);

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/see-Date/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                        $rowsTest = json_decode($Common->cUrlCallWithPost($cClient, $eData));



                        //$rowsTest = $Invoice->seeDate($eData);
                        if ((@$rowsTest[0]->ORIGINAL_APPROVAL_DATE < "0000-00-00 00:00:00") || ($rowsTest[0]->ORIGINAL_APPROVAL_DATE == "0000-00-00 00:00:00")) {
                            $Invoice->insertDateO($eData);
                        }

                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/add-Actual-Id-To-Agl/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                        $Common->cUrlCallWithPost($cClient, $eData);

                        //$Invoice->addActualIdToAgl($statusMode, $eData);


                        $sPath = $this->view->sPath = $Common->getRootDocumentPath();
                        $html = $this->view->partial('invoice/originalinvoice.phtml', array('eInvoices' => $eInvoices, 'dInvoices' => $dInvoices, 'publisher' => $publisher, 'oPiId' => $oriPerformaId, 'sPath' => $sPath));
                        $tmphtml = $this->getPdfOriginal($html, $client_Id);


                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Pmo-Admin-Account-Emails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType;
                        $Emails = json_decode($Common->cUrlCall($cUrl));

                        //$Emails = $Invoice->getPmoAdminAccountEmails();
                        $emailUser = $ns->USER_EMAIL;
                        for ($i = 0; $i < count($Emails); $i++) {
                            $aapc[$i] = $Emails[$i]->USER_EMAIL;
                        }

                        $aapc[] = $emailUser;
                        $aapc[] = $EmailCreater[0]->USER_USERID;

                        $custMessage = $Common->custMessage();

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $eData['cId'];
                        $clientInfoById = json_decode($Common->cUrlCall($cUrl));


                        //$clientInfoById = $Invoice->getClientIdById($eData['cId']);
                        $html = $this->view->partial('invoice/pemail.phtml', array('eData' => $eData, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'custMessage' => $custMessage, 'sPath' => $sPath));


                        $mail = new Zend_Mail();
                        $mail->setType(Zend_Mime::MULTIPART_RELATED);
                        $mail->setBodyHtml($html);
                        //$mail->setFrom($emailUser);
                        $mail->setFrom('invoice@adv8.co');
                        for ($m = 0; $m < count($aapc); $m++) {
                            $mail->addTo($aapc[$m]);
                        }
                        $mail->addTo($emailUser);
                        $mail->addTo('ashish.jain@adglobal360.com');
                        //$mail->addTo('shruti.kakkar@adglobal360.com');
                        $mail->addTo('vishnu.dass@adglobal360.com');
                        $mail->setSubject('Invoice Paid');
                        $test = file_get_contents($tmphtml);
                        $file = $mail->createAttachment($test);
                        $file->filename = $clientInfoById[0]->COMPANY_NAME . '.pdf';
                        $mail->send();

                        /**

                        $iData[0] = $clientInfoById[0]->COMPANY_NAME;
                        $iData[1] = $eData['Invoice_Actual_Id'];
                        $iData[2] = $shortName;
                        $iData[3] = '1';
                        $iData[4] = $eData['gTotal'];
                        //Quick Book
                        require_once 'application/models/quickbook/docs/example_app_web_connector/config.php';


                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/quickbook-Invoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                        $testRows = $Common->cUrlCallWithPost($cClient, $iData, true);

                        //$Invoice->quickbookInvoice($iData, $eData, $eInvoices, $dInvoices);
                        $Table = 'my_invoice_table';

                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Last-Insert-Id-Invoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/table/' . $Table;
                        $id = json_decode($Common->cUrlCall($cUrl));


                        //$id = $Invoice->getLastInsertIdInvoice($Table);
                        $Queue = new QuickBooks_WebConnector_Queue($dsn);
                        $Queue->enqueue(QUICKBOOKS_ADD_INVOICE, $id);
                        //QuickBook End
                        **/
                        $this->_redirect('Invoice/index');
                    }

                    $this->_redirect('Invoice/index');
                    break;
                case '4':
                    $this->_redirect('Invoice/index');
                    break;
                case '5':

                    $statusMode = $eData['pstatus'];
                    $uId = $eData['uId'];
                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $uId;
                    $EmailCreater = json_decode($Common->cUrlCall($cClient));

                    $userId = $ns->USER_ID;

                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/change-Status-Of-Invoice-Another/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                    $test = $Common->cUrlCallWithPost($cClient, $eData);




                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/see-Date/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId;
                    $rowsTest = json_decode($Common->cUrlCallWithPost($cClient, $eData));


                    if (($rowsTest[0]->PERFORMA_APPROVAL_DATE < "0000-00-00 00:00:00") || ($rowsTest[0]->PERFORMA_APPROVAL_DATE == "0000-00-00 00:00:00")) {
                        $cClient = $Common->getBrodcasterUrl() . 'Invoice/insert-Date/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId;
                        $rowsTest = json_decode($Common->cUrlCallWithPost($cClient, $eData));
                    }
                    $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Pmo-Admin-Account-Emails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType;
                    $Emails = json_decode($Common->cUrlCall($cUrl));



                    $emailUser = $ns->USER_EMAIL;

                    for ($i = 0; $i < count($Emails); $i++) {
                        $aapc[$i] = $Emails[$i]->USER_EMAIL;
                    }

                    $aapc[] = $emailUser;
                    $aapc[] = $EmailCreater[0]->USER_EMAIL;
                    $custMessage = $Common->custMessage();

                    $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $eData['cId'];
                    $clientInfoById = json_decode($Common->cUrlCall($cUrl));


                    $sPath = $this->sPath = $this->getRootDocumentPath();
		    
		      $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $eData['InvoiceId'];
                    $eInvoices = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient),true);
		

                    $html = $this->view->partial('invoice/appmail.phtml', array('eData' => $eData, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'custMessage' => $custMessage, 'sPath' => $sPath,"eInvoices"=>$eInvoices));

                    $mail = new Zend_Mail();
                    $mail->setType(Zend_Mime::MULTIPART_RELATED);
                    $mail->setBodyHtml($html);
                    //$mail->setFrom($emailUser);
                    $mail->setFrom('invoice@adv8.co');
                    for ($m = 0; $m < count($aapc); $m++) {
                        $mail->addTo($aapc[$m]);
                    }
                    $mail->addTo($emailUser);
//$mail->addTo("shrutikakkar26@gmail.com");

                    $mail->setSubject('Invoice Approved');
                    //$mail->send();
					$aapc[] = $emailUser;
						$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($html);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = 'Invoice Approved';
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = implode(",", $aapc);
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			

                    $this->_redirect('Invoice/index');
                    break;
                case '6':
                    $statusMode = $eData['pstatus'];
                    $userId = $ns->USER_ID;
                    $uId = $eData['created_by'];
                    //$EmailCreater = $Invoice->getEmailIdOfCreaterById($uId);

                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $uId;
                    $EmailCreater = json_decode($Common->cUrlCall($cClient));


                    $emailUser = $ns->USER_EMAIL;


                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/change-Status-Of-Invoice-Another/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode;
                    $test = $Common->cUrlCallWithPost($cClient, $eData);

                    //$Invoice->changeStatusOfInvoiceAnother($statusMode, $eData, $userId);

                    $aapc[] = $emailUser;
                    $aapc[] = $EmailCreater[0]->USER_USERID;

                    $uId = $eData['created_by'];


                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $uId;
                    $EmailCreater = json_decode($Common->cUrlCall($cClient));


                    //$EmailCreater = $Invoice->getEmailIdOfCreaterById($uId);

                    $oriPerformaId = @$eData['Invoice_Actual_Id'];
                    $userId = $eData['created_by'];
                    $invoiceId = $eData['InvoiceId'];
                    $clientId = $eData['cId'];
                    $custMessage = $Common->custMessage();

                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId;
                    $eInvoices = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient));
                    //$eInvoices = $this->view->eInvoices = $Invoice->getInvoiceInfoByInvoiceId($invoiceId);


                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Details-Byi-Cu/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/clientId/' . $clientId . '/uId/' . $uId;
                    $dInvoices = $this->view->dInvoices = json_decode($Common->cUrlCall($cClient));

                    //$dInvoices = $this->view->dInvoices = $Invoice->getInvoiceDetailsByiCu($invoiceId, $clientId, $userId);

                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
                    $publishers = json_decode($Common->cUrlCall($cClient));
                    //$publishers = $Invoice->getPublisherList();

                    $clientIdInvoice = $eData['cId'];
                    $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $clientIdInvoice;
                    $clientInfoById = json_decode($Common->cUrlCall($cUrl));
                    //$clientInfoById = $this->view->clientInfoById = $Invoice->getClientIdById($eData['cId']);
                    foreach ($publishers as $publisherm) {
                        $publisher[$publisherm->ID] = $publisherm->PUBLISHER_DESC;
                    }
                    $sPath = $this->view->sPath = $this->getRootDocumentPath();

                    $html = $this->view->partial('invoice/cancel.phtml', array('eData' => $eData, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'custMessage' => $custMessage, 'sPath' => $sPath, "eInvoices"=>$eInvoices));

                    $mail = new Zend_Mail();
                    $mail->setType(Zend_Mime::MULTIPART_RELATED);
                    $mail->setBodyHtml($html);
                    //$mail->setFrom($emailUser);
                    $mail->setFrom('invoice@adv8.co');
                    for ($m = 0; $m < count($aapc); $m++) {
                        $mail->addTo($aapc[$m]);
                    }
                    $mail->addTo($emailUser);
                    $mail->setSubject('Invoice Cancel');
                    //$mail->send();
					
					$aapc[] = $emailUser;
						$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($html);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = 'Invoice Cancel';
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = implode(",", $aapc);
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			
			
                    $this->_redirect('Invoice/index');
                    break;
            }
        }
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function getLastInsertIdInvoice($Table) {
        $sql = "SELECT MAX(ID)  Id  FROM " . $Table;
        $db=Zend_Registry::get('DB_C');
        //$resourceId = mysql_query($sql);
        //$rows = mysql_fetch_array($resourceId);
        $rows = $db->Fetchall($sql);
        return $rows[0]->Id;
    }

    public function getLastInsertIdInvoiceQb($Table) {
        $sql = "SELECT MAX(ID)  Id  FROM " . $Table;
        $db=Zend_Registry::get('DB_I');
        //$resourceId = mysql_query($sql);
        //$rows = mysql_fetch_array($resourceId);
        $rows = $db->Fetchall($sql);
        return $rows[0]->Id;
    }

    public function quickbookInvoice($iData,$eInvoices,$dInvoices) {

		$db=Zend_Registry::get('DB_I');



        $sqlM = "insert into my_invoice_table(sid)values('1')";
        $db->query($sqlM);

        $Table = 'my_invoice_table';
        $id = $this->getLastInsertIdInvoiceQb($Table);




        for ($J = 0; $J < count($dInvoices); $J++) {
            if ($dInvoices[$J]['SERVICE_ID'] == '2') {
                switch ($dInvoices[$J]['PUBLISHER_ID']) {
                    case '1':
                        $ServiceName = 'PPC:PPC- FACEBOOK';
                        break;
                    case '2':
                        $ServiceName = 'PPC:PPC- GOOGLE';
                        break;
                    case '3':
                        $ServiceName = 'PPC:PPC- MSN';
                        break;
                    case '4':
                        $ServiceName = 'PPC:PPC- YAHOO';
                        break;
                }
                $sql = "INSERT my_invoice_table_sec
					SET
					    id = '" . $id . "',
						TxnID = '1',
						TimeCreated = '" . date('Y/m/d') . "',
						PublisherId = '" . $dInvoices[$J]['PUBLISHER_ID'] . "',
						PublisherName = 'No',
						ServiceId = '2',
						ServiceName = '" . $ServiceName . "',
						AglCharge = '" . $dInvoices[$J]['AGL_CHARGES']. "',
						ServiceTax = '" . $eInvoices[0]['SERVICE_TAX']. "',
						SubTotal = '" . $eInvoices[0]['SUBTOTAL'] . "',
						Gtotal = '" . $eInvoices[0]['TOTAL_AMT'] . "',
						TimeModified = '" . date('Y/m/d') . "',
						RefNumber = '" . $iData[1] . "',
						Customer_ListID = '1',
						Customer_FullName = '" . $iData[0] . "',
						ShipAddress_Addr1 = 'NO',
						ShipAddress_Addr2 = 'NO',
						ShipAddress_City = 'NO',
						ShipAddress_State = 'NO',
						ShipAddress_Province = 'NO',
						ShipAddress_PostalCode = 'NO',
						BalanceRemaining = 'NO',
						irefrence = '" . $ServiceName . "',
						quantity = '" . $iData[3] . "',
						rate = '" . $dInvoices[$J]['AMOUNT'] . "'";
            }

            if ($dInvoices[$J]['SERVICE_ID'] != '2') {
                $shortName = $this->getShortServiceNameByServiceId($dInvoices[$J]['SERVICE_ID']);
                $sql = "INSERT my_invoice_table_sec
					SET
						id = '" . $id . "',
						TxnID = '1',
						TimeCreated = '" . date('Y/m/d') . "',
						PublisherId = '0',
						PublisherName = '0',
						ServiceId = '" . $dInvoices[$J]['SERVICE_ID'] . "',
						ServiceName = '" . $shortName . "',
						AglCharge = '0',
						ServiceTax = '" . $eInvoices[0]['SERVICE_TAX']. "',
						SubTotal = '" . $eInvoices[0]['SUBTOTAL']. "',
						Gtotal = '" . $eInvoices[0]['TOTAL_AMT']. "',
						TimeModified = '" . date('Y/m/d') . "',
						RefNumber = '" . $iData[1] . "',
						Customer_ListID = '1',
						Customer_FullName = '" . $iData[0] . "',
						ShipAddress_Addr1 = 'NO',
						ShipAddress_Addr2 = 'NO',
						ShipAddress_City = 'NO',
						ShipAddress_State = 'NO',
						ShipAddress_Province = 'NO',
						ShipAddress_PostalCode = 'NO',
						BalanceRemaining = 'NO',
						irefrence = '" . $shortName . "',
						quantity = '" . $iData[3] . "',
						rate = '" . $dInvoices[$J]['AMOUNT']. "'";
            }
           $db->query($sql);
        }

		/**
		  *enabled by rakesh singh 19th jun 2014
		*/

		if($iData[0]== 'QB50'){
        $cUrl = 'https://www.adv8.in/invoice/insertintoqbinvoice/id/'.$id;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);
        $info = @curl_getinfo($ch);
        curl_close($ch);
        $responsePub = $response;

		$update = "UPDATE `cust_invoice_payment_master` SET QB ='1' where INVOICE_ID = '".$eInvoices[0]['INVOICE_ID']."'  AND ID = '".$eInvoices[0]['ID']."'";
		$db->query($update);

        echo $update = "UPDATE `cust_invoice_payment_matser_details` SET QB ='1' where INVOICE_ID = '".$eInvoices[0]['INVOICE_ID']."' AND  FKEY_PAYMENT_ID ='".$eInvoices[0]['ID']."'";
		die;
		$db->query($update);
		}
    }




    public function getRootDocumentPath() {
        return $rootPath = ROOT;
    }

    public function deleteAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;
        $invoiceId = $this->view->invoiceId = $this->_request->getparam('I');
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/delete-Invoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId;
        $delete = json_decode($Common->cUrlCall($cClient));


        //$Invoice->deleteInvoice($invoiceId);
        $this->_redirect('Invoice/index');
    }

    public function servicesdwAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $netRows = json_decode($Common->cUrlCall($cClient));

        //$netRows = $Invoice->getServiceName();
        $arrayCount = count($netRows);
        $client_combo = '';
        $client_combo = '<div id="service_div_dw_0">';
        $client_combo .= '<select name="service_n_0" id="service_n_0" onchange="selectDisableItemsLower(0,this.value);">';
        $client_combo .= '<option value="">--Please Select service name--</option>';
        for ($i = 0; $i < $arrayCount; $i++) {
            if ($netRows[$i]->ID != '2') {
                $client_combo .= '<option value="' . $netRows[$i]->ID . '">' . $netRows[$i]->SERVICE_NAME . '</option>';
            }
        }
        $client_combo .= '</select></div>
            <div class="width532" id="descs_n_0">
                <input type="text" autocomplete="off" value="" id="desc_n_0" name="desc_n_0" />
            </div>
            <div id="amounts_n_0">
                <input type="text" value="" autocomplete="off" name="amount_n_0" id="amount_n_0" onkeydown="javascript:maskInput();  notCopy(this.id);"  />
            </div>
            <div class="iconblock" id="ps_n_0">
                <a href="javascript:void();" class="moreicon" id="p_n_0" onClick="appendNewEntryDw();">
                    <img src="' . IMAGE_PATH . 'plus.gif" alt="more" /></a></div>';
        echo $client_combo;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function appendsdwAction() {
        $incId = $this->_request->getparam('I');
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $netRows = json_decode($Common->cUrlCall($cClient));

        $arrayCount = count($netRows);
        $client_combo = '';
        $client_combo = '<div id="service_div_dw_' . $incId . '">';
        $client_combo .= '<select name="service_n_' . $incId . '" id="service_n_' . $incId . '" onchange="selectDisableItemsLower('.$incId.',this.value);">';
        $client_combo .= '<option value="">--Please Select service name--</option>';
        for ($i = 0; $i < $arrayCount; $i++) {
            if ($netRows[$i]->ID != '2') {
                $client_combo .= '<option value="' . $netRows[$i]->ID . '">' . $netRows[$i]->SERVICE_NAME . '</option>';
            }
        }

        $client_combo .= '</select></div>
            <div class="width532" id="descs_n_' . $incId . '">
                <input type="text" value="" autocomplete="off" id="desc_n_' . $incId . '" name="desc_n_' . $incId . '" />
            </div>
            <div id="amounts_n_' . $incId . '">
                <input type="text" value="" autocomplete="off" name="amount_n_' . $incId . '" id="amount_n_' . $incId . '"  onkeydown="javascript:maskInput();  notCopy(this.id);" />
            </div>
            <div class="iconblock" id="ps_n_' . $incId . '">
                <a href="javascript:void();" class="moreicon" id="p_n_' . $incId . '" onClick="appendNewEntryDw();">
                    <img src="' . IMAGE_PATH . 'plus.gif" alt="more" /></a>
                 <a href="javascript:void();" class="moreicon" id="d_n_' . $incId . '" onClick="removeNewEntryDw(' . $incId . ');">
                    <img src="' . IMAGE_PATH . 'minus.gif" alt="more" /></a>
           </div>';
        echo $client_combo;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function sendinvoiceAction() {
        if (isset($_POST)) {
            $ns = new Zend_Session_Namespace('AGLconSol');
            /**
             * Call Object
             * Get Skeys
             * Get returnType
             */
            $Common = new Common();
            $sKeys = $Common->getSkeys();
            $returnType = $Common->getreturnType();

            /**
             * Get Data from session
             */
            $ns = new Zend_Session_Namespace('AGLconSol');
            $userName = $ns->USER_EMAIL;
            $password = $ns->PASSWORD;

            $userId = $ns->USER_ID;
            $roleId = $ns->USER_ROLE;

            $sdData = $_POST;
            $userId = $ns->USER_EMAIL;
            $email_post = $userId . ',' . $sdData['email'];
            $length = strlen($email_post);
            $check_comma = substr($email_post, $length, 1);

            if ($check_comma == ",") {
                $mEmail_post = substr($email_post, 0, $length - 1);
            } else {
                $mEmail_post = substr($email_post, 0, $length);
            }

            $Email = explode(",", $mEmail_post);
            $invoiceId = $sdData['I'];
            $clientId = $sdData['qs'];
            $uId = $userId = $sdData['u'];



            $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId;
            $eInvoices = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient));

            //$eInvoices = $this->view->eInvoices = $Invoice->getInvoiceInfoByInvoiceId($invoiceId);

            $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Details-Byi-Cu/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/clientId/' . $clientId . '/uId/' . $uId;
            $dInvoices = $this->view->dInvoices = json_decode($Common->cUrlCall($cClient));

            //$dInvoices = $this->view->dInvoices = $Invoice->getInvoiceDetailsByiCu($invoiceId, $clientId, $uId);

            $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
            $this->view->publishers = $publishers = json_decode($Common->cUrlCall($cClient));

            // $publishers = $Invoice->getPublisherList();
            foreach ($publishers as $publisherm) {
                $publisher[$publisherm->ID] = $publisherm->PUBLISHER_DESC;
            }

            $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Creator-Emails-By-Created-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $uId;
            $CreatorEmails = $this->CreatorEmails = json_decode($Common->cUrlCall($cClient));

            //$CreatorEmails = $this->CreatorEmails = $Invoice->getInvoiceCreatorEmailsByCreatedId($uId);
            $sPath = $this->view->sPath = $this->getRootDocumentPath();
            //$publishers = $this->view->publishers = $Invoice->getPublisherList();

            $html = $this->view->partial('invoice/invoice.phtml', array('eInvoices' => $eInvoices, 'dInvoices' => $dInvoices, 'publishers' => $publishers, 'sPath' => $sPath));
            $tmphtml = $this->getPdf($html, $eInvoices[0]->PROFORMA_INVOICE_ID);

            $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Pmo-Admin-Account-Emails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType;
            $Emails = json_decode($Common->cUrlCall($cUrl));

            //$Emails = $Invoice->getPmoAdminAccountEmails();
            $emailUser = $ns->USER_EMAIL;
            for ($i = 0; $i < count($Emails); $i++) {
                $aapc[$i] = $Emails[$i]->USER_EMAIL;
            }

            $aapc[] = $emailUser;
            $custMessage = $Common->custMessage();

            //$clientInfoById = $Invoice->getClientIdById($sdData['qs']);
            $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $sdData['qs'];
            $clientInfoById = json_decode($Common->cUrlCall($cUrl));



            $html = $this->view->partial('invoice/semail.phtml', array('eInvoices' => $eInvoices, 'clientInfoById' => $clientInfoById, 'eMail' => $emailUser, 'custMessage' => $custMessage, 'sPath' => $sPath));


              if (count($Email) > 1) {
              $mail = new Zend_Mail();
              $mail->setType(Zend_Mime::MULTIPART_RELATED);
              $mail->setBodyHtml($html);
              //$emailUser
              $mail->setFrom('invoice@adv8.co');
//              for ($m = 0; $m < count($aapc); $m++) {
//              $mail->addTo($aapc[$m]);
//              }
//              $mail->addTo($emailUser);
              for ($n = 0; $n < count($Email); $n++) {
              $mail->addTo($Email[$n]);
              }
              $mail->addBcc('accounts@adglobal360.com');

              //$mail->addBcc('shruti.kakkar@adglobal360.com');
              $mail->addBcc('vishnu.dass@adglobal360.com');
              $mail->setSubject('Invoice');
              $mail->type = 'application/pdf';
              $test = file_get_contents($tmphtml);
              $file = $mail->createAttachment($test);
              $file->filename = $clientInfoById[0]->COMPANY_NAME . '.pdf';
              $mail->send();
              } else {
              $mail = new Zend_Mail();
              $mail->setType(Zend_Mime::MULTIPART_RELATED);
              $mail->setBodyHtml($html);
              $mail->setFrom($emailUser);
//              for ($m = 0; $m < count($aapc); $m++) {
//              $mail->addTo($aapc[$m]);
//              }
//              $mail->addTo($emailUser);
              $mail->addTo($Email);

        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
              $mail->setSubject('Invoice');
              $mail->type = 'application/pdf';
              $test = file_get_contents($tmphtml);
              $file = $mail->createAttachment($test);
              $file->filename = $clientInfoById[0]->COMPANY_NAME . '.pdf';
              $mail->send();
              }

            $statusMode = '1';
            $cClient = $Common->getBrodcasterUrl() . 'Invoice/change-Status-Of-Invoice-Send/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode . '/Iid/' . $eInvoices[0]->ID . '/cId/' . $eInvoices[0]->cId . '/created_by/' . $eInvoices[0]->CREATED_BY;
            $rowsTest = json_decode($Common->cUrlCall($cClient));

echo $tmphtml;
exit;
            //$Invoice->changeStatusOfInvoiceSend($statusMode, $eInvoices);
            $this->_redirect('Invoice/index');
        }
        $this->_redirect('Invoice/index');
    }

    public function submitpayrequestAction() {
        if (isset($_POST)) {
            $ns = new Zend_Session_Namespace('AGLconSol');
            /**
             * Call Object
             * Get Skeys
             * Get returnType
             */
            $Common = new Common();
            $sKeys = $Common->getSkeys();
            $returnType = $Common->getreturnType();

            /**
             * Get Data from session
             */
            $ns = new Zend_Session_Namespace('AGLconSol');
            $userName = $ns->USER_EMAIL;
            $password = $ns->PASSWORD;

            $userId = $ns->USER_ID;
            $roleId = $ns->USER_ROLE;

            $userId = $ns->USER_EMAIL;
            $rData = $_POST;

            $cClient = $Common->getBrodcasterUrl() . 'Invoice/request-Insert/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId;
            $rowsTest = json_decode($Common->cUrlCallWithPost($cClient, $rData));

            //$Invoice->requestInsert($rData);


            $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Pmo-Admin-Account-Emails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType;
            $Emails = json_decode($Common->cUrlCall($cUrl));

            //$Emails = $Invoice->getPmoAdminAccountEmails();
            //$Invoice = new Invoice();
            //$ClientAndUser = new ClientAndUser();
            //$cCommon = new Common();
            $emailUser = $ns->USER_EMAIL;
            for ($i = 0; $i < count($Emails); $i++) {
                $aapc[$i] = $Emails[$i]->USER_EMAIL;
            }

            $aapc[] = $emailUser;
            $custMessage = $Common->custMessage();
            $sPath = $this->view->sPath = $this->getRootDocumentPath();
            $emailUser = $ns->USER_EMAIL;

            $html = $this->view->partial('invoice/reqpayment.phtml', array('rData' => $rData, 'eMail' => $emailUser, 'custMessage' => $custMessage, 'sPath' => $sPath));


            $mail = new Zend_Mail();
            $mail->setType(Zend_Mime::MULTIPART_RELATED);
            $mail->setBodyHtml($html);
            $mail->setFrom($emailUser);
            $mail->addTo($aapc);
            $mail->setSubject('Payment Request');
            $mail->send();
			
			
						$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($html);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = 'Payment Request';
			$arrEmail['from'] = $emailUser;
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = implode(",", $aapc);
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 

            $statusMode = '4';
            $cClient = $Common->getBrodcasterUrl() . 'Invoice/change-Status-Of-Invoice-Send/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/statusMode/' . $statusMode . '/Iid/' . $rData['InvoiceId'] . '/cId/' . $rData['cId'] . '/created_by/' . $rData['created_by'];
            $rowsTest = json_decode($Common->cUrlCall($cClient));
            /**
              $db = Zend_Registry::get('DB_C');
              $sql = "UPDATE cust_invoices SET INVOICE_STATUS ='4', INVOICE_PAYMENT_STATUS = '4' WHERE ID ='" . $rData['InvoiceId'] . "' AND CLIENT_ID='" . $rData['cId'] . "' AND CREATED_BY ='" . $rData['created_by'] . "'";
              $db->query($sql);
             *
             */
        }
        $this->_redirect('Invoice/index');
    }

    public function previewAction() {

        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $Id = $this->view->Id = $ns->USER_ID;
        $userId = $ns->USER_ID;

        if (!$userId) {
            $this->redirect('Login/index');
        }
        $this->_helper->layout->setLayout('invoice_edit');
        $userId = $ns->USER_EMAIL;

        $invoiceId = $this->view->invoiceId = $this->_request->getparam('I');
        $clientId = $this->view->clientId = $this->_request->getparam('qs');

        $uId = $this->view->userId = $this->_request->getparam('u');
        $Id = $this->view->Id = $ns->USER_ID;
        $role = $ns->ROLE;


        $sPath = $this->view->sPath = $this->getRootDocumentPath();

    $brodcastUrl = $Common->getBrodcasterUrl();



        $cClient =  $brodcastUrl. 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId; 
        $invoices = json_decode($Common->cUrlCall($cClient));

//print_R($invoices);exit;

        //$invoices = $Invoice->getInvoiceInfoByInvoiceId($invoiceId);


        $cClient = $brodcastUrl . 'Invoice/get-User-Info-Array/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/createdBy/' . $invoices[0]->CREATED_BY;
        $userInfo = (array) json_decode($Common->cUrlCall($cClient));
        $userInfo = explode('~', $userInfo[0]);



        $userNameFromEmail = substr($userInfo[1], 0, strpos($userInfo[1], '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);
        $invoices[0]->USER_NAME = $userName1 = $this->view->userName = $sUserName;
        $invoices[0]->USER_BY = $userInfo[0];


        $this->view->eInvoices = $invoices;


        $cClient = $brodcastUrl . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->publishers = json_decode($Common->cUrlCall($cClient));

        //$this->view->publishers = $Invoice->getPublisherList();


        $cClient = $brodcastUrl . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->services = json_decode($Common->cUrlCall($cClient));

        //$this->view->services = $Invoice->getServiceName();


        $cClient = $brodcastUrl . 'Invoice/get-Invoice-Details-Byi-Cu/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/clientId/' . $clientId . '/uId/' . $uId;
        $rows = $this->view->dInvoices = json_decode($Common->cUrlCall($cClient));

        //$rows = $this->view->dInvoices = $Invoice->getInvoiceDetailsByiCu($invoiceId, $clientId, $uId);


        $cClient = $brodcastUrl . 'Invoice/get-Client-Id-By-User-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->clients = json_decode($Common->cUrlCall($cClient));


        //$this->view->clients = $Invoice->getClientIdByUserId($role, $Id);


        $cClient = $brodcastUrl . 'Invoice/get-Status-Array/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->status = json_decode($Common->cUrlCall($cClient));

        //$this->view->status = $Invoice->getStatusArray();
    }

    public function payreqAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $this->_helper->layout->setLayout('invoice_edit');
        $userId = $ns->USER_ID;
        if (!$userId) {
            $this->redirect('Login/index');
        }
        $invoiceId = $this->_request->getparam('I');
        $clientId = $this->_request->getparam('qs');
        $userId = $this->_request->getparam('u');

        $Id = $this->view->Id = $ns->USER_ID;
        $role = $this->view->Role = $ns->ROLE;
        $userId = $ns->USER_EMAIL;

        if (!$userId) {
            $this->redirect('Login/index');
        }



        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId;
        $invoices = json_decode($Common->cUrlCall($cClient));


        //$invoices = $Invoice->getInvoiceInfoByInvoiceId($invoiceId);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-User-Info-Array/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/createdBy/' . $invoices[0]->CREATED_BY;
        $userInfo = (array) json_decode($Common->cUrlCall($cClient));
        $userInfo = explode('~', $userInfo[0]);



        $userNameFromEmail = substr($userInfo[1], 0, strpos($userInfo[1], '@'));
        $userNameArray = explode('.', $userNameFromEmail);
        $sUserName = ucfirst($userNameArray[0]) . ' ' . ucfirst($userNameArray[1]);
        $invoices[0]->USER_NAME = $userName1 = $this->view->userName = $sUserName;
        $invoices[0]->USER_BY = $userInfo[0];


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Status-Array/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $status = json_decode($Common->cUrlCall($cClient));


        //$status = $Invoice->getStatusArray();
        if (array_key_exists($invoices[0]->INVOICE_STATUS, $status)) {
            $invoices[0]->INVOICE_STATUS_WORD = $status[$invoices[0]->INVOICE_STATUS];
        }

        $this->view->eInvoices = $invoices;


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Cheque-Status/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/clientId/' . $clientId;
        $this->view->address = json_decode($Common->cUrlCall($cClient));

        //$this->view->address = $Invoice->getChequeStatus($clientId);


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Client-Id-By-User-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->clients = json_decode($Common->cUrlCall($cClient));

        //$this->view->clients = $Invoice->getClientIdByUserId($role, $Id);
    }

    public static function getPdfOriginal($html, $client_Id) {

        $pdfCreator = new WKPDF();
        $pdfCreator->set_html($html);
        $pdfCreator->set_orientation(WKPDF::$PDF_PORTRAIT);
        $pdfCreator->render();

        # creating a temp path
        $basePath = $basePath = Folder . "common/wkhtml/Invoices/Original";
        if (!is_dir($basePath)) {
            mkdir($basePath);
        }

        $filename = '';
        do {
            $filename = $basePath . '/' . $client_Id . '_' . mt_rand() . '_Invoice.pdf';
        } while (file_exists($filename));

        $pdfCreator->output(WKPDF::$PDF_SAVEFILE, $filename);

        return $filename;
    }

    public function getPdf($html, $proformaId) {

        $pdfCreator = new WKPDF();
        $pdfCreator->set_html($html);
        $pdfCreator->set_orientation(WKPDF::$PDF_PORTRAIT);

        $pdfCreator->render();

        # creating a temp path
        $basePath = Folder . "common/wkhtml/Invoices/Proforma";
        if (!is_dir($basePath)) {
            mkdir($basePath);
        }

        $filename = '';
        do {
            $filename = $basePath . '/' . $proformaId . '_' . mt_rand() . '.pdf';
        } while (file_exists($filename));
        $pdfCreator->output(WKPDF::$PDF_SAVEFILE, $filename);
        return $filename;
    }

    /*     * *
     * Ledger
     */

    public function ledgerlistAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('ledgerlayout');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $this->view->username = $userName;
        $this->view->password = $password;
        $this->view->skeys = $sKeys;
        $this->view->returntype = $returnType;
        $this->view->userid = $userId;
        $this->view->roleid = $roleId;

        $InId = $this->_request->getparam('I');
        $uId = $this->_request->getparam('uId');
        $ns->uId = $uId;



        $cClient = $Common->getBrodcasterUrl() . 'Invoice/last-Diff/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $lastDiff = json_decode($Common->cUrlCall($cClient), true);
        $this->view->lastDiff = @$lastDiff[0]['NET_DEFF'];


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Count/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->getCount = $getCount = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Adv-Inv/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->advInv = $advInv = json_decode($Common->cUrlCall($cClient), true);




        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->shaddowInvoice = $response = json_decode($Common->cUrlCall($cClient), true);

        $clientId = $response[0]['CLIENT_ID'];
        $createdBy = $response[0]['CREATED_BY'];

        $this->view->clientid = $clientId;

        $profileInfo = $Common->getBrodcasterUrl() . 'Invoice/get-Profile-By-Client-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/clientId/' . $clientId . '/createdBy/' . $createdBy;
        $this->view->profile = json_decode($Common->cUrlCall($profileInfo), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->detailsInvoice = $response1 = json_decode($Common->cUrlCall($cClient), true);

        foreach ($response1 as $res) {
            $serviceArray[] = $res['SERVICE_ID'];
            $publishersArray[] = $res['PUBLISHER_ID'];
        }

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $this->view->services = json_decode($Common->cUrlCall($cClient), TRUE);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/';
        $this->view->ledgerInvoice = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/';
        $this->view->ledgerdetailsInvoice = $response1 = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledger-Total-Paid-Amount/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->totalPaidAmount = $paidAmountResponse = json_decode($Common->cUrlCall($cClient), true);

        $this->view->paymentStatus = $paymentStatus = array('1' => 'Payment Received', '2' => 'Paid', '4' => 'Partial Payment', '5' => 'Cheque Realization', '6' => 'Advance Invoice', '7' => 'Credit', '8' => 'Credit Approved', '9' => 'Credit Paid', '10' => 'Payment Approved', '11' => 'Payment Declined');
        $this->view->paymentMode = $paymentMode = array('1' => 'Cash', '2' => 'DD', '3' => 'Transfer', '4' => 'Cheque', '5' => 'EBS', '6' => 'First Data');

        $creditCall = $Common->getBrodcasterUrl() . 'Invoice/ledger-Total-Credit-Amount/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->totalCreditAmount = $totalCreditAmount = json_decode($Common->cUrlCall($creditCall), true);

        $cUrl = $Common->getBrodcasterUrl() . 'Project/get-Project-And-Gc-Id-By-Client-Id-And-Publisher-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/clientId/' .$response[0]['CLIENT_ID']. '/roleId/' . $roleId . '/publisherId/2';
        $this->view->responsePub = json_decode($Common->cUrlCall($cUrl),true);
    }


    public function payrequestsubmitAction() {
        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $InId = $_POST['invoice_id'];
        $clientId = $_POST['client_id'];

        $postData = $_POST;


        /**
         * Check there is any credit
         */


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinsert/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $response = $Common->cUrlCallWithPost($cClient, $postData);

        $fKeyId = $response;

        /* Send Email to CM that payment is added. Please bifrucate. */

        $subject = 'Payment Added';
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $ns->uId;
        $EmailCreater = json_decode($Common->cUrlCall($cClient));






        $data = $this->generalInvoiceInfo($clientId,$InId,$fKeyId);
        $data['heading'] = $subject;
        $mailHtml = $this->view->partial('invoice/notifications.phtml', array('content' => $data,'invoiceId'=>$InId));
        $mail = new Zend_Mail();
        $mail->setType(Zend_Mime::MULTIPART_RELATED);
        $mail->setBodyHtml($mailHtml);
        $mail->setFrom('invoice@adv8.co');

        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
        $mail->addTo('pawan.dhingra@adglobal360.com');
        //$mail->addTo('himmat.singh@adglobal360.com');
		$mail->addTo('accounts@adglobal360.com');
		//$mail->addTo('sushant.vashisht@adglobal360.com');
        $mail->addTo($EmailCreater[0]->USER_EMAIL);
        $mail->setSubject($subject);
        //$mail->send();
		
		$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($mailHtml);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = $subject;
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = $EmailCreater[0]->USER_EMAIL.',pawan.dhingra@adglobal360.com,accounts@adglobal360.com';
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			
			
        $this->_redirect('Invoice/ledgerlist/I/'.$InId);
    }

    public function actionsallAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('ledgerlayout');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $id = "'";
        $id .='popup2';
        $id .= "'";

        $none = "'";
        $none .= 'none';
        $none .= "'";


        /**
         * Call Invoice Functions
         */
        $InId = $this->_request->getparam('inId');
        $paymentId = $this->_request->getparam('paymentId');
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->shaddowInvoice = $shaddowInvoice = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->detailsInvoice = $detailsInvoice = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $services = json_decode($Common->cUrlCall($cClient), TRUE);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/' . $paymentId;
        $ledgerInvoice = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/' . $paymentId;
        $this->view->ledgerdetailsInvoice = $ledgerdetailsInvoice = json_decode($Common->cUrlCall($cClient), true);

        $getgcidbreakup = $Common->getBrodcasterUrl() . 'Invoice/getgcidbreakup/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId.'/InId/'.$InId.'/clientId/'.$ledgerInvoice[0]['CLIENT_ID'].'/paymentId/' . $paymentId;
        $resgetgcidbreakup =  json_decode($Common->cUrlCall($getgcidbreakup),true);

        $publishersArray = array('1' => 'Facebook', '2' => 'Google', '3' => 'Yahoo', '4' => 'Msn');
        foreach ($detailsInvoice as $details) {
            if ($details['PUBLISHER_ID'] != '0') {
                $Publishers[] = $details['PUBLISHER_ID'];
            }
            if ($details['SERVICE_ID'] != '2') {
                $Services[] = $details['SERVICE_ID'];
            }
        }

        if (@$Publishers > 0) {
            $PublishersString = implode(',', $Publishers);
        } else {
            $PublishersString = '0';
        }


        if (@$Services > 0) {
            $ServicesString = implode(',', $Services);
        } else {
            $ServicesString = '0';
        }
        $allowedStatus = array('1','2','3','4','5','6','8','9');
        $readOnly = ($ledgerInvoice[0]['PAYMENT_STATUS'] == 8 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 9 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 10) ? 'readonly="readonly"' : '';
        $disabled = ($ledgerInvoice[0]['PAYMENT_STATUS'] == 8 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 9 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 10) ? 'disabled="disabled"' : '';

		if($ledgerInvoice[0]['PAYMENT_STATUS'] == 2 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 4 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 10){
            $displayNone = 'style="display:block;"';
        }else{
            $displayNone = 'style="display:none;"';
        }
		$selectDisabled = '';
        if($roleId == 5) {
            $selectDisabled = 'disabled';
        }
        $tpl = '';
        $tpl .='<div id="popup">
                    <a href="javascript:void(0);" class="actionclose" onclick="document.getElementById(' . $id . ').style.display = ' . $none . ';"><img src="'.ROOT.'common/images/close.png" /></a>
                    <div class="popupinner">
                        <form action="/Invoice/actionbutton" name="submitPaymentDetails" id="submitPaymentDetails" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="paymentid" value="'.$paymentId.'" />
                            <input type="hidden" name="clientId" value="'.$shaddowInvoice[0]['CLIENT_ID'].'"/>
                            <h2>Payment Details';
                            if((($roleId == 1) || ($roleId == 3)) && in_array($ledgerInvoice[0]['PAYMENT_STATUS'], $allowedStatus)) {
                                $tpl .= '<span class="approvalstatus" '.$displayNone.'><a style="margin-right:5px;color:green;" onclick="approvalStatus('.$InId.','.$paymentId.',10,'.$ledgerInvoice[0]['CLIENT_ID'].');">Approve</a><a style="color:red;" onclick="approvalStatus('.$InId.','.$paymentId.',11,'.$ledgerInvoice[0]['CLIENT_ID'].');">Decline</a></span>';
                            }
                    $tpl .= '</h2>
                            <div class="pop-topsection">
                                <div class="left-side">
                                    <div class="topsection-row">
                                        <label>Actual Invoice No </label> --';
                                        if($roleId == 1 || $roleId == '3' || $roleId == '13' ){
                                            $tpl .= '<input type="text" name="actualInvoiceId"  id="actualInvoiceId" value="' . $ledgerInvoice[0]['ACTUAL_INVOICE_ID'] . '" class="topsection-input" />';
                                        }else{
                                            $tpl .= '<input type="text" name="actualInvoiceId" readonly="readonly" id="actualInvoiceId" value="' . $ledgerInvoice[0]['ACTUAL_INVOICE_ID'] . '" class="topsection-input" />';
                                        }
                                     $tpl .= '</div>
                                    <div class="topsection-row">
                                        <label>Invoice Date </label> --
                                        <input type="text" name="invoiceDate" id="invoiceDate" readonly="readonly" value="' . $ledgerInvoice[0]['INVOICE_DATE'] . '" class="topsection-input" />
                                    </div>';
                                    if($ledgerInvoice[0]['PAYMENT_STATUS'] == 7 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 8) {
                                $tpl .='<div class="topsection-row">
                                        <label>Expected Date </label> --
                                        <input type="text" name="expectedDate" id="expectedDate" value="' . $ledgerInvoice[0]['EXPECTED_DATE'] . '" class="topsection-input" />
                                    </div>';
                                    } else {
                                        $tpl .= '<input type="hidden" name="expectedDate" id="expectedDate" value="" />';
                                    }
                                $tpl .= '<div class="topsection-row">
                                        <label>Payment Status</label> --
                                        <select class="selectbox" name="payment_status_cm" id="payment_status_cm">
                                            <option value="1"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 1) { $tpl .= 'selected="selected"'; } $tpl .='>Payment Rec.</option>
                                            <option value="2"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 2) { $tpl .= 'selected="selected"'; } $tpl .='>Paid</option>
                                            <option value="4"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 4) { $tpl .= 'selected="selected"'; } $tpl .='>Partial Pay.</option>
                                            <option value="5"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 5) { $tpl .= 'selected="selected"'; } $tpl .='>Cheque Under Realization</option>
                                            <option value="6"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 6) { $tpl .= 'selected="selected"'; } $tpl .='>Advance Inv.</option>
                                            <option value="7"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 7) { $tpl .= 'selected="selected"'; } $tpl .='>Credit</option>
                                            <option value="8"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 8) { $tpl .= 'selected="selected"'; } $tpl .='>Credit Approved</option>
                                            <option value="9"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 9) { $tpl .= 'selected="selected"'; } $tpl .='>Credit Paid</option>';
                                                 if($roleId == 1 || $roleId == '3' || $roleId == '13' ){
                                            $tpl .='<option value="10"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 10) { $tpl .= 'selected="selected"'; } $tpl .='>Payment Approved</option>';
                                                }
                                            $tpl .='<option value="12"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 12) { $tpl .= 'selected="selected"'; } $tpl .='>Open Invoice</option>
                                        </select>
                                    </div>';
                                    if($ledgerInvoice[0]['PAYMENT_STATUS'] == 7 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 8) {
                                        $tpl .= '<input type="hidden" name="paymentModeCm" id="paymentModeCm" value="" />';
                                    } else {
                                        $tpl .= '<div class="topsection-row">
                                        <label>Payment Mode</label> --
                                        <select class="selectbox" name="paymentModeCm" id="paymentModeCm" '.$readOnly.'>
                                            <option value="1"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 1) { $tpl .= 'selected="selected"'; } $tpl .='>Cash</option>
                                            <option value="2"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 2) { $tpl .= 'selected="selected"'; } $tpl .='>DD</option>
                                            <option value="3"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 3) { $tpl .= 'selected="selected"'; } $tpl .='>Transfer</option>
                                            <option value="4"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 4) { $tpl .= 'selected="selected"'; } $tpl .='>Cheque</option>
                                            <option value="5"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 5) { $tpl .= 'selected="selected"'; } $tpl .='>EBS</option>
                                            <option value="6"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 6) { $tpl .= 'selected="selected"'; } $tpl .='>First Data</option>
                                        </select>
                                    </div>';
                                    }
                        $tpl .= '
                           <div class="topsection-row">
                                        <label>Bank Charges/CC</label> --
                                        <span>'.number_format($ledgerInvoice[0]['BANK_CHARGES']).'</span>
                            </div>
                            <div class="topsection-row">
                                        <label>Reverse Cal.</label> --
                                        <span id="rc"></span>
                            </div>
                            </div>
                                <div class="right-side">
                                    <label>Remarks</label>
                                    <textarea class="topsection-textarea" '.$readOnly.'>' . $ledgerInvoice[0]['REMARKS'] . '</textarea>
                                </div>
                            </div>
                       <div class="middle-box">
                            <div class="invoice-box">
                                <div class="invoice-inner">
                                    <h3>Shadow Invoice Details</h3>
                                        <div class="pricebox">';
                                        foreach ($detailsInvoice as $details) {
                                            if (array_key_exists($details['PUBLISHER_ID'], $publishersArray)) {
                                                if ($details['PUBLISHER_ID'] != '0') {
                                                    $tpl .='<div class="price-row">
                                                                <label>' . $publishersArray[$details['PUBLISHER_ID']] . '</label> -- <label>' . number_format($details['INVOICE_DETAILS_AMOUNT']) . '</label></div>';
                                                }
                                            }if ($details['SERVICE_ID'] != '2') {
                                                $tpl .='<div class="price-row">';
                                                foreach ($services as $service) {
                                                    if ($service['ID'] == $details['SERVICE_ID']) {
                                                        $tpl .='<label>' . $service['SERVICE_SHORT_NAME'] . '</label> -- <label>' . number_format($details['INVOICE_DETAILS_AMOUNT']) . '</label>';
                                                    }
                                                }
                                                $tpl .='</div>';
                                            }
                                        }
                                        $tpl .='<div class="price-row">
                                                    <label>Service tax</label> -- <label>' . number_format($shaddowInvoice[0]['SERVICE_TAX']) . '</label>
                                                </div>
                                <div class="price-row">
                                   <label class="total">Total</label> -- <label class="total">' . number_format($shaddowInvoice[0]['AMOUNT']) . '</label>
                                    <input type="hidden" id="performa_id" value="' . $shaddowInvoice[0]['PROFORMA_INVOICE_ID'] . '" name="performa_id"/>';
                $tpl .='</div></div></div></div>';

                $tpl .='<div class="amountbox">
                <div class="amount-heading">
                    <ul>
                        <li><span>Amount Received</span> <input '.$readOnly.' id="total_recived" name="total_recived" type="text" class="amount-input" value="' . number_format($ledgerInvoice[0]['TOTAL_AMOUNT_RECIVED']) . '" /> </li>
                        <li><span>Allowed Payment</span> <input '.$readOnly.'  readonly="readonly"  id="budget_allowed" name="budget_allowed" type="text" class="amount-input" value="' . number_format($ledgerInvoice[0]['TOTAL_BUDGET_ALLOWED']) . '" />
                        <input id="budget_alloweduc" name="budget_alloweduc" type="hidden" class="amount-input" value="' . $ledgerInvoice[0]['TOTAL_BUDGET_ALLOWED'] . '" />
                        </li>
                        <li><span>Net Difference </span><input '.$readOnly.'  readonly="readonly"  id="net_diff" name="net_diff" type="text" class="amount-input" value="' . number_format($ledgerInvoice[0]['NET_DEFF']) . '" /></li>
                            <input id="invoice_id" name="invoice_id" type="hidden" class="amount-input" value="' . $ledgerInvoice[0]['INVOICE_ID'] . '" />
                    </ul>
                </div>
                <div class="amount-structure">
                    <div class="pricebox">
                    <input type="hidden" value="' . $ServicesString . '" name="serviceIdHidden" id="serviceIdHidden"/>
                    <input type="hidden" value="' . $PublishersString . '" name="publisherIdHidden" id="publisherIdHidden"/>';

                    foreach ($ledgerdetailsInvoice as $details) {
                        if (array_key_exists($details['PUBLISHER_ID'], $publishersArray)) {
                            $tpl .= '<div class="price-row">
                                        <label>' . $publishersArray[$details['PUBLISHER_ID']] . '</label> -- <label><input type="text" '.$readOnly.' name="publisher_agl_' . $details['PUBLISHER_ID'] . '" id="publisher_agl_' . $details['PUBLISHER_ID'] . '" value="' . $details['AMOUNT'] . '" class="topsection-input" onkeyup="sumValue(this.value,' . $details['PUBLISHER_ID'] . '); reverseCalculationForPPC(this.value,' . $details['PUBLISHER_ID'] . ');" /></label>
                                    </div>';
                            $tpl .= '<div class="price-row">
                                        <label>AGL Charge for ' . $publishersArray[$details['PUBLISHER_ID']] . '</label> -- <label><input  readonly="readonly"  type="text" '.$readOnly.' name="charge_agl_' . $details['PUBLISHER_ID'] . '" id="charge_agl_' . $details['PUBLISHER_ID'] . '" value="' . $details['AGL_CHARGES'] . '" class="topsection-input"  /></label>
                                            <input type="hidden" name="agl_method_' . $details['PUBLISHER_ID'] . '" id="agl_method_' . $details['PUBLISHER_ID'] . '"  value="' . $details['METHODS'] . '"/>
                                            <input type="hidden" name="agl_percentage_' . $details['PUBLISHER_ID'] . '" id="agl_percentage_' . $details['PUBLISHER_ID'] . '"  value="' . $details['AGL_CHARGES_PERCENTAGE'] . '"/>
                                            <input type="hidden" name="getAglCharge" value="" id="getAglCharge"/>
                                    </div>';
                        }
                    if ($details['SERVICE_ID'] != '2') {
                        foreach ($services as $service) {
                            if ($service['ID'] == $details['SERVICE_ID']) {
                                $tpl .= '<div class="price-row">
                                    <label>' . $service['SERVICE_SHORT_NAME'] . '</label> -- <label><input type="text" name="service_agl_' . $service['ID'] . '" id="service_agl_' . $service['ID'] . '" value="' . $details['AMOUNT'] . '" class="topsection-input" onkeyup="calculateServiceTax(this.value,' . $service['ID'] . ');  reverseCalculationForNONPPC(this.value,' . $service['ID'] . ')"/></label>
                                </div>';
                            }
                        }
                    }
                }
                $tpl .= '<div class="price-row">
                            <label>Service tax</label> -- <label><input type="text" '.$readOnly.' name="service_tax" id="service_tax" value="' . $ledgerInvoice[0]['SERVICE_TAX'] . '" class="topsection-input" /></label>
                        </div>
                        <div class="price-row">
                            <label>TDS</label> -- <label><span id="tds">' . $ledgerInvoice[0]['TDS'] . '</span></label>
                        </div>
                        <div class="price-row">
                        <label>SubTotal</label> -- <label><input type="text" '.$readOnly.' readonly="readonly" name="sub_total" id="sub_total" value="' . $ledgerInvoice[0]['SUBTOTAL'] . '" class="topsection-input" /></label>
                        </div>
                        <div class="price-row">
                        <label class="total">Total</label> -- <label class="total"><input '.$readOnly.' readonly="readonly" type="text" name="total" id="total" value="' . $ledgerInvoice[0]['TOTAL_AMT'] . '" class="topsection-input" /></label>
                        </div>
                        <div class="savebtn">
                            <input type="button" '.$disabled.' name="submit" id="sbutton" value="Save" class="btn" disabled="'.$selectDisabled.'" onClick="return addPayemntCmDetails();" />
                            <img src="'.IMAGE_PATH.'ajax-loader.gif" id="ajaxPaymentForm" style="display:none;" />
                        </div>
                    </div>
                </div>
            </div>
         </div>
        </form>';
        $netVar = array();
        if ($PublishersString != '0') {
            $pubString = explode(',', $PublishersString);
            for ($i = 0; $i < count($pubString); $i++) {
                if (array_key_exists($pubString[$i], $publishersArray)) {
                    $netVar[] = $publishersArray[$pubString[$i]] . '_' . $pubString[$i] . '~' . $i;
                 $netCount[] = $i;}
            }
        }
        $explodeData = @implode(',', $netVar);
        $fertherExplode = @implode(',',$netCount);

        $netUp = array();
        if(@$resgetgcidbreakup['CODE'] != 'C-103'){
            foreach($resgetgcidbreakup as $resp){
                if($resp['UP'] !=""){
                    $up[] = $resp['UP'];
                    $dw[] = $resp['DW'];
                }
            }

            foreach($resgetgcidbreakup as $resp){
                $explode = explode('_',$resp['UP']);
                $netUp[] = $explode[0].'_'.$explode[1].'~'.$explode[2];
            }
        }
        @$up = implode(',', @$netUp);
        @$dw = implode(',', @$dw);
        if($PublishersString !='0'){
        $tpl .='<form action="/Invoice/publisherbreakup" id="publisherbreakup" name="publisherbreakup" method="post">
            <input type="hidden" name="paymentId" value="'.$paymentId.'" />
            <div class="pulishe-sec">
            <img src="'.IMAGE_PATH.'ajax-big-loader.gif" id="ajaxbigloader" style="display:none;position:absolute;left:45%;" />
            <h3>Publisers Budget</h3>';
            if($up !="") {
                $tpl .='<input type="hidden" id="upcount" name="upcount" value="'.$up.'"/>';
            } else {
              $tpl .='<input type="hidden" id="upcount" name="upcount" value="'.$explodeData.'"/>';
            }
            if($dw !="") {
             $tpl .='<input type="hidden" id="dwncount" name="dwncount" value="'.$dw.'"/>';
            } else {
                $tpl .='<input type="hidden" id="dwncount" name="dwncount" value="'.$fertherExplode.'"/>';
            }

            $tpl .='<input type="hidden" id="invoiceId" name="invoiceId" value="'.$shaddowInvoice[0]['ID'].'"/>
            <input type="hidden" name="clientId" value="'.$shaddowInvoice[0]['CLIENT_ID'].'"/>';

            if($PublishersString !='0'){
                $pubString = explode(',', $PublishersString);
                for($i=0;$i<count($pubString);$i++){
                    if(array_key_exists($pubString[$i],$publishersArray)){

                    $pub = "'";
                    $pub .=$publishersArray[$pubString[$i]];
                    $pub .="'";
                    if($pubString[$i] =='4'){
                      $pubID = '3';
                      $cUrl = $Common->getBrodcasterUrl() . 'Project/get-Project-And-Gc-Id-By-Client-Id-And-Publisher-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/clientId/' . $ledgerInvoice[0]['CLIENT_ID'] . '/roleId/' . $roleId . '/publisherId/'.$pubID;
                    }else{
                    $pubID = $pubString[$i];
                    $cUrl = $Common->getBrodcasterUrl() . 'Project/get-Project-And-Gc-Id-By-Client-Id-And-Publisher-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/clientId/' . $ledgerInvoice[0]['CLIENT_ID'] . '/roleId/' . $roleId . '/publisherId/'.$pubID;
                    }
                    $responsePub = json_decode($Common->cUrlCall($cUrl),true);
                    foreach ($ledgerdetailsInvoice as $details){
                     if($details['PUBLISHER_ID']==$pubString[$i]){
                    $tpl .='<h4>'.$publishersArray[$pubString[$i]].'&nbsp; (<span id="pub_gcid_'.$pubString[$i].'">'.number_format($details['AMOUNT']).'</span>)</h4>
                     <div class="servicebox"  id="main_append_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_0">';
                            if(@$resgetgcidbreakup['CODE'] != 'C-103'){
                               foreach($resgetgcidbreakup as $resp){
                                    if($resp['PUBLISHER_ID']==$pubString[$i]){
                                        $split = explode('_',$resp['UP']);
                                        $upt = "'";
                                        $upt .= $resp['UP'];
                                        $upt .="'";
                                        $tpl .='<div class="servicerow added clearfix" id="main_div_'.$resp['UP'].'">';
                                            if(@$responsePub['CODE'] != 'C-103'){
                                                $tpl .='<select name="gcproject_'.$resp['UP'].'" id="gjproject_'.$resp['UP'].'" class="budgetInfoChange">';
                                                $disable = '0';
                                                foreach($responsePub as $resPub){
                                                    if($resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID']==$resp['GCID']) {
                                                        $dGCID = $resPub['PUBLISHER_ACCOUNT_ID'];
                                                    }
                                                    $tpl .='<option value="'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'"'; if($resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID']==$resp['GCID']){ $tpl .='selected="selected"';} $tpl .='>'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'</option>';
                                                }
                                                $tpl .='</select>
                                                <input type="text" class="service-input" value="'.$resp['AMOUNT'].'" name="valueAmt_'.$resp['UP'].'" id="valueAmt_'.$resp['UP'].'" onkeyup="calculateGcidCharge('.$pubString[$i].','.$pub.','.$split[2].');"/>';
                                                if($pubString[$i] == 2 && ($roleId == 1 || $roleId == 3 || $roleId == 13)) {
                                                    $budgetInfo = $this->getBudgetInfo($dGCID);
                                                    $tpl .='<div class="servicerow-section clearfix">
                                                                <div class="servicerow-value">
                                                                    <span class="label">Budget :</span>
                                                                    <span class="value">'.number_format($budgetInfo['spendingLimit']['microAmount']/1000000).'</span>
                                                                </div>
                                                                <div class="servicerow-value">
                                                                    <span class="label">Start Date :</span>
                                                                    <span class="value">'.date('d M Y',  strtotime($budgetInfo['startDateTime'])).'</span>
                                                                </div>
                                                                <div class="servicerow-value last">
                                                                    <span class="label">End Date :</span>
                                                                    <span class="value">'.date('d M Y', strtotime($budgetInfo['endDateTime'])).'</span>
                                                                </div>
                                                                <a onclick="editBudget('.$dGCID.');" class="edit link">Edit</a>
                                                            </div>';
                                                }
                                                if($pubString[$i] == 2 && ($roleId == 5)) {
                                                    $tpl .='<div class="servicerow-section clearfix">
                                                                <div class="servicerow-value">
                                                                    <select style="width:178px;" class="checkactivity">
                                                                        <option>Check Account Last Activities</option>
                                                                        <option value="spent_'.$dGCID.'">Last 5 Spents</option>
                                                                        <option value="budget_'.$dGCID.'">Last 5 Budgets</option>
                                                                    </select>
                                                                </div>
                                                            </div>';
                                                }
												$tpl .='<div class="add-delete"><a href="Javascript:void(0);" class="add" onclick="addRow('.$pubString[$i].','.$pub.','.$ledgerInvoice[0]['CLIENT_ID'].');">Add</a>';
                                                $tpl .='<a href="Javascript:void(0);" class="delete" onclick="removeRow(' . $pubString[$i] . ',' . $pub . ',' . $upt. ');">Remove</a>';
                                                $tpl .='</div>';
                                             $tpl .='</div>';
                                                }else{
                                                $disable = '1';
                                        $tpl .='<strong>&nbsp;Please map publisher id for '.$publishersArray[$pubString[$i]].'</strong>';
                                            }
                                    }
                                }
                            }else{
                                $tpl .='<div class="servicerow added clearfix" id="main_div_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'">';
                                        if(@$responsePub['CODE'] !='C-103'){
                                            $tpl .='<select class="budgetInfoChange" name="gcproject_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'" id="gjproject_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'">';

                                                $disable = '0';
                                                foreach($responsePub as $resPub){
                                                $tpl .='<option value="'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'">'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'</option>';
                                               }
                                                $tpl .='</select>
                                                       <input type="text" class="service-input" value="" name="valueAmt_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'" id="valueAmt_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'" onkeyup="calculateGcidCharge('.$pubString[$i].','.$pub.','.$i.');"/>';

                                                if($pubString[$i] == 2 && ($roleId == 1 || $roleId == 3 || $roleId == 13)) {
                                                    $budgetInfo = $this->getBudgetInfo($responsePub[0]['PUBLISHER_ACCOUNT_ID']);
                                                    $tpl .='<div class="servicerow-section clearfix">
                                                                <div class="servicerow-value">
                                                                    <span class="label">Budget :</span>
                                                                    <span class="value">'.number_format($budgetInfo['spendingLimit']['microAmount']/1000000).'</span>
                                                                </div>
                                                                <div class="servicerow-value">
                                                                    <span class="label">Start Date :</span>
                                                                    <span class="value">'.date('d M Y',  strtotime($budgetInfo['startDateTime'])).'</span>
                                                                </div>
                                                                <div class="servicerow-value last">
                                                                    <span class="label">End Date :</span>
                                                                    <span class="value">'.date('d M Y', strtotime($budgetInfo['endDateTime'])).'</span>
                                                                </div>
                                                                <a href="#" class="edit link">Edit</a>
                                                            </div>';
                                                }
                                                if($pubString[$i] == 2 && ($roleId == 5)) {
                                                    $tpl .='<div class="servicerow-section clearfix">
                                                                <div class="servicerow-value">
                                                                    <select style="width:178px;" class="checkactivity">
                                                                        <option>Check Account Last Activities</option>
                                                                        <option value="spent_'.$responsePub[0]['PUBLISHER_ACCOUNT_ID'].'">Last 5 Spents</option>
                                                                        <option value="budget_'.$responsePub[0]['PUBLISHER_ACCOUNT_ID'].'">Last 5 Budgets</option>
                                                                    </select>
                                                                </div>
                                                            </div>';
                                                }
												$tpl .= '<div class="add-delete"><a href="Javascript:void(0);" class="add" onclick="addRow('.$pubString[$i].','.$pub.','.$ledgerInvoice[0]['CLIENT_ID'].');">Add</a></div>
                                                  </div>';
                                            }else{
                                                $disable = '1';
                                                $tpl .='<strong>&nbsp;Please map publisher id for '.$publishersArray[$pubString[$i]].'</strong>';
                                           }
                             }

                     $tpl .='</div>';
                    }
                    }
                    }
                }
            }

                $tpl .= '<div class="savebtn">';
                     if(@$disable == '0'){
                        $tpl .= '<input type="submit" value="Save" disabled="'.$selectDisabled.'" class="btn" id="save_break" '.$disabled.' />';
                     }else{
                       $tpl .= '<input type="submit" value="Save" class="btn"  disabled="disabled" />';
                     }
                $tpl .= '</div>
            </div>
        </div
        </form>';
        }
    $tpl .= '</div>
</div>';
        echo $tpl;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }


    public function getShortServiceNameByServiceId($serviceId){
        $sql = "select SERVICE_SHORT_NAME from admin_services where ID ='".$serviceId."'";
        $db=Zend_Registry::get('DB_A');
        $rows = $db->Fetchall($sql);
        return $rows[0]->SERVICE_SHORT_NAME;
    }


    public function actionbuttonAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('ledgerlayout');


        /**
         * Call Object
         * Get Skeys
         * Get returnType
         */
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        /**
         * Get Data from session
         */
        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        /**
         * Get parameters
         */
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $postData = $_POST;

        $invoiceId = $InId = $postData['invoice_id'];



        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgeredit/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $Common->cUrlCallWithPost($cClient, $postData);

        /**
         * Quick Book Integration
         */

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId;
        $eInvoices = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient), true);



		$cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Details-Byi-Cu/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/clientId/' . $postData['clientId'] . '/uId/' . $ns->USER_ID;
		$dInvoices = $this->view->dInvoices = json_decode($Common->cUrlCall($cClient), true);

        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $postData['clientId'];
        $clientInfoById = json_decode($Common->cUrlCall($cUrl));





        //$shortName = $Invoice->getShortServiceNameByServiceId($serviceId);


        $iData[0] = $clientInfoById[0]->COMPANY_NAME;
        $iData[1] = $postData['actualInvoiceId'];
        $iData[2] = 'PPC';
        $iData[3] = '1';
        $iData[4] = $postData['total'];

		$subject = "Bifurcation has been done !!";
        $data = $this->generalInvoiceInfo($postData['clientId'],$postData['invoice_id'],$postData['paymentId']);
        $mailHtml = $this->view->partial('invoice/bifercation.phtml', array('content' => $postData,'invoiceId'=>$postData['invoice_id'],'clientInfo'=>$clientInfoById,'subject'=>$subject,'email'=>$ns->USER_EMAIL));
        $mail = new Zend_Mail();
        $mail->setType(Zend_Mime::MULTIPART_RELATED);
        $mail->setBodyHtml($mailHtml);
        $mail->setFrom('invoice@adv8.co');

        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        //$mail->addBcc('vishnu.dass@adglobal360.com');
        $mail->addTo('pawan.dhingra@adglobal360.com');
        //$mail->addTo('himmat.singh@adglobal360.com');

		$mail->addTo('accounts@adglobal360.com');
		//$mail->addTo('sushant.vashisht@adglobal360.com');
        $mail->addTo($EmailCreater[0]->USER_EMAIL);
        $mail->setSubject($subject);
        //$mail->send();
		
		$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($mailHtml);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = $subject;
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = $EmailCreater[0]->USER_EMAIL.',pawan.dhingra@adglobal360.com, accounts@adglobal360.com';
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			
			
        $this->_redirect('Invoice/ledgerlist/I/'.$InId);

		$this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);


    }

    public function addCreditDetailsAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('ledgerlayout');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $postData = $_POST;

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/add-Credit-Details/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId;
        $response = $Common->cUrlCallWithPost($cClient, $postData);


        $subject = 'Credit Request';

        $data = $postData;

        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $postData['client_id'];
        $clientInfoById = json_decode($Common->cUrlCall($cUrl));

        $data['amountRecived'] = $postData['amountRecived'];
        $data['totalAllowedBudget'] = $postData['totalAllowedBudget'];
        $data['cr'] = '1';
        $data['remark'] = $postData['remark'];
        $data['heading'] = $subject;

        $mailHtml = $this->view->partial('invoice/addadvinvoice.phtml', array('content' => $data,'clientInfoById'=>$clientInfoById,'invoiceId'=>$data['invoice_id']));
        $mail = new Zend_Mail();
        $mail->setType(Zend_Mime::MULTIPART_RELATED);
        $mail->setBodyHtml($mailHtml);
        $mail->setFrom('invoice@adv8.co');
        $mail->addTo($ns->USER_EMAIL);

        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
        $mail->addTo('pawan.dhingra@adglobal360.com');
        //$mail->addTo('himmat.singh@adglobal360.com');

		//$mail->addTo('accounts@adglobal360.com');
		//$mail->addTo('sushant.vashisht@adglobal360.com');

        $mail->setSubject($subject);
        //$mail->send();
		
		$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($mailHtml);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = $subject;
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = $EmailCreater[0]->USER_EMAIL.',pawan.dhingra@adglobal360.com, accounts@adglobal360.com';
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			

        echo $response;
        die;
    }

    public function addrowgoogleAction() {
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $PuId = $this->_request->getparam('PuId');
        $pubLi = $this->_request->getparam('pubLi');
        $getCount = $this->_request->getparam('getCount');
        $cId = $this->_request->getparam('cId');


        $explodeVal = explode('~', $getCount);

        $length = count($explodeVal) - 1;

        $arrayLastElement = $explodeVal[$length] + 1;


        $cUrl = $Common->getBrodcasterUrl() . 'Project/get-Project-And-Gc-Id-By-Client-Id-And-Publisher-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/clientId/' . $cId . '/roleId/' . $roleId . '/publisherId/'.$PuId;
        $responsePub = json_decode($Common->cUrlCall($cUrl),true);

        $pub = "'";
        $pub .=$pubLi;
        $pub .="'";

        $arrayLast = "'";
        $arrayLast .=$arrayLastElement;
        $arrayLast .="'";

        $tpl = '';

        $tpl .='<div class="servicerow added clearfix" id="main_div_' . $pubLi . '_' . $PuId . '_' . $arrayLastElement . '">
        <select class="budgetInfoChange" name="gcproject_' . $pubLi . '_' . $PuId . '_' . $arrayLastElement . '" id="gcproject_' . $pubLi . '_' . $PuId . '_' . $arrayLastElement . '">';
            foreach($responsePub as $resPub){
            $tpl .='<option value="'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'">'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'</option>';
            }
        $tpl .='</select>
        <input type="text" class="service-input" name="valueAmt_' . $pubLi . '_' . $PuId . '_' . $arrayLastElement . '" id="valueAmt_' . $pubLi . '_' . $PuId . '_' . $arrayLastElement . '"  onkeyup="calculateGcidCharge('.$PuId.','.$pub.','.$arrayLastElement.');" />';

		if($PuId == 2 && ($roleId == 1 || $roleId == 3 || $roleId == 13)) {
                $budgetInfo = $this->getBudgetInfo($responsePub[0]['PUBLISHER_ACCOUNT_ID']);
                    $tpl .='<div class="servicerow-section clearfix">
                                <div class="servicerow-value">
                                    <span class="label">Budget :</span>
                                    <span class="value">'.number_format($budgetInfo['spendingLimit']['microAmount']/1000000).'</span>
                                </div>
                                <div class="servicerow-value">
                                    <span class="label">Start Date :</span>
                                    <span class="value">'.date('d M Y',  strtotime($budgetInfo['startDateTime'])).'</span>
                                </div>
                                <div class="servicerow-value last">
                                    <span class="label">End Date :</span>
                                    <span class="value">'.date('d M Y', strtotime($budgetInfo['endDateTime'])).'</span>
                                </div>
                                <a onclick="editBudget('.$resPub['PUBLISHER_ACCOUNT_ID'].');" class="edit link">Edit</a>
                            </div>';
            } else if($PuId == 2 && $roleId == 5) {
                $tpl .='<div class="servicerow-section clearfix">
                    <div class="servicerow-value">
                        <select style="width:178px;" class="checkactivity">
                            <option>Check Account Last Activities</option>
                            <option value="spent_'.$responsePub[0]['PUBLISHER_ACCOUNT_ID'].'">Last 5 Spents</option>
                            <option value="budget_'.$responsePub[0]['PUBLISHER_ACCOUNT_ID'].'">Last 5 Budgets</option>
                        </select>
                    </div>
                </div>';
            }
        $pub = "'";
        $pub .= $pubLi;
        $pub .="'";
        $tpl .='<div class="add-delete"><a href="Javascript:void(0);" class="add" onclick="addRow(' . $PuId . ',' . $pub . ','.$cId.');">Add</a><a href="Javascript:void(0);" class="delete" onclick="removeRow(' . $PuId . ',' . $pub . ',' . $arrayLast . ');">Remove</a>
        </div></div>';
        echo $tpl;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function updatePaymentStatusAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $invoiceId = $InId = $invoiceId = $this->_request->getparam('invoiceId');
        $fkey = $fKeyId = $this->_request->getparam('fKeyId');
        $status = $this->_request->getparam('status');
        $clientId = $this->_request->getparam('clientId');

        if (($roleId == '3' || $roleId == '1') && ($status == '10')) {

            $cCredit = $Common->getBrodcasterUrl() . 'Invoice/creditcheck/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
            $response = json_decode($Common->cUrlCall($cCredit), true);



            if (@$response['CODE'] != 'C-103') {
                $cCreditPay = $Common->getBrodcasterUrl() . 'Invoice/creditpaycheck/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
                $responsePay = json_decode($Common->cUrlCall($cCreditPay), true);
                $fKeyIdT = array();

                foreach ($response as $res) {
                    $fKeyIdT[] = $res['ID'];
                }
                $i = count($fKeyIdT);
                foreach ($responsePay as $resPay) {
                    $fKeyIdT[$i] = $resPay['ID'];
                    $i++;
                }

                $afKeyIdT = array();
                for($j=0;$j<count($fKeyIdT);$j++){
                    $afKeyIdT['ID_'.$j] = $fKeyIdT[$j];
                }



                $db = Zend_Registry::get('DB_I');
                $sqlM = "insert into my_invoice_table(sid)values('1')";
                $db->query($sqlM);
                $Table = 'my_invoice_table';
                $id = $this->getLastInsertIdInvoiceQb($Table);
                $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $clientId;
                $clientInfoById = json_decode($Common->cUrlCall($cUrl));
                $cCreditPayService = $Common->getBrodcasterUrl() . 'Invoice/getserpub/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/fkey/' . $fkey;
                $responsePayTest = json_decode($Common->cUrlCall($cCreditPayService), true);

               if($responsePayTest[0]['ACTUAL_INVOICE_ID']=='000000'){
                   die('Qb has not updated');
               }else{
                $pub = array();
                $ser = array();
                if (@$responsePayTest['CODE'] != 'C-103') {
                    foreach ($responsePayTest as $resTest) {
                        if ($resTest['SERVICE_ID'] == '2') {
                            $pub[] = $resTest['PUBLISHER_ID'];
                        }

                        if ($resTest['SERVICE_ID'] != '2') {
                            $ser[] = $resTest['SERVICE_ID'];
                        }
                    }
                }



                $postData['publisherHidden'] = implode(',', $pub);
                $postData['serviceHidden'] = implode(',', $ser);



                if ($postData['publisherHidden'] != '0' && $postData['publisherHidden'] !="") {
                    $explodePub = explode(',', $postData['publisherHidden']);
                    for ($i = 0; $i < count($explodePub); $i++) {

                        $cCredit = $Common->getBrodcasterUrl() . 'Invoice/getsum/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/sId/2/pId/' . $explodePub[$i];
                        $responseDetailsTestP = json_decode($Common->cUrlCallWithPost($cCredit, $afKeyIdT),true);



                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Short-Service-Name-By-Service-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/serviceId/2';
                        $shortName = json_decode($Common->cUrlCall($cUrl));


                        switch ($explodePub[$i]) {
                            case '1':
                                $ServiceName = 'PPC:PPC- FACEBOOK';
                                break;
                            case '2':
                                $ServiceName = 'PPC:PPC- GOOGLE';
                                break;
                            case '3':
                                $ServiceName = 'PPC:PPC- MSN';
                                break;
                            case '4':
                                $ServiceName = 'PPC:PPC- YAHOO';
                                break;
                        }

                        $serviceTax = $responseDetailsTestP[0]['AGL_CHARGE'] * 14 / 100;
                        $subToatl = $responseDetailsTestP[0]['AMOUNT'] + $responseDetailsTestP[0]['AGL_CHARGE'];
                        $total = $subToatl + $serviceTax;

                        $sql = "INSERT my_invoice_table_sec
                            SET
                                id = '" . $id . "',
                                    TxnID = '1',
                                    TimeCreated = '" . date('Y/m/d') . "',
                                    PublisherId = '" . $explodePub[$i] . "',
                                    PublisherName = 'No',
                                    ServiceId = '2',
                                    ServiceName = '" . $ServiceName . "',
                                    AglCharge = '" . $responseDetailsTestP[0]['AGL_CHARGE'] . "',
                                    ServiceTax = '" . $serviceTax . "',
                                    SubTotal = '" . $subToatl . "',
                                    Gtotal = '" . $total . "',
                                    TimeModified = '" . date('Y/m/d') . "',
                                    RefNumber = '".$responsePayTest[0]['ACTUAL_INVOICE_ID']."',
                                    Customer_ListID = '1',
                                    Customer_FullName = '".$clientInfoById[0]->COMPANY_NAME."',
                                    ShipAddress_Addr1 = 'NO',
                                    ShipAddress_Addr2 = 'NO',
                                    ShipAddress_City = 'NO',
                                    ShipAddress_State = 'NO',
                                    ShipAddress_Province = 'NO',
                                    ShipAddress_PostalCode = 'NO',
                                    BalanceRemaining = 'NO',
                                    irefrence = 'PPC',
                                    quantity = '1',
                                    rate = '" . $responseDetailsTestP[0]['AMOUNT'] . "'";

                        $db->query($sql);

                    }
                }

                if ($postData['serviceHidden'] != '0' &&  $postData['serviceHidden'] !="") {
                    $explodeSer = explode(',', $postData['serviceHidden']);
                    for ($i = 0; $i < count($explodeSer); $i++) {
                        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Short-Service-Name-By-Service-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/serviceId/' . $explodeSer[$i];
                        $shortName = json_decode($Common->cUrlCall($cUrl));


                        $cCreditT = $Common->getBrodcasterUrl() . 'Invoice/getsum/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/sId/' . $explodeSer[$i] . '/pId/0';
                        $responseDetailsTestS = json_decode($Common->cUrlCallWithPost($cCreditT, $afKeyIdT),true);



                        $sTax = $responseDetailsTestS[0]['AMOUNT'] * 14 / 100;
                        $totalSer = $sTax + $responseDetailsTestS[0]['AMOUNT'];
                        $sqlS = "INSERT my_invoice_table_sec
                            SET
                            id = '" . $id . "',
                            TxnID = '1',
                            TimeCreated = '" . date('Y/m/d') . "',
                            PublisherId = '0',
                            PublisherName = '0',
                            ServiceId = '" . $explodeSer[$i] . "',
                            ServiceName = '" . $shortName . "',
                            AglCharge = '0',
                            ServiceTax = '" . $sTax . "',
                            SubTotal = '" . $responseDetailsTestS[0]['AMOUNT'] . "',
                            Gtotal = '" . $totalSer . "',
                            TimeModified = '" . date('Y/m/d') . "',
                            RefNumber = '".$responsePayTest[0]['ACTUAL_INVOICE_ID']."',
                            Customer_ListID = '1',
                            Customer_FullName = '".$clientInfoById[0]->COMPANY_NAME."',
                            ShipAddress_Addr1 = 'NO',
                            ShipAddress_Addr2 = 'NO',
                            ShipAddress_City = 'NO',
                            ShipAddress_State = 'NO',
                            ShipAddress_Province = 'NO',
                            ShipAddress_PostalCode = 'NO',
                            BalanceRemaining = 'NO',
                            irefrence = 'serviceShortName',
                            quantity = '1',
                            rate = '" . $responseDetailsTestS[0]['AMOUNT'] . "'";

                        $db->query($sqlS);
                    }
                }



                $inSerch = implode(',', $afKeyIdT);


                $sqlSelect = "select sum(ServiceTax) as SERVICETAX FROM my_invoice_table_sec where id='" . $id . "'";
                $rows = $db->Fetchall($sqlSelect);

                $update = "UPDATE my_invoice_table_sec SET ServiceTax ='" . $rows[0]->SERVICETAX . "' where id='" . $id . "'";
                $db->query($update);





                $dbc = Zend_Registry::get('DB_C');
                $updateMaster = "UPDATE `cust_invoice_payment_master` SET QB ='1' where INVOICE_ID = '" . $invoiceId . "' AND ID IN(" . $inSerch . ")";
                $dbc->query($updateMaster);



                $updateMasterDetails = "UPDATE `cust_invoice_payment_matser_details` SET QB ='1' where INVOICE_ID = '" . $invoiceId . "' AND  FKEY_PAYMENT_ID IN(30,31,32)";
                $dbc->query($updateMasterDetails);


			/**
               $cUrl = 'https://www.adv8.in/invoice/insertintoqbinvoice/id/' . $id;
               $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $cUrl);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                $response = curl_exec($ch);
                $info = @curl_getinfo($ch);
                curl_close($ch);
                $responsePub = $response;
**/
                $cClient = $Common->getBrodcasterUrl() . 'Invoice/update-Payment-Status/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/fKeyId/' . $fKeyId . '/status/' . $status;
                $Common->cUrlCall($cClient);

                /* Send Email to CM with sttaus that payment is declined or approved. */
                $subject = '';
                if ($status == 10) {
                    $subject = 'Payment Approved';
                } else if ($status == 11) {
                    $subject = 'Payment Declined';
                }

                $data = $this->generalInvoiceInfo($clientId, $invoiceId, $fKeyId);
                $data['heading'] = $subject;
                $mailHtml = $this->view->partial('invoice/notifications.phtml', array('content' => $data, 'invoiceId' => $InId));

                $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $ns->uId;
                $EmailCreater = json_decode($Common->cUrlCall($cClient));

                $mail = new Zend_Mail();
                $mail->setType(Zend_Mime::MULTIPART_RELATED);
                $mail->setBodyHtml($mailHtml);
                $mail->setFrom('invoice@adv8.co');

        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
				$mail->addTo('pawan.dhingra@adglobal360.com');
				//$mail->addTo('himmat.singh@adglobal360.com');

				$mail->addTo('accounts@adglobal360.com');
				$mail->addTo('sushant.vashisht@adglobal360.com');
                $mail->addTo($EmailCreater[0]->USER_EMAIL);
                $mail->setSubject($subject);
                $mail->send();
                die('QuickBook has been updated');
               }
            } else {

                $uId = '0';
                $cClient = $Common->getBrodcasterUrl() . 'Invoice/getinvoicebyid/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/fKeyId/' . $fKeyId;
                $eInvoices = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient), true);



                if($eInvoices['CODE'] !='C-103'){
                $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Details-Byi-Cu-Qb/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/clientId/' . $clientId . '/uId/' . $uId;
                $dInvoices = $this->view->dInvoices = json_decode($Common->cUrlCall($cClient), true);

                $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $clientId;
                $clientInfoById = json_decode($Common->cUrlCall($cUrl));

                $iData[0] = $clientInfoById[0]->COMPANY_NAME;
                $iData[1] = $eInvoices[0]['ACTUAL_INVOICE_ID'];
                $iData[2] = 'PPC';
                $iData[3] = '1';
                $iData[4] = $eInvoices[0]['TOTAL_AMT'];
                $this->quickbookInvoice($iData, $eInvoices, $dInvoices);

                $cClient = $Common->getBrodcasterUrl() . 'Invoice/update-Payment-Status/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/fKeyId/' . $fKeyId . '/status/' . $status;
                $Common->cUrlCall($cClient);

                /* Send Email to CM with sttaus that payment is declined or approved. */
                $subject = '';
                if ($status == 10) {
                    $subject = 'Payment Approved';
                } else if ($status == 11) {
                    $subject = 'Payment Declined';
                }

                $data = $this->generalInvoiceInfo($clientId, $invoiceId, $fKeyId);
                $data['heading'] = $subject;
                $mailHtml = $this->view->partial('invoice/notifications.phtml', array('content' => $data, 'invoiceId' => $InId));

                $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $ns->uId;
                $EmailCreater = json_decode($Common->cUrlCall($cClient));

                $mail = new Zend_Mail();
                $mail->setType(Zend_Mime::MULTIPART_RELATED);
                $mail->setBodyHtml($mailHtml);
                $mail->setFrom('invoice@adv8.co');

        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
                $mail->addTo('pawan.dhingra@adglobal360.com');
                //$mail->addTo('himmat.singh@adglobal360.com');
                $mail->addTo($EmailCreater[0]->USER_EMAIL);
                $mail->setSubject($subject);
                //$mail->send();
				
				$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($mailHtml);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = $subject;
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = $EmailCreater[0]->USER_EMAIL.',pawan.dhingra@adglobal360.com';
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			
			
                $this->_redirect('Invoice/ledgerlist/I/' . $invoiceId);
                }else{
                    $cClient = $Common->getBrodcasterUrl() . 'Invoice/update-Payment-Status/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' . $invoiceId . '/fKeyId/' . $fKeyId . '/status/' . $status;
                $Common->cUrlCall($cClient);

                /* Send Email to CM with sttaus that payment is declined or approved. */
                $subject = '';
                if ($status == 10) {
                    $subject = 'Payment Approved';
                } else if ($status == 11) {
                    $subject = 'Payment Declined';
                }

                $data = $this->generalInvoiceInfo($clientId, $invoiceId, $fKeyId);
                $data['heading'] = $subject;
                $mailHtml = $this->view->partial('invoice/notifications.phtml', array('content' => $data, 'invoiceId' => $InId));

                $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $ns->uId;
                $EmailCreater = json_decode($Common->cUrlCall($cClient));

                $mail = new Zend_Mail();
                $mail->setType(Zend_Mime::MULTIPART_RELATED);
                $mail->setBodyHtml($mailHtml);
                $mail->setFrom('invoice@adv8.co');

        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
                $mail->addTo('pawan.dhingra@adglobal360.com');
                $mail->addTo('himmat.singh@adglobal360.com');
                $mail->addTo($EmailCreater[0]->USER_EMAIL);
                $mail->setSubject($subject);
                $mail->send();
                die('QuickBook has been updated');
                }
            }
        } else {
            die;
        }
    }


    public function publisherbreakupAction(){
        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('ledgerlayout');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $InId = $_POST['invoiceId'];
        $clientId = $_POST['clientId'];
        $fKeyId = $_POST['paymentId'];

        $cCommon = new Common();
        $db = Zend_Registry::get('DB_C');

        $paymentId = $_POST['paymentId'];
        $getgcidbreakup = $Common->getBrodcasterUrl() . 'Invoice/getgcidbreakup/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId.'/InId/'.$InId.'/clientId/'.$_POST['clientId'].'/paymentId/' . $paymentId;
        $resgetgcidbreakup =  json_decode($Common->cUrlCall($getgcidbreakup),true);

        $dwncount = explode(',',$_POST['dwncount']);
        $upcount = explode(',',$_POST['upcount']);

        $netArray = array();
        $upcount1 = explode('~',$upcount[0]);
        for($m=0;$m<count($upcount);$m++){
           $upcount3 = explode('~',$upcount[$m]);
           $netArray[$upcount3[1]]=$upcount3[0];
        }

        $sqlD = "DELETE FROM cust_invoice_gcid_mapping WHERE FKEY_ID = '".@$paymentId."' AND INVOICE_ID = '".$_POST['invoiceId']."' AND CLIENT_ID='".@$_POST['clientId']."'";
        $db->query($sqlD);

        for($c=0;$c<count($dwncount);$c++){
            if(array_key_exists($dwncount[$c],$netArray)){

                $publisherId = explode('_',$netArray[$dwncount[$c]]);

                $explodeGCID = explode('_',$_POST['gcproject_'.$netArray[$dwncount[$c]].'_'.$dwncount[$c]]);
                $length = count($explodeGCID);
                $netLength = $length-1;
                $sql = "INSERT INTO cust_invoice_gcid_mapping SET INVOICE_ID = '".$_POST['invoiceId']."',
                                    FKEY_ID = '".@$_POST['paymentId']."',
                                    CLIENT_ID='".@$_POST['clientId']."',
                                    PUBLISHER_ID='".$publisherId[1]."',
                                    GCID='".@$_POST['gcproject_'.$netArray[$dwncount[$c]].'_'.$dwncount[$c]]."',
                                    AMOUNT='".@$_POST['valueAmt_'.$netArray[$dwncount[$c]].'_'.$dwncount[$c]]."',
                                    CREATED_AT ='".date('Y-m-d h:i:s')."',
                                    UP='".$netArray[$dwncount[$c]]."_".$dwncount[$c]."',
                                    DW='".$dwncount[$c]."',
                                    PUBLISHER_ACCOUNT_ID ='".$explodeGCID[$netLength]."',
                                    STATUS ='1'";

                $db->query($sql);
            }
        }
        /* Send Email */
        if($roleId == 5) {
            $subject = '';
            $data = $this->generalInvoiceInfo($clientId,$InId,$fKeyId);
            if($data['PAYMENT_STATUS'] == 7) {
                $subject = 'Credit Request';
            } else {
                $subject = 'Bifurcation Done';
            }
            $data['heading'] = $subject;
            $mailHtml = $this->view->partial('invoice/notifications.phtml', array('content' => $data,'invoiceId'=>$_POST['invoiceId']));

            $mail = new Zend_Mail();
            $mail->setType(Zend_Mime::MULTIPART_RELATED);
            $mail->setBodyHtml($mailHtml);
            $mail->setFrom('invoice@adv8.co');

        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
			$mail->addTo('pawan.dhingra@adglobal360.com');
			//$mail->addTo('himmat.singh@adglobal360.com');

			$mail->addTo('accounts@adglobal360.com');
			$mail->addTo('sushant.vashisht@adglobal360.com');
            $mail->setSubject($subject);
            //$mail->send();
			
			$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($mailHtml);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = $subject;
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = 'pawan.dhingra@adglobal360.com,accounts@adglobal360.com';
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail); 
			
			
        }

        $this->_redirect('/Invoice/ledgerlist/I/'.$_POST['invoiceId']);
    }

    public function generatepdfAction() {

        $ns = new Zend_Session_Namespace('AGLconSol');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $InId = $this->_request->getparam('I');
        $clientId = $this->_request->getparam('clientId');
        $paymentId = $this->_request->getparam('LId');
        $customEmail = $this->_request->getparam('customEmail');
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/'.$paymentId;
        $ledgerInvoice = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/'.$paymentId;
        $ledgerdetailsInvoice = json_decode($Common->cUrlCall($cClient), true);


        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $clientId;
        $clientInfoById = json_decode($Common->cUrlCall($cUrl));

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $publishers = $this->view->publishers = json_decode($Common->cUrlCall($cClient));

        foreach ($publishers as $publisherm) {
            $publisher[$publisherm->ID] = $publisherm->PUBLISHER_DESC;
        }

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $services = json_decode($Common->cUrlCall($cClient),true);
        $service = array();
        for($m=0;$m<count($services);$m++){
            $service[$services[$m]['ID']] = $services[$m]['SERVICE_NAME'];
        }

	   
	$cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Invoice-Info-By-Invoice-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/invoiceId/' .$InId;
	$eInvoices1 = $this->view->eInvoices = json_decode($Common->cUrlCall($cClient));
			
        $html = $this->view->partial('invoice/generatepdf.phtml', array('eInvoices' => $ledgerInvoice, 'dInvoices' => $ledgerdetailsInvoice, 'clientInfo'=>$clientInfoById,'publisher'=>$publisher,'service'=>$service,"eInvoices1"=>$eInvoices1));
	
        $tmphtml = $this->getPdfOriginal($html, $clientId);
echo $tmphtml;

        $content = array();
        $content['heading'] = $this->_request->getparam('payStatus');

        $html = $this->view->partial('invoice/mailformate.phtml', array('clientInfoById' => $clientInfoById, 'content' => $content,'invoiceId'=>$InId));
        $mail = new Zend_Mail();
        $mail->setType(Zend_Mime::MULTIPART_RELATED);
        $mail->setBodyHtml($html);
        $mail->setFrom('invoice@adv8.co');
        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
        $mail->addTo('pawan.dhingra@adglobal360.com');
        //$mail->addTo('himmat.singh@adglobal360.com');

        $mail->addTo('accounts@adglobal360.com');
        //$mail->addTo('sushant.vashisht@adglobal360.com');
        $mail->addTo($customEmail);
        $mail->setSubject('Invoice');
        $test = file_get_contents($tmphtml);
        $file = $mail->createAttachment($test);
        $file->filename = $clientInfoById[0]->COMPANY_NAME . '.pdf';
        $mail->send();
exit;
        $this->_redirect('/Invoice/ledgerlist/I/'.$InId);
    }

    public function generatepdftestAction(){
        $to = "deepak.garg@adglobal360.biz";
        $subject = "Test mail";
        $message = "Hello! This is a simple email message.";
        $from = "invoice@adv8.co";
        $headers = "From:" . $from;
        mail($to,$subject,$message,$headers);
        echo "Mail Sent.";

        die;
        $mail = new Zend_Mail();
        //$mail->setType(Zend_Mime::MULTIPART_RELATED);
        $mail->setBodyHtml('Hi Test Mail');
        $mail->setFrom('invoice@adv8.co');
        $mail->addTo('deepak.garg@adglobal360.biz');
        $mail->setSubject('Invoice');
        //$test = file_get_contents($tmphtml);
        //$file = $mail->createAttachment($test);
        //$file->filename = $clientInfoById[0]->COMPANY_NAME . '.pdf';
        //$mail->send();

        die;
        $ns = new Zend_Session_Namespace('AGLconSol');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $InId = $this->_request->getparam('I');
        $clientId = $this->_request->getparam('clientId');
        $paymentId = $this->_request->getparam('LId');
        $customEmail = $this->_request->getparam('customEmail');
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/'.$paymentId;
        $ledgerInvoice = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/'.$paymentId;
        $ledgerdetailsInvoice = json_decode($Common->cUrlCall($cClient), true);


        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $clientId;
        $clientInfoById = json_decode($Common->cUrlCall($cUrl));

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Publishers/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $publishers = $this->view->publishers = json_decode($Common->cUrlCall($cClient));


        foreach ($publishers as $publisherm) {
            $publisher[$publisherm->ID] = $publisherm->PUBLISHER_DESC;
        }

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/';
        $services = json_decode($Common->cUrlCall($cClient),true);
        $service = array();
        for($m=0;$m<count($services);$m++){
            $service[$services[$m]['ID']] = $services[$m]['SERVICE_NAME'];
        }

        $html = $this->view->partial('invoice/generatepdf.phtml', array('eInvoices' => $ledgerInvoice, 'dInvoices' => $ledgerdetailsInvoice, 'clientInfo'=>$clientInfoById,'publisher'=>$publisher,'service'=>$service));
        $tmphtml = $this->getPdfOriginal($html, $clientId);

        $content = array();
        $content['heading'] = $this->_request->getparam('payStatus');

        $html = $this->view->partial('invoice/mailformate.phtml', array('clientInfoById' => $clientInfoById, 'content' => $content,'invoiceId'=>$InId));

        echo $html; echo $tmphtml; die;
        $mail = new Zend_Mail();
        $mail->setType(Zend_Mime::MULTIPART_RELATED);
        $mail->setBodyHtml($html);
        $mail->setFrom('invoice@adv8.co');
        //$mail->addTo('deepak.garg@adglobal360.biz');
        $mail->addTo($customEmail);
        $mail->setSubject('Invoice');
        $test = file_get_contents($tmphtml);
        $file = $mail->createAttachment($test);
        $file->filename = $clientInfoById[0]->COMPANY_NAME . '.pdf';
        $mail->send();

        die;
    }

    public function generalInvoiceInfo($clientId,$invoiceId,$fKeyId) {
        $ns = new Zend_Session_Namespace('AGLconSol');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $InId = $invoiceId;
        $paymentId = trim($fKeyId);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/'.$paymentId;
        $ledgerInvoice = json_decode($Common->cUrlCall($cClient), true);

        $result = array();
        $result['PROFORMA_INVOICE_ID'] = $ledgerInvoice[0]['PROFORMA_INVOICE_ID'];
        $result['TOTAL_AMOUNT_RECIVED'] = number_format($ledgerInvoice[0]['TOTAL_AMOUNT_RECIVED'],'0');
        $result['TOTAL_BUDGET_ALLOWED'] = number_format($ledgerInvoice[0]['TOTAL_BUDGET_ALLOWED'],'0');
        $result['TOTAL_AMT'] = number_format($ledgerInvoice[0]['TOTAL_AMT'],'0');
        $result['REMARKS'] = $ledgerInvoice[0]['REMARKS'];
        $result['PAYMENT_STATUS'] = $ledgerInvoice[0]['PAYMENT_STATUS'];

        if($clientId != '') {
            $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $clientId;
            $clientInfoById = json_decode($Common->cUrlCall($cUrl), true);
            $result['SALUTATION'] = $clientInfoById[0]['SALUTATION'];
            $result['FIRST_NAME'] = $clientInfoById[0]['FIRST_NAME'];
            $result['COMPANY_NAME'] = $clientInfoById[0]['COMPANY_NAME'];
        }

        return $result;
    }


    public function addadvinvoiceAction() {

        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('ledgerlayout');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $postData = $_POST;


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $postData['invoice_id'];
        $response = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $postData['invoice_id'];
        $response1 = json_decode($Common->cUrlCall($cClient), true);




        $dbI = Zend_Registry::get('DB_I');

        $sqlM = "insert into my_invoice_table(sid)values('1')";
        $dbI->query($sqlM);
        $Table = 'my_invoice_table';
	
        $id = $this->getLastInsertIdInvoiceQb($Table);

        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $response1[0]['CLIENT_ID'];
        $clientInfoById = json_decode($Common->cUrlCall($cUrl));


        if($postData['actualInvoiceId'] =='000000'){
              // nothing
        }else{
        foreach($response1 as $resp){


         if($resp['SERVICE_ID'] == '2'){


             $serviceTax = round($resp['INVOICE_DETAILS_TAXAMOUNT'] * 14 / 100);
             $subToatl = $resp['INVOICE_DETAILS_AGL_CHARGES'];
             $total = $subToatl + round($serviceTax);

            switch ($resp['PUBLISHER_ID']) {
                case '1':
                    $ServiceName = 'PPC:PPC- FACEBOOK';
                    break;
                case '2':
                    $ServiceName = 'PPC:PPC- GOOGLE';
                    break;
                case '3':
                    $ServiceName = 'PPC:PPC- MSN';
                    break;
                case '4':
                    $ServiceName = 'PPC:PPC- YAHOO';
                    break;
            }


           $sql = "INSERT my_invoice_table_sec
                SET
                    id = '" . $id . "',
                        TxnID = '1',
                        TimeCreated = '" . date('Y/m/d') . "',
                        PublisherId = '" . $resp['PUBLISHER_ID'] . "',
                        PublisherName = 'No',
                        ServiceId = '2',
                        ServiceName = '" . $ServiceName . "',
                        AglCharge = '" . $resp['INVOICE_DETAILS_TAXAMOUNT']. "',
                        ServiceTax = '" . $serviceTax . "',
                        SubTotal = '" . $subToatl . "',
                        Gtotal = '" . $total . "',
                        TimeModified = '" . date('Y/m/d') . "',
                        RefNumber = '".$postData['actualInvoiceId']."',
                        Customer_ListID = '1',
                        Customer_FullName = '".$clientInfoById[0]->COMPANY_NAME."',
                        ShipAddress_Addr1 = 'NO',
                        ShipAddress_Addr2 = 'NO',
                        ShipAddress_City = 'NO',
                        ShipAddress_State = 'NO',
                        ShipAddress_Province = 'NO',
                        ShipAddress_PostalCode = 'NO',
                        BalanceRemaining = 'NO',
                        irefrence = 'PPC',
                        quantity = '1',
                        rate = '" .$resp['INVOICE_DETAILS_AMOUNT']. "'";
                        $dbI->query($sql);
            }

            if($resp['SERVICE_ID'] != '2'){
                 $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Short-Service-Name-By-Service-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/serviceId/'.$resp['SERVICE_ID'];
                 $shortName = json_decode($Common->cUrlCall($cUrl));
                        $sTax = $resp['INVOICE_DETAILS_AMOUNT'] * 14 / 100;
                        $totalSer = $sTax + $resp['INVOICE_DETAILS_AMOUNT'];
                        $sqlS = "INSERT my_invoice_table_sec
                            SET
                            id = '" . $id . "',
                            TxnID = '1',
                            TimeCreated = '" . date('Y/m/d') . "',
                            PublisherId = '0',
                            PublisherName = '0',
                            ServiceId = '" . $resp['SERVICE_ID'] . "',
                            ServiceName = '" . $shortName . "',
                            AglCharge = '0',
                            ServiceTax = '" . $sTax . "',
                            SubTotal = '" . $resp['INVOICE_DETAILS_AMOUNT'] . "',
                            Gtotal = '" . $totalSer . "',
                            TimeModified = '" . date('Y/m/d') . "',
                            RefNumber = '".$postData['actualInvoiceId']."',
                            Customer_ListID = '1',
                            Customer_FullName = '".$clientInfoById[0]->COMPANY_NAME."',
                            ShipAddress_Addr1 = 'NO',
                            ShipAddress_Addr2 = 'NO',
                            ShipAddress_City = 'NO',
                            ShipAddress_State = 'NO',
                            ShipAddress_Province = 'NO',
                            ShipAddress_PostalCode = 'NO',
                            BalanceRemaining = 'NO',
                            irefrence = 'serviceShortName',
                            quantity = '1',
                            rate = '" . $resp['INVOICE_DETAILS_AMOUNT'] . "'";

                        $dbI->query($sqlS);
                    }
            }


                $sqlSelect = "select sum(ServiceTax) as SERVICETAX FROM my_invoice_table_sec where id='" . $id . "'";
                $rows = $dbI->Fetchall($sqlSelect);

                $update = "UPDATE my_invoice_table_sec SET ServiceTax ='" . $rows[0]->SERVICETAX . "' where id='" . $id . "'";
                $dbI->query($update);





                $dbc = Zend_Registry::get('DB_C');
                $updateMaster = "UPDATE `cust_invoice_payment_master` SET QB ='1' where INVOICE_ID = '" . $postData['invoice_id']."'";
                $dbc->query($updateMaster);

				/**
				*enabled by rakesh singh 19th jun 2014
				*/

				if($clientInfoById[0]->COMPANY_NAME== 'QB50'){
					$cUrl = 'https://www.adv8.in/invoice/insertintoqbinvoice/id/' . $id;
					
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, $cUrl);
					curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
					$response = curl_exec($ch);
					$info = @curl_getinfo($ch);
					curl_close($ch);
					$responsePub = $response;
				}

        }


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/add-Adv-Invoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId;
        
	$response = $Common->cUrlCallWithPost($cClient, $postData);
	


        $subject = 'Advanced Invoice';



        $cUrl = $Common->getBrodcasterUrl() . 'Invoice/get-Client-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientIdInvoice/' . $postData['client_id'];
        $clientInfoById = json_decode($Common->cUrlCall($cUrl));

        $data['amountRecived'] = $postData['amountRecived'];
        $data['totalAllowedBudget'] = $postData['totalAllowedBudget'];
        $data['actualInvoiceId'] = $postData['actualInvoiceId'];
        $data['remark'] = $postData['remark'];
        $data['heading'] = $subject;

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Email-Id-Of-Creater-By-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/uId/' . $ns->uId;
        $EmailCreater = json_decode($Common->cUrlCall($cClient));


        $mailHtml = $this->view->partial('invoice/addadvinvoice.phtml', array('content' => $data,'clientInfoById'=>$clientInfoById,'invoiceId'=>$data['invoice_id']));
        $mail = new Zend_Mail();
        $mail->setType(Zend_Mime::MULTIPART_RELATED);
        $mail->setBodyHtml($mailHtml);
        $mail->setFrom('invoice@adv8.co');
        $mail->addTo($EmailCreater[0]->USER_EMAIL);
        $mail->addTo('pawan.dhingra@adglobal360.com');
        //$mail->addTo('himmat.singh@adglobal360.com');
        $mail->addTo('accounts@adglobal360.com');
        //$mail->addTo('sushant.vashisht@adglobal360.com');
        //$mail->addBcc('shruti.kakkar@adglobal360.com');
        $mail->addBcc('vishnu.dass@adglobal360.com');
        $mail->setSubject($subject);
        $mail->send();
		
		$arrEmail['clientId'] = $ns->CLIENT_ID;
			$arrEmail['email_body'] = base64_encode($mailHtml);
			$arrEmail['date'] = date("Y-m-d");
			$arrEmail['subject'] = $subject;
			$arrEmail['from'] = 'invoice@adv8.co';
			$arrEmail['user_name'] = '';
			$arrEmail['email'] = 'pawan.dhingra@adglobal360.com,accounts@adglobal360.com';
			
			
			
			$cUrlForPost = $Common->getBrodcasterUrl() . 'Form/insert-In-Internal-Email/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $clientId;
			$mesVal = $responseData1 = $Common->cUrlCallWithPost($cUrlForPost, $arrEmail);
			

        $this->_redirect('/Invoice/ledgerlist/I/'.$postData['invoice_id']);
    }

    public function actionsadvAction() {

        $ns = new Zend_Session_Namespace('AGLconSol');
        $this->_helper->layout->setLayout('ledgerlayout');

        $Common = new Common();
        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $ns = new Zend_Session_Namespace('AGLconSol');
        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;

        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $id = "'";
        $id .='popup2';
        $id .= "'";

        $none = "'";
        $none .= 'none';
        $none .= "'";


        /**
         * Call Invoice Functions
         */
        //$InId = $this->_request->getparam('InId');
        $paymentId = $this->_request->getparam('paymentId');
        $advInvoice = $InId = $this->_request->getparam('paymentType');
        $stP = $this->_request->getparam('stP');
        $InId = $this->_request->getparam('InId');


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Count/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->getCount = $getCount = json_decode($Common->cUrlCall($cClient), true);


        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->shaddowInvoice = $shaddowInvoice = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $this->view->detailsInvoice = $detailsInvoice = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/get-Service-Name/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $services = json_decode($Common->cUrlCall($cClient), TRUE);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/' . $paymentId;
        $ledgerInvoice = json_decode($Common->cUrlCall($cClient), true);



        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/' . $paymentId;
        $this->view->ledgerdetailsInvoice = $ledgerdetailsInvoice = json_decode($Common->cUrlCall($cClient), true);

        $getgcidbreakup = $Common->getBrodcasterUrl() . 'Invoice/getgcidbreakup/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId.'/InId/'.$InId.'/clientId/'.$ledgerInvoice[0]['CLIENT_ID'].'/paymentId/' . $paymentId;
        $resgetgcidbreakup =  json_decode($Common->cUrlCall($getgcidbreakup),true);

        $publishersArray = array('1' => 'Facebook', '2' => 'Google', '3' => 'Yahoo', '4' => 'Msn');
        foreach ($detailsInvoice as $details) {
            if ($details['PUBLISHER_ID'] != '0') {
                $Publishers[] = $details['PUBLISHER_ID'];
            }
            if ($details['SERVICE_ID'] != '2') {
                $Services[] = $details['SERVICE_ID'];
            }
        }

        if (@$Publishers > 0) {
            $PublishersString = implode(',', $Publishers);
        } else {
            $PublishersString = '0';
        }


        if (@$Services > 0) {
            $ServicesString = implode(',', $Services);
        } else {
            $ServicesString = '0';
        }
        $allowedStatus = array('1','2','3','4','5','6');
        $readOnly = ($ledgerInvoice[0]['PAYMENT_STATUS'] == 8 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 9 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 10) ? 'readonly="readonly"' : '';
        $disabled = ($ledgerInvoice[0]['PAYMENT_STATUS'] == 8 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 9 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 10) ? 'disabled="disabled"' : '';
        if($roleId == 5) {
            $selectDisabled = 'disabled';
        }

        $tpl = '';
        $tpl .='<div id="popup">
                    <a href="javascript:void(0);" class="actionclose" onclick="document.getElementById(' . $id . ').style.display = ' . $none . ';"><img src="'.ROOT.'common/images/close.png" /></a>
                    <div class="popupinner">
                        <form action="/Invoice/actionbutton" name="submitPaymentDetails" id="submitPaymentDetails" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="paymentid" value="'.$paymentId.'" />
                            <h2>Payment Details';
                            if(($roleId == 1 || $roleId == 3 || $role==13) && (in_array($ledgerInvoice[0]['PAYMENT_STATUS'], $allowedStatus))) {
                                $tpl .= '<!--<span class="approvalstatus"><a style="margin-right:5px;color:green;" onclick="approvalStatus('.$InId.','.$paymentId.',10,'.$ledgerInvoice[0]['CLIENT_ID'].');">Approve</a><a style="color:red;" onclick="approvalStatus('.$InId.','.$paymentId.',11,'.$ledgerInvoice[0]['CLIENT_ID'].');">Decline</a></span>-->';
                            }
                    $tpl .= '</h2>
                            <div class="pop-topsection">
                                <div class="left-side">
                                    <div class="topsection-row">
                                        <label>Actual Invoice No </label> --
                                        <input type="text" name="actualInvoiceId" readonly="readonly" id="actualInvoiceId" value="' . $ledgerInvoice[0]['ACTUAL_INVOICE_ID'] . '" class="topsection-input" />
                                    </div>
                                    <div class="topsection-row">
                                        <label>Invoice Date </label> --
                                        <input type="text" name="invoiceDate" id="invoiceDate" readonly="readonly" value="' . $ledgerInvoice[0]['INVOICE_DATE'] . '" class="topsection-input" />
                                    </div>';
                                    if($ledgerInvoice[0]['PAYMENT_STATUS'] == 7 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 8) {
                                $tpl .='<div class="topsection-row">
                                        <label>Expected Date </label> --
                                        <input type="text" name="expectedDate" id="expectedDate" value="' . $ledgerInvoice[0]['EXPECTED_DATE'] . '" class="topsection-input" />
                                    </div>';
                                    } else {
                                        $tpl .= '<input type="hidden" name="expectedDate" id="expectedDate" value="" />';
                                    }
                                $tpl .= '<div class="topsection-row">
                                        <label>Payment Status</label> --
                                        <select class="selectbox" name="payment_status_cm" id="payment_status_cm" '.$selectDisabled.'>
                                            <option value="1"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 1) { $tpl .= 'selected="selected"'; } $tpl .='>Payment Rec.</option>
                                            <option value="2"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 2) { $tpl .= 'selected="selected"'; } $tpl .='>Paid</option>
                                            <option value="4"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 4) { $tpl .= 'selected="selected"'; } $tpl .='>Partial Pay.</option>
                                            <option value="5"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 5) { $tpl .= 'selected="selected"'; } $tpl .='>Cheque Under Realization</option>
                                            <option value="6"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 6) { $tpl .= 'selected="selected"'; } $tpl .='>Advance Inv.</option>
                                            <option value="7"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 7) { $tpl .= 'selected="selected"'; } $tpl .='>Credit</option>
                                            <option value="8"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 8) { $tpl .= 'selected="selected"'; } $tpl .='>Credit Approved</option>
                                            <option value="9"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 9) { $tpl .= 'selected="selected"'; } $tpl .='>Credit Paid</option>
                                            <option value="10"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 10) { $tpl .= 'selected="selected"'; } $tpl .='>Payment Approved</option>
                                            <option value="12"'; if ($ledgerInvoice[0]['PAYMENT_STATUS'] == 12) { $tpl .= 'selected="selected"'; } $tpl .='>Open Invoice</option>
                                        </select>
                                    </div>';
                                    if($ledgerInvoice[0]['PAYMENT_STATUS'] == 7 || $ledgerInvoice[0]['PAYMENT_STATUS'] == 8) {
                                        $tpl .= '<input type="hidden" name="paymentModeCm" id="paymentModeCm" value="" />';
                                    } else {
                                        $tpl .= '<div class="topsection-row">
                                        <label>Payment Mode</label> --
                                        <select class="selectbox" name="paymentModeCm" id="paymentModeCm" '.$readOnly.'>
                                            <option value="1"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 1) { $tpl .= 'selected="selected"'; } $tpl .='>Cash</option>
                                            <option value="2"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 2) { $tpl .= 'selected="selected"'; } $tpl .='>DD</option>
                                            <option value="3"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 3) { $tpl .= 'selected="selected"'; } $tpl .='>Transfer</option>
                                            <option value="4"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 4) { $tpl .= 'selected="selected"'; } $tpl .='>Cheque</option>
                                            <option value="5"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 5) { $tpl .= 'selected="selected"'; } $tpl .='>EBS</option>
                                            <option value="6"'; if ($ledgerInvoice[0]['PAYMENT_TYPE'] == 6) { $tpl .= 'selected="selected"'; } $tpl .='>First Data</option>
                                        </select>
                                    </div>';
                                    }
                                 $tpl .= '<div class="topsection-row">
                                        <label>Bank Charge/CC</label> --
                                        <span>'.number_format($ledgerInvoice[0]['BANK_CHARGES']).'</span>
                                        <span id="backcal"></span>
                                    </div>
                                    <div class="topsection-row">
                                        <label>Reverse Cal.</label> --
                                        <span id="backcal"></span>
                                </div>
                                </div>
                                <div class="right-side">
                                    <label>Remarks</label>
                                    <textarea class="topsection-textarea" '.$readOnly.'>' . $ledgerInvoice[0]['REMARKS'] . '</textarea>
                                </div>
                            </div>
                       <div class="middle-box">
                            <div class="invoice-box">
                                <div class="invoice-inner">
                                    <h3>Shadow Invoice Details</h3>
                                        <div class="pricebox">';
                                        foreach ($detailsInvoice as $details) {
                                            if (array_key_exists($details['PUBLISHER_ID'], $publishersArray)) {
                                                if ($details['PUBLISHER_ID'] != '0') {
                                                    $tpl .='<div class="price-row">
                                                                <label>' . $publishersArray[$details['PUBLISHER_ID']] . '</label> -- <label>' . number_format($details['INVOICE_DETAILS_AMOUNT']) . '</label></div>';
                                                }
                                            }if ($details['SERVICE_ID'] != '2') {
                                                $tpl .='<div class="price-row">';
                                                foreach ($services as $service) {
                                                    if ($service['ID'] == $details['SERVICE_ID']) {
                                                        $tpl .='<label>' . $service['SERVICE_SHORT_NAME'] . '</label> -- <label>' . number_format($details['INVOICE_DETAILS_AMOUNT']) . '</label>';
                                                    }
                                                }
                                                $tpl .='</div>';
                                            }
                                        }
                                        $tpl .='<div class="price-row">
                                                    <label>Service tax</label> -- <label>' . number_format($shaddowInvoice[0]['SERVICE_TAX']) . '</label>
                                                </div>
                                <div class="price-row">
                                   <label class="total">Total</label> -- <label class="total">' . number_format($shaddowInvoice[0]['AMOUNT']) . '</label>
                                    <input type="hidden" id="performa_id" value="' . $shaddowInvoice[0]['PROFORMA_INVOICE_ID'] . '" name="performa_id"/>
                                        <input type="hidden" name="ctotal" id="ctotal" value="'.$shaddowInvoice[0]['AMOUNT'].'" />';
                $tpl .='</div></div></div></div>';

                $tpl .='<div class="amountbox">
                <div class="amount-heading">
                    <ul>
                        <li><span>Amount Received</span> <input '.$readOnly.' id="total_recived" readonly="readonly" name="total_recived" type="text" class="amount-input" value="' . number_format($ledgerInvoice[0]['TOTAL_AMOUNT_RECIVED']) . '" />
                            <input type="hidden" name="tel_allowed" id="tel_allowed" value="'.$ledgerInvoice[0]['TOTAL_BUDGET_ALLOWED'].'"</li>
                        <li><span>Allowed Payment</span> <input '.$readOnly.' readonly="readonly" id="budget_allowed" name="budget_allowed" type="text" class="amount-input" value="' . number_format($ledgerInvoice[0]['TOTAL_BUDGET_ALLOWED']) . '" />
                        <input id="budget_alloweduc" name="budget_alloweduc" type="hidden" class="amount-input" value="' . $ledgerInvoice[0]['TOTAL_BUDGET_ALLOWED'] . '" />
                        </li>
                        <li><span>Net Difference </span><input '.$readOnly.' id="net_diff" readonly="readonly" name="net_diff" type="text" class="amount-input" value="' . number_format($ledgerInvoice[0]['NET_DEFF']) . '" /></li>
                            <input id="invoice_id" name="invoice_id" type="hidden" class="amount-input" value="' . $ledgerInvoice[0]['INVOICE_ID'] . '" />';
                            if($stP == '1'){
                                $tpl .='<input id="service_tax" name="service_tax" type="hidden" class="amount-input" value="'.$ledgerInvoice[0]['SERVICE_TAX'].'" />';
                            }else{
                               $tpl .='<input id="service_tax" name="service_tax" type="hidden" class="amount-input" value="0.00" />';
                            }

                    $tpl .='</ul>
                </div>
                <div class="amount-structure">
                    <div class="pricebox">
                    <input type="hidden" value="' . $ServicesString . '" name="serviceIdHidden" id="serviceIdHidden"/>
                    <input type="hidden" value="' . $PublishersString . '" name="publisherIdHidden" id="publisherIdHidden"/>';

                    foreach ($ledgerdetailsInvoice as $details) {
                        if (array_key_exists($details['PUBLISHER_ID'], $publishersArray)) {
                            $tpl .= '<div class="price-row">
                                        <label>' . $publishersArray[$details['PUBLISHER_ID']] . '</label> -- <label><input type="text" '.$readOnly.' name="publisher_agl_' . $details['PUBLISHER_ID'] . '" id="publisher_agl_' . $details['PUBLISHER_ID'] . '" value="' . $details['AMOUNT'] . '" class="topsection-input" onkeyup="sumadvValue(this.value,' . $details['PUBLISHER_ID'] . '); reverseCalculationForPPCAdv(this.value,' . $details['PUBLISHER_ID'] . ');" /></label>
                                    </div>';
                            $tpl .= '<div class="price-row">
                                        <label>AGL Charge for ' . $publishersArray[$details['PUBLISHER_ID']] . '</label> -- <label><input type="text" '.$readOnly.' readonly="readonly" name="charge_agl_' . $details['PUBLISHER_ID'] . '" id="charge_agl_' . $details['PUBLISHER_ID'] . '" value="' . $details['AGL_CHARGES'] . '" class="topsection-input"  /></label>
                                            <input type="hidden" name="agl_method_' . $details['PUBLISHER_ID'] . '" id="agl_method_' . $details['PUBLISHER_ID'] . '"  value="' . $details['METHODS'] . '"/>
                                            <input type="hidden" name="agl_percentage_' . $details['PUBLISHER_ID'] . '" id="agl_percentage_' . $details['PUBLISHER_ID'] . '"  value="' . $details['AGL_CHARGES_PERCENTAGE'] . '"/>
                                            <input type="hidden" name="getAglCharge" value="" id="getAglCharge"/>
                                    </div>';
                        }
                    if ($details['SERVICE_ID'] != '2') {
                        foreach ($services as $service) {
                            if ($service['ID'] == $details['SERVICE_ID']) {
                                $tpl .= '<div class="price-row">
                                    <label>' . $service['SERVICE_SHORT_NAME'] . '</label> -- <label><input type="text" name="service_agl_' . $service['ID'] . '" id="service_agl_' . $service['ID'] . '" value="' . $details['AMOUNT'] . '" class="topsection-input" onkeyup="calculateAdvServiceTax(this.value,' . $service['ID'] . '); reverseCalculationForNONPPCAdv(this.value,' . $service['ID'] . ');"/></label>
                                </div>';
                            }
                        }
                    }
                }
                $tpl .= '<div class="price-row">
                            <label>TDS</label> -- <label><span id="tds">' . $ledgerInvoice[0]['TDS'] . '</span></label>

                         </div>';
                        if($stP == '1'){
                            $tpl .= '<input type="hidden" id="stP" value="'.$stP.'" name="stP"/>';
                        }else{
                            $tpl .= '<input type="hidden" id="stP" value="0" name="stP"/>';
                        }
                        $tpl .='<div class="price-row">
                        <label>SubTotal</label> -- <label><input type="text" '.$readOnly.' name="sub_total" readonly="readonly" id="sub_total" value="' . $ledgerInvoice[0]['SUBTOTAL'] . '" class="topsection-input" /></label>
                        </div>
                        <div class="price-row">
                        <label class="total">Total</label> -- <label class="total"><input '.$readOnly.' readonly="readonly" type="text" name="total" id="total" value="' . $ledgerInvoice[0]['TOTAL_AMT'] . '" class="topsection-input" /></label>
                        </div>
                        <div class="savebtn">
                            <input type="button" '.$disabled.' name="submit" id="abutton" value="Save" class="btn" onClick="return addPayemntCmDetails();" />
                            <img src="'.IMAGE_PATH.'ajax-loader.gif" id="ajaxPaymentForm" style="display:none;" />
                        </div>
                    </div>
                </div>
            </div>
         </div>
        </form>';
        $netVar = array();
        if ($PublishersString != '0') {
            $pubString = explode(',', $PublishersString);
            for ($i = 0; $i < count($pubString); $i++) {
                if (array_key_exists($pubString[$i], $publishersArray)) {
                    $netVar[] = $publishersArray[$pubString[$i]] . '_' . $pubString[$i] . '~' . $i;
                 @$netCount[] = $i;

                 }
            }
        }
        $explodeData = @implode(',', $netVar);
        $fertherExplode = @implode(',',$netCount);

        $netUp = array();
        if(@$resgetgcidbreakup['CODE'] != 'C-103'){
            foreach($resgetgcidbreakup as $resp){
                if($resp['UP'] !=""){
                    $up[] = $resp['UP'];
                    $dw[] = $resp['DW'];
                }
            }

            foreach($resgetgcidbreakup as $resp){
                $explode = explode('_',$resp['UP']);
                $netUp[] = $explode[0].'_'.$explode[1].'~'.$explode[2];
            }
        }
        @$up = implode(',', @$netUp);
        @$dw = implode(',', @$dw);
        if(@$PublishersString !='0'){
        $tpl .='<form action="/Invoice/publisherbreakup" id="publisherbreakup" name="publisherbreakup" method="post">
            <input type="hidden" name="paymentId" value="'.$paymentId.'" />
            <div class="pulishe-sec">
            <img src="'.IMAGE_PATH.'ajax-big-loader.gif" id="ajaxbigloader" style="display:none;position:absolute;left:45%;" />
            <h3>Publishers Budget</h3>';
            if($up !="") {
                $tpl .='<input type="hidden" id="upcount" name="upcount" value="'.$up.'"/>';
            } else {
              $tpl .='<input type="hidden" id="upcount" name="upcount" value="'.$explodeData.'"/>';
            }
            if($dw !="") {
             $tpl .='<input type="hidden" id="dwncount" name="dwncount" value="'.$dw.'"/>';
            } else {
                $tpl .='<input type="hidden" id="dwncount" name="dwncount" value="'.$fertherExplode.'"/>';
            }

            $tpl .='<input type="hidden" id="invoiceId" name="invoiceId" value="'.$shaddowInvoice[0]['ID'].'"/>
            <input type="hidden" name="clientId" value="'.$shaddowInvoice[0]['CLIENT_ID'].'"/>';

            if(@$PublishersString !='0'){
                $pubString = explode(',', $PublishersString);


                for($i=0;$i<count($pubString);$i++){
                    if(array_key_exists($pubString[$i],$publishersArray)){

                    $pub = "'";
                    $pub .=$publishersArray[$pubString[$i]];
                    $pub .="'";

                    $cUrl = $Common->getBrodcasterUrl() . 'Project/get-Project-And-Gc-Id-By-Client-Id-And-Publisher-Id/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/clientId/' . $ledgerInvoice[0]['CLIENT_ID'] . '/roleId/' . $roleId . '/publisherId/'.$pubString[$i];
                    $responsePub = json_decode($Common->cUrlCall($cUrl),true);

                    foreach ($ledgerdetailsInvoice as $details){
                     if($details['PUBLISHER_ID']==$pubString[$i]){
                    $tpl .='<h4>'.$publishersArray[$pubString[$i]].'&nbsp (<span id="pub_gcid_'.$pubString[$i].'">'.number_format($details['AMOUNT']).'</span>)</h4>
                     <div class="servicebox"  id="main_append_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_0">';
                            if(@$resgetgcidbreakup['CODE'] != 'C-103'){
                               foreach($resgetgcidbreakup as $resp){
                                    if($resp['PUBLISHER_ID']==$pubString[$i]){
                                        $split = explode('_',$resp['UP']);
                                        $upt = "'";
                                        $upt .= $resp['UP'];
                                        $upt .="'";
                                        $tpl .='<div class="servicerow added" id="main_div_'.$resp['UP'].'">';
                                                if(@$responsePub['CODE'] != 'C-103'){
                                                $tpl .='<select name="gcproject_'.$resp['UP'].'" id="gjproject_'.$resp['UP'].'">';

                                                $disable = '0';
                                                foreach($responsePub as $resPub){
                                                    $tpl .='<option value="'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'"'; if($resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID']==$resp['GCID']){ $tpl .='selected="selected"';} $tpl .='>'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'</option>';
                                                }
                                            $tpl .='</select>
                                            <input type="text" class="service-input" value="'.$resp['AMOUNT'].'" name="valueAmt_'.$resp['UP'].'" id="valueAmt_'.$resp['UP'].'" onkeyup="calculateGcidCharge('.$pubString[$i].','.$pub.','.$split[2].');"/>';

                                            $tpl .='<div class="add-delete"><a href="Javascript:void(0);" class="add" onclick="addRow('.$pubString[$i].','.$pub.','.$ledgerInvoice[0]['CLIENT_ID'].');">Add</a>';

                                                    $tpl .='<a href="Javascript:void(0);" class="delete" onclick="removeRow(' . $pubString[$i] . ',' . $pub . ',' . $upt. ');">Remove</a>';

                                                $tpl .='</div>';
                                             $tpl .='</div>';
                                                }else{
                                                $disable = '1';
                                                $tpl .='Please map publisher id for '.$publishersArray[$pubString[$i]];
                                            }
                                    }
                                }
                            }else{
                                $tpl .='<div class="servicerow added" id="main_div_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'">';
                                            if(@$responsePub['CODE'] !='C-103'){
                                                $tpl .='<select name="gcproject_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'" id="gjproject_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'">';

                                                $disable = '0';
                                                foreach($responsePub as $resPub){
                                                $tpl .='<option value="'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'">'.$resPub['PROJECT_NAME'].'_'.$resPub['PUBLISHER_ACCOUNT_ID'].'</option>';
                                               }
                                                $tpl .='</select>
                                                       <input type="text" class="service-input" value="" name="valueAmt_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'" id="valueAmt_'.$publishersArray[$pubString[$i]].'_'.$pubString[$i].'_'.$i.'" onkeyup="calculateGcidCharge('.$pubString[$i].','.$pub.','.$i.');"/>
                                                       <div class="add-delete"><a href="Javascript:void(0);" class="add" onclick="addRow('.$pubString[$i].','.$pub.','.$ledgerInvoice[0]['CLIENT_ID'].');">Add</a></div>
                                                  </div>';
                                            }else{
                                                $disable = '1';
                                                $tpl .='Please map publisher id for '.$publishersArray[$pubString[$i]];
                                           }
                             }

                     $tpl .='</div>';
                    }
                    }
                    }
                }
            }

                $tpl .= '<div class="savebtn">';
                     if(@$disable == '0'){
                        $tpl .= '<input type="submit" value="Save" class="btn" id="save_break" />';
                     }else{
                       $tpl .= '<input type="submit" value="Save" class="btn"  disabled="disabled" />';
                     }
                $tpl .= '</div>
            </div>
        </div
        </form>';
        }
    $tpl .= '</div>
    </div>';




        echo $tpl;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

	public function getBudgetInfo($gcid) {
        $Common = new Common();

        $curl = "http://adwords.aglkuber.in/examples/AdWords/v201306/AccountManagement/GetBudgetOrders.php?gcid=".$gcid;
        $result = json_decode($Common->cUrlCall($curl), true);
        return $result;
    }

    public function ajaxBudgetInfoAction() {
        $ns = new Zend_Session_Namespace('AGLconSol');
        $gcid = $this->_request->getparam('gcid');
        $Common = new Common();

        if($ns->USER_ROLE != '5') {
            $curl = "http://adwords.aglkuber.in/examples/AdWords/v201306/AccountManagement/GetBudgetOrders.php?gcid=".$gcid;
            $result = json_decode($Common->cUrlCall($curl), true);

            $html = '';
            $html .= '<div class="servicerow-value">
                        <span class="label">Budget :</span>
                        <span class="value">'.number_format($result['spendingLimit']['microAmount']/1000000).'</span>
                    </div>
                    <div class="servicerow-value">
                        <span class="label">Start Date :</span>
                        <span class="value">'.date('d M Y',  strtotime($result['startDateTime'])).'</span>
                    </div>
                    <div class="servicerow-value last">
                        <span class="label">End Date :</span>
                        <span class="value">'.date('d M Y', strtotime($result['endDateTime'])).'</span>
                    </div>
                    <a onclick="editBudget('.$gcid.');" class="edit link">Edit</a>';
            echo $html;
        } else {
            echo '<div class="servicerow-section clearfix">
                    <div class="servicerow-value">
                        <select style="width:178px;" class="checkactivity">
                            <option>Check Account Last Activities</option>
                            <option value="spent_'.$gcid.'">Last 5 Spents</option>
                            <option value="budget_'.$gcid.'">Last 5 Budgets</option>
                        </select>
                    </div>
                </div>';
        }
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function editBudgetInfoAction() {
        $gcid = $this->_request->getparam('gcid');
        $Common = new Common();

        $curl = "http://adwords.aglkuber.in/examples/AdWords/v201306/AccountManagement/GetBudgetOrders.php?gcid=".$gcid;
        $result = json_decode($Common->cUrlCall($curl), true);

        $html = '';
        $html .= '<ul>
                    <li class="clearfix">
                        <span class="left">GCID</span>
                        <span class="right">'.$gcid.'</span>
                        <input type="hidden" id="updatebudgetgcid" value="'.$gcid.'"  />
                        <input type="hidden" id="updatebudgetbid" value="'.$result['id'].'"  />
                    </li>
                    <li class="clearfix">
                        <label class="left" for="budget">Budget: </label>
                        <span class="right"><input type="text" id="updatebudgetbudget" class="textbox" value="'.($result['spendingLimit']['microAmount']/1000000).'"/></span>
                    </li>
                    <li class="clearfix">
                        <label class="left" for="startDate">Start Date: </label>
                        <span class="right"><input type="text" id="updatebudgetstartDate" class="textbox" value="'.date('d M Y',  strtotime($result['startDateTime'])).'"/></span>
                    </li>
                    <li class="clearfix">
                        <label class="left" for="endDate">End Date: </label>
                        <span class="right"><input type="text" id="updatebudgetendDate" class="textbox" value="'.date('d M Y',  strtotime($result['endDateTime'])).'" /></span>
                    </li>
                    <li class="submit-field">
                        <input type="button" value="Save" id="updatebudgetorder"/>
                        <img src="'.IMAGE_PATH.'ajax-loader.gif" class="ajaxsmallloader" style="display:none;"/>
                    </li>
                </ul>';
        echo $html;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function updateBudgetInfoAction() {
        $gcid = $this->_request->getparam('gcid');
        $bid = $this->_request->getparam('bid');
        $startDate = date('Ymd', strtotime($this->_request->getparam('startDate')));
        $endDate = date('Ymd', strtotime($this->_request->getparam('endDate')));
        $budget = $this->_request->getparam('budget');
        $Common = new Common();
        $ns = new Zend_Session_Namespace('AGLconSol');

        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;

        $data = array();
        $data['gcid']       = $gcid;
        $data['bid']        = $bid;
        $data['budget']     = $budget;
        $data['startdate']  = $startDate;
        $data['enddate']    = $endDate;
        $data['createdby']  = $userName;

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/update-Budget-Info/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId;
        $Common->cUrlCallWithPost($cClient, $data);

        $curl = "http://adwords.aglkuber.in/examples/AdWords/v201306/AccountManagement/UpdateBudgetOrders.php?gcid=".$gcid."&baid=8706105266&bid=".$bid."&amount=".$budget."&sdate=".$startDate."&edate=".$endDate;
        $Common->cUrlCall($curl);

        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function getAccountActivitesAction() {
        $Common = new Common();
        $data = $this->_request->getparam('value');
        $data = explode('_', $data);
        $html = '';

        if($data[0] == 'spent') {
            $curl = "http://adwords.aglkuber.in/examples/AdWords/v201306/AccountManagement/GetLastFiveDaysSpent.php?gcid=".$data[1];
            $response = json_decode($Common->cUrlCall($curl), true);
            $html .= '<div id="popup17" style="margin:-125px 0px 0px -150px; width:300px;">
                        <div class="popupinner">
                            <h2>Last 5 Budget Spent</h2>
                            <div class="popup-box">
                                <div class="colSection">
                                    <div class="heading clearfix">
                                        <div class="column">Date</div>
                                        <div class="column">Spent</div>
                                    </div>';
                                    foreach(@$response as $val) {
                                        $html .= '<div class="clearfix">
                                            <div class="column">'.date("d M Y", strtotime($val['Date'])).'</div>
                                            <div class="column">'.number_format($val['TotalSpend'],2).'</div>
                                        </div>';
                                    }
                        $html .= '</div>
                            </div>
                        </div>
                        <a class="close" onclick="closeactivity();"></a>
                    </div>';
        } else if($data[0] == 'budget') {
            $curl = "http://adwords.aglkuber.in/examples/AdWords/v201306/AccountManagement/GetLastFiveAccountBudgets.php?gcid=".$data[1];
            $response = json_decode($Common->cUrlCall($curl), true);
            $html .= '<div id="popup17" style="margin:-125px 0px 0px -200px; width:400px;">
                        <div class="popupinner">
                            <h2>Last 5 Budgets</h2>
                            <div class="popup-box">
                                <div class="colSection three-column">
                                    <div class="heading clearfix">
                                        <div class="column">Start Date</div>
                                        <div class="column">Exp Date</div>
                                        <div class="column">Budget</div>
                                    </div>';
                                foreach(@$response as $val) {
                                    $html .= '<div class="clearfix">
                                        <div class="column">'.date("d M Y", strtotime($val['StartDate'])).'</div>
                                        <div class="column">'.date("d M Y", strtotime($val['EndDate'])).'</div>
                                        <div class="column">'.number_format($val['Budget']/1000000).'</div>
                                    </div>';
                                }
                        $html .= '</div>
                            </div>
                        </div>
                        <a class="close" onclick="closeactivity();"></a>
                    </div>';
        }

        echo $html;
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }


    public function deletepaymentAction(){
        $Common = new Common();
        $I = $this->_request->getparam('I');
        $LI = $this->_request->getparam('LI');
        $dbI = Zend_Registry::get('DB_C');
        $sql = "DELETE FROM cust_invoice_payment_master WHERE ID='".$LI."'";
        $dbI->query($sql);
        $sql = "DELETE FROM cust_invoice_payment_matser_details WHERE FKEY_PAYMENT_ID='".$LI."'";
        $dbI->query($sql);
        $this->_redirect('/Invoice/ledgerlist/I/'.$I);
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }


    public function getdetailspaymentAction(){

        $Common = new Common();
        $ns = new Zend_Session_Namespace('AGLconSol');

        $sKeys = $Common->getSkeys();
        $returnType = $Common->getreturnType();

        $userName = $ns->USER_EMAIL;
        $password = $ns->PASSWORD;
        $userId = $ns->USER_ID;
        $roleId = $ns->USER_ROLE;
        $InId = $this->_request->getparam('I');
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoice/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/';
        $ledgerInvoice = json_decode($Common->cUrlCall($cClient), true);
        $cClient = $Common->getBrodcasterUrl() . 'Invoice/getshaddowinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId;
        $detailsInvoice = $response1 = json_decode($Common->cUrlCall($cClient), true);

        $cClient = $Common->getBrodcasterUrl() . 'Invoice/ledgerinvoicedetails/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/userId/' . $userId . '/roleId/' . $roleId . '/InId/' . $InId . '/paymentId/';
        $ledgerdetailsInvoice = $response1 = json_decode($Common->cUrlCall($cClient), true);

        foreach ($response1 as $res) {
            $serviceArray[] = $res['SERVICE_ID'];
            $publishersArray[] = $res['PUBLISHER_ID'];
        }


        $detailsHTML = '';
        $detailsHTML = '<div class="paymen-section">
        <div class="payment-table">
        <div class="table-left-scroll">
            <ul class="payment-heading">
                <li><span>Invoice No.</span></li>
                <li><span>Actual Inv. No.</span></li>
                <li><span>Payment Date</span></li>
                <li><span> Payment Status</span></li>';

                $publishersArray = array('1' => 'Facebook', '2' => 'Google', '3' => 'Yahoo', '4' => 'Msn');
                foreach ($detailsInvoice as $details) {
                    if (array_key_exists($details['PUBLISHER_ID'], $publishersArray)) {
                       $detailsHTML .= '<li class="invoice-sec3"><span>'.$publishersArray[$details['PUBLISHER_ID']].'</span></li>';
                            }
                            if ($details['SERVICE_ID'] != '2') {
                        $detailsHTML .= '<li class="invoice-sec5"><span>';
                                if ($details['SERVICE_ID'] != '2') {
                                foreach ($services as $service) {
                                 if ($service['ID'] == $details['SERVICE_ID']) {
                                    $detailsHTML .= $service['SERVICE_SHORT_NAME'];
                                }
                             }
                           }
                            $detailsHTML .= '</span></li>';
                    }
                }
                $detailsHTML .= '<li><span>Service Tax </span></li>
                <li><span>Sub Total</span></li>
                <li><span>Bank/CC Charges</span></li>
                <li><span>TDS</span></li>
                <li><span>Total Amount </span></li>
                <li><span>Payment Mode</span></li>
            </ul>
            <div class="clear"></div>';

               if (@$ledgerInvoice['CODE'] != 'C-103') {
                    $i = 0;
                    foreach ($ledgerInvoice as $ledger) {
                    $sum = $i % 2;
                    $detailsHTML .= '<ul class="table-row">';
                        $detailsHTML .= '<li><span>'.$ledger['PROFORMA_INVOICE_ID'].'</span></li>
                        <li><span>'.$ledger['ACTUAL_INVOICE_ID'].'</span></li>
                        <li><span>'.date('jS F Y', strtotime($ledger['INVOICE_DATE'])).'</span></li>
                        <li>
                            <span>';
                            if (array_key_exists($ledger['PAYMENT_STATUS'], $paymentStatus)) {
                                $detailsHTML .=  $paymentStatus[$ledger['PAYMENT_STATUS']];
                            }
                            $detailsHTML .= '</span>
                        </li>';
                        foreach ($ledgerdetailsInvoice as $ledgerDetails) {
                           if($ledgerDetails['FKEY_PAYMENT_ID'] == $ledger['ID']) {
                                $detailsHTML .= '<li><span>'.number_format($ledgerDetails['AMOUNT']).'</span></li>';
                            }
                        }
                         $detailsHTML .= '<li><span>'.number_format($ledger['SERVICE_TAX']).'</span></li>
                        <li><span>'.number_format($ledger['SUBTOTAL']).'</span></li>
                        <li><span>'.number_format($ledger['BANK_CHARGES']).'</span></li>
                        <li><span>'.number_format($ledger['TDS']).'</span></li>
                        <li><span>'.number_format($ledger['TOTAL_AMOUNT_RECIVED']).'</span></li>
                        <li>
                            <span>';
                                if (array_key_exists($ledger['PAYMENT_TYPE'], $paymentMode)) {
                                     $detailsHTML .= $paymentMode[$ledger['PAYMENT_TYPE']];
                                }
                             $detailsHTML .= '</span>
                        </li>
                    </ul>';
                    }

         echo $detailsHTML .= '</div></div>';
         $this->_helper->layout->disableLayout();
         $this->_helper->viewRenderer->setNoRender(true);
         }else{
              echo $detailsHTML .= '<div> No payment details</div>';
             $this->_helper->layout->disableLayout();
             $this->_helper->viewRenderer->setNoRender(true);
         }
    }
}
?>
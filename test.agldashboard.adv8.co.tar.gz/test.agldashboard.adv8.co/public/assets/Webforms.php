<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AgencyReport
 *
 * @author Administrator
 */
require_once 'application/models/Common.php';

class Webforms {

    var $parentChain;

    public function getClientList() {
        //print_r($_SESSION[AGLconSol]);
        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from adv8_client where agency_id=" . $_SESSION['AGLconSol']['agencyId'] . " order by  company_name ASC";
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function getCampaignList($clientId, $landingPages = true) {
        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from adv8_client_business_unit where client_id=$clientId order by  business_unit_name ASC";
        $rows = $db->Fetchall($sql);

        $data = array();
        if ($landingPages) {
            foreach ($rows as $row) {
                $sql1 = "select * from adv8_client_landing_page where business_unit_id=$row->id order by  landing_page_name ASC";
                $row->landing_pages = $db->Fetchall($sql1);
                $data[] = $row;
            }
            return $data;
        } else {
            return $rows;
        }

        //print_r($data);
    }

    public function getLandingPages($campaignId) {
        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from adv8_client_landing_page where business_unit_id=$campaignId order by  landing_page_name ASC";
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function getUserList() {

        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from adv8_users where agency_id=" . $_SESSION[AGLconSol][agencyId] . " and agency_client_id!=0 order by  user_name ASC";
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function getFormList($params) {
        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select a.*, count(b.webform_data_id) as cnt
            from adv8_client_landing_page_webform a left join adv8_client_landing_page_webform_data b
            on  a.id=b.webform_id  where a.status ='1'";
        if ($params['clientId'])
            $sql .= " and a.client_id=$params[clientId]";
        if ($params['landingPageId'])
            $sql .= " and a.landing_page_id=$params[landingPageId]";

        $sql .= " group by a.id order by  cnt DESC";
        $rows = $db->Fetchall($sql);

        //print_r($rows);
        return $rows;
    }

    public function getFormFileds($id) {

        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from adv8_client_landing_page_webform_fields where web_form_id  = $id order by field_order";
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function getFormDetails($id, $client_id = '') {
        if ($client_id == 102) {
            $db = Zend_Registry::get('DB_LPU');
        } else {
            $db = Zend_Registry::get('DB_MASTER');
        }


        //$db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from adv8_client_landing_page_webform where id  = $id";
        $rows = $db->Fetchall($sql);
        return $rows[0];
    }

    public function getUserDetails($id) {
        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from adv8_users where id  = $id";
        $rows = $db->Fetchall($sql);
        return $rows[0];
    }

    public function saveFormStructure($params) {
        $db = Zend_Registry::get('DB_MASTER');
        $data = array();
        foreach ($params['form_data'] as $key => $value) {
            if ($key == 'campaign_id')
                $data['business_unit_id'] = $value;
            else
                $data[$key] = $value;
        }
        $data['service_from'] = date("Y-m-d H:i:s");
        $data['service_to'] = date("Y-m-d H:i:s", strtotime('next month', time()));
        //echo "<pre>";
        //print_r($data);

        $db->insert('adv8_client_landing_page_webform', $data);

        $webform_id = $db->lastInsertId();
        $i = 0;
        foreach ($params['field_data'] as $key => $value) {
            $field_type = substr((preg_replace('/\d+/', '', $key)), 0, -1);
            $field_type_id = 0;
            switch ($field_type) {
                case 'elm_heading': $field_type_id = 1;
                    break;
                case 'elm_text' : $field_type_id = 2;
                    break;
                case 'elm_textbox': $field_type_id = 3;
                    break;
                case 'elm_textarea': $field_type_id = 4;
                    break;
                case 'elm_select' : $field_type_id = 5;
                    break;
                case 'elm_radio' : $field_type_id = 6;
                    break;
                case 'elm_checkbox' : $field_type_id = 7;
                    break;
                case 'elm_date' : $field_type_id = 8;
                    break;
                case 'elm_daterange' : $field_type_id = 9;
                    break;
                case 'elm_button' : $field_type_id = 10;
                    break;
            }
            $data = array();
            $data['web_form_id'] = $webform_id;
            $data['field_type'] = $field_type_id;
            $data['attributes'] = json_encode($value);
            $data['status'] = 1;
            $data['field_order'] = $i++;
            //print_r($data);
            $db->insert('adv8_client_landing_page_webform_fields', $data);
        }
    }

    public function saveFormData($params, $obj) {
//print_R($params);exit;
        if ($params['client_id'] == 102) {

            $db = Zend_Registry::get('DB_LPU');
        } else {
            $db = Zend_Registry::get('DB_MASTER');
        }
        //$exclude = array('client_id','business_unit_id','landing_page_id','lead_owner','webform_id','lead_owner','redirect_url','Submit','button','utm_source','utm_medium','utm_campaignname','utm_campaignid','utm_adgroupname','utm_adgroupid','utm_keyword','utm_website','utm_geo','controller','action','module','webformId','action_url');

        $exclude = array('client_id', 'business_unit_id', 'landing_page_id', 'lead_owner', 'webform_id', 'lead_owner', 'redirect_url', 'Submit', 'button',
            'utm_source', 'utm_medium', 'utm_campaignname', 'utm_campaignid', 'utm_adgroupname', 'utm_adgroupid', 'utm_keyword', 'utm_website', 'utm_geo', 'utm_adtextid',
            'utm_bannername', 'utm_websitecategory', 'utm_form_source_url', 'utm_type', 'gclid', 'controller', 'action', 'module', 'webformId', 'action_url', 'owner',
            'star', 'type', 'datesee', 'dateme', 'captcha', 'submit', 'fb_user_id', 'form type', 'agl_source', 'agl_keyword', 'agl_medium', 'agl_campaign_name',
            'agl_campaignid', 'agl_adgroupId', 'agl_bannername', 'agl_websitecategory', 'agl_website', 'agl_type', 'agl_form_source_url', 'agl_adtextId', 'agl_geo',
            'agl_user_id', 'agl_campaign', 'session_user_id', 'IP', 'post_dump', 'otp', 'webfordataId', 'notification', 'thnkyoumail', 'hiddenphoneerrormessage', 'thankyoumail', 'otperror', 'mobileerror', 'doverified', 'hiddenrefererrormessage', 'specialisation1');


        $d = array();
        $data = array();

        $params['IP'] = $_SERVER['REMOTE_ADDR'];


        $data['webform_id'] = $params['webformId'];

        $sql = "select a.*, b.user_email, b.user_mobile_number from adv8_client_landing_page_webform a, adv8_users b where a.lead_owner = b.id and  a.id  = $data[webform_id]";
        $rows = $db->Fetchall($sql);

        $data['client_id'] = $rows[0]->client_id;
        $data['business_unit_id'] = $rows[0]->business_unit_id;
        $data['landing_page_id'] = $rows[0]->landing_page_id;
        $data['owner_id'] = $rows[0]->lead_owner;

        $webform_self_fields = $rows[0]->webform_self_fields;
        if (!empty($webform_self_fields)) {
            $webform_self_fields_array = explode(",", $webform_self_fields);
            foreach ($params as $key => $value) {
                if (in_array($key, $webform_self_fields_array))
                    $d[str_replace('_', ' ', $key)] = $value;
            }
        }else {
            foreach ($params as $key => $value) {
                if (!in_array($key, $exclude))
                    $d[str_replace('_', ' ', $key)] = $value;
            }
        }

        $map_form_fields = $rows[0]->map_form_fields;
        if (!empty($map_form_fields)) {
            $map_form_fields_array = explode(",", $map_form_fields);
            $emailOfUserField = $map_form_fields_array['1'];
        } else {
            $emailOfUserField = 'email';
        }

        //print_R($d);exit;


        if (!empty($params["doverified"])) {
            $data['otp_verified'] = '1';
        }

        $data['fields_data'] = json_encode($d);





        if (!empty($rows[0]->lead_owners)) {
            $lead_owners = $rows[0]->lead_owners;
            $leadOwnersArray = explode(",", $lead_owners);
            if (!empty($leadOwnersArray)) {

                $aArray = array();
                $aArray['clientId'] = $rows[0]->client_id;
                $aArray['leaveDate'] = date("Y-m-d");
                $userOnLeaveTempArray = $this->getRoster($aArray);
                $userOnLeaveArray = array();
                foreach ($userOnLeaveTempArray as $k => $v) {
                    $userOnLeaveArray[] = $v->user_id;
                }

                //print_R($userOnLeaveArray);exit;
                $activeUserArray = array_diff($leadOwnersArray, $userOnLeaveArray);
                $random_keys = array_rand($activeUserArray);
                $data['owner_id'] = $activeUserArray[$random_keys];
            }
        }

        $datauserdetail = $this->getOwnerEmail($data['owner_id']);
        $data_email[$datauserdetail[0]->user_email] = $datauserdetail[0]->user_email;
        $data_sms[$datauserdetail[0]->user_mobile_number] = $datauserdetail[0]->user_mobile_number;


        if (!empty($rows[0]->lead_notification)) {
            $lead_notification = $rows[0]->lead_notification;
            $leadNotificationArray = explode(",", $lead_notification);
            if (!empty($leadNotificationArray)) {

                foreach ($leadNotificationArray as $lOwners) {
                    $datauserdetail = $this->getOwnerEmail($lOwners);
                    $data_email[$datauserdetail[0]->user_email] = $datauserdetail[0]->user_email;
                    $data_sms[$datauserdetail[0]->user_mobile_number] = $datauserdetail[0]->user_mobile_number;
                }
            }
        }


        $thank_you_email_alert = $rows[0]->thank_you_email_alert;
        $lead_notification_alert = $rows[0]->lead_notification_alert;
        $sms_alert = $rows[0]->sms_alert;

        $data['utm_source'] = $params['utm_source'];
        $data['utm_medium'] = $params['utm_medium'];
        $data['utm_campaignname'] = $params['utm_campaignname'];
        $data['utm_campaignid'] = $params['utm_campaignid'];
        $data['utm_adgroupname'] = $params['utm_adgroupname'];
        $data['utm_adgroupid'] = $params['utm_adgroupid'];
        $data['utm_keyword'] = $params['utm_keyword'];
        $data['utm_website'] = $params['utm_website'];
        $data['utm_geo'] = $params['utm_geo'];

        $data['utm_adtextid'] = $params['utm_adtextid'];

        $data['utm_bannername'] = $params['utm_bannername'];
        $data['utm_websitecategory'] = $params['utm_websitecategory'];
        $data['utm_form_source_url'] = $params['utm_form_source_url'];
        $data['utm_type'] = $params['utm_type'];

        $data['gclid'] = $params['gclid'];
        $data['ip'] = $params['IP'];

        $data['post_dump'] = $params['post_dump'];
        $verifier = $rows[0]->verifier;
        $generatedOtp = '';
        /* if($verifier == 1){

          $generatedOtp = $this->random();
          } */
        $generatedOtp = $this->random();
        $data['otp'] = $generatedOtp;
        $data['otp_created_on'] = date("Y-m-d H:i:s");



        $data['status'] = 1;
        $data['browser'] = $_SERVER['HTTP_USER_AGENT'];

        $db->insert('adv8_client_landing_page_webform_data', $data);
        $wflids = array();
        $wflids['pushNotification'][] = array('leadId' => $db->lastInsertId(), 'ownerId' => $data['owner_id']);
        $wflids['verifier'] = $verifier;
        $wflids['otp'] = $generatedOtp;







        //ini_set("display_errors", 1);
        //////////////////////////////Thank You Email///////////////////////////
        $email = $rows[0]->user_email;

        if ($params[$emailOfUserField] && $thank_you_email_alert == 1) {
            $userEmail = $params[$emailOfUserField];

            if (empty($params['name'])) {
                $params['name'] = $params['fname'];
            }
            $htmlForthankyouEmail = $obj->partial('webforms/thanks/' . $data['client_id'] . '/' . $data['webform_id'] . '.phtml', array('lead' => $data, 'verifier' => $verifier, 'username' => $params['name']));

            //$htmlForthankyouEmail = $obj->partial('webforms/new_lead_Adv8.phtml', array('lead' => $data, 'verifier'=> $verifier));
            //$htmlForthankyouEmail;


            $subject = "Thanks ";
            $mail = new Zend_Mail();
            $mail->setType(Zend_Mime::MULTIPART_RELATED);
            //$mail->setReplyTo('Reply-To','noreply@adv8.co');
            $mail->setBodyHtml($htmlForthankyouEmail);
            $mail->setFrom("admin@adv8.co");
            //$email = "shrutikakkar26@gmail.com";
            $mail->addTo($userEmail);
            //$mail->addBcc('shrutikakkar26@gmail.com');
            $mail->setSubject($subject);
            $x = $mail->send();
            if ($x) {
                //echo "Yes";
            } else {
                //echo "No";
            }
        }
        $email = $rows[0]->user_email;

        $data_email[$email] = $email;
        $data_sms[$rows[0]->user_mobile_number] = $rows[0]->user_mobile_number;


        if ($email && $lead_notification_alert == 1) {
            if (!empty($data_email)) {
                $user_enail_string = implode(",", $data_email);
            }

            $htmlForClientEmail = $obj->partial('webforms/new_lead_Adv8.phtml', array('lead' => $data, 'verifier' => $verifier));
//echo $htmlForClientEmail;exit;
            $subject = "New Lead Submitted";
            $mail = new Zend_Mail();
            $mail->setType(Zend_Mime::MULTIPART_RELATED);
            $mail->setBodyHtml($htmlForClientEmail);
            $mail->setFrom("admin@adv8.co");
            foreach ($data_email as $emailClient) {
                $mail->addTo($emailClient);
            }

            //$mail->addBcc('shrutikakkar26@gmail.com');
            $mail->setSubject($subject);
            $x = $mail->send();
            if ($x) {
                //echo "Yes";
            } else {
                //echo "No";
            }
        }

        if ($sms_alert == 1) {

            foreach ($data_sms as $clientsmsMobile) {
                $msg = "New Lead => Name: $d[name], Phone: $d[phone], Email: $d[email]";


                $cUrl = "http://203.212.70.200/smpp/sendsms?username=adglobalapi&password=del12345&to=" . $clientsmsMobile . "&from=AGLENQ&text=" . urlencode($msg);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $cUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                //print_R($response);exit;
                if ($response === false) {
                    //echo 'Curl error: ' . curl_error($ch);
                } else {
                    //echo 'Operation completed without any errors';
                }
            }
        }

        $dir = dirname(__FILE__) . '/crm';

        $filename = $dir . '/' . $params['client_id'] . '-' . $data['landing_page_id'] . '-' . $data["webform_id"] . '.php';

        //$filename = '/path/to/foo.';

        $crmFound = 0;

        if (file_exists($filename)) {
            $crmFound = 1;
        } else {
            $filename = $dir . '/' . $params['client_id'] . '-' . $params['landing_page_id'] . '.php';

            if (file_exists($filename)) {
                $crmFound = 1;
            } else {
                $filename = $dir . '/' . $params['client_id'] . '.php';

                if (file_exists($filename)) {
                    $crmFound = 1;
                }
            }
        }


        if ($crmFound == 1) {
            require_once $filename;
        }


        return $wflids;
    }

    public function getRoster($params) {

        $db = Zend_Registry::get('DB_MASTER');
        $sqlFrag = $sqlFrag1 = '';
        if (!empty($params['clientId'])) {
            $sqlFrag = " and client_id = '" . $params['clientId'] . "'";
        }
        if (!empty($params['leaveDate'])) {
            $sqlFrag1 = " and leave_date = '" . $params['leaveDate'] . "'";
        }

        $sql = "select * from adv8_client_roster where 1 = 1 " . $sqlFrag . $sqlFrag1;
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function saveFormDataGrrenlam($params, $obj) {


        $db = Zend_Registry::get('DB_MASTER');

        $notfound = 1;
        $ipAddress = $_SERVER['REMOTE_ADDR'];

        $sql = "select webform_data_id from adv8_client_landing_page_webform_data where ip =  '" . $ipAddress . "' and submitted_on >= DATE_SUB(NOW(), INTERVAL 2 MINUTE) and webform_id = '" . $params['webform_id'] . "'";
        $row = $db->Fetchall($sql);
        if ($row)
            $notfound = 0;
        else
            $notfound = 1;


        if ($notfound == 1 || 1) {


            $exclude = array('client_id', 'business_unit_id', 'landing_page_id', 'lead_owner', 'webform_id', 'lead_owner', 'redirect_url', 'Submit', 'button',
                'utm_source', 'utm_medium', 'utm_campaignname', 'utm_campaignid', 'utm_adgroupname', 'utm_adgroupid', 'utm_keyword', 'utm_website', 'utm_geo', 'utm_adtextid',
                'utm_bannername', 'utm_websitecategory', 'utm_form_source_url', 'utm_type', 'gclid',
                'controller', 'action', 'module', 'IP', 'otp', 'webfordataId', 'notification', 'thnkyoumail', 'specialisation1', 'post_dump');

            if ($params['form_type'] == 'Self') {


                $d = array();
                $data = array();
                $params['IP'] = $_SERVER['REMOTE_ADDR'];


                $sql = "select a.*, b.user_email from adv8_client_landing_page_webform a, adv8_users b where a.lead_owner = b.id and  a.id  = $params[webform_id]";
                $rows = $db->Fetchall($sql);

                $data['client_id'] = $rows[0]->client_id;
                $data['business_unit_id'] = $rows[0]->business_unit_id;
                $data['landing_page_id'] = $rows[0]->landing_page_id;

                if($params['owner_id']) $data['owner_id'] = $params['owner_id'];
                else $data['owner_id'] = $rows[0]->lead_owner;

                print_r($data);

                $webform_self_fields = $rows[0]->webform_self_fields;
                if (!empty($webform_self_fields)) {
                    $webform_self_fields_array = explode(",", $webform_self_fields);
                    foreach ($params as $key => $value) {
                        if (in_array($key, $webform_self_fields_array))
                            $d[str_replace('_', ' ', $key)] = $value;
                    }
                }else {
                    foreach ($params as $key => $value) {
                        if (!in_array($key, $exclude))
                            $d[str_replace('_', ' ', $key)] = $value;
                    }
                }

                $map_form_fields = $rows[0]->map_form_fields;
                if (!empty($map_form_fields)) {
                    $map_form_fields_array = explode(",", $map_form_fields);
                    $emailOfUserField = $map_form_fields_array['1'];
                } else {
                    $emailOfUserField = 'email';
                }


                if (!empty($rows[0]->lead_owners)) {
                    $lead_owners = $rows[0]->lead_owners;
                    $leadOwnersArray = explode(",", $lead_owners);
                    if (!empty($leadOwnersArray)) {

                        $aArray = array();
                        $aArray['clientId'] = $rows[0]->client_id;
                        $aArray['leaveDate'] = date("Y-m-d");
                        $userOnLeaveTempArray = $this->getRoster($aArray);
                        $userOnLeaveArray = array();
                        foreach ($userOnLeaveTempArray as $k => $v) {
                            $userOnLeaveArray[] = $v->user_id;
                        }

                        //print_R($userOnLeaveArray);exit;
                        $activeUserArray = array_diff($leadOwnersArray, $userOnLeaveArray);
                        $random_keys = array_rand($activeUserArray);
                        $data['owner_id'] = $activeUserArray[$random_keys];
                    }
                }

                $datauserdetail = $this->getOwnerEmail($data['owner_id']);
                $data_email[$datauserdetail[0]->user_email] = $datauserdetail[0]->user_email;
                $data_sms[$datauserdetail[0]->user_mobile_number] = $datauserdetail[0]->user_mobile_number;


                if (!empty($rows[0]->lead_notification)) {
                    $lead_notification = $rows[0]->lead_notification;
                    $leadNotificationArray = explode(",", $lead_notification);
                    if (!empty($leadNotificationArray)) {

                        foreach ($leadNotificationArray as $lOwners) {
                            $datauserdetail = $this->getOwnerEmail($lOwners);
                            $data_email[$datauserdetail[0]->user_email] = $datauserdetail[0]->user_email;
                            $data_sms[$datauserdetail[0]->user_mobile_number] = $datauserdetail[0]->user_mobile_number;
                        }
                    }
                }


                $thank_you_email_alert = $rows[0]->thank_you_email_alert;
                $lead_notification_alert = $rows[0]->lead_notification_alert;
                $sms_alert = $rows[0]->sms_alert;



                $data['fields_data'] = json_encode($d);
                $data['webform_id'] = $params['webform_id'];


                $data['utm_source'] = $params['utm_source'];
                $data['utm_medium'] = $params['utm_medium'];
                $data['utm_campaignname'] = $params['utm_campaignname'];
                $data['utm_campaignid'] = $params['utm_campaignid'];
                $data['utm_adgroupname'] = $params['utm_adgroupname'];
                $data['utm_adgroupid'] = $params['utm_adgroupid'];
                $data['utm_keyword'] = $params['utm_keyword'];
                $data['utm_website'] = $params['utm_website'];
                $data['utm_geo'] = $params['utm_geo'];
                $data['utm_adtextid'] = $params['utm_adtextid'];
                $data['utm_bannername'] = $params['utm_bannername'];
                $data['utm_websitecategory'] = $params['utm_websitecategory'];
                $data['utm_form_source_url'] = $params['utm_form_source_url'];
                $data['utm_type'] = $params['utm_type'];
                $data['gclid'] = $params['gclid'];
                $data['ip'] = $ipAddress;

                $data['status'] = 1;
                $data['browser'] = $_SERVER['HTTP_USER_AGENT'];

                $db->insert('adv8_client_landing_page_webform_data', $data);
                $wflids = array();
                $wflids[] = array('leadId' => $db->lastInsertId(), 'ownerId' => $data['owner_id']);



                //ini_set("display_errors", 1);
                //////////////////////////////Thank You Email///////////////////////////

                if ($params[$emailOfUserField] && $thank_you_email_alert == 1) {

                    $userEmail = $params[$emailOfUserField];
                    if (empty($params['name'])) {
                        $params['name'] = $params['fname'];
                    }
                    $htmlForthankyouEmail = $obj->partial('webforms/thanks/' . $data['client_id'] . '/' . $data['webform_id'] . '.phtml', array('lead' => $data, 'verifier' => $verifier, 'username' => $params['name']));

                    $subject = "Thanks ";
                    $mail = new Zend_Mail();
                    $mail->setType(Zend_Mime::MULTIPART_RELATED);
                    //$mail->setReplyTo('Reply-To','noreply@adv8.co');
                    $mail->setBodyHtml($htmlForthankyouEmail);

                    if ($params['webform_id'] == 402) {
                        $from = 'admin@mikasafloors.com';
                    } else {
                        $from = 'admin@adv8.co';
                    }
                    $mail->setFrom($from);

                    $mail->addTo($userEmail);
                    //$mail->addBcc('shrutikakkar26@gmail.com');
                    $mail->setSubject($subject);
                    $x = $mail->send();
                    if ($x) {
                        //echo "Yes";
                    } else {
                        //echo "No";
                    }
                }


                if ($lead_notification_alert == 1) {
                    $htmlForEmail = $obj->partial('webforms/new_lead.phtml', array('lead' => $data));
                    $subject = "New Lead Submitted";
                    $mail = new Zend_Mail();
                    $mail->setType(Zend_Mime::MULTIPART_RELATED);
                    $mail->setBodyHtml($htmlForEmail);
                    $mail->setFrom("admin@adv8.co");
                    foreach ($data_email as $emailClient) {
                        $mail->addTo($emailClient);
                    }

                    //$mail->addBcc('vivek.awasthi@adglobal360.com');
                    $mail->setSubject($subject);
                    $mail->send();
                }
            } else {
                $notfound = 1;
                $ipAddress = $_SERVER['REMOTE_ADDR'];



                $owners = array();
                foreach ($params['Product'] as $product) {
                    if ((in_array('Laminates', $params['Product']) || in_array('Compact Laminates', $params['Product']) || in_array('Restroom Cubicles & Lockers', $params['Product']) || in_array('Exterior & Interior Grade Cladding', $params['Product'])) && !in_array('Laminates', $owners)) {
                        $owners[] = 'Laminates';
                    } else if ((in_array('Decorative Veneers', $params['Product'])) && !in_array('Veneers', $owners)) {
                        $owners[] = 'Veneers';
                    } else if ((in_array('Engineered Wood Floorings', $params['Product'])) && !in_array('Floor', $owners)) {
                        $owners[] = 'Floor';
                    } else if (in_array('Doors & Frames', $params['Product']) && !in_array('Door', $owners)) {
                        $owners[] = 'Door';
                    }
                }

                $wflids = array();
                $duplicate = 0;
                foreach ($owners as $owner) {
                    $d = array();
                    $params['IP'] = $_SERVER['REMOTE_ADDR'];
                    if ($params['Country'] != 'India') {
                        unset($params['State']);
                        unset($params['City']);
                    }

                    unset($params['StateOther']);
                    unset($params['CityOther']);

                    /* if ($params['City'] == 'Other') {
                      $params['City'] = $params['CityOther'];
                      unset($params['CityOther']);
                      } else {
                      unset($params['CityOther']);
                      } */
                    // echo "<pre>";
                    //print_r($params);


                    foreach ($params as $key => $value) {
                        if (!in_array($key, $exclude))
                            $d[str_replace('_', ' ', $key)] = $value;
                    }

                    $data = array();

                    $data['fields_data'] = json_encode($d);
                    $data['webform_id'] = $params['webform_id'];
                    $data['ip'] = $ipAddress;
                    $data['client_id'] = $params['client_id'];
                    $data['business_unit_id'] = $params['business_unit_id'];
                    $data['landing_page_id'] = $params['landing_page_id'];
                    $data['owner_id'] = $params['lead_owner'];
                    $data['utm_source'] = $params['utm_source'];
                    $data['utm_medium'] = $params['utm_medium'];
                    $data['utm_campaignname'] = $params['utm_campaignname'];
                    $data['utm_campaignid'] = $params['utm_campaignid'];
                    $data['utm_adgroupname'] = $params['utm_adgroupname'];
                    $data['utm_adgroupid'] = $params['utm_adgroupid'];
                    $data['utm_keyword'] = $params['utm_keyword'];
                    $data['utm_website'] = $params['utm_website'];
                    $data['utm_geo'] = $params['utm_geo'];
                    $data['status'] = 1;

                    /* $sql = "select * from adv8_client_landing_page_webform_data where fields_data like '%$params[Email]%' limit 1";
                      $row = $db->Fetchall($sql);
                      if ($row)
                      $data['duplicate'] = 1;
                      else
                      $data['duplicate'] = 0;
                     */


                    //$data['sendItTo'] = $owner;

                    $email = 'surbhi.panwar@greenlam.com';

                    $emails_cc = array();

                    if ($owner == 'Laminates') {

                        $d['Product'] = array_diff($params['Product'], array('Decorative Veneers', 'Engineered Wood Floorings', 'Doors & Frames'));

                        if ($d['State'] && $d['City']) {

                            $sql = "select a.id as owner_id,a.user_email,a.user_mobile_number from adv8_users a, product_laminates b where a.user_email = b.first_contact_bm_email 
			    and b.name_of_city_town='$d[City]' and b.name_of_state='$d[State]' limit 1";
                            $rows = $db->Fetchall($sql);
                            if ($rows[0]->owner_id > 0) {
                                $data['owner_id'] = $rows[0]->owner_id;
                                $email = $rows[0]->user_email;
                            } else {
                                $sql = "select a.id as owner_id, a.user_email,a.user_mobile_number from adv8_users a, product_laminates b where a.user_email = b.reporting_boss_zm_email 
					and name_of_city_town='$d[City]' and b.name_of_state='$d[State]' limit 1";
                                $rows = $db->Fetchall($sql);
                                if ($rows[0]->owner_id > 0) {
                                    $data['owner_id'] = $rows[0]->owner_id;
                                    $email = $rows[0]->user_email;
                                } else {
                                    $data['owner_id'] = '187';
                                    $email = "anuj.sangal@greenlam.com";
                                }
                            }
                            ///SMS to lead 
                            $phone = $rows[0]->first_contact_bm_mobile;
                            $message = "New Lead => Name: $d[Name], Phone: $d[Phone], Email: $d[Email]";
                            $url = "http://www.myvaluefirst.com/smpp/sendsms?username=adglobal360&password=global0210h&to=" . $phone . "&from=Greenl&text=" . urlencode($message) . "&dlr-url=&category=bulk";
                            file_get_contents($url);

                            $phone = '9999350914';
                            $url = "http://www.myvaluefirst.com/smpp/sendsms?username=adglobal360&password=global0210h&to=" . $phone . "&from=Greenl&text=" . urlencode($message) . "&dlr-url=&category=bulk";
                            //file_get_contents($url);
                        } else {
                            $data['owner_id'] = 503;
                            $email = 'banita.sg@greenlam.com';
                        } /* else if($d['Country'] == 'Singapore'){
                          $data['owner_id'] = 503;
                          }else if($d['Country'] == 'United States'){
                          $data['owner_id'] = 501;
                          }else if($d['Country'] == 'United Kingdom'){
                          $data['owner_id'] = 502;
                          } else {
                          $data['owner_id'] = $data['owner_id'];
                          } */
                    }

                    if ($owner == 'Veneers') {
                        $d['Product'] = array_diff($params['Product'], array('Laminates', 'Compact Laminates', 'Restroom Cubicles & Lockers', 'Exterior & Interior Grade Cladding', 'Engineered Wood Floorings', 'Doors & Frames'));

                        if ($d['State'] && $d['City']) {
                            $sql = "select a.id as owner_id,a.user_email,a.user_mobile_number from adv8_users a, products_veneer b where a.user_email = b.first_contact_rm_email and b.name_of_city_town='$d[City]' and b.name_of_state='$d[State]' limit 1";
                            $rows = $db->Fetchall($sql);
                            if ($rows[0]->owner_id > 0) {
                                $data['owner_id'] = $rows[0]->owner_id;
                                $email = $rows[0]->user_email;
                            } else {
                                $sql = "select a.id as owner_id, a.user_email,a.user_mobile_number from adv8_users a, products_veneer b where a.user_email = b.first_contact_zm_email and name_of_city_town='$d[City]' and b.name_of_state='$d[State]' limit 1";
                                $rows = $db->Fetchall($sql);
                                if ($rows[0]->owner_id > 0) {
                                    $data['owner_id'] = $rows[0]->owner_id;
                                    $email = $rows[0]->user_email;
                                } else {
                                    $data['owner_id'] = '189';
                                    $email = 'shivaji.mohinta@greenlam.com';
                                }
                            }
                            $phone = $rows[0]->first_contact_bm_mobile;
                            $message = "New Lead => Name: $d[Name], Phone: $d[Phone], Email: $d[Email]";
                            $url = "http://www.myvaluefirst.com/smpp/sendsms?username=adglobal360%20&password=global0210h&to=" . $phone . "&from=Greenlam&text=" . urlencode($message) . "&dlr-url=&category=bulk";
                            file_get_contents($url);
                        } else {
                            $data['owner_id'] = 503;
                            $email = 'banita.sg@greenlam.com';
                        } /* else if($d['Country'] == 'Singapore'){
                          $data['owner_id'] = 503;
                          }else if($d['Country'] == 'United States'){
                          $data['owner_id'] = 501;
                          }else if($d['Country'] == 'United Kingdom'){
                          $data['owner_id'] = 502;
                          } else {
                          $data['owner_id'] = $data['owner_id'];
                          } */
                    }
                    if ($owner == 'Floor') {
                        $d['Product'] = array_diff($params['Product'], array('Laminates', 'Compact Laminates', 'Restroom Cubicles & Lockers', 'Exterior & Interior Grade Cladding', 'Decorative Veneers', 'Doors & Frames'));
                        if ($d['State'] && $d['City']) {

                            $arrayOfCallCenter = array("Andaman & Nicobar", "Assam", "Bihar", "Delhi", "Haryana", "Jammu & Kashmir", "Jharkhand", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Punjab", "Rajasthan", "Sikkim", "Uttar Pradesh", "Uttranchal", "West Bengal");

                            $arrayOfInternal = array("Andhra Pradesh", "Chhattisgarh", "Dadra & Nagar Haveli", "Daman & Diu", "Goa", "Gujarat", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Pondicherry", "Tamil Nadu");

                            $foundUser = 0;
                            if (in_array($d['State'], $arrayOfCallCenter)) {
                                $foundUser = 1;
                                $data['owner_id'] = "593";
                                $email = "callcenter@greenlam.com";
                                $phone = "0987654321";
                            } else {
                                if (in_array($d['State'], $arrayOfInternal)) {
                                    $foundUser = 1;
                                    $data['owner_id'] = "592";
                                    $email = "greenlaminternal@greenlam.com";
                                    $phone = "0987654321";
                                }
                            }

                            if ($foundUser == 0) {
                                $data['owner_id'] = '188';
                                $email = 'anil.tyagi@greenlam.com';
                                $phone = '9619798186';

                                $file = fopen("grenlam_assign.txt", "a+");
                                fwrite($file, "\n");
                                fwrite($file, date("Y-m-d: H:i:s"));
                                fwrite($file, "\n");
                                fwrite($file, $data['owner_id']);
                                fwrite($file, "\n");
                                fwrite($file, "email - " . $email);
                                fwrite($file, "\n\n");
                                fclose($file);
                            }

                            /* $sql = "select a.id as owner_id,a.user_email, a.user_mobile_number from adv8_users a, products_floors b where a.user_email = b.first_contact_bm_email and b.name_of_city_town='$d[City]' and b.name_of_state='$d[State]' limit 1";
                              $rows = $db->Fetchall($sql);
                              if ($rows[0]->owner_id) {
                              $data['owner_id'] = $rows[0]->owner_id;
                              $email = $rows[0]->user_email;
                              $phone = $rows[0]->user_mobile_number;
                              } else {
                              $sql = "select a.id as owner_id, a.user_email, a.user_mobile_number from adv8_users a, products_floors b where a.user_email =  b.zm_email and name_of_city_town='$d[City]' and b.name_of_state='$d[State]' limit 1";
                              $rows = $db->Fetchall($sql);
                              if ($rows[0]->owner_id > 0) {
                              $data['owner_id'] = $rows[0]->owner_id;
                              $email = $rows[0]->user_email;
                              $phone = $rows[0]->user_mobile_number;
                              } else {
                              $data['owner_id'] = '188';
                              $email = 'anil.tyagi@greenlam.com';
                              $phone = '9619798186';
                              }
                              }
                              $phone = $rows[0]->first_contact_bm_mobile;
                              $message = "New Lead => Name: $d[Name], Phone: $d[Phone], Email: $d[Email]";
                              $url = "http://www.myvaluefirst.com/smpp/sendsms?username=adglobal360%20&password=global0210h&to=" . $phone . "&from=Greenlam&text=" . urlencode($message) . "&dlr-url=&category=bulk";
                              file_get_contents($url);

                              New Code
                              $infoArray['593']['email'] = 'callcenter@greenlam.com';
                              $infoArray['593']['phone'] = '0987654321';

                              $infoArray['592']['email'] = 'greenlaminternal@greenlam.com';
                              $infoArray['592']['phone'] = '0987654321';

                              $infoKeyArray = array_keys($infoArray);;
                              //print_R($infoArray);

                              $random_keys = array_rand($infoKeyArray);
                              $ownerId = $infoKeyArray[$random_keys];


                              $data['owner_id'] = $ownerId;
                              $email = $infoArray[$ownerId]['email'];
                              $phone = $infoArray[$ownerId]['phone']; */
                        } else {
                            $data['owner_id'] = 503;
                            $email = 'banita.sg@greenlam.com';
                            $phone = "9999999999";
                        }

                        /* else if($d['Country'] == 'Singapore'){
                          $data['owner_id'] = 503;
                          }else if($d['Country'] == 'United States'){
                          $data['owner_id'] = 501;
                          }else if($d['Country'] == 'United Kingdom'){
                          $data['owner_id'] = 502;
                          } else {
                          $data['owner_id'] = $data['owner_id'];
                          } */



                        $message = "New Lead => Name: $d[Name], Phone: $d[Phone], Email: $d[Email]";
                        $url = "http://www.myvaluefirst.com/smpp/sendsms?username=adglobal360%20&password=global0210h&to=" . $phone . "&from=Greenlam&text=" . urlencode($message) . "&dlr-url=&category=bulk";
                        file_get_contents($url);
                    }

                    if ($owner == 'Door') {
                        $d['Product'] = array_diff($params['Product'], array('Laminates', 'Compact Laminates', 'Restroom Cubicles & Lockers', 'Exterior & Interior Grade Cladding', 'Decorative Veneers', 'Engineered Wood Floorings'));
                        if ($d['State']) {
                            //$sql = "select a.id as owner_id,a.user_email, a.user_mobile_number from adv8_users a, products_doors b where a.user_email = b.first_contact_bm_email and b.name_of_city_town='$d[City]' and b.name_of_state='$d[State]' limit 1";

                            $sql = "select a.id as owner_id,a.user_email, a.user_mobile_number from adv8_users a, products_doors b where a.user_email = b.first_contact_bm_email and b.name_of_state='$d[State]'   limit 1";
                            $rows = $db->Fetchall($sql);
                            if ($rows[0]->owner_id) {
                                $data['owner_id'] = $rows[0]->owner_id;
                                $email = $rows[0]->user_email;
                                $phone = $rows[0]->user_mobile_number;
                            } else {
                                $sql = "select a.id as owner_id, a.user_email, a.user_mobile_number from adv8_users a, products_doors b where a.user_email =  b.first_contact_zm_email and b.name_of_state='$d[State]' limit 1";
                                $rows = $db->Fetchall($sql);
                                if ($rows[0]->owner_id > 0) {
                                    $data['owner_id'] = $rows[0]->owner_id;
                                    $email = $rows[0]->user_email;
                                    $phone = $rows[0]->user_mobile_number;
                                } else {
                                    $sql = "select a.id as owner_id, a.user_email, a.user_mobile_number from adv8_users a, products_doors b where a.user_email =  b.ch_email and b.name_of_state='$d[State]'  limit 1";
                                    $rows = $db->Fetchall($sql);
                                    if ($rows[0]->owner_id > 0) {
                                        $data['owner_id'] = $rows[0]->owner_id;
                                        $email = $rows[0]->user_email;
                                        $phone = $rows[0]->user_mobile_number;
                                    } else {
                                        $data['owner_id'] = '545';
                                        $email = 'kalyan.roy@mikasadoors.com';
                                        $phone = '9999999999';
                                    }
                                }
                            }
                            //$phone = "9999350914";
                            $message = "New Lead => Name: $d[Name], Phone: $d[Phone], Email: $d[Email]";
                            $url = "http://www.myvaluefirst.com/smpp/sendsms?username=adglobal360&password=global0210h&to=" . $phone . "&from=Greenlam&text=" . urlencode($message) . "&dlr-url=&category=bulk";
                            file_get_contents($url);
                            $data['owner_id'];
                        } else {
                            $data['owner_id'] = 503;
                            $email = 'banita.sg@greenlam.com';
                        }
                    }

                    if ($duplicate == 0) {
                        $duplicate = 1;
                        $data['duplicate'] = 0;
                    } else {
                        $data['duplicate'] = 1;
                    }
                    $data['fields_data'] = json_encode($d);
                    $db->insert('adv8_client_landing_page_webform_data', $data);
                    $wflids['pushNotification'][] = array('leadId' => $db->lastInsertId(), 'ownerId' => $data['owner_id']);
                    $wflids['verifier'] = $verifier;
                    //////////////////////////////Thank You Email///////////////////////////

                    if ($params['webform_id'] == 402) {
                        $htmlForEmail = $obj->partial('webforms/thanks/181/402.phtml');

                        $subject = "Thankyou";
                        $mail = new Zend_Mail();
                        $mail->setType(Zend_Mime::MULTIPART_RELATED);
                        $mail->setBodyHtml($htmlForEmail);
                        $mail->setFrom("admin@mikasafloors.com");
                        $mail->addTo($params['txtEmail']);
                        $mail->setSubject($subject);
                        $mail->send();
                    }

                    if ($email) {



                        /* user */
                        $htmlForEmail = $obj->partial('webforms/new_lead_users.phtml', array('lead' => $data));

                        $subject = "New Lead Submitted";
                        $mail = new Zend_Mail();
                        $mail->setType(Zend_Mime::MULTIPART_RELATED);
                        $mail->setBodyHtml($htmlForEmail);
                        $mail->setFrom("admin@greenlam.com");
                        $mail->addTo($params['Email']);
                        $mail->setSubject($subject);
                        $mail->send();


                        $htmlForEmail = $obj->partial('webforms/new_lead.phtml', array('lead' => $data));
                        $subject = "New Lead Submitted - Greenlam";
                        $mail = new Zend_Mail();
                        $mail->setType(Zend_Mime::MULTIPART_RELATED);
                        $mail->setBodyHtml($htmlForEmail);
                        $mail->setFrom("admin@greenlam.com");
                        if ($email == "callcenter@greenlam.com") {
                            $email = "callcenter@greenlam.com,nashrah@quickfins.in";
                        }
                        $mail->addTo($email);
                        //$mail->addBcc('shrutikakkar26@gmail.com');
                        $mail->setSubject($subject);



                        $sql = "select parent_manager_id from adv8_users where id = $data[owner_id]";
                        $rows = $db->Fetchall($sql);

                        $this->parentChain = array();
                        $this->getParentChain($rows[0]->parent_manager_id);

                        foreach ($this->parentChain as $parent) {
                            $message = "New Lead => Name: $d[Name], Phone: $d[Phone], Email: $d[Email]";
                            $url = "http://www.myvaluefirst.com/smpp/sendsms?username=adglobal360%20&password=global0210h&to=" . $parent->user_mobile_number . "&from=Greenlam&text=" . urlencode($message) . "&dlr-url=&category=bulk";
                            file_get_contents($url);

                            $mail->addBcc($parent->user_email);
                        }
                    }

                    $mail->send();
                }
            }

            //echo $notfound;exit;
            $message = "Thank for your enquiry. Our Branch Manager will get in touch with you shortly.";
            $url = "http://www.myvaluefirst.com/smpp/sendsms?username=adglobal360%20&password=global0210h&to=" . $d['Phone'] . "&from=Greenlam&text=" . urlencode($message) . "&dlr-url=&category=bulk";
            file_get_contents($url);
            return $wflids;
        }
    }

    function getParentChain($parent_manager_id) {
        $db = Zend_Registry::get('DB_MASTER');

        $sql = "select id as user_id, user_email, user_mobile_number,parent_manager_id from adv8_users where parent_manager_id !=0 and  id = $parent_manager_id";
        $rows = $db->Fetchall($sql);
        foreach ($rows as $row) {
            $this->parentChain[] = $row;
            $this->getParentChain($row->parent_manager_id);
        }
    }

    public function showFormData($client_id = 0, $params) {

        $db = Zend_Registry::get('DB_MASTER');

        $sql = "select a.*,
           b.business_unit_name,
           c.landing_page_name, c.landing_page_url,
           d.company_name as client

           from adv8_client_landing_page_webform a,
           adv8_client_business_unit b,
           adv8_client_landing_page c,
           adv8_client d where a.client_id=d.id
           and a.business_unit_id=b.id
           and a.landing_page_id=c.id
           and a.client_id = $client_id ";

        if ($params['business_unit_id'])
            $sql .= " and business_unit_id='$params[business_unit_id]'";

        if ($params['landing_page_id'])
            $sql .= " and landing_page_id='$params[landing_page_id]'";

        if ($params['web_form_name'])
            $sql .= " and web_form_name='$params[web_form_name]'";

        if ($params['service_from'] || $params['service_from']) {
            if ($params['service_from'] && !$params['service_to'])
                $sql .= " and service_from <= '$params[service_from]'";

            if (!$params['service_from'] && $params['service_to'])
                $sql .= " and service_to >= '$params[service_to]'";

            if ($params['service_from'] && $params['service_to'])
                $sql .= " and service_to  between '$params[service_from]' and '$params[service_to]'";
        }

        if ($params['lead_receiver_ids'])
            $sql .= " and service_to  between '$params[service_from]' and '$params[service_to]'";

        if ($params['lead_owner'])
            $sql .= " and lead_owner  = '$params[lead_owner]'";

        if ($params['wf_status'])
            $sql .= " and status  = '$params[wf_status]'";

        //echo $sql;
        $rows = $db->Fetchall($sql);

        $data = array();
        foreach ($rows as $key => $value) {
            $sql1 = "select * from adv8_client_landing_page_webform_data where webform_id=$value->id";
            if ($params['webform_id'])
                $sql .= " and webform_id  = '$params[webform_id]'";

            if ($params['lead_status'])
                $sql .= " and status  = '$params[lead_status]'";

            $sql1 .= " order by submitted_on DESC ";
            $rows1 = $db->Fetchall($sql1);
            foreach ($rows1 as $k => $v) {
                $d = $value;
                $d->lead_id = $v->webform_data_id;
                $d->submitted_on = $v->submitted_on;
                $d->lead_status = $v->status;
                $fields_data = json_decode($v->fields_data, false);
                $d->Name = $fields_data->Name;
                $d->Email = $fields_data->Email;
                $d->Phone = $fields_data->Phone;
                $data[] = $d;
            }
        }
        return $data;
    }

    public function showLead($lead_id) {

        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select a.*,
           b.business_unit_name,
           c.landing_page_name, c.landing_page_url,
           d.company_name as client,
           e.webform_data_id as lead_id, e.submitted_on,e.status as lead_status, e.fields_data

           from adv8_client_landing_page_webform a,
           adv8_client_business_unit b,
           adv8_client_landing_page c,
           adv8_client d,
           adv8_client_landing_page_webform_data e

           where a.client_id=d.id
           and a.business_unit_id=b.id
           and a.landing_page_id=c.id
           and a.id=e.webform_id
           and e.webform_data_id = $lead_id ";

        $rows = $db->Fetchall($sql);
        //echo '<pre>';
        //print_r($rows[0]);
        return $rows;
    }

    public function random($length = 6) {
        $chars = '0123456789';
        $result = '';

        for ($p = 0; $p < $length; $p++) {
            $result .= ($p % 2) ? $chars[mt_rand(0, 4)] : $chars[mt_rand(5, 9)];
        }

        return $result;
    }

    public function getDataById($data) {
        if ($data['client_id'] == 102) {
            $db = Zend_Registry::get('DB_LPU');
        } else {
            $db = Zend_Registry::get('DB_MASTER');
        }
        $sql = "select *, DATE_FORMAT(DATE_ADD(otp_created_on, INTERVAL 90 SECOND),'%Y%m%d%H%i%s') AS otp_created_on_formated  from adv8_client_landing_page_webform_data where webform_data_id = '" . $data["webfordataId"] . "'";

        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function updateOtp($data) {
        if ($data['client_id'] == 102) {
            $db = Zend_Registry::get('DB_LPU');
        } else {
            $db = Zend_Registry::get('DB_MASTER');
        }
        $sql = "UPDATE adv8_client_landing_page_webform_data set otp = '" . $data['otp'] . "', otp_created_on = now() where webform_data_id = '" . $data["webfordataId"] . "'";
        $db->query($sql);
        return "success";
    }

    public function updateFieldData($fielddata, $webforDatatId, $client_id = '') {
        if ($client_id == 102) {
            $db = Zend_Registry::get('DB_LPU');
        } else {
            $db = Zend_Registry::get('DB_MASTER');
        }

        $fielddata["address"] = str_replace(array("\n", "\r", "'", "`", '"'), '', $fielddata['address']);

        $sqlUpdate = "UPDATE adv8_client_landing_page_webform_data set fields_data = '" . json_encode($fielddata) . "' where webform_data_id = '" . $webforDatatId . "'";
        $db->query($sqlUpdate);
        return "success";
    }

    public function updateVerifyStatus($data) {
        $db = Zend_Registry::get('DB_LPU');
        if ($data['client_id'] == 102) {

            $db = Zend_Registry::get('DB_LPU');
        } else {

            $db = Zend_Registry::get('DB_MASTER');
        }
        //exit;
        $sql = "UPDATE adv8_client_landing_page_webform_data set otp_verified = '" . $data['verified'] . "' where webform_data_id = '" . $data["webfordataId"] . "'";

        $db->query($sql);
        return "success";
    }

    public function saveSuatData($data) {
        $db = Zend_Registry::get('DB_MASTER');
        $data["address"] = str_replace(array("\n", "\r", "'", "`", '"'), '', $data['address']);
        //$p['id'] = $data['phone'];
        //$row = $this->getSuatData($p);
        //if(empty($row)){
        $x = $db->insert('sharda_students', $data);
        //}
        $arr['error'] = $error;
        $arr['id'] = $x;
        return $arr;
    }

    public function getSuatData($data) {
        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from sharda_students where suat_id = '" . $data['id'] . "' || phone = '" . $data['id'] . "' ORDER BY created_at DESC limit 1";
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function getSuatDetail($data) {
        $db = Zend_Registry::get('DB_MASTER');
        if (!empty($data['order_id'])) {
            $sqlFrag = " and order_id = '" . $data['order_id'] . "'";
        }
        $sql = "select * from sharda_students where 1 = 1 " . $sqlFrag;
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function updateSuatData($data, $obj) {


        $db = Zend_Registry::get('DB_MASTER');

        if ($data['response'] == 1) {
            $sql = "UPDATE sharda_students SET amount = '" . $data['TXNAMOUNT'] . "' , transaction_id = '" . $data['TXNID'] . "' , bank_transaction_id = '" . $data['BANKTXNID'] . "' , response_code = '" . $data['RESPCODE'] . "' , response_msg = '" . $data['RESPMSG'] . "' , response_status = '" . $data['STATUS'] . "' , transaction_date = '" . $data['TXNDATE'] . "' , gateway_name = '" . $data['GATEWAYNAME'] . "' , bank_name = '" . $data['BANKNAME'] . "' , payment_mode = '" . $data['PAYMENTMODE'] . "', date_of_transaction = now() WHERE order_id = '" . $data['ORDERID'] . "'";

            $db->query($sql);
            $params['order_id'] = $data['ORDERID'];

            $detailArray = $this->getSuatDetail($params);


            $json = json_encode($detailArray);
            $detail = json_decode($json, true);
//print_R($detail);exit;
            $webforDatatId = $detail[0]['webform_data_id'];

            $fielddata = array();
            $fielddata['name'] = $detail[0]['name'];
            $fielddata['email'] = $detail[0]['email'];
            $fielddata['state'] = $detail[0]['state'];
            $fielddata['phone'] = $detail[0]['phone'];
            $fielddata['course'] = $detail[0]['courses'];
            if (empty($detail[0]['courses'])) {
                $fielddata['course'] = $detail[0]['course'];
            }

            $fielddata['specialisation'] = $detail[0]['specialisation'];
            $fielddata['academic'] = $detail[0]['academic'];
            $fielddata['dateofbirth'] = $detail[0]['dateofbirth'];
            $fielddata['gender'] = $detail[0]['gender'];
            $fielddata['city'] = $detail[0]['city'];
            $fielddata['country'] = $detail[0]['country'];

            $fielddata['address'] = str_replace(array("\n", "\r", "'", "`", '"'), '', $detail[0]['address']);
            //print_R("ddddddddddddddddddddddddddddddddd");
            //print_R($fielddata);exit;
            //$fielddata['address'] = $detail[0]['address'];

            $fielddata['origin'] = $detail[0]['origin'];

            $fielddata['SUATID'] = $detail[0]['suat_id'];

            $fielddata['ORDERID'] = $data['ORDERID'];
            $fielddata['TXNAMOUNT'] = $data['TXNAMOUNT'];
            $fielddata['TXNAMOUNT'] = $data['TXNAMOUNT'];
            $fielddata['TXNID'] = $data['TXNID'];
            $fielddata['BANKTXNID'] = $data['BANKTXNID'];

            $fielddata['RESPCODE'] = $data['RESPCODE'];
            $fielddata['RESPMSG'] = $data['RESPMSG'];
            $fielddata['STATUS'] = $data['STATUS'];
            $fielddata['TXNDATE'] = $data['TXNDATE'];
            $fielddata['GATEWAYNAME'] = $data['GATEWAYNAME'];
            $fielddata['BANKNAME'] = $data['BANKNAME'];
            $fielddata['PAYMENTMODE'] = $data['PAYMENTMODE'];

            $sqlUpdate = "UPDATE adv8_client_landing_page_webform_data set fields_data = '" . json_encode($fielddata) . "' where webform_data_id = '" . $webforDatatId . "'";
            $db->query($sqlUpdate);

            $msg = 'Congratulations! You have successfully applied for SUAT 2016. You will receive the System id on your registered Mobile no and E-mail id within 24 hrs.';

            $subject = 'Sharda University | Transaction Alert: ' . $data['STATUS'];
            $html = '<html>
<head>
    <meta charset="utf-8" />
    <title>New Lead</title>
</head>
<body style="font-family: Verdana, Arial, Helvetica, sans-serif; margin:0;">
	<div>
	Hi,<br/>
	Please note the following transaction made :<br/>
	NAME- ' . $fielddata['name'] . '<br/>
	EMAIL- ' . $fielddata['email'] . '<br/>
	STATE- ' . $fielddata['state'] . '<br/>
	PHONE- ' . $fielddata['phone'] . '<br/>
	COURSES- ' . $fielddata['course'] . '<br/>
	Specialisation- ' . $fielddata['specialisation'] . '<br/>
	SUATID- ' . $fielddata['SUATID'] . '<br/>
	DateofBirth- ' . $fielddata['dateofbirth'] . '<br/>
	CITY- ' . $fielddata['city'] . '<br/>
	ORDERID- ' . $fielddata['ORDERID'] . '<br/>
	TXNAMOUNT- ' . $fielddata['TXNAMOUNT'] . '<br/>
	TXNID- ' . $fielddata['TXNID'] . '<br/>
	BANKTXNID- ' . $fielddata['BANKTXNID'] . '<br/>
	RESPCODE- ' . $fielddata['RESPCODE'] . '<br/>
	RESPMSG- ' . $fielddata['RESPMSG'] . '<br/>
	STATUS- ' . $fielddata['STATUS'] . '<br/>
	TXNDATE- ' . $fielddata['TXNDATE'] . '<br/>
	GATEWAYNAME- ' . $fielddata['GATEWAYNAME'] . '<br/>
	BANKNAME- ' . $fielddata['BANKNAME'] . '<br/>
	PAYMENTMODE- ' . $fielddata['PAYMENTMODE'] . '<br/>
	DATE-- ' . date("Y-m-d") . '<br/>
	ORIGIN- ' . $fielddata['origin'] . '<br/>
	
    </div>
</body>
</html>';
            $from = "admission@sharda.ac.in";
            $mail = new Zend_Mail();
            $mail->setType(Zend_Mime::MULTIPART_RELATED);
            $mail->setBodyHtml($html);

            $mail->setFrom($from, 'Sharda University');
            $mail->addTo('balwinder.singh@adglobal360.com');
            $mail->addTo('vinit.singh@sharda.ac.in');
            $mail->addTo('sorabh.kumar@sharda.ac.in');
            $mail->addTo('vinit.singh@sharda.ac.in');
            $mail->addTo('vikas.dhankhar@adglobal360.com');
            $mail->addTo('aastha.bhatia@adglobal360.com');
            $mail->addTo('raghvendra.singh@adglobal360.com');
            $mail->addTo('muskaan.aggarwal@adglobal360.com');
            $mail->addBcc('gaurav.tiwari@sharda.ac.in');
            $mail->setSubject($subject);
            $x = $mail->send();

            if ($data['STATUS'] == 'TXN_SUCCESS') {
                if ($fielddata['email']) {
                    if ($fielddata['origin'] == 'NON-SUAT') {
                        $subject = "Congratulations!! You have successfully applied for Sharda University Admissions 2016";
                        $htmlForthankyouEmail = $obj->partial('webforms/thanks/144/144-1.phtml', array('username' => $fielddata['name']));
                    }if ($fielddata['origin'] == 'SU-Microsite') {
                        $subject = "Congratulations!! You have successfully applied for Sharda University Admissions 2016";
                        $htmlForthankyouEmail = $obj->partial('webforms/thanks/144/144-2.phtml', array('username' => $fielddata['name']));
                    } else {
                        $subject = "Congratulations!! You Have Successfully Applied for SUAT 2016";
                        $htmlForthankyouEmail = $obj->partial('webforms/thanks/144/144.phtml', array('username' => $fielddata['name']));
                    }
                    $from = "admission@sharda.ac.in";

                    $mail = new Zend_Mail();
                    $mail->setType(Zend_Mime::MULTIPART_RELATED);
                    $mail->setBodyHtml($htmlForthankyouEmail);
                    //$mail->setFrom("admission@sharda.ac.in");
                    $mail->setFrom($from, 'Sharda University');

                    $mail->addTo($fielddata['email']);
                    //$mail->addBcc('shrutikakkar26@gmail.com');
                    $mail->setSubject($subject);
                    $x = $mail->send();
                }

                $to = $fielddata['phone'];
                $cUrl = 'http://otp2.maccesssmspush.com/OTP_ACL_Web/OtpRequestListener?enterpriseid=shauotp&subEnterpriseid=shauotp&pusheid=shauotp&pushepwd=shauotp12&msisdn=91' + $to + '&sender=SHUNIV&msgtext=' . urlencode($msg);

                $response = file_get_contents($cUrl);

                $file = fopen("sharda-sms.txt", "a+");
                fwrite($file, "\n");
                fwrite($file, date("Y-m-d: H:i:s"));
                fwrite($file, "\n");
                fwrite($file, $cUrl);
                fwrite($file, "\n");
                fwrite($file, "response - " . $response);
                fwrite($file, "\n\n");
                fclose($file);
            }
        } else {
            $coursearry = explode("_", $data['courses']);
            $courses = $coursearry['0'];
            $academic = $coursearry['1'];

            $address = str_replace(array("\n", "\r", "'", "`", '"'), '', $data['address']);


            $sql = "UPDATE sharda_students SET name = '" . $data['name'] . "' , email = '" . $data['email'] . "' , phone = '" . $data['phone'] . "' , state = '" . $data['state'] . "' , course = '" . $courses . "' , academic = '" . $academic . "' , specialisation = '" . $data['specialisation'] . "' , dateofbirth = '" . $data['dateofbirth'] . "' , gender = '" . $data['gender'] . "' , address = '" . $address . "' , city = '" . $data['city'] . "', country = '" . $data['country'] . "', order_id = '" . $data['ORDER_ID'] . "', status = '1' WHERE id = '" . $data['studentId'] . "'";
            $db->query($sql);
            $detailArray['error'] = 0;
        }

        return "Success";
    }

    public function getOwnerEmail($lOwners) {
        $db = Zend_Registry::get('DB_MASTER');
        $sql_email = "select user_email, user_mobile_number from adv8_users where id = $lOwners";
        $rows_email = $db->Fetchall($sql_email);
        //$data_email[$rows_email[0]->user_email] = $rows_email[0]->user_email;
        return $rows_email;
    }

    public function saveOtp($data) {
        $error = false;

        $db = Zend_Registry::get('DB_MASTER');

        $db->insert('webform_data_otp', $data);
        $arr['error'] = $error;
        return $arr;
    }

    public function getOtp($data) {
        $error = false;
        $db = Zend_Registry::get('DB_MASTER');
        $sql = "select * from webform_data_otp where mobile = '" . $data['mobile'] . "' and client_id = '" . $data['client_id'] . "' order by id desc limit 1";
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function updateSuat($data) {
        $error = false;
        $db = Zend_Registry::get('DB_MASTER');
        $sql = "UPDATE sharda_students SET course = '" . $data['courses'] . "' , academic = '" . $data['academic'] . "' , specialisation = '" . $data['specialisation'] . "' WHERE webform_data_id = '" . $data['webfordataId'] . "'";

        $db->query($sql);
        return $rows;
    }

    public function updateSuatDataByPhone($data, $obj) {


        $db = Zend_Registry::get('DB_MASTER');

        $sql = "UPDATE sharda_students SET  order_id = '" . $data['ORDER_ID'] . "', amount = '" . $data['TXN_AMOUNT'] . "', status = '1' WHERE phone = '" . $data['phone'] . "'";
        $db->query($sql);
        $detailArray['error'] = 0;
        return $detailArray;
    }

    public function getShardaDataBySystemId($data) {
        $error = false;
        $sqlFrag = $sqlFrag1 = '';
        $db = Zend_Registry::get('DB_MASTER');
        if (!empty($data['systemid'])) {
            $sqlFrag = " and systemid = '" . $data['systemid'] . "'";
        }
        if (!empty($data['mobile'])) {
            $sqlFrag1 = " and mobile = '" . $data['mobile'] . "'";
        }

        $sql = "select * from sharda_system_data where 1=1 " . $sqlFrag . ' ' . $sqlFrag1;
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function getShardaInviteData($data) {
        $error = false;
        $sqlFrag = $sqlFrag1 = '';
        $db = Zend_Registry::get('DB_MASTER');
        if (!empty($data['systemid'])) {
            $sqlFrag = " and systemid = '" . $data['systemid'] . "'";
        }
        if (!empty($data['mobile'])) {
            $sqlFrag1 = " and mobile = '" . $data['mobile'] . "'";
        }

        $sql = "select * from sharda_system_invite_data where 1=1 " . $sqlFrag . ' ' . $sqlFrag1 . ' ORDER BY id desc limit 1';
        $rows = $db->Fetchall($sql);
        return $rows;
    }

    public function insertShardaInviteData($data) {
        $error = false;
        $db = Zend_Registry::get('DB_MASTER');

        $db->insert('sharda_system_invite_data', $data);
        return 'sucess';
    }

}
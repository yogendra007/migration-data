<?php
session_start();
//mysql_connect('localhost','root','');
//mysql_select_db('test');

$host="50.62.146.5";
$pwd='$AES-128-CBC$AVuwh3ufJKhpwNJTBJHqow==$5Q7Gq9v4C1Xp0Jg5l3iSAaqzgcl2OtuWgOgTawZ4lrA=';
$user="admin";
mysql_connect($host,$user,$pwd);
mysql_select_db('shopping_report');


  <form action="index.php?report=process" method="POST" name="cost_graph" id="cost_graph" enctype="multipart/form-data" onsubmit="return Checkfiles()">
   <table width="90%"  border="0">
    <tr>
	 <td align="right">
      Upload Csv	 
	 </td>
	 <td>
	 <input type="file" name="csv_upload" id="csv_upload" class="required">
	 </td>
	 <td align="left"><input type="submit" name="uploadCsv" value="Upload"></td>
	</tr>
	
   </table
   </form>
<script type="text/javascript">
    function Checkfiles()
    {
        var fup = document.getElementById('csv_upload');
        var fileName = fup.value;
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);

    if(ext =="XLS" || ext=="xls")
    {
        return true;
    }
    else
    {
        alert("Upload .xls Extension File only");
        return false;
    }
    }
</script>
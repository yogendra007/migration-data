<?php

//DATE_FORMAT(email_reminder_date, \"%Y%m%d%H%i%s\")
include('../conn_iadv8.php');


function sendemail($to, $subject, $body, $attachmentContent, $from = 'Adv8 Alert<admin@adv8.co>', $format = 'html') {
    $emailBody = "<html><body>" . $body . "</body></html>";
    $emailSubject = $subject;
    $attachment = $attachmentContent;
    $boundary = md5(time());
    $header = "From: " . $from . "\r\n";
    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-Type: multipart/mixed;boundary=\"" . $boundary . "\"\r\n";
    $header .= 'Bcc: shruti.kakkar@adglobal360.com' . "\r\n";
    $output = '';
    if (!empty($attachment)) {

	$output = "--" . $boundary . "\r\n";
	$output .= "Content-Type: text/csv; name=\"" . date("Y-m-d") . ".csv\";\r\n";
	$output .= "Content-Disposition: attachment;\r\n\r\n";

	$output .= $attachment . "\r\n\r\n";
	$output .= "--" . $boundary . "\r\n";
    }

    $output .= "Content-type: text/html; charset=\"utf-8\"\r\n";
    $output .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
    $output .= $emailBody . "\r\n\r\n";
    $output .= "--" . $boundary . "--\r\n\r\n";
    $status = mail($to, $emailSubject, $output, $header);

    if ($status) {
	//echo "yes";
    } else {
	//echo "no";
    }


    return $status;
}


$sql  = "SELECT * FROM adv8_client_landing_page_webform_data WHERE webform_id='209' ORDER BY submitted_on DESC";

//$sql = "SELECT * FROM sharda_students WHERE response_status = 'TXN_SUCCESS' ORDER BY  created_at DESC";
$result = mysql_query($sql);
$count = mysql_num_rows($result);
$countMy = 0;
if ($count > 0) {
    while ($v = mysql_fetch_assoc($result)) {
	$params = array();

	echo $otp_verified =  $v["otp_verified"] ;
	if($otp_verified == 1){
	    
	    $fields_datajson = $v['fields_data'];
	    
	    $fieldsDataArray = json_decode($fields_datajson, true);
	    if(isset($fieldsDataArray["SUATID"])){
		
	    }else{
		$countMy = $countMy + 1;
		$nameCon = substr($fieldsDataArray['name'], 0, 2);
		$webformIdlenght = str_pad($v['webform_data_id'], 7, "0", STR_PAD_LEFT);
		
		$suatId = 'SU-' . strtoupper($nameCon) . $webformIdlenght;
		$fieldsDataArray["SUATID"] = $suatId;
		
		$sqlUpdate = "UPDATE adv8_client_landing_page_webform_data set fields_data = '".json_encode($fieldsDataArray)."' where webform_data_id = '".$v['webform_data_id']."'";
		$result = mysql_query($sqlUpdate);
		
	
	    }
	}
	
    }
} else {
    echo "No data found";
    exit;
}
echo $countMy;

?>
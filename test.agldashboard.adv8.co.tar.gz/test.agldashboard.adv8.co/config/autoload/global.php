<?php
/**
 * Global Configuration Override
 *
 * You can use this file for overriding configuration values from modules, etc.
 * You would place values in here that are agnostic to the environment and not
 * sensitive to security.
 *
 * @NOTE: In practice, this file will typically be INCLUDED in your source
 * control, so do not include passwords or other sensitive information in this
 * file.
 */

/*define('SHOPPING_AD_ARRAY',serialize(array('driver' => 'PDO_MYSQL','HOST'=>'50.62.146.5','database' =>'shopping_report','username' => 'shoppingapi','password' => 'D46umTc384TP',
'driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''),)));
//adv8dbserver.cihghgwr22up.ap-southeast-1.rds.amazonaws.com
*/
define('DB_AD_ARRAY_OLD',serialize(array('driver' => 'PDO_MYSQL','host'=>'198.12.156.187','database' =>'adv8zf2','username' => 'adv8zf2','password' => 'Ln58(pLW93))VrX',
'driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''),)));

define('SHOPPING_AD_ARRAY',serialize(array('driver' => 'PDO_MYSQL','HOST'=>'198.12.156.187','database' =>'shopping_report','username' => 'shoppingapi','password' => 'D46umTc384TP',
'driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''),)));

if($_SERVER['HTTP_HOST'] == "lpudashboard.adv8.co"){
	define('DB_AD_ARRAY',serialize(array('driver' => 'PDO_MYSQL','host'=>'52.76.110.86','database' =>'adv8zf2','username' => 'adv8zf2','password' => 'Mn67Mn459MX',
'driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''),)));
} else {
	if(0) {
	define('DB_AD_ARRAY',serialize(array('driver' => 'PDO_MYSQL','host'=>'198.12.156.187','database' =>'adv8zf2','username' => 'adv8zf2','password' => 'M1nX98@1,p6%#)V',
'driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''),)));
} else {
	define('DB_AD_ARRAY',serialize(array('driver' => 'PDO_MYSQL','host'=>'localhost','database' =>'adv8zf2','username' => 'root','password' => 'root',
'driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''),)));
}
}

define('DB_HRM_ARRAY',serialize(array('driver' => 'PDO_MYSQL','host'=>'198.12.156.187','database' =>'adv8_time_db','username' => 'adv8_time','password' => 'Ca840ilc948LSiy','driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''),)));

/* 
define('DB_AD_ARRAY',serialize(array('driver' => 'PDO_MYSQL','host'=>'50.62.146.5','database' =>'adv8','username' => 'adv8','password' => 'St(0FKc35YtGCr',
'driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''),)));
*/

return array(
    // ...
);

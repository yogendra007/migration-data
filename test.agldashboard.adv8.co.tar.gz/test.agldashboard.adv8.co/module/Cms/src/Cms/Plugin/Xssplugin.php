<?php

namespace Cms\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;
use Zend\Session\Container;

class Xssplugin extends AbstractPlugin {

    protected $_ns;

    function __construct() {
	//echo "<br>P=".time();
	$this->_ns = new Container('Adv8360');
    }

    function escape($val) {
	return htmlentities(trim($val), ENT_QUOTES);
    }

    function checklogin($e) {
	$matches = $e->getRouteMatch();
	$parent_folder_name = strtoupper($matches->getMatchedRouteName());
	$namespace = $matches->getParam('controller');
	$type = $matches->getParam('type');
	$arr = explode('\\', trim($namespace));
	$controller = array_pop($arr);
	$action = $matches->getParam('action', 'index');
	$this->_ns->_ControllerName = trim($controller);
	$this->_ns->_ActionName = trim($action);
	$this->_ns->_ModuleName = trim(trim(@$arr[0]));
	$this->_ns->_RestApiType = trim(trim($type));


 $action_array=explode("-",$this->_ns->_ActionName);
	$action_array= array_map("ucfirst",$action_array);

	$this->_ns->_CmsAclCheck = trim($this->_ns->_ModuleName . '_' . $this->_ns->_ControllerName.'_'.lcfirst(implode("",$action_array)));


	if(trim($this->_ns->Adv8Uid)!="") {
	if (trim(strtoupper($action)) == "LOGIN" || trim(strtoupper($action)) == "LOGOUT" || trim(strtoupper($this->_ns->_ModuleName)) == "SERVICES" || trim($parent_folder_name) == "OAUTH"){
	}else{	
	if($this->_ns->_ObjAcl->isAllowed(trim($this->_ns->Adv8Aclid),$this->_ns->_CmsAclCheck)){ 
		}else{
		#ini_set('display_errors', 1); 
		$matches->setParam('controller', 'Cms\Controller\Error'); // redirect
		$matches->setParam('action', 'accessdenied');
		}
	}
}
	if (trim($this->_ns->Adv8Uid) == "" && trim($this->_ns->Adv8Emailid) == "") {
	    
	  if (trim(strtoupper($action)) == "LOGIN" || trim(strtoupper($this->_ns->_ModuleName)) == "SERVICES" || trim($parent_folder_name) == "OAUTH"){
		
	    } else {
		$matches->setParam('controller', 'Cms\Controller\Login'); // redirect
		$matches->setParam('action', 'login');
		return;
	    }
	}
    }

}
<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zdend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Cms\Controller\Settings;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Services\Model\Campaigns\Campaigns;
use Services\Model\Campaigns\ClientAudiCampaigns;
use Services\Model\Clients\Client;
use Services\Model\Users;
use Services\Model\ClientBusinessUnit;
use Services\Model\ClientBusinessUnitPublisher;
use Services\Model\Webforms\ClientLandingPage;
use Services\Model\Webforms\CampaignWebforms;
use Services\Model\Webforms\ClientLandingPageWebform;
use Services\Model\Webforms\InfoLeadStatus;
use Services\Model\Role\AclUserRole;

class SettingsController extends AbstractActionController
{
	public $_view;
	public $_ObjClientAudiCampaigns;
    public $_ObjClient;
    public $_ObjCampaignWebforms;
    public $_ObjClientPublisher;
	public $_ObjClientLandingPage;
	public $_ObjClientLandingPageWebform;
	public $_ObjUsers;
	public $_ns;
	public $_agencyId;
	public $_ObjInfoLeadStatus;
	public $_ObjAclUserRole;
    public $_ObjClientBusinessUnit;
	function __construct(){
		$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
		$this->_view=new ViewModel();
		$this->_ObjClientAudiCampaigns = new ClientAudiCampaigns($adapter);
		$this->_ObjClient= new Client($adapter);
		$this->_ObjClientPublisher= new ClientBusinessUnitPublisher($adapter);
        $this->_ObjClientBusinessUnit = new ClientBusinessUnit($adapter);
        $this->_ObjClientLandingPage = new ClientLandingPage($adapter);
        $this->_ObjClientLandingPageWebform = new ClientLandingPageWebform($adapter);
        $this->_ObjCampaignWebforms = new CampaignWebforms($adapter);
		$this->_ObjInfoLeadStatus = new InfoLeadStatus($adapter);
		$this->_ObjAclUserRole=new AclUserRole($adapter);
		$this->_ObjUsers= new Users($adapter);
		
		$this->_ns = new Container('Adv8360');
		$this->_agencyId=trim($this->_ns->Adv8Agencyid);
	}

    public function indexAction()
    {	
       $clientId = $this->_ns->Adv8Clientid;
	   $Adv8Roleid = $this->_ns->Adv8Roleid;
	   $clientData = $this->_ObjClient->getClientList($agencyId);
       $this->_view->clientData = $clientData;
	   $this->_view->Adv8Roleid = $Adv8Roleid; 
	   $this->_view->Adv8Clientid = $clientId; 
	   return $this->_view;
    }
	
	public function listStatusAction(){
		$cId = $this->Xssplugin()->escape($this->getRequest()->getPost('cId'));
		if(empty($cId)){
			$cId = $this->_ns->Adv8Clientid;
		}
		$fields = array('*');
		$where = array('client_id'=>$cId);
		$listStatus = $this->_ObjInfoLeadStatus->chkLeadNm($where);
		
		$html= "";
		foreach($listStatus as $lStatus){
			if(!empty($lStatus['lead_status'])){
				$html .= '<tr class="odd gradeX" id="tr_'.$lStatus['id'].'">
						<td class="center">'.$lStatus['lead_status'].'</td>
						<td class="center">';
						if(!empty($lStatus['client_id'])){
						
							$html .= ' <a href="javascript:void(0);" class="btn btn-default btn-sm btn-icon1 icon-left1 globalBtn editLStatus" data-toggle="tooltip" data-placement="top" onclick="return editLStatus('.$lStatus['id'].');" title="Edit"><i class="entypo-pencil"></i></a>	
							<a href="javascript:void(0);" data-id="" onclick="delLStatus('.$lStatus['id'].');" class="btn btn-danger btn-sm btn-icon1 icon-left1 delete_lead_status" data-toggle="tooltip" data-placement="top" title="Delete"><i class="entypo-cancel"></i></a>';
							}
						$html .= '</td>
					</tr>';
			}
		}
		echo $html;
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function editLStatusAction(){
		$lStsId = $this->Xssplugin()->escape($this->getRequest()->getPost('lStsId'));
		$where=array('id'=>$lStsId);
		$fields=array('*');
		$statusData = $this->_ObjInfoLeadStatus->editLStatus($fields,$where);
		//echo "<pre>"; print_r($statusData); die('sdd');
		$result['error'] = 0;
		$result['lStsId'] = $statusData[0]['id'];
		$result['lStsNm'] = $statusData[0]['lead_status'];
		$result['stop_followup'] = $statusData[0]['stop_followup'];
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function delLStatusAction(){
		$lStsId = $this->Xssplugin()->escape($this->getRequest()->getPost('lStsId'));
		$fields = array('status'=>'0');
		$where = array('id'=>$lStsId);
		$delstatusData = $this->_ObjInfoLeadStatus->delLStatus($fields,$where);
		$result['error'] = 0;
		$result['lStsId'] = $lStsId;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function chklStsAction(){
		$lstatusName = $this->Xssplugin()->escape($this->getRequest()->getPost('name'));
		$stFlwp = $this->Xssplugin()->escape($this->getRequest()->getPost('stFlwp'));
		$lStsId = $this->Xssplugin()->escape($this->getRequest()->getPost('id'));
		$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('cid'));
		if(empty($clientId)){
			$clientId = $this->_ns->Adv8Clientid;
		}
		$params['client_id'] = $clientId;
		$params['lead_status'] = $lstatusName;
		$chkstatusData = $this->_ObjInfoLeadStatus->chkLeadNm($params);
		$cnt = count($chkstatusData);
		if($cnt > 0){
			$html = "Already Exists !";
			echo $html;
			$this->_view->setTerminal(true);
			exit;
		}else{
			if(!empty($lStsId)){
				$fields = array('lead_status'=>$lstatusName,'stop_followup'=>$stFlwp);
				$where = array('id'=>$lStsId);
				$updtlstatusData = $this->_ObjInfoLeadStatus->updtLStatus($fields,$where);
				$html = "Status updated successfully !";
				echo $html;
				$this->_view->setTerminal(true);
				exit;
			}else{
				$stsArray = array('client_id'=>$clientId , 'lead_status'=>$lstatusName , 'stop_followup'=>$stFlwp , 'status'=>'1');
				$addlstatus = $this->_ObjInfoLeadStatus->addLStatus($stsArray);
				$html = 'Status added successfully .';
				echo $html;
				$this->_view->setTerminal(true);
				exit;
			}
		}
	}
	
	public function listAclRolesAction(){
		$cId = $this->Xssplugin()->escape($this->getRequest()->getPost('cId'));
		if(empty($cId)){
			$cId = $this->_ns->Adv8Clientid;
		}
		$fields = array('*');
		$where = array('client_id'=>$cId , 'role_status'=>'1');
		$listRoles = $this->_ObjAclUserRole->listRoles($fields,$where);
		$html= "";
		foreach($listRoles as $lRoles){
			if(!empty($lRoles['role_name'])){
				$html .= '<tr class="odd gradeX" id="tr_'.$lRoles['id'].'">
						<td class="center">'.$lRoles['role_name'].'</td>
						<td class="center">'.$lRoles['role_desc'].'</td>
						<td class="center">';
						if(!empty($lRoles['client_id'])){
						
							$html .= ' <a href="javascript:void(0);" class="btn btn-default btn-sm btn-icon1 icon-left1 globalBtn editLRoles" data-toggle="tooltip" data-placement="top" onclick="return editLRoles('.$lRoles['id'].');" title="Edit"><i class="entypo-pencil"></i></a>	
							<a href="javascript:void(0);" data-id="" onclick="delLRoles('.$lRoles['id'].');" class="btn btn-danger btn-sm btn-icon1 icon-left1 delete_roles" data-toggle="tooltip" data-placement="top" title="Delete"><i class="entypo-cancel"></i></a>';
							}
						$html .= '</td>
					</tr>';
			}
		}
		echo $html;
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function editRolesAction(){
		$roleId = $this->Xssplugin()->escape($this->getRequest()->getPost('roleId'));
		$where=array('id'=>$roleId);
		$fields=array('*');
		$roleData = $this->_ObjAclUserRole->editRoles($fields,$where);
		$result['error'] = 0;
		$result['roleId'] = $roleData[0]['id'];
		$result['roleNm'] = $roleData[0]['role_name'];
		$result['roleDsc'] = $roleData[0]['role_desc'];
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function chkRoleAction(){
		$roleName = $this->Xssplugin()->escape($this->getRequest()->getPost('name'));
		$roleDesc = $this->Xssplugin()->escape($this->getRequest()->getPost('desc'));
		$roleId = $this->Xssplugin()->escape($this->getRequest()->getPost('id'));
		$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('cid'));
		if(empty($clientId)){
			$clientId = $this->_ns->Adv8Clientid;
		}
		$params['client_id'] = $clientId;
		$params['role_name'] = $roleName;
		$params['role_desc'] = $roleDesc;
		$chkroleData = $this->_ObjAclUserRole->chkRoleNm($params);
		$cnt = count($chkroleData);
		if($cnt > 0){
			$html = "Already Exists !";
			echo $html;
			$this->_view->setTerminal(true);
			exit;
		}else{
			if(!empty($roleId)){
				$fields = array('role_name'=>$roleName,'role_desc'=>$roleDesc);
				$where = array('id'=>$roleId);
				$updtroleData = $this->_ObjAclUserRole->updtRole($fields,$where);
				$html = "Role updated successfully !";
				echo $html;
				$this->_view->setTerminal(true);
				exit;
			}else{
				$RoleArray = array('client_id'=>$clientId , 'role_name'=>$roleName , 'role_desc'=>$roleDesc , 'role_status'=>'1', 'agency_id'=>'1');
				$addRole = $this->_ObjAclUserRole->addRole($RoleArray);
				$html = 'Role added successfully .';
				echo $html;
				$this->_view->setTerminal(true);
				exit;
			}
		}
	}
	
	public function delLRolesAction(){
		$roleId = $this->Xssplugin()->escape($this->getRequest()->getPost('roleId'));
		$fields = array('role_status'=>'0');
		$where = array('id'=>$roleId);
		$delroleData = $this->_ObjAclUserRole->delLRoles($fields,$where);
		$result['error'] = 0;
		$result['roleId'] = $roleId;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
}
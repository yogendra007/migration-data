<?php

/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zdend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Cms\Controller\Lms;

//use Zend\Mail;
//use Zend\Mime\Message as MimeMessage;
//use Zend\Mime\Part as MimePart;

use Zend\Session\Container;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\View\Model\JsonModel;

use Services\Model\Clients\Client;
use Services\Model\Users;
use Services\Model\ClientBusinessUnit;
use Services\Model\Webforms\ClientLandingPage;
use Services\Model\Webforms\ClientLandingPageWebformData;
use Services\Model\Webforms\ClientLandingPageWebform;
use Services\Model\Webforms\ShardaStudents;
use Services\Model\Webforms\LeadWebDataFollowup;
use Services\Model\Webforms\InfoLeadStatus;

use Services\Model\Webforms\ClientCallTrackingNumberSource;
use Services\Model\Notification;
use Zend\Http\Headers;
use Zend\Paginator\Paginator;
use Zend\Paginator\Adapter\ArrayAdapter;
use Services\Common\Common;

class LmsController extends AbstractActionController {

    public $_view;
    public $_ObjClient;
    public $_ObjUsers;
    public $_ns;
    public $_agencyId;
    public $_ObjClientBusinessUnit;
    public $_ObjClientLandingPage;
	public $_ObjNotification;
    protected $_ObjClientLandingPageWebformData;
    protected $_ObjClientLandingPageWebform;
    protected $_ObjLeadWebDataFollowup;
    protected $_ObjInfoLeadStatus;
    protected $_ObjShardaStudents;
	protected $_ObjClientCallTrackingNumberSource;
    //public $_ObjMail;
    public $_ObjCommon;

    function __construct() {

        //ini_set('display_errors', '1');echo "f";exit;
        $adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
        $this->_view = new ViewModel();
        $this->_ObjClient = new Client($adapter);
        $this->_ObjClientLandingPage = new ClientLandingPage($adapter);
        $this->_ObjUsers = new Users($adapter);
        $this->_ns = new Container('Adv8360');
        $this->_ObjClientBusinessUnit = new ClientBusinessUnit($adapter);
        $this->_ObjClientLandingPageWebformData = new ClientLandingPageWebformData($adapter);
        $this->_agencyId = trim($this->_ns->Adv8Agencyid);
        $this->_ObjClientLandingPageWebform = new ClientLandingPageWebform($adapter);
		$this->_ObjClientCallTrackingNumberSource = new ClientCallTrackingNumberSource($adapter);
        $this->_ObjLeadWebDataFollowup = new LeadWebDataFollowup($adapter);
        $this->_ObjInfoLeadStatus = new InfoLeadStatus($adapter);
        $this->_ObjShardaStudents = new ShardaStudents($adapter);
		$this->_ObjNotification = new Notification($adapter);
        //$this->_ObjMail = new Mail\Message();
        //$this->_ObjTransport = new Mail\Transport\Sendmail();
        $this->_ObjCommon = new Common();
    }

    public function plistAction() {
        // Session Agency Id Name Space
        $agencyId = $this->_agencyId;

        // Client List 
        $clientData = $this->_ObjClient->getClientList($agencyId);
        $this->_view->clientData = $clientData;
        return $this->_view;
    }

    function dashboardAction() {
        //die("maintance downtime");
        //$this->_ns->Adv8Clientid=1;
        //$CampaignsList=$this->_ObjClientBusinessUnit->getCampaignsList($this->_ns->Adv8Clientid,array('id','business_unit_name'));

        if ($_REQUEST['sDate']) {
            $sDate = $_REQUEST['sDate'] . " 00:00:00";
        } else {
			$sDate = date("Y-m-01 00:00:00");
		}        		
		
        if ($_REQUEST['eDate']) {
            $eDate = $_REQUEST['eDate'] . " 23:59:59";            
        } else {
			$eDate = date("Y-m-t 23:59:59");
		}
        
        $this->_view->sDate = $this->_ns->sDate = $sDate;
        $this->_view->eDate = $this->_ns->eDate = $eDate;
		$acl_role = $this->getRequest()->getPost('hdn_acl_role');
        $this->_view->acl_role = $acl_role;        
        return $this->_view;
    }
    
	public function getLeadStatusAjaxAction() {
		$sDate = !empty($_REQUEST['sDate']) ? $_REQUEST['sDate'] . " 00:00:00" : $this->_ns->sDate;
		$eDate = !empty($_REQUEST['eDate']) ? $_REQUEST['eDate'] . " 00:00:00" : $this->_ns->eDate;
		$statusSummary = $this->_ObjClientLandingPageWebform
		->getCampaignUnitsSummery_by_status($this->_ns->Adv8Clientid, '', '', '', '', $sDate, $eDate);
		return new JsonModel($statusSummary);
	}
	
	public function getCampaignUnitAjaxAction() {
		$sDate = !empty($_REQUEST['sDate']) ? $_REQUEST['sDate'] . " 00:00:00" : $this->_ns->sDate;
		$eDate = !empty($_REQUEST['eDate']) ? $_REQUEST['eDate'] . " 00:00:00" : $this->_ns->eDate;
		$campaignsList = $this->_ObjClientBusinessUnit->getCampaignUnitsSummery($this->_ns->Adv8Clientid, '', '', '', '', $sDate, $eDate);
		return new JsonModel($campaignsList);
	}
	
	public function getLeadOwnerAjaxAction() {
		$sDate = !empty($_REQUEST['sDate']) ? $_REQUEST['sDate'] . " 00:00:00" : $this->_ns->sDate;
		$eDate = !empty($_REQUEST['eDate']) ? $_REQUEST['eDate'] . " 00:00:00" : $this->_ns->eDate;
		$owner_summery = $this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_lead_owner($this->_ns->Adv8Clientid, $acl_role, '', '', '', '', $sDate, $eDate);
		return new JsonModel($owner_summery);
	}
	
	public function getLeadHistoryAjaxAction() {
		$sDate = !empty($_REQUEST['sDate']) ? $_REQUEST['sDate'] . " 00:00:00" : $this->_ns->sDate;
		$eDate = !empty($_REQUEST['eDate']) ? $_REQUEST['eDate'] . " 00:00:00" : $this->_ns->eDate;
		$leadHistory = $this->_ObjClientLandingPageWebform->getLeadHistory($this->_ns->Adv8Clientid);
		return new JsonModel($leadHistory);
	}
	
	public function getProductSummaryAjaxAction() {
		$sDate = !empty($_REQUEST['sDate']) ? $_REQUEST['sDate'] . " 00:00:00" : $this->_ns->sDate;
		$eDate = !empty($_REQUEST['eDate']) ? $_REQUEST['eDate'] . " 00:00:00" : $this->_ns->eDate;
		$productSummary = $this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_product($this->_ns->Adv8Clientid, '', '', '', '', $sDate, $eDate);
		return new JsonModel($productSummary);
	}
	
    function updateleadstatusajaxAction() {
        $status_id = $this->Xssplugin()->escape($this->getRequest()->getPost('status_id'));
        $lead_id = $this->Xssplugin()->escape($this->getRequest()->getPost('lead_id'));
        $this->_ObjClientLandingPageWebformData->update(array('status' => $status_id), array('webform_data_id' => $lead_id));
        die;
    }

    function addfollowupAction() {

        $lead_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webformdata_id'));
        if ($lead_id > 0) {

            $comments = $this->Xssplugin()->escape($this->getRequest()->getPost('follow_lead_desc'));
            $follow_lead_status = $this->Xssplugin()->escape($this->getRequest()->getPost('follow_lead_status'));

            $date = $this->Xssplugin()->escape($this->getRequest()->getPost('follow_lead_date'));

            $time = $this->Xssplugin()->escape($this->getRequest()->getPost('follow_lead_time'));

            if (!empty($date)) {
                $email_reminder_date = date('Y-m-d', strtotime($date)) . " " . date('H:i:s', strtotime($time));
            } else {
                $email_reminder_date = "0000-00-00 00:00:00";
            }


            $email_reminder = $this->Xssplugin()->escape($this->getRequest()->getPost('email_reminder'));

            $total_deal_size = $this->Xssplugin()->escape($this->getRequest()->getPost('total_deal_size'));
            $upfront_realized = $this->Xssplugin()->escape($this->getRequest()->getPost('upfront_realized'));
            $expected_payment_date = $this->Xssplugin()->escape($this->getRequest()->getPost('expected_payment_date'));

            if ($email_reminder == 'on') {
                $email_reminder = 1;
            } else {
                $email_reminder = 0;
            }
			
			$owner_id = $this->_ns->Adv8Uid;
			
			
            $this->_ObjLeadWebDataFollowup->addFolloups(array('lead_id' => $lead_id, 'comments' => $comments, 'email_reminder_date' => $email_reminder_date, 'owner_id' => $owner_id, 'status' => $follow_lead_status, 'email_reminder' => $email_reminder, 'expected_payment' => $total_deal_size, 'upfront_payment' => $upfront_realized, 'expected_payment_date' => $expected_payment_date));


            $field_data = json_encode($data);

            $call_data['upfront_payment'] = $upfront_realized;
            $call_data['expected_payment'] = $total_deal_size;
            $call_data['expected_payment_date'] = $expected_payment_date;

            $where['webform_data_id'] = $lead_id;
            $callArray = $this->_ObjClientLandingPageWebformData->update($call_data, $where);

			
			$converted_by = $this->_ns->Adv8Emailid;
				
			$notificationParam['module'] = 'Lead';
			$notificationParam['module_id'] = $lead_id;
			$notificationParam['message'] = "A followup has been added";
			$notificationParam['created_by'] = $owner_id;
			$notificationParam['created_for'] = $owner_id;
			
			$this->_ObjNotification->insert($notificationParam);
					

            if ($follow_lead_status == 'Hot' || $follow_lead_status == 'Closed Won') {

                $detailArray = $this->_ObjClientLandingPageWebformData->getDetails(array('webform_data_id' => $lead_id));
                //print_R($detailArray);exit;

                $lead_type = $detailArray[0]['lead_type'];

                $fieldsData = $detailArray[0]['fields_data'];
				//print_R($fieldsData);exit;
                if (!empty($fieldsData)) {
                    $data = json_decode($detailArray[0]['fields_data'], true);

                    $map_form_fields = $detailArray[0]['map_form_fields'];
                    if (!empty($map_form_fields)) {
                        $map_form_fields_array = explode(",", $map_form_fields);
                    } else {
                        $map_form_fields_array = array('name', 'email', 'phone');
                    }

                   $name = $data[$map_form_fields_array[0]];
				   //exit;
                    $emailForSubject = $email = $data[$map_form_fields_array[1]];
                    $phone = $data[$map_form_fields_array[2]];

                    $message = "A Lead has been Assigned to you => Name: $name, Phone: $phone, Email: $email";
                } else {
                    if ($lead_type == 'Call') {

                        $data = array(
                            "calling" => $detailArray[0]['calling'],
                            "ctn" => $detailArray[0]['ctn']
                        );

                        $ctn = $detailArray[0]['ctn'];
                        $calling = $detailArray[0]['calling'];

                        //$data = (object) $array;

                        $message = "A Lead has been Assigned to you => Ctn: $ctn, Calling: $calling";
                    }
                }

               

                $clientId = $detailArray[0]['client_id'];


                $dir = "/cms/lms/email_templates/lead_won_hot_notification";

                $viewRender = $this->getServiceLocator()->get('ViewRenderer');

                $filename = $_SERVER['DOCUMENT_ROOT'] . '/module/Cms/view/cms/lms/email_templates/lead_won_hot_notification/' . $clientId . '.phtml';



                if (file_exists($filename)) {
                    $htmlTemplate = $dir . '/' . $clientId;
                } else {
                    $htmlTemplate = $dir . '/default';
                }

                if ($_POST['lead_status'] == 'Closed Won') {
                    $statusVAr = 'Closed Won';
                    $subjectEmail = 'Closed Won ';
                } else {
                    $statusVAr = 'HOT';
                    $subjectEmail = 'HOT';
                }



                $this->_view->setTemplate($htmlTemplate);
                $this->_view->setVariable("data", $data);
                if (!empty($name)) {
                    $this->_view->setVariable("name", $name);
                    $this->_view->setVariable("email", $email);
                    $this->_view->setVariable("phone", $phone);
                } else {
                    $this->_view->setVariable("ctn", $ctn);
                    $this->_view->setVariable("calling", $calling);
                }
                $this->_view->setVariable("statusVAr", $statusVAr);
                $this->_view->setVariable("userEmail", $converted_by);
                $this->_view->setVariable("comments", $comments);
                $this->_view->setVariable("expected_payment", $total_deal_size);
                $this->_view->setVariable("upfront_payment", $upfront_realized);


                $mBody = $viewRender->render($this->_view);

                $bccArray = array();
                $subject = $subjectEmail . ' - ' . $emailForSubject;
                $to = 'shruti.kakkar@adglobal360.com';
                $ccArray = array('inbound@adglobal360.com', 'pmo@adglobal360.com', 'accounts@adglobal360.com','shrutikakkar26@gmail.com');
				$ccArray = array('shrutikakkar26@gmail.com');
                $bccArray = array();
                if ($clientId == '196') {
                    $this->_ObjCommon->sendEmail($to, $subject, $mBody, $bccArray, $ccArray);
                }
            }

			//$this->_view->setTemplate('/cms/lms/moredetails');
            //$this->_view->hdn_webformdata_id = $lead_id;
			return $this->redirect()->toUrl('/lms/details?i=' . $lead_id);
			die;
		
        }
        
    }

    function updateleadownerajaxAction() {

        $webform_id = $this->Xssplugin()->escape($this->getRequest()->getPost('webform_id'));
        $u_id = $this->Xssplugin()->escape($this->getRequest()->getPost('u_id'));


        $detailArray = $this->_ObjClientLandingPageWebformData->getDetails(array('webform_data_id' => $webform_id));
        $lead_type = $detailArray[0]['lead_type'];

        $fieldsData = $detailArray[0]['fields_data'];
        if (!empty($fieldsData)) {
            $data = json_decode($detailArray[0]['fields_data']);

            $map_form_fields = $detailArray[0]['map_form_fields'];
            if (!empty($map_form_fields)) {
                $map_form_fields_array = explode(",", $map_form_fields);
            } else {
                $map_form_fields_array = array('name', 'email', 'phone');
            }

            $name = $data->$map_form_fields_array[0];
            $email = $data->$map_form_fields_array[1];
            $phone = $data->$map_form_fields_array[2];

            $message = "A Lead has been Assigned to you => Name: $name, Phone: $phone, Email: $email";
        } else {
            if ($lead_type == 'Call') {

                $array = array(
                    "calling" => $detailArray[0]['calling'],
                    "ctn" => $detailArray[0]['ctn']
                );

                $ctn = $detailArray[0]['ctn'];
                $calling = $detailArray[0]['calling'];

                $data = (object) $array;

                $message = "A Lead has been Assigned to you => Ctn: $ctn, Calling: $calling";
            }
        }


        //print_R($data);exit;


        $clientId = $detailArray[0]['client_id'];


        $dir = "/cms/lms/email_templates/lead_assign";

        $viewRender = $this->getServiceLocator()->get('ViewRenderer');

        $filename = '/var/www/vhosts/adv8.co/agldashboard/module/Cms/view/cms/lms/email_templates/lead_assign/' . $clientId . '.phtml';



        if (file_exists($filename)) {
            $htmlTemplate = $dir . '/' . $clientId;
        } else {
            $htmlTemplate = $dir . '/default';
        }

        $this->_view->setTemplate($htmlTemplate);
        $this->_view->setVariable("data", $data);
        $mBody = $viewRender->render($this->_view);
        //exit;

        $this->_ObjClientLandingPageWebformData->update(array('owner_id' => $u_id), array('webform_data_id' => $webform_id));
		
		$created_by = $this->_ns->Adv8Uid;
		$notificationParam['module'] = 'Lead';
		$notificationParam['module_id'] = $webform_id;
		$notificationParam['message'] = "A Lead has been assigned to you";
		$notificationParam['created_by'] = $created_by;
		$notificationParam['created_for'] = $u_id;
		
		$this->_ObjNotification->insert($notificationParam);
		
		
        $params_owner = array();
        $params_owner['userId'] = $u_id;
        $ownerDetail = $this->_ObjUsers->getUserDetail($params_owner);

        //print_R($ownerDetail);exit;
        $to = $ownerDetail[0]['user_email'];
        $ownerPhone = $ownerDetail[0]['user_mobile_number'];

        $bccArray = array();
        $subject = 'Lead has been Assigned';
        if ($clientId == '196') {
            $bccArray = array('inbound@adglobal360.com');
        }
        //$bccArray = array('vidit.consul@adglobal360.com');


        $this->_ObjCommon->sendEmail($to, $subject, $mBody, $bccArray);

        $this->_ObjCommon->sendSms($ownerPhone, $message);

        echo "success";
        exit;
        die;
    }

    function detailsAction() {

        $hdn_webformdata_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webformdata_id'));
        if (empty($hdn_webformdata_id)) {
            $hdn_webformdata_id = $_REQUEST['i'];
        }

        $hdn_referfollowup = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_referfollowup'));
        $hdn_referurl = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_referurl'));


        $param['webform_data_id'] = trim($hdn_webformdata_id);
        $webform = $this->_ObjClientLandingPageWebformData->getDetails($param);
        //print_r($webform); exit;
        //$Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webformdata_id), 'next' => true));
        //$PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webformdata_id), 'last' => true));
        $Followups = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webformdata_id)));
        //print_r($Followups);
        $LeadOwners = $this->_ObjUsers->getLeadOwners($this->_ns->Adv8Clientid, array());
        $parentOwnerId = $this->_ns->Adv8Uid;

        $param = array();
        $param["ides"] = $this->_ns->Child_User_Id;

        $param["sortBy"] = "user_name ASC";

        $LeadOwners1 = $this->_ObjUsers->getUserDetail($param);
        //print_R($LeadOwners1);exit;

        $this->_view->LeadOwners = $LeadOwners1;

        $paramArray = array();
        $paramArray['clientId'] = $this->_ns->Adv8Clientid;
        //$paramArray['userId'] = $this->_ns->Adv8Uid;

        $UsersOfClients = $this->_ObjUsers->getUsers($paramArray);

        //$UsersOfClients = $this->_ObjUsers->getLowerHierarchy($paramArray);
        //print_R($UsersOfClients);exit;
        $this->_view->UsersOfClients = $UsersOfClients;


        $this->_view->setTemplate('/cms/lms/moredetails');

        /* $webform_id = $webform[0]['webform_id'];
          $convertArray = array();
          $convertArray['webform_id'] = $webform_id;
          $CallToWeb = $this->_ObjClientLandingPageWebform->getCallFields($convertArray);
          //print_R($CallToWeb);exit;
          $this->_view->ConvertData = $CallToWeb; */


        $this->_view->setTemplate('/cms/lms/moredetails');
        $sParams = array();
        $sParams['client_id'] = $this->_ns->Adv8Clientid;
        //$InfoLeadStatus = $this->_ObjInfoLeadStatus->getDetail(array('id', 'lead_status'), array('status' => 1));
        $InfoLeadStatus = $this->_ObjInfoLeadStatus->chkLeadNm($sParams);
        //echo "<pre>"; print_r($InfoLeadStatus); die('  sdf');
        $this->_view->hdn_webformdata_id = $hdn_webformdata_id;
        $this->_view->InfoLeadStatus = $InfoLeadStatus;
        $this->_view->webform = $webform;
        $this->_view->PreFollowup = $PreFollowup;
        $this->_view->Followup = $Followup;
        $this->_view->Followups = $Followups;
        $this->_view->hdn_referfollowup = $hdn_referfollowup;
        $this->_view->hdn_referurl = $hdn_referurl;
        return $this->_view;
    }

    function listAction() { //echo "f";exit;
        //print_R($_SESSION);exit;
        $webformIdsArray = $_POST['checkdelete'];
        //print_R($_POST);
        if (!empty($webformIdsArray)) {
            //print_R($_POST);
            $this->_ObjClientLandingPageWebformData->update(array('is_deleted' => '1'), array('webform_data_id' => $webformIdsArray));
        }


        if ($_REQUEST['sDate']) {
            $sDate = $_REQUEST['sDate'] . " 00:00:00";
            $this->_ns->sDate = $sDate;
        }

        if ($_REQUEST['eDate']) {
            $eDate = $_REQUEST['eDate'] . " 23:59:59";
            $this->_ns->eDate = $eDate;
        }

        if (!empty($this->_ns->sDate)) {
            $sDate = $this->_ns->sDate;
        }
        if (!empty($this->_ns->eDate)) {
            $eDate = $this->_ns->eDate;
        }

        if (empty($sDate)) {
            $sDate = date("Y-m-01 00:00:00");
            $this->_ns->sDate = $sDate;
        }
        if (empty($eDate)) {
            $eDate = date("Y-m-t 23:59:59");
            $this->_ns->eDate = $eDate;
        }


        $this->_ns->excel_data_field = array();
        $all_src = trim($this->getRequest()->getPost('all_src'));

        //$all_src = 'Doors & Frames';

        $hdn_webform_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webform_id'));
        $hdn_unit_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_unit_id'));
        $hdn_flg = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_flg'));
        $info_status = $this->Xssplugin()->escape($this->getRequest()->getPost('info_status'));
        $hdn_lead_type = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_lead_type'));
//print_R($_POST);exit;


        $owner_id = $this->Xssplugin()->escape($this->getRequest()->getPost('owner_id'));

        $this->_view->PreFollowup = $PreFollowup;
        $this->_view->Followup = $Followup;
        $this->_view->hdn_unit_id = $hdn_unit_id;
        $this->_view->info_status = $info_status;
        $this->_view->hdn_lead_type = $hdn_lead_type;
        $this->_view->owner_id = $owner_id;
        $this->_view->hdn_flg = $hdn_flg;

        $cpage = $this->Xssplugin()->escape($this->getRequest()->getPost('paginator'), '1');
        $this->_view->cpage = $cpage;

        $param['cid'] = $this->_ns->Adv8Clientid;

        $arra = $this->_ObjClientLandingPageWebformData->AdvanceFilter($param);

        $this->_view->setTemplate('/cms/lms/details');
        $this->_view->FilterData = $arra;
        ###########################################
        $this->_view->hdn_webform_id = $hdn_webform_id;
        $this->_view->hdn_unit_id = $hdn_unit_id;
        // $this->_ObjClientLandingPageWebformData->fetch_webform_data(array(),$where)
        $param['client_id'] = trim($this->_ns->Adv8Clientid);

        //if($hdn_flg==1)
        $param['business_unit_id'] = trim($hdn_unit_id);
        //if($hdn_flg==2)
        $param['info_status'] = $info_status;
        //if($hdn_flg==3)
        $param['owner_id'] = $owner_id;

        /// REPORT FILTER ///////////
        if ($hdn_unit_id)
            $param['business_unit_id'] = $hdn_unit_id;
        if ($info_status)
            $param['info_status'] = $info_status;

        if ($hdn_lead_type)
            $param['hdn_lead_type'] = $hdn_lead_type;

        if ($owner_id)
            $param['owner_id'] = $owner_id;

        //print_r($param);
        /// END REPORT FILTER //////////
        $cu_checkbox = $this->getRequest()->getPost('cu_checkbox');
        $lp_checkbox = $this->getRequest()->getPost('lp_checkbox');
        $owner_checkbox = $this->getRequest()->getPost('owner_checkbox');
        $status_checkbox = $this->getRequest()->getPost('status_checkbox');
        $leadtype_checkbox = $this->getRequest()->getPost('leadtype_checkbox');
        $createdby_checkbox = $this->getRequest()->getPost('createdby_checkbox');
        if ($this->getRequest()->isPost()) {
            $Condation['cu'] = $cu_checkbox;
            $Condation['lp'] = $lp_checkbox;
            $Condation['owner'] = $owner_checkbox;
            $Condation['lead_status'] = $status_checkbox;
            $Condation['lead_type'] = $leadtype_checkbox;
            $Condation['created_by'] = $createdby_checkbox;

            $this->_ns->CondationCheckBoxArray = $Condation;
            $this->_ns->all_src = $all_src;
            $this->_ns->page = $cpage;
        } else {
            
        }
        $this->_view->checkbox_array = $this->_ns->CondationCheckBoxArray;
        $webformArray = $this->_ObjClientLandingPageWebform->get_lead_detail($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src, $sDate, $eDate);
        $webform = array();
        if (!empty($webformArray)) {
            foreach ($webformArray as $kwebform => $vwebform) {
                //print_R($vwebform);
                $Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($vwebform['webform_data_id']), 'next' => true));
                //print_R($Followup);
                //exit;
                if (!empty($Followup)) {
                    $vwebform['nextFollowUp'] = $Followup[0]['email_reminder_date'];
                }
                $PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($vwebform['webform_data_id']), 'last' => true));

                if (!empty($PreFollowup)) {
                    $vwebform['PreFollowup'] = $PreFollowup[0]['email_reminder_date'];
                }
                $webform[$kwebform] = $vwebform;
            }
        }

        //print_R($webform);exit;
        $this->_ns->_LeadArray = $webform;
        $this->_view->all_src = $this->_ns->all_src;
//		$webform=$this->_ObjClientLandingPageWebformData->getDetails($param);
        $this->_view->webform = $webform;

        $paginator = new Paginator(new ArrayAdapter($webform));
        $paginator->setCurrentPageNumber($this->_ns->page)
                ->setItemCountPerPage(4);

        $this->_view->paginator = $paginator;

        $this->_view->sDate = $sDate;
        $this->_view->eDate = $eDate;

        return $this->_view;
    }

    /* function listfollowupbkpAction() {
      $this->_ns->excel_data_field = array();
      $all_src = $this->Xssplugin()->escape($this->getRequest()->getPost('all_src'));
      $hdn_webform_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webform_id'));
      $hdn_unit_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_unit_id'));
      $hdn_flg = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_flg'));
      $info_status = $this->Xssplugin()->escape($this->getRequest()->getPost('info_status'));
      $owner_id = $this->Xssplugin()->escape($this->getRequest()->getPost('owner_id'));
      $Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'next' => true));
      $PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'last' => true));
      $this->_view->PreFollowup = $PreFollowup;
      $this->_view->Followup = $Followup;
      $this->_view->hdn_unit_id = $hdn_unit_id;
      $this->_view->info_status = $info_status;
      $this->_view->owner_id = $owner_id;
      $this->_view->hdn_flg = $hdn_flg;

      $cpage = $this->Xssplugin()->escape($this->getRequest()->getPost('paginator'), '1');
      $this->_view->cpage = $cpage;

      $param['cid'] = $this->_ns->Adv8Clientid;

      $arra = $this->_ObjClientLandingPageWebformData->AdvanceFilter($param);

      //$this->_view->setTemplate('/cms/lms/followup');
      $this->_view->FilterData = $arra;
      ###########################################
      $this->_view->hdn_webform_id = $hdn_webform_id;
      $this->_view->hdn_unit_id = $hdn_unit_id;
      // $this->_ObjClientLandingPageWebformData->fetch_webform_data(array(),$where)
      $param['client_id'] = trim($this->_ns->Adv8Clientid);

      //if($hdn_flg==1)
      $param['business_unit_id'] = trim($hdn_unit_id);
      //if($hdn_flg==2)
      $param['info_status'] = $info_status;
      //if($hdn_flg==3)
      $param['owner_id'] = $owner_id;

      /// REPORT FILTER ///////////
      if ($hdn_unit_id)
      $param['business_unit_id'] = $hdn_unit_id;
      if ($info_status)
      $param['info_status'] = $info_status;
      if ($owner_id)
      $param['owner_id'] = $owner_id;

      //print_r($param);
      /// END REPORT FILTER //////////
      $cu_checkbox = $this->getRequest()->getPost('cu_checkbox');
      $lp_checkbox = $this->getRequest()->getPost('lp_checkbox');
      $owner_checkbox = $this->getRequest()->getPost('owner_checkbox');
      $status_checkbox = $this->getRequest()->getPost('status_checkbox');
      if ($this->getRequest()->isPost()) {
      $Condation['cu'] = $cu_checkbox;
      $Condation['lp'] = $lp_checkbox;
      $Condation['owner'] = $owner_checkbox;
      $Condation['lead_status'] = $status_checkbox;
      $this->_ns->CondationCheckBoxArray = $Condation;
      $this->_ns->all_src = $all_src;
      $this->_ns->page = $cpage;
      } else {

      }
      $this->_view->checkbox_array = $this->_ns->CondationCheckBoxArray;
      $webform = $this->_ObjClientLandingPageWebform->get_lead_detail($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src);
      //print_R($webform);exit;
      //echo"d";exit;
      //$sParam['client_id'] = $this->_ns->Adv8Clientid;
      $statusArray = array('4', '5', '6', '7', '12', '14', '15', '16');
      $webformArray = array();
      $followUpArray = array();
      $followUpArray = array();
      foreach ($webform as $k => $v) {
      if (in_array($v['status'], $statusArray)) {
      continue;
      }
      $FollowupArray = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($v['webform_data_id'])));
      if (empty($FollowupArray)) {
      continue;
      }

      if (date('Y-m-d', strtotime($FollowupArray[0]['email_reminder_date'])) == '1970-01-01') {
      //echo date('Y-m-d',strtotime($FollowupArray[0]['email_reminder_date']));
      //echo "f";exit;
      continue;
      }
      $v['email_reminder_date'] = $FollowupArray[0]['email_reminder_date'];
      if (isset($FollowupArray[1]['email_reminder_date'])) {
      $followUpPreArray[$v['webform_data_id']] = $FollowupArray[1]['email_reminder_date'];
      } else {
      $followUpPreArray[$v['webform_data_id']] = '';
      }
      }else{
      $v['email_reminder_date'] = '';
      }
      $webformArray[$k] = $v;
      }


      if (!empty($webformArray)) {
      foreach ($webformArray as $key => $row) {
      $volume[$key] = $row['email_reminder_date'];
      $followUpArray[$row['webform_data_id']] = $row['email_reminder_date'];
      }
      array_multisort($volume, SORT_DESC, $webformArray);
      }
      print_R($webformArray);
      exit;

      $this->_ns->_LeadArray = $webformArray;
      $this->_view->all_src = $this->_ns->all_src;
      //		$webform=$this->_ObjClientLandingPageWebformData->getDetails($param);
      $this->_view->webform = $webformArray;
      $this->_view->followUpArray = $followUpArray;
      $this->_view->followUpPreArray = $followUpPreArray;

      $paginator = new Paginator(new ArrayAdapter($webformArray));
      $paginator->setCurrentPageNumber($this->_ns->page)
      ->setItemCountPerPage(4);

      $this->_view->paginator = $paginator;
      return $this->_view;
      } */

    function listfollowupAction() {

        $sDate = $this->Xssplugin()->escape($this->getRequest()->getPost('sDate'));
        $eDate = $this->Xssplugin()->escape($this->getRequest()->getPost('eDate'));

        if (empty($sDate)) {
            $sDate = date('Y-m-d', strtotime('-30 days'));
        }

        if (empty($eDate)) {
            $eDate = date("Y-m-t");
        }

        $this->_ns->excel_data_field = array();
        $all_src = $this->Xssplugin()->escape($this->getRequest()->getPost('all_src'));
        $hdn_webform_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webform_id'));
        $hdn_unit_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_unit_id'));
        $hdn_flg = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_flg'));
        $info_status = $this->Xssplugin()->escape($this->getRequest()->getPost('info_status'));
        $owner_id = $this->Xssplugin()->escape($this->getRequest()->getPost('owner_id'));
        $Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'next' => true));
        $PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'last' => true));
        $this->_view->PreFollowup = $PreFollowup;
        $this->_view->Followup = $Followup;
        $this->_view->hdn_unit_id = $hdn_unit_id;
        $this->_view->info_status = $info_status;
        $this->_view->owner_id = $owner_id;
        $this->_view->hdn_flg = $hdn_flg;

        $cpage = $this->Xssplugin()->escape($this->getRequest()->getPost('paginator'), '1');
        $this->_view->cpage = $cpage;

        $param['cid'] = $this->_ns->Adv8Clientid;

        $arra = $this->_ObjClientLandingPageWebformData->AdvanceFilter($param);

        //$this->_view->setTemplate('/cms/lms/followup');
        $this->_view->FilterData = $arra;
        ###########################################
        $this->_view->hdn_webform_id = $hdn_webform_id;
        $this->_view->hdn_unit_id = $hdn_unit_id;
        // $this->_ObjClientLandingPageWebformData->fetch_webform_data(array(),$where)
        $param['client_id'] = trim($this->_ns->Adv8Clientid);

        //if($hdn_flg==1)
        $param['business_unit_id'] = trim($hdn_unit_id);
        //if($hdn_flg==2)
        $param['info_status'] = $info_status;
        //if($hdn_flg==3)
        $param['owner_id'] = $owner_id;

        /// REPORT FILTER ///////////
        if ($hdn_unit_id)
            $param['business_unit_id'] = $hdn_unit_id;
        if ($info_status)
            $param['info_status'] = $info_status;
        if ($owner_id)
            $param['owner_id'] = $owner_id;

        //print_r($param);
        /// END REPORT FILTER //////////
        $cu_checkbox = $this->getRequest()->getPost('cu_checkbox');
        $lp_checkbox = $this->getRequest()->getPost('lp_checkbox');
        $owner_checkbox = $this->getRequest()->getPost('owner_checkbox');
        $status_checkbox = $this->getRequest()->getPost('status_checkbox');
        if ($this->getRequest()->isPost()) {
            $Condation['cu'] = $cu_checkbox;
            $Condation['lp'] = $lp_checkbox;
            $Condation['owner'] = $owner_checkbox;
            $Condation['lead_status'] = $status_checkbox;
            $this->_ns->CondationCheckBoxArray = $Condation;
            $this->_ns->all_src = $all_src;
            $this->_ns->page = $cpage;
        } else {
            
        }
        $this->_view->checkbox_array = $this->_ns->CondationCheckBoxArray;

        //$webform = $this->_ObjClientLandingPageWebform->get_lead_detail($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src);



        $paramsfollowup = array();
        $paramsfollowup['groupBy'] = true;
        $paramsfollowup['sDate'] = $sDate;
        $paramsfollowup['eDate'] = $eDate;

        $allLatestFollowup = $this->_ObjLeadWebDataFollowup->getLatestFollowUps($paramsfollowup);


        $sParam = array();
        $sParam['client_id'] = $this->_ns->Adv8Clientid;
        $sParam['stop_followup'] = '1';
        $chkstatusData = $this->_ObjInfoLeadStatus->chkLeadNm($sParam);
        $statusArray = array();
        foreach ($chkstatusData as $sData) {
            $statusArray[] = $sData['id'];
        }
        //echo "<pre>"; print_r($statusArray); die('asdass');
        //$statusArray = array('4', '5', '6', '7', '12', '14', '15', '16', '10', '9');
        //$statusArray = array('Rejected', 'Junk', 'Duplicate', 'Trash', 'Closed', 'Paid')Closed Lost;

        $webformArray = array();
        $fullFollowupArray = array();
        $followUpPreArray = array();
        //print_r($allLatestFollowup);
        foreach ($allLatestFollowup as $k => $v) {
            /* if (in_array($v['status'], $statusArray)) {
              continue;
              } */
            $param['webform_data_id'] = $v['lead_id'];

            $webformDetail = $this->_ObjClientLandingPageWebform->get_lead_detail_new($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src);
            ;
            //print_R($webformDetail);exit;

            if (empty($webformDetail)) {
                continue;
            }

            if (in_array($webformDetail[0]['status_id'], $statusArray)) {
                continue;
            }


            $fullFollowupArray = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($v['lead_id'])));
            if (isset($fullFollowupArray[1]['email_reminder_date'])) {
                //PRINT_R($fullFollowupArray);exit;
                $followUpPreArray[$v['lead_id']] = $fullFollowupArray[1]['email_reminder_date'];
            } else {
                $followUpPreArray[$v['lead_id']] = '';
            }

            $tempArray = $webformDetail[0];
            $tempArray['email_reminder_date'] = $v['email_reminder_date'];
            $webformArray[] = $tempArray;
            //print_R($webformArray);exit;
        }

        $this->_ns->_LeadArray = $webformArray;
        $this->_view->all_src = $this->_ns->all_src;
//		$webform=$this->_ObjClientLandingPageWebformData->getDetails($param);
        $this->_view->webform = $webformArray;
        $this->_view->followUpArray = $followUpArray;
        $this->_view->followUpPreArray = $followUpPreArray;

        $this->_view->eDate = $eDate;
        $this->_view->sDate = $sDate;

        $paginator = new Paginator(new ArrayAdapter($webformArray));
        $paginator->setCurrentPageNumber($this->_ns->page)
                ->setItemCountPerPage(4);

        $this->_view->paginator = $paginator;
        return $this->_view;
    }

    function trackingAction() {

        if ($_REQUEST['sDate']) {
            $sDate = $_REQUEST['sDate'] . " 00:00:00";
            $this->_ns->sDate = $sDate;
        }

        if ($_REQUEST['eDate']) {
            $eDate = $_REQUEST['eDate'] . " 23:59:59";
            $this->_ns->eDate = $eDate;
        }

        if (!empty($this->_ns->sDate)) {
            $sDate = $this->_ns->sDate;
        }
        if (!empty($this->_ns->eDate)) {
            $eDate = $this->_ns->eDate;
        }

        if (empty($sDate)) {
            $sDate = date("Y-m-01 00:00:00");
            $this->_ns->sDate = $sDate;
        }
        if (empty($eDate)) {
            $eDate = date("Y-m-t 23:59:59");
            $this->_ns->eDate = $eDate;
        }


        $cpage = $this->Xssplugin()->escape($this->getRequest()->getPost('paginator'), '1');
        $this->_view->cpage = $cpage;

        $param['cid'] = $this->_ns->Adv8Clientid;


        $array = array();
        $array['sDate'] = $sDate;
        $array['eDate'] = $eDate;

        $followupCount = $this->_ObjLeadWebDataFollowup->getCountGroupByOwner($array);
        foreach ($followupCount as $k => $v) {
            $followupCountArray[$v['owner_id']] = $v['count'];
        }

        $array = array();
        $array['sDate'] = $sDate;
        $array['eDate'] = $eDate;
        $webformDetailCount = $this->_ObjClientLandingPageWebformData->getCountByCallType($array);
        foreach ($webformDetailCount as $k => $v) {
            $detail[$v['owner_id']][$v['lead_type']] = isset($v['count']) ? $v['count'] : 0;
            $detail[$v['owner_id']]['followUp'] = isset($followupCountArray[$v['owner_id']]) ? $followupCountArray[$v['owner_id']] : 0;

            $parmas['userId'] = $v['owner_id'];
            $uarr = $this->_ObjUsers->getUserDetail($parmas);
            $detail[$v['owner_id']]['name'] = $uarr[0]['user_email'];
        }

        $this->_view->detail = $detail;
        $this->_view->eDate = $eDate;
        $this->_view->sDate = $sDate;
        return $this->_view;
    }

    function followuptrackinglistAction() {

        if ($_REQUEST['sDate']) {
            $sDate = $_REQUEST['sDate'] . " 00:00:00";
            $this->_ns->sDate = $sDate;
        }

        if ($_REQUEST['eDate']) {
            $eDate = $_REQUEST['eDate'] . " 23:59:59";
            $this->_ns->eDate = $eDate;
        }

        if (!empty($this->_ns->sDate)) {
            $sDate = $this->_ns->sDate;
        }
        if (!empty($this->_ns->eDate)) {
            $eDate = $this->_ns->eDate;
        }

        if (empty($sDate)) {
            $sDate = date("Y-m-01 00:00:00");
            $this->_ns->sDate = $sDate;
        }
        if (empty($eDate)) {
            $eDate = date("Y-m-t 23:59:59");
            $this->_ns->eDate = $eDate;
        }


        $owner_id = $this->Xssplugin()->escape($this->getRequest()->getPost('owner_id'));



        $cpage = $this->Xssplugin()->escape($this->getRequest()->getPost('paginator'), '1');
        $this->_view->cpage = $cpage;

        $param['cid'] = $this->_ns->Adv8Clientid;


        $paramsfollowup = array();

        $paramsfollowup['sDate'] = $sDate;
        $paramsfollowup['eDate'] = $eDate;
        $paramsfollowup['ownerId'] = $owner_id;

        $allLatestFollowup = $this->_ObjLeadWebDataFollowup->getAllFollowUpOfClient($paramsfollowup);


        $parmasOwner['clientId'] = $this->_ns->Adv8Clientid;
        $ownerArray = $this->_ObjUsers->getUserDetail($parmasOwner);



        $webformArray = array();
        $fullFollowupArray = array();
        $followUpPreArray = array();

        foreach ($allLatestFollowup as $k => $v) {

            $parmasFollow['userId'] = $v['owner_id'];
            $uarr = $this->_ObjUsers->getUserDetail($parmasFollow);
            $v['owner_name'] = $uarr[0]['user_email'];

            $Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($v['lead_id']), 'next' => true));
            $PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($v['lead_id']), 'last' => true));


            $v['last'] = $PreFollowup[0]['email_reminder_date'];
            $v['next'] = $Followup[0]['email_reminder_date'];
            $v['date'] = date("j M ,Y", strtotime($v["created_at"]));
            $v['time'] = date("G:i:s", strtotime($v["created_at"]));
            $webformArray[] = $v;
            //print_R($webformArray);exit;
        }

        $this->_ns->_LeadArray = $webformArray;
        $this->_view->eDate = $eDate;
        $this->_view->sDate = $sDate;

        $paginator = new Paginator(new ArrayAdapter($webformArray));
        $paginator->setCurrentPageNumber($this->_ns->page)
                ->setItemCountPerPage(4);

        $this->_view->paginator = $paginator;
        $this->_view->countLead = count($webformArray);
        $this->_view->ownerArray = $ownerArray;
        $this->_view->owner_id = $owner_id;

        return $this->_view;
    }

    public function exportxlsAction() {
        //ini_set("display_errors",1 );
        //print_R($_POST);exit;
        /* $fields[] = 'map_form_fields';
          $params['clientId'] = $this->_ns->Adv8Clientid;

          $wbformList = $this->_ObjClientLandingPageWebform->getWebFormList($params, $fields);
          //print_R($wbformList); die('sdds');
          if(!empty($wbformList)){
          foreach($wbformList as $k=>$v){
          if(!empty($v['map_form_fields'])){
          $arrayFields = explode(",", $v['map_form_fields']);
          //print_R($arrayFields);
          //exit;
          foreach($arrayFields as $kk=>$vv){
          $excel_data_field_new[strtoupper($vv)] = strtoupper($vv);
          }
          }
          }
          } */

        if (isset($_POST['exportsubmit'])) {
            foreach ($_POST['fields'] as $kk => $vv) {
                $excel_data_field_new[strtoupper($vv)] = strtoupper($vv);
            }
            //print_R($excel_data_field_new);exit;
        } else {
            /* $fields[] = 'map_form_fields';
              $params['clientId'] = $this->_ns->Adv8Clientid;

              $wbformList = $this->_ObjClientLandingPageWebform->getWebFormList($params, $fields);
              //print_R($wbformList); die('sdds');
              if(!empty($wbformList)){
              foreach($wbformList as $k=>$v){
              if(!empty($v['map_form_fields'])){
              $arrayFields = explode(",", $v['map_form_fields']);
              //print_R($arrayFields);
              //exit;
              foreach($arrayFields as $kk=>$vv){
              $excel_data_field_new[strtoupper($vv)] = strtoupper($vv);
              }
              }
              }
              } */
        }

        //print_R($excel_data_field_new);
        //		exit;
        //$excel_data_field_new = array();
        if (!empty($excel_data_field_new)) {
            $excel_data_field = $excel_data_field_new;
            /* $excel_data_field['status_label'] = 'status_label';
              $excel_data_field['user_name'] = 'user_name';
              $excel_data_field['landing_page_url'] = 'landing_page_url';


              $excel_data_field['ctn'] = 'ctn';
              $excel_data_field['calling'] = 'calling';
              $excel_data_field['recording'] = 'recording';


              $excel_data_field['otp_verified'] = 'otp_verified';

              $excel_data_field['utm_source'] = 'utm_source';
              $excel_data_field['utm_medium'] = 'utm_medium';
              $excel_data_field['utm_campaignname'] = 'utm_campaignname';
              $excel_data_field['utm_adgroupname'] = 'utm_adgroupname';
              $excel_data_field['utm_adgroupid'] = 'utm_adgroupid';
              $excel_data_field['utm_keyword'] = 'utm_keyword';
              $excel_data_field['utm_website'] = 'utm_website';
              $excel_data_field['utm_geo'] = 'utm_geo';
              $excel_data_field['utm_adtextid'] = 'utm_adtextid';
              $excel_data_field['utm_bannername'] = 'utm_bannername';

              $excel_data_field['utm_websitecategory'] = 'utm_websitecategory';
              $excel_data_field['utm_form_source_url'] = 'utm_form_source_url';
              $excel_data_field['utm_type'] = 'utm_type';
              $excel_data_field['submitted_on'] = 'submitted_on';
              $excel_data_field['last_comment'] = 'last_comment'; */

            set_time_limit(0);

            $data = $this->_ns->_LeadArray;
            //print_R($data);exit;
            $filename = "public/report.xls";
            $realPath = realpath($filename);
            if (false === $realPath) {
                touch($filename);
                chmod($filename, 0777);
            }
            $filename = realpath($filename);
            $handle = fopen($filename, "w");
            $finalData = array();
            $head_tab = array();
            foreach ($excel_data_field as $hk => $hv) {
                $head_tab[] = utf8_decode($hv);
            }
            $finalData[] = $head_tab;
            //print_r($excel_data_field);
            //die;

            foreach ($data AS $row) {
                $datafield = array();
                $fields_data1 = (array) json_decode($row['fields_data']);

                $fields_data = array_change_key_case($fields_data1, CASE_UPPER);
                //print_R($fields_data);exit;

                foreach ($excel_data_field as $fk => $fv) {
                    $value = " ";
                    $fv = strtolower($fv);
                    if ($fv == "status_label") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "user_name") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "calling") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "recording") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "otp_verified") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "ctn") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "landing_page_url") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_source") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_medium") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_campaignname") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_adgroupname") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_adgroupid") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_keyword") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_website") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_geo") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_adtextid") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_bannername") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_websitecategory") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_form_source_url") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_type") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "submitted_on") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "last_comment") {
                        $value = $row[trim($fv)];
                    } elseif (isset($fields_data[trim(strtoupper($fv))])) {
                        $fv = strtoupper($fv);
                        if (is_array($fields_data[trim($fv)]) || is_object($fields_data[trim($fv)])) {
                            $value = utf8_decode(implode(',', $fields_data[trim($fv)]) . " 	");
                        } else {
                            $value = utf8_decode($fields_data[trim($fv)] . " 	");
                        }
                    }

                    $datafield[] = $value;
                }
                //print_r($datafield);

                /*
                  $datafield[]=utf8_decode( $row['status_label'] );
                  $datafield[]=utf8_decode( $row['user_name'] );
                  $datafield[]=utf8_decode( $row['landing_page_url'] );
                  $datafield[]=utf8_decode( $row['submitted_on'] );
                 */
                $finalData[] = $datafield;
            }
        } else {

            $excel_data_field = $this->_ns->excel_data_field;

            $clientId = trim($this->_ns->Adv8Clientid);


            //print_R($excel_data_field);exit;
            unset($excel_data_field['submit']);
            unset($excel_data_field['datesee']);
            unset($excel_data_field['dateme']);
            unset($excel_data_field['utm adtextId']);
            unset($excel_data_field['utm adgroupId']);
            unset($excel_data_field['utm adgroupId']);
            unset($excel_data_field['utm form source url']);
            unset($excel_data_field['utm websitecategory']);
            unset($excel_data_field['captcha']);
            unset($excel_data_field['session user id']);

            unset($excel_data_field['owner']);
            unset($excel_data_field['star']);
            unset($excel_data_field['type']);
            unset($excel_data_field['utm bannername']);
            unset($excel_data_field['fb user id']);
            if ($clientId != '217') {
                unset($excel_data_field['lp url']);
            }


            if ($clientId == 144) {
                $excel_data_field['dateofbirth'] = 'dateofbirth';
                $excel_data_field['gender'] = 'gender';
                $excel_data_field['address'] = 'address';
                $excel_data_field['city'] = 'city';
                $excel_data_field['country'] = 'country';

                $excel_data_field['SUATID'] = 'SUATID';
                $excel_data_field['ORDERID'] = 'ORDERID';
                $excel_data_field['TXNAMOUNT'] = 'TXNAMOUNT';
                $excel_data_field['TXNID'] = 'TXNID';
                $excel_data_field['BANKTXNID'] = 'BANKTXNID';
                $excel_data_field['RESPCODE'] = 'RESPCODE';
                $excel_data_field['RESPMSG'] = 'RESPMSG';
                $excel_data_field['STATUS'] = 'STATUS';
                $excel_data_field['TXNDATE'] = 'TXNDATE';
                $excel_data_field['GATEWAYNAME'] = 'GATEWAYNAME';
                $excel_data_field['BANKNAME'] = 'BANKNAME';
                $excel_data_field['PAYMENTMODE'] = 'PAYMENTMODE';
            }

            $excel_data_field['status_label'] = 'status_label';
            $excel_data_field['user_name'] = 'user_name';
            $excel_data_field['landing_page_url'] = 'landing_page_url';

            $excel_data_field['ctn'] = 'ctn';
            $excel_data_field['calling'] = 'calling';
            $excel_data_field['recording'] = 'recording';
            $excel_data_field['otp_verified'] = 'otp_verified';


            $excel_data_field['utm_source'] = 'utm_source';
            $excel_data_field['utm_medium'] = 'utm_medium';
            $excel_data_field['utm_campaignname'] = 'utm_campaignname';
            $excel_data_field['utm_adgroupname'] = 'utm_adgroupname';
            $excel_data_field['utm_adgroupid'] = 'utm_adgroupid';
            $excel_data_field['utm_keyword'] = 'utm_keyword';
            $excel_data_field['utm_website'] = 'utm_website';
            $excel_data_field['utm_geo'] = 'utm_geo';
            $excel_data_field['utm_adtextid'] = 'utm_adtextid';
            $excel_data_field['utm_bannername'] = 'utm_bannername';

            $excel_data_field['utm_websitecategory'] = 'utm_websitecategory';
            $excel_data_field['utm_form_source_url'] = 'utm_form_source_url';
            $excel_data_field['utm_type'] = 'utm_type';





            $excel_data_field['submitted_on'] = 'submitted_on';

            $excel_data_field['last_comment'] = 'last_comment';


            set_time_limit(0);
            /* $Condation['cu']=array();
              $Condation['lp']=array();
              $Condation['owner']=array();
              $Condation['lead_status']=array();
              $param['client_id']=trim($this->_ns->Adv8Clientid);
              $data=$this->_ObjClientLandingPageWebform->get_lead_detail($param,$Condation,'');
             */
            $data = $this->_ns->_LeadArray;
            //print_R($data);exit;
            $filename = "public/report.xls";
            $realPath = realpath($filename);
            if (false === $realPath) {
                touch($filename);
                chmod($filename, 0777);
            }
            $filename = realpath($filename);
            $handle = fopen($filename, "w");
            $finalData = array();
            $head_tab = array();
            foreach ($excel_data_field as $hk => $hv) {
                $head_tab[] = utf8_decode($hv);
            }
            $finalData[] = $head_tab;
            //print_r($finalData);
            // die;

            foreach ($data AS $row) {
                $datafield = array();
                $fields_data = (array) json_decode($row['fields_data']);



                foreach ($excel_data_field as $fk => $fv) {
                    $value = " ";
                    if ($fv == "status_label") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "user_name") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "calling") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "recording") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "otp_verified") {
                        //$value = $row[trim($fv)];
                        if ($row[trim($fv)] == '1') {
                            $value = 'Verified';
                        } else {
                            $value = 'Not Verified';
                        }
                    } elseif ($fv == "ctn") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "landing_page_url") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_source") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_medium") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_campaignname") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_adgroupname") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_adgroupid") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_keyword") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_website") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_geo") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_adtextid") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_bannername") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_websitecategory") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_form_source_url") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "utm_type") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "submitted_on") {
                        $value = $row[trim($fv)];
                    } elseif ($fv == "last_comment") {
                        $value = $row[trim($fv)];
                    } elseif (isset($fields_data[trim($fv)])) {

                        if ($clientId == 144) {
                            if ($fields_data['courses'] == '')
                                $fields_data['courses'] = $fields_data['course'];

                            if ($fields_data['courses'] != '')
                                $fields_data['course'] = $fields_data['courses'];
                            if ($fields_data['course'] != '')
                                unset($fields_data['course']);

                            if ($fields_data['origin'] == '')
                                $fields_data['origin'] = $fields_data['ORIGIN'];
                            if ($fields_data['ORIGIN'] != '')
                                unset($fields_data['ORIGIN']);
                        }
                        if (is_array($fields_data[trim($fv)]) || is_object($fields_data[trim($fv)])) {
                            $value = utf8_decode(implode(',', $fields_data[trim($fv)]) . " 	");
                        } else {
                            $value = utf8_decode($fields_data[trim($fv)] . "");
                        }
                    }

                    $datafield[] = $value;
                }
                //print_r($datafield);

                /*
                  $datafield[]=utf8_decode( $row['status_label'] );
                  $datafield[]=utf8_decode( $row['user_name'] );
                  $datafield[]=utf8_decode( $row['landing_page_url'] );
                  $datafield[]=utf8_decode( $row['submitted_on'] );
                 */
                $finalData[] = $datafield;
            }
        }
        //print_R($finalData);exit;
        foreach ($finalData AS $finalRow) {

            /* if(isset($excel_data_field["SUATID"])){

              print_R($finalRow);
              exit;
              $phone = trim($finalRow["5"]);
              $suat_id = trim($finalRow["9"]);
              //echo "Phone--".$phone;
              //echo "Suat-Id--".$suat_id;
              $where['phone'] = $phone;
              $filelds[] = 'suat_id';

              //print_R($finalRow);

              if(empty($suat_id)){
              $fullFollowupArray = $this->_ObjShardaStudents->getDetail($where, $filelds);
              if(!empty($fullFollowupArray)){
              $finalRow["10"] = $fullFollowupArray[0]['suat_id'];
              }
              }
              } */
            fputcsv($handle, $finalRow, "\t", '"');
        }

        fclose($handle);
        $myfile = $filename;

        $response = new \Zend\Http\Response\Stream();
        $response->setStream(fopen($myfile, 'r')); //read file which you want to download as xls
        $response->setStatusCode(200);
        $headers = new \Zend\Http\Headers();
        $headers->addHeaderLine("Content-Type: application/vnd.ms-excel; charset=UTF-8")
                ->addHeaderLine('Content-Disposition', 'attachment; filename=LeadReport.xls')
                ->addHeaderLine("Content-Transfer-Encoding: binary")
                ->addHeaderLine('Content-Length', filesize($myfile));
        $response->setHeaders($headers);

        return $response;
        die;
    }

    public function exportFollowupAction() {
        $sDate = $this->Xssplugin()->escape($this->getRequest()->getPost('sDateFlwp'));
        $eDate = $this->Xssplugin()->escape($this->getRequest()->getPost('eDateFlwp'));
        $client_id = $this->_ns->Adv8Clientid;
        $params = array();
        $params['sDate'] = $sDate;
        $params['client_id'] = $client_id;
        $params['stop_followup'] = '1';
        $params['eDate'] = $eDate;
        $data = $this->_ObjLeadWebDataFollowup->getLatestFollowUps($params);
        $chkstatusData = $this->_ObjInfoLeadStatus->chkLeadNm($params);
        $statusArray = array();
        foreach ($chkstatusData as $sData) {
            $statusArray[] = $sData['id'];
        }
        //$statusArray = array('4', '5', '6', '7', '12', '14', '15', '16', '10', '9');
        $webformArray = array();
        $fullFollowupArray = array();
        $followUpPreArray = array();
        foreach ($data as $k => $v) {
            /* if (in_array($v['status'], $statusArray)) {
              continue;
              } */
            $param['webform_data_id'] = $v['lead_id'];

            $webformDetail = $this->_ObjClientLandingPageWebform->get_lead_detail_new($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src);
            ;
            //print_R($webformDetail);exit;

            if (empty($webformDetail)) {
                continue;
            }

            if (in_array($webformDetail[0]['status_id'], $statusArray)) {
                continue;
            }


            $fullFollowupArray = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($v['lead_id'])));
            if (isset($fullFollowupArray[1]['email_reminder_date'])) {
                //PRINT_R($fullFollowupArray);exit;
                $followUpPreArray[$v['lead_id']] = $fullFollowupArray[1]['email_reminder_date'];
            } else {
                $followUpPreArray[$v['lead_id']] = '';
            }

            $tempArray = $webformDetail[0];

            $tempArray['email_reminder_date'] = $v['email_reminder_date'];

            $flwpParam = array();
            $flwpParam['userId'] = $tempArray['owner_id'];
            $owner_name_array = $this->_ObjUsers->getUserDetail($flwpParam);
            $owner_name = $owner_name_array[0]['user_name'];

            $fields_data = json_decode($tempArray['fields_data'], true);
            $fields_data['comments'] = $v['comments'];
            $fields_data['owner_name'] = $owner_name;
            $fields_data['landing_page_name'] = $tempArray['landing_page_name'];

            unset($fields_data['lp url']);
            unset($fields_data['utm adtextId']);
            unset($fields_data['utm adgroupId']);
            unset($fields_data['form type']);
            unset($fields_data['form type']);
            $webformArray[] = $fields_data;
        }

        //echo json_encode($data);
        $this->_view->setTerminal(true);
        $filename = "Followups" . date("Y-m-d H:i:s") . '.xls';
        header("Content-type: application/vnd.ms-excel; name='excel'");
        header("Content-Disposition: attachment; filename=exportfile.xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        $sep = "\t";

        $k = 0;
        foreach ($webformArray as $row) {

            //print_r($row); die;
            //unset($row['fields_data']);
            if ($k < 1) {
                echo "Name" . "\t";
                echo "Email" . "\t";
                echo "Phone" . "\t";
                echo "Query" . "\t";
                echo "Comments" . "\t";
                echo "Owner Name" . "\t";
                echo "Landing Page Name" . "\t";
                print("\n");
            }
            $schema_insert = "";
            foreach ($row as $col => $val) {
                if (!isset($val))
                    $schema_insert .= "NULL" . $sep;
                elseif ($val != "")
                    $schema_insert .= "$val" . $sep;
                else
                    $schema_insert .= "" . $sep;
            }
            $schema_insert = str_replace($sep . "$", "", $schema_insert);
            $schema_insert = preg_replace("/\r\n|\n\r|\n|\r/", " ", $schema_insert);
            $schema_insert .= "\t";
            print(trim($schema_insert));
            print "\n";

            $k++;
        }
        exit;
    }

    public function lmsListAjaxAction() {
        $agencyId = $this->_agencyId;
        $clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('companyId'));
        $result = $this->_ObjClientLandingPage->getLmsList($clientId);
        echo json_encode($result);
        $this->_view->setTerminal(true);
        exit;
    }

    public function getCampaignByClientAjaxAction() {

        $agencyId = $this->_agencyId;
        $clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('companyId'));
        $result = $this->_ObjClientBusinessUnit->getCampaignListByClientList($clientId);
        echo json_encode($result);
        $this->_view->setTerminal(true);
        exit;
    }

    public function addAction() {
        $agencyId = $this->_agencyId;
        $data = $_POST;
        $dataArrayFirst = array('client_id' => $data['companyName'], 'business_unit_id' => $data['Business_unit'], 'landing_page_name' => $data['LPname'], 'landing_page_url' => $data['url']);
        $result = $this->_ObjClientLandingPage->addLms($dataArrayFirst);
        return $this->redirect()->toUrl('/lms/list');
    }

    public function addnewleadAction() {
        $clientId = trim($this->_ns->Adv8Clientid);
        $campaignUniltList = $this->_ObjClientBusinessUnit->getCampaignsList($clientId, $filelds = array('id', 'business_unit_name'));

        $data['clientId'] = $clientId;
        $ownerList = $this->_ObjUsers->getUserDetail($data);

        $this->_view->campaignUniltList = $campaignUniltList;
        $this->_view->ownerList = $ownerList;
        $this->_view->clientId = $clientId;
        return $this->_view;
    }

    function getLandingPageByCampaignUnitAction() {
        $data['cuId'] = $this->getRequest()->getPost('cuId');
        $landingPageList = $this->_ObjClientLandingPage->getLandingPageList($data, $fields = array('id', 'landing_page_name'));
        echo json_encode($landingPageList);
        $this->_view->setTerminal(true);
        die;
    }

    function getWebFormByLandingPageAction() {

        $data['lpId'] = $this->getRequest()->getPost('lpId');
        $webformList = $this->_ObjClientLandingPageWebform->getWebFormList($data, $fields = array('id', 'web_form_name'));
        echo json_encode($webformList);
        $this->_view->setTerminal(true);
        die;
    }

    public function getLandingPageDataByIdAction() {
        $landingId = $this->Xssplugin()->escape($this->getRequest()->getPost('landingId'));
        $result = $this->_ObjClientLandingPage->getLandingPageDataById($landingId);
        echo json_encode($result);
        $this->_view->setTerminal(true);
        exit;
    }

    public function addNewLeadSaveAction() {
        $error = false;
        $msg = '';
        $fieldsDataArray = array();

        foreach ($_POST['requirements'] as $k => $v) {
            if (!empty($v['fieldname']) && !empty($v['fieldvalue'])) {
                $fieldsDataArray[$v['fieldname']] = $v['fieldvalue'];
            }
        }

        if (!empty($fieldsDataArray)) {
            $data['client_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
            $data['business_unit_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('campaign_unit'));
            $data['landing_page_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('lp'));
            $data['webform_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('webform'));
            $data['submitted_on'] = $this->Xssplugin()->escape($this->getRequest()->getPost('submittedOn'));
            $data['owner_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('owner'));
            $data['fields_data'] = json_encode($fieldsDataArray);
            $data['duplicate'] = 0;

            $this->_ObjClientLandingPageWebformData->save($data);
            $msg = 'Successfully Inserted';
        } else {
            $error = true;
            $msg = 'Field Value cannot be empty';
        }

        $arr['error'] = $error ? 1 : 0;
        $arr['msg'] = $msg;
        //print_R($data);
        echo json_encode($arr);
        $this->_view->setTerminal(true);
        die();
    }

    public function getFieldsAction() {
        $error = false;

        $cId = $this->getRequest()->getPost('cId');
        if (empty($cId)) {
            $cId = $this->_ns->Adv8Clientid;
        }

        $fields[] = 'webform_self_fields';
        $params['clientId'] = $cId;
        $unique_values = array();

        $wbformList = $this->_ObjClientLandingPageWebform->getWebFormList($params, $fields);

        if (!empty($wbformList)) {
            foreach ($wbformList as $k => $v) {
                if (!empty($v['webform_self_fields'])) {
                    $arrayFields = explode(",", $v['webform_self_fields']);
                    //print_R($arrayFields);
                    //exit;
                    foreach ($arrayFields as $kk => $vv) {
                        $unique_values[strtoupper($vv)] = strtoupper($vv);
                    }
                }
            }
        }

        $arr['error'] = $error ? 1 : 0;
        $arr['unique_values'] = $unique_values;
        //print_R($data);
        echo json_encode($arr);
        $this->_view->setTerminal(true);
        die();
    }

    public function getProductGraphAction() {
        $this->_view->setTerminal(true);
        exit;
    }

    public function getStatusGraphAction() {
        $this->_view->setTerminal(true);
        exit;
    }

    public function getOwnerGraphAction() {
        $this->_view->setTerminal(true);
        exit;
    }

    public function getCampaignUnitGraphAction() {
        $this->_view->setTerminal(true);
        exit;
    }

    public function saveLeadShareUserAction() {

        $partials_lead_share = $this->Xssplugin()->escape($this->getRequest()->getPost('partials_lead_share'));
        $hdn_webformdata_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webformdata_id'));


        $this->_ObjClientLandingPageWebformData->update(array('lead_sharing_id' => $partials_lead_share), array('webform_data_id' => $hdn_webformdata_id));

        $result['error'] = false;

        echo json_encode($result);
        $this->_view->setTerminal(true);
        exit;
    }

    public function addConvertLeadAction() {
        $data = $_POST;

        $hdn_webformdata_id = $_POST['hdn_webformdata_id'];
        $clientId = $_POST['clientId'];
        $email_notification = trim($_POST['email_notification']);
        //echo $hdn_webformdata_id; die;
        unset($data['callConvert_sbmt']);
        unset($data['hdn_webformdata_id']);
        unset($data['email_notification']);
        unset($data['clientId']);
        $field_data = json_encode($data);
        $call_data['fields_data'] = $field_data;
        $where['webform_data_id'] = $hdn_webformdata_id;
        $callArray = $this->_ObjClientLandingPageWebformData->update($call_data, $where);




        if (!empty($email_notification)) {
            $subject = "Web Lead Converted";

            $dir = "/cms/lms/email_templates/call_lead_converted";

            $viewRender = $this->getServiceLocator()->get('ViewRenderer');

            $filename = '/var/www/vhosts/adv8.co/agldashboard/module/Cms/view/cms/lms/email_templates/call_lead_converted/' . $clientId . '.phtml';



            if (file_exists($filename)) {
                $htmlTemplate = $dir . '/' . $clientId;
            } else {
                $htmlTemplate = $dir . '/default';
            }


            $this->_view->setTemplate($htmlTemplate);

            $this->_view->setVariable("data", $data);

            $changed_by = $this->_ns->Adv8Emailid;
            $this->_view->setVariable("Adv8Emailid", $changed_by);

            $mBody = $viewRender->render($this->_view);

            $bccArray = array('shruti.kakkar@adglobal360.com');

            $ccArray = explode(",", $email_notification);
            $ccArray = array_filter($ccArray);

            $this->_ObjCommon->sendEmail($changed_by, $subject, $mBody, $bccArray, $ccArray);
        }

        return $this->redirect()->toUrl('/lms/details?i=' . $hdn_webformdata_id);
        die;
    }

    public function deleteAction() {
        //code is not being used but function is being used for permission purpose
        $webformIdsArray = $_POST['check'];
        //print_R($_POST);
        $this->_ObjClientLandingPageWebformData->update(array('status' => '0'), array('webform_data_id' => $webformIdsArray));
        return $this->redirect()->toUrl('/lms/list');
        die;
    }
	
	public function keywordTrackingAction() {
		$data = $_REQUEST['kData'];
//print_r($data);exit;
		$callTrackingNumber = $data[0];
		$ipAddress = $data[1];
		$source = $data[2];
		$medium = $data[3];
		$keyword = urldecode($data[4]);
		$campaignId = $data[5];
		$gclid = $data[6];
		$parasArray = array("ctn"=>$callTrackingNumber,"ip"=>$ipAddress,"source"=>$source,"medium"=>$medium,"keyword"=>$keyword,"campaign_id"=>$campaignId,"gclid"=>$gclid);
		
		$this->_ObjClientCallTrackingNumberSource->insert($parasArray);
        die;
    }


}

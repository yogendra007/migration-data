<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Cms\Controller\Users;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Session\Container;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Services\Model\Users;
use Services\Model\Notification;
use Services\Model\ClientRoaster;
use Services\Model\Role\AclUserRole;
use Services\Model\Role\InfoUserRole;

use Services\Model\InfoDepartment;
use Services\Model\UserTreeView\InfoRole;
use Zend\Permissions\Acl\Acl as ZendAcl;
class UsersController extends AbstractActionController
{
	public $_view;
	private $_ObjUsers;
	public $_ObjRoaster;
	public $_ns;
	protected $_ObjAclUserRole;
	protected $_ObjAclResource;	
	protected $_ObjAclPrivilege;	
	protected $_ObjAcl;
	protected $_ObjInfoRole;
	protected $_ObjInfoDepartment;
	protected $_ObjInfoUserRole;
	protected $_ObjNotification;
	
	function __construct(){	
//session_destroy();
		$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));	
		$this->_ObjInfoRole=new InfoRole($adapter);
		$this->_ObjAclUserRole=new AclUserRole($adapter);
		$this->_view=new ViewModel();
		$this->_ns = new Container('Adv8360');
		$this->_ObjUsers=new Users($adapter);
		$this->_ObjRoaster=new ClientRoaster($adapter);
		$this->_ObjInfoDepartment=new InfoDepartment($adapter);
		$this->_ObjAcl = new ZendAcl();
		$this->_ObjInfoUserRole=new InfoUserRole($adapter);
		$this->_ObjNotification=new Notification($adapter);
	}
	function dashboardAction(){
		echo phpinfo();
	}
    public function accountAction()
    {

		$mode=trim($this->getEvent()->getRouteMatch()->getParam('mode'));
		$UserEmail=trim($this->getRequest()->getPost('UserEmail',''));
		if($UserEmail!="" && $UserEmail==$this->_ns->Adv8Emailid){
			$newPassword=trim($this->getRequest()->getPost('newPassword',''));
			if($newPassword!=""){
				$this->_ObjUsers->update(array('user_password'=>md5($newPassword)),array('user_email'=>$UserEmail,'id'=>$this->_ns->Adv8Uid));
				$this->_view->Msg="Password changed successfully.";
			}
		}
		$this->_view->setTemplate('cms/users/'.$mode);
		$this->_view->EmailId=$this->_ns->Adv8Emailid;
		return $this->_view;
		
	}
	function validateDesignationAjaxAction() {
		$designation=$this->Xssplugin()->escape($this->getRequest()->getPost('designation'));
		$d_pid=$this->Xssplugin()->escape($this->getRequest()->getPost('d_pid'));
		echo $this->_ObjInfoUserRole->check_designation_availability($d_pid,$designation);
		die;
	}
	function addDesignationAction(){
		$add_designation=$this->Xssplugin()->escape($this->getRequest()->getPost('add_designation'));
		$d_uid=$this->Xssplugin()->escape($this->getRequest()->getPost('d_uid'));
		$d_pid=$this->Xssplugin()->escape($this->getRequest()->getPost('d_pid'));
		if($add_designation!="" && $d_uid>0 && $d_pid>0){			
			$this->_ObjInfoUserRole->AddUserDesignation(array('role_name'=>trim($add_designation),'parent_id'=>$d_pid,'user_type'=>'1'))	;
		}
		$this->redirect()->toUrl('/users/view');
		//die;
	}
    public function viewAction()
    {
		//print_r($_POST);
		$movebtn=$this->Xssplugin()->escape($this->getRequest()->getPost('movebtn',''));
		$move_uid=$this->Xssplugin()->escape($this->getRequest()->getPost('move_uid',0));
		$moveuserid=$this->Xssplugin()->escape($this->getRequest()->getPost('moveuserid',0));
		
	//	echo $movebtn."&&".$move_uid." && ".$moveuserid;
		if($move_uid>0 && $moveuserid>0){
			
//			print_r($_REQUEST);
	//		die;
			$flag=$this->Xssplugin()->escape($this->getRequest()->getPost('move_flag',''));
			
			
			$this->_ObjUsers->update(array('parent_manager_id'=>$moveuserid),array('id'=>$move_uid));			

			if($flag=="A"){
				$move_pid=$this->Xssplugin()->escape($this->getRequest()->getPost('move_pid',''));								
				$this->_ObjUsers->update(array('parent_manager_id'=>$move_pid),array('parent_manager_id'=>$move_uid));			
			}
		}
		$cient_view=$this->getRequest()->getPost('cient_view');		

        if($cient_view!=""){
			$this->_ns->TAdv8Agencyid=trim($this->getRequest()->getPost('agid'));
			$this->_ns->TAdv8Clientid=trim($this->getRequest()->getPost('cid'));
			$this->_ns->TAdv8Roleid=trim($this->getRequest()->getPost('rid'));
			$this->_ns->TAdv8Uid=trim($this->getRequest()->getPost('uid'));
		}else{
			$this->_ns->TAdv8Agencyid=$this->_ns->Adv8Agencyid;
			$this->_ns->TAdv8Clientid=$this->_ns->Adv8Clientid;
			$this->_ns->TAdv8Roleid=$this->_ns->Adv8Roleid;
			$this->_ns->TAdv8Uid=$this->_ns->Adv8Uid;
		}
		
		$return_array=$this->_ObjInfoRole->get_Tree_view_array($this->_ns->TAdv8Uid,0,true);
		
		$this->_view->return_array=$return_array;
		$departmentList=$this->_ObjInfoRole->get_department();
		
		$AccessList=$this->_ObjAclUserRole->get_AccessList();
		$this->_view->AccessList=$AccessList;
		$MovePArray=$this->_ObjInfoRole->MovePArray;
		$this->_view->MovePArray=$MovePArray;

		//$RoleArray=$this->_ObjInfoRole->RoleArray;
		$RoleArray = $this->_ObjInfoRole->get_department_designation(185);
		
		$RArray=array();
		$i=0;
		foreach($RoleArray as $k=>$v){
			$RArray[$i]['id']=trim($RoleArray[$k]['id']);
			$RArray[$i]['role_name']=trim($RoleArray[$k]['role_name']);
			$i++;
		}

		$RoleArray=json_encode($RArray);
		$this->_view->RoleArray=$RoleArray;
		$this->_view->departmentList=$departmentList;
		return $this->_view;
	}
	function getDesignationListAjaxAction(){
	$deptid=$this->Xssplugin()->escape($this->getRequest()->getPost('deptid'));
	$list=array();
		if($deptid>0){
				$list=$this->_ObjInfoRole->get_department_designation($deptid);
		}
		echo json_encode(array('list'=>$list));
		die;
	}
	function validateChildDesignationAjaxAction(){
				$uid=$this->Xssplugin()->escape($this->getRequest()->getPost('uid'));
				$MoveU=$this->Xssplugin()->escape($this->getRequest()->getPost('MoveU'));
				$p="";
				$flag=false;
				$error=false;
				if($MoveU>0 && $uid>0){
					$p=$this->_ObjUsers->get_user_child_array($uid,$output);
					$exists=explode(',',$p);
					if(in_array($MoveU,$exists)){
						$flag=true;
					}
				}else{
				$error=true;						
				}
		echo json_encode(array('flag'=>$flag,'error'=>$error));
		die;
	}
	function addUserAction(){
		// print_r($this->getRequest()->getPost());
		$flag=$this->Xssplugin()->escape($this->getRequest()->getPost('flag'));
		$password=md5('123456');
		$user_name=$this->Xssplugin()->escape($this->getRequest()->getPost('userName'));
		$user_email=$this->Xssplugin()->escape($this->getRequest()->getPost('userEmail'));
		$acl_role=$this->Xssplugin()->escape($this->getRequest()->getPost('userAccess'));
		$user_role=$this->Xssplugin()->escape($this->getRequest()->getPost('userRole'));
		$parent_id=$this->Xssplugin()->escape($this->getRequest()->getPost('hidden_uid'));
		$user_department=$this->Xssplugin()->escape($this->getRequest()->getPost('userDepartment'));
		$user_designation="";
		$user_mobile_number=$this->Xssplugin()->escape($this->getRequest()->getPost('userMobile'));
		$user_alt_mobile_number=0;
		$access_token="";
		$access_token_expire="";
		$gcm_token="";
		if($flag=="A"){
	$field=array('agency_id'=>$this->_ns->TAdv8Agencyid,'agency_client_id'=>$this->_ns->TAdv8Clientid,'user_password'=>$password,'user_name'=>$user_name,
	'user_email'=>$user_email,'acl_role'=>$acl_role,'user_role'=>$user_role,'parent_manager_id'=>$parent_id,'approval_manager_id'=>'0',
	'user_department'=>$user_department,'user_designation'=>$user_designation,'user_mobile_number'=>$user_mobile_number,
	'user_alt_mobile_number'=>$user_alt_mobile_number,'access_token'=>$access_token,'access_token_expire'=>$access_token_expire,
	'gcm_token'=>$gcm_token,'created_by'=>$this->_ns->TAdv8Uid);	
	$this->_ObjUsers->save($field);
		}else{
	$field=array('user_role'=>$user_role,'user_name'=>$user_name,'acl_role'=>$acl_role,'user_department'=>$user_department,'user_mobile_number'=>$user_mobile_number);	
		$this->_ObjUsers->update($field,array('id'=>$parent_id));
			
		}
			$this->redirect()->toUrl('/users/view');
	}
	function deleteAction(){
		$deluid=$this->Xssplugin()->escape($this->getRequest()->getPost('deluid',''));
		if($deluid>0){
			$this->_ObjUsers->update(array('status'=>0),array('id'=>$deluid));
				echo json_encode(array('OK'=>1));
		}else{
				echo json_encode(array('OK'=>0));
		}
		die;
	}
	function getdesignationajaxAction(){
		$ress=array();
		$role_id=$this->Xssplugin()->escape($this->getRequest()->getPost('roleid'));		
		$uid=$this->Xssplugin()->escape($this->getRequest()->getPost('uid'));
		$user_department=$this->Xssplugin()->escape($this->getRequest()->getPost('user_department'));
		
		$parmas['userId']=$uid;
		$uarr=$this->_ObjUsers->getUserDetail($parmas);
		$ress['USER']=$uarr[0];
		$return_array=$this->_ObjInfoRole->get_role_view($role_id);
		$all_role_array=$this->_ObjInfoRole->getAllRole($role_id);
		$ress['ALL_ROLE']=$all_role_array;
		if(sizeof($return_array)>0)
			$ress['ROLE']=$return_array;
		else{
		$return_array_id=$this->_ObjInfoRole->get_id_role_name($role_id);
		$rootid=trim($return_array_id[0]['parent_id']);
		if($rootid<0){
					$return_array_id=$this->_ObjInfoRole->get_role_view(0);
		}
			$ress['ROLE']=$return_array_id;
		}
		echo json_encode($ress);
		
		die;
		
		
	}
	
	public function userRoasterAction(){
		$r_uid = $this->_ns->Adv8Uid;
		$client_id = $this->_ns->Adv8Clientid;
		$parmas['userId']=$r_uid;
		$result = $this->_ObjUsers->getUserIdsByHierarchy($parmas);
		foreach($result as $k=>$v){
			$paramss["uId"] = $v['id'];
			$uIdArray = $this->_ObjRoaster->selectRoastDate($paramss);
			$dateArray = array();
			foreach($uIdArray as $roastDate){
				$dateArray[$roastDate['id']] = $roastDate['leave_date'];
			}
			$v['leaveDate'] = $dateArray;
			$result[$k]=$v;
			
		}
		
		/*$notificationFileds = array('module'=>'lead','module_id'=>'1234','message'=>'New Lead received','created_by'=>'0', 'created_for'=>$r_uid);   
		print_R($notificationFileds);
		$rid = $this->_ObjNotification->insert($notificationFileds);
		exit;*/
		$this->_view->roasterlist=$result;
		$this->_view->r_uid=$r_uid;
		$this->_view->client_id=$client_id;
		return $this->_view;
	}
	
	
	public function saveRoasterAction(){
		$json = array();
		$uid = $this->Xssplugin()->escape($this->getRequest()->getPost('uid'));
		$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
		$leaveDate = $this->Xssplugin()->escape($this->getRequest()->getPost('leaveDate'));
		$created_by = $this->Xssplugin()->escape($this->getRequest()->getPost('created_by'));
		$leaveDateArr = explode(",", $leaveDate);
		$cnt=count($leaveDateArr);
		$return_data = array();
		for($i=0;$i<$cnt;$i++){
			$show_date = date('Y-m-d', strtotime($leaveDateArr[$i]));
			$roaster_field = array('client_id'=>$clientId,'user_id'=>$uid,'leave_date'=>$show_date,'created_by'=>$created_by); 
			$rid = $this->_ObjRoaster->roastInsert($roaster_field);
			$return_data[] = array('rid' => $rid, 'leave_date' => $show_date);
		}
		$json['success'] = true;
		$json['data'] = $return_data;
		echo json_encode($json);
		$this->_view->setTerminal(true);
		die;
	}
	
	public function updateRoasterAction(){
		$json = array();
		$login_id = $this->_ns->Adv8Uid;
		$key = $this->Xssplugin()->escape($this->getRequest()->getPost('id'));
		$where = array('id'=>$key);
		$update_field = array('updated_by'=>$login_id,'status'=>'0');
		$this->_ObjRoaster->roastUpdate($update_field,$where);
		$json['success'] = true;
		echo json_encode($json);
		$this->_view->setTerminal(true);
		die;
	}

	public function validateUserEmailAjaxAction() {
		
		$user_name = $this->Xssplugin()->escape($this->getRequest()->getPost('user_name'));
        $result = $this->_ObjUsers->validateUserEmail($user_name);
        echo json_encode($result);
        $this->_view->setTerminal(true);
        exit;
		

	} 
	
	public function listUsersAction(){
		$fields = array('*');
		$where = array('status'=>'1');
		$result = $this->_ObjUsers->listUsers($fields,$where);
		$this->_view->usersList=$result;
		return $this->_view;
	}
	
	public function changePasswordAction(){
		$user_id = $this->Xssplugin()->escape($this->getRequest()->getPost('userEmailId'));
		$rPwd = $this->Xssplugin()->escape($this->getRequest()->getPost('rPwd'));
		$encryptPwd = md5($rPwd);
		$data = array('user_password'=>$encryptPwd);
		$where = array('id'=>$user_id);
		$result = $this->_ObjUsers->changePassword($data,$where);
		$this->_view->updtPwd = $result;
		$this->_view->setTemplate('/cms/users/list-users');
		return $this->_view;
	}

}

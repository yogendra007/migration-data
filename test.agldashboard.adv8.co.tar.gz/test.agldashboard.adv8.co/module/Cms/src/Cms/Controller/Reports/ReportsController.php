<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zdend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Cms\Controller\Reports;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController; 
use Zend\View\Model\ViewModel;
use Services\Model\Clients\Client;
use Services\Model\Users;
use Services\Model\ClientBusinessUnit;
use Services\Model\Webforms\ClientLandingPage;
use Services\Model\Webforms\ClientLandingPageWebformData;
use Services\Model\Webforms\ClientLandingPageWebform;
use Services\Model\Webforms\LeadWebDataFollowup;
use Services\Model\Webforms\InfoLeadStatus;
use Zend\Http\Headers;
use Zend\Paginator\Paginator;
use Zend\Paginator\Adapter\ArrayAdapter;
use Services\Common\Common;

class ReportsController extends AbstractActionController
{
	public $_view;
    public $_ObjClient;
	public $_ObjUsers;
	public $_ns;
	public $_agencyId;
    public $_ObjClientBusinessUnit;
    public $_ObjClientLandingPage;
	protected $_ObjClientLandingPageWebformData;
	protected $_ObjClientLandingPageWebform;
	protected $_ObjLeadWebDataFollowup;	
	protected $_ObjInfoLeadStatus;
	public $_ObjCommon;
	
	function __construct(){
		
		$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
		$this->_view=new ViewModel();
		$this->_ObjClient= new Client($adapter);
		$this->_ObjClientLandingPage= new ClientLandingPage($adapter);
		$this->_ObjUsers= new Users($adapter);
		$this->_ns = new Container('Adv8360');
		$this->_ObjClientBusinessUnit = new ClientBusinessUnit($adapter);
		$this->_ObjClientLandingPageWebformData=new ClientLandingPageWebformData($adapter);
		$this->_agencyId=trim($this->_ns->Adv8Agencyid);
		$this->_ObjClientLandingPageWebform=new ClientLandingPageWebform($adapter);
		$this->_ObjLeadWebDataFollowup=new LeadWebDataFollowup($adapter);
		$this->_ObjInfoLeadStatus=new InfoLeadStatus($adapter);
		$this->_ObjCommon = new Common();

	}

	function indexAction(){
		//$CampaignsList=$this->_ObjClientBusinessUnit->getCampaignsList($this->_ns->Adv8Clientid,array('id','business_unit_name'));
		$CampaignsList=$this->_ObjClientBusinessUnit->getCampaignUnitsSummery($this->_ns->Adv8Clientid);
		$status_summery=$this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_status($this->_ns->Adv8Clientid);
		$acl_role = $this->getRequest()->getPost('hdn_acl_role');
		$this->_view->acl_role=$acl_role;
		$owner_summery=$this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_lead_owner($this->_ns->Adv8Clientid,$acl_role);
		$product_summery=$this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_product($this->_ns->Adv8Clientid);
		$lead_history=$this->_ObjClientLandingPageWebform->getLeadHistory($this->_ns->Adv8Clientid);
		
		$this->_view->owner_summery=$owner_summery;	
		$this->_view->CampaignsList=$CampaignsList;	
		$this->_view->status_summery=$status_summery;
		$this->_view->product_summery=$product_summery;	
		$this->_view->lead_history=$lead_history;
		$this->_view->setTemplate('/cms/reports/lms');
		return $this->_view;
	}
	
	function lmsAction(){		

		$this->_view->CampaignsList = $this->_ObjClientBusinessUnit->getCampaignUnitsSummery($this->_ns->Adv8Clientid);
		$this->_view->product_summery = $this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_product($this->_ns->Adv8Clientid);
		$this->_view->owner_ch = $this->_ObjClientLandingPageWebform->getNextLevelChilds($this->_ns->Adv8Clientid,$this->_ns->Adv8Uid);
		$this->_view->status_summery = $this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_status($this->_ns->Adv8Clientid);
		$this->_ObjClientLandingPageWebform->_userParentIds = array($this->_ns->Adv8Uid);
		$this->_ObjClientLandingPageWebform->getUserParentIdsByHierarchy($this->_ns->Adv8Uid);
		$this->_view->parentIds= $this->_ObjClientLandingPageWebform->_userParentIds;
		$this->_view->setTemplate('/cms/reports/lms');
		return $this->_view;
	}
	function getCampaignsListAction(){
		$campaignId = $this->getRequest()->getPost('campaignId');
		$product = $this->getRequest()->getPost('product');
		$status = $this->getRequest()->getPost('status');
		$userId = $this->getRequest()->getPost('userId');
		$sDate = $this->getRequest()->getPost('sDate');
		$eDate = $this->getRequest()->getPost('eDate');
		$CampaignsList = $this->_ObjClientBusinessUnit->getCampaignUnitsSummery($this->_ns->Adv8Clientid,$campaignId,$product,$status,$userId,$sDate, $eDate);
		echo json_encode($CampaignsList);
		$this->_view->setTerminal(true);
		die;
	    return $this->_view;
		
	}
	function getLeadsByStatusAction(){
		$campaignId = $this->getRequest()->getPost('campaignId');
		$product = $this->getRequest()->getPost('product');
		$status = $this->getRequest()->getPost('status');
		$userId = $this->getRequest()->getPost('userId');
		$sDate = $this->getRequest()->getPost('sDate');
		$eDate = $this->getRequest()->getPost('eDate');
		$status_summery=$this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_status($this->_ns->Adv8Clientid,$campaignId,$product,$status,$userId,$sDate, $eDate);
		echo json_encode($status_summery);
		$this->_view->setTerminal(true);
		die;
	    return $this->_view;
	}
	function getLeadsByLeadOwnerAction(){
		$campaignId = $this->getRequest()->getPost('campaignId');
		$product = $this->getRequest()->getPost('product');
		$status = $this->getRequest()->getPost('status');
		$userId = $this->getRequest()->getPost('userId');
		$aclrole = $this->getRequest()->getPost('aclrole');
		$sDate = $this->getRequest()->getPost('sDate');
		$eDate = $this->getRequest()->getPost('eDate');
		$owner_summery=$this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_lead_owner($this->_ns->Adv8Clientid,$aclrole,$campaignId,$product,$status,$userId,$sDate, $eDate);
		echo json_encode($owner_summery);
		$this->_view->setTerminal(true);
		die;
	    return $this->_view;
	}
	function getLeadsByProductAction(){
		$campaignId = $this->getRequest()->getPost('campaignId');
		$product = $this->getRequest()->getPost('product');
		$status = $this->getRequest()->getPost('status');
		$userId = $this->getRequest()->getPost('userId');;
		$sDate = $this->getRequest()->getPost('sDate');;
		$eDate = $this->getRequest()->getPost('eDate');;
		$product_summery=$this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_product($this->_ns->Adv8Clientid,$campaignId,$product,$status,$userId, $sDate, $eDate);
		echo json_encode($product_summery);
		$this->_view->setTerminal(true);
		die;
	    return $this->_view;
	}
	
	function getLeadHistoryAction(){
		$campaignId = $this->getRequest()->getPost('campaignId');
		$product = $this->getRequest()->getPost('product');
		$status = $this->getRequest()->getPost('status');
		$userId = $this->getRequest()->getPost('userId');
		$lead_history=$this->_ObjClientLandingPageWebform->getLeadHistory($this->_ns->Adv8Clientid,$campaignId,$product,$status,$userId);
		echo json_encode($lead_history);
		$this->_view->setTerminal(true);
		die;
	    return $this->_view;
	}
	
	function getNextLevelChildsAction(){
		if($this->getRequest()->getPost('userId'))
			$userId = $this->getRequest()->getPost('userId');
		else 	 
			$userId = $this->_ns->Adv8Uid;
		$owner_summery=$this->_ObjClientLandingPageWebform->getNextLevelChilds($this->_ns->Adv8Clientid,$userId);
		echo json_encode($owner_summery);
		$this->_view->setTerminal(true);
		die;
	    return $this->_view;
		
	}
	
	function roiAction() {
		$this->_ns->sDate = !empty($_POST['sDate']) ? $_POST['sDate']." 00:00:00" : date("Y-m-d",strtotime(date("Y-m-01 00:00:00")));
		$this->_ns->eDate = !empty($_POST['eDate']) ? $_POST['eDate']." 23:59:59" : date("Y-m-d",strtotime(date("Y-m-t 23:59:59")));		
		return $this->_view;
	
	}
	
	public function getCpaRoiReportAction() {
				
		$clientId = $this->_ns->Adv8Clientid;
		$this->_view->data = !empty($clientId) ? $this->getCpaRoiReport($clientId) : array();		
		return $this->_view->setTerminal(true);
	}
	
	public function getOwnerWiseDataAction() {
		$headerArray = array();
		$clientId = $this->_ns->Adv8Clientid;
		$sDate = !empty($_REQUEST['sDate']) ? $_REQUEST['sDate']." 00:00:00" : $this->_ns->sDate;
		$eDate = !empty($_REQUEST['eDate']) ? $_REQUEST['eDate']." 23:59:59" : $this->_ns->eDate;
		
		$ownerDatas = $this->_ObjClientLandingPageWebformData->getLeadByStatusByOwnerLp(array(
			'groupBy' => 'owner_id', 
			'clientId' => $clientId, 
			'sDate' => $sDate, 
			'eDate' => $eDate,
			'join'	=> true,
			'join_owner' => true,
			'fields' => array(
				'expected_payment',
				'upfront_payment'
			),
			
		));
		
		$newBudgetsArr = array();
		foreach($budgets as $budget) {
			$newBudgetsArr[$budget['PUBLISHER_ACCOUNT_ID']] = $budget['budget'];
		}
		foreach($ownerDatas as $data) {			
			$key = $data['user_email'];
			$displayRows[$key]['status'][$data['lead_status']] = $data['count'];
			$displayRows[$key]['expected_payment'][] = !empty($data['expected_payment']) ? $data['expected_payment'] : 0;
			$displayRows[$key]['upfront_payment'][] = !empty($data['upfront_payment']) ? $data['upfront_payment'] : 0;					
		}
		
		$arrayStatusColumn = array_unique(array_column($ownerDatas, 'lead_status'));
		$this->_view->data = array(
			'tableHeader' => $arrayStatusColumn,
			'rowsStatusData' => $displayRows,
		);
		
		
        return $this->_view->setTerminal(true);
		
		
	}
	
	public function getLpRegionWiseReportAction() {
		$headerArray = array();
		$clientId = $this->_ns->Adv8Clientid;
		$sDate = !empty($_REQUEST['sDate']) ? $_REQUEST['sDate']." 00:00:00" : $this->_ns->sDate;
		$eDate = !empty($_REQUEST['eDate']) ? $_REQUEST['eDate']." 23:59:59" : $this->_ns->eDate;
				
		$landingPageWiseArray = $this->_ObjClientLandingPageWebformData->getLeadByStatusByOwnerLp(array(
			'groupBy' => 'landing_page_id', 
			'clientId' => $clientId, 
			'sDate' => $sDate, 
			'eDate' => $eDate,
			'join'	=> true,
			'join_landing_page' => true,
			'fields' => array(
				'expected_payment',
				'upfront_payment'
			),
			
		));
		
		$arryLp = array (
			'7689767120' => '102', 
			'2216140289' => '134', 
			'9705768780' => '101', 
			'8964334480'=> '286', 
			'2246167387' => '103', 
			'3214748169' => '415',
		);
		$lpBudgetArr = array_flip($arryLp);
		
		$budgets = $this->getBudgets($sDate, $eDate);
		
		$newBudgetsArr = array();
		foreach($budgets as $budget) {
			$newBudgetsArr[$budget['PUBLISHER_ACCOUNT_ID']] = $budget['budget'];
		}
		
		foreach($landingPageWiseArray as $lpData) {			
			$displayRows[$lpData['landing_page_name']]['status'][$lpData['lead_status']] = $lpData['count'];
			$displayRows[$lpData['landing_page_name']]['budget'] = (!empty($lpBudgetArr[$lpData['landing_page_id']]) && !empty($newBudgetsArr[$lpBudgetArr[$lpData['landing_page_id']]])) ? $newBudgetsArr[$lpBudgetArr[$lpData['landing_page_id']]] : 0;
			$displayRows[$lpData['landing_page_name']]['expected_payment'][] = !empty($lpData['expected_payment']) ? $lpData['expected_payment'] : 0;
			$displayRows[$lpData['landing_page_name']]['upfront_payment'][] = !empty($lpData['upfront_payment']) ? $lpData['upfront_payment'] : 0;
		}
		
		$arrayStatusColumn = array_unique(array_column($landingPageWiseArray, 'lead_status'));
		$this->_view->data = array(
			'tableHeader' => $arrayStatusColumn,
			'rowsStatusData' => $displayRows,
		);
		
		
        return $this->_view->setTerminal(true);
		
		
	}
	
	private function getCpaRoiReport($clientId) {
		
		$totalLeadsForCpa = 0;
		$leadStatusReport = $leadStatusTotalReport = array();
		
		$sDate = !empty($_REQUEST['sDate']) ? $_REQUEST['sDate']." 00:00:00" : $this->_ns->sDate;
		$eDate = !empty($_REQUEST['eDate']) ? $_REQUEST['eDate']." 23:59:59" : $this->_ns->eDate;
		
		$budgetData = $this->getBudgets($sDate, $eDate);
		
		$totalBudgetSpent = array_sum(array_column($budgetData, 'budget'));
		
		$statuses = $this->getClientStatus($clientId, $sDate, $eDate);
		foreach($statuses as $status) {
			$leadStatusId = $status['status'];
			$leadStatusName = $status['lead_status'];
			$leadStatusCount = $status['count'];				
			if($leadStatusId == 8 || $leadStatusId == 2) {
				$totalLeadsForCpa += $leadStatusCount;
			}				
			$leadStatusTotalReport[$leadStatusId] = $leadStatusReport[$leadStatusName . '_' . $leadStatusId] = $leadStatusCount;				
		}
		
		$cpa = !empty($totalLeadsForCpa) ? $totalBudgetSpent/$totalLeadsForCpa : 0;
							
		$closedWonBudgetArray = $this->_ObjClientLandingPageWebformData
		->getBudgetDetailByStatus(array (
				'clientId' => $this->_ns->Adv8Clientid, 
				'sDate' => $sDate, 
				'eDate' => $eDate, 
				'leadStatus' => '8'
		));
		$totalUpfrontPayment = !empty($closedWonBudgetArray['0']['budget']) ? $closedWonBudgetArray['0']['budget'] : 0;
		
		$totalLeadStauBudgetArray = $this->_ObjClientLandingPageWebformData->getBudgetDetail(array(
			'clientId' => $this->_ns->Adv8Clientid, 
			'sDate' => $sDate, 
			'eDate' => $eDate, 
			'leadStatus' => '2,8'
		));
		
		$totalExpectedPaymentTmp = !empty($totalLeadStauBudgetArray['0']['budget']) ? $totalLeadStauBudgetArray['0']['budget'] : 0;
				
		$totalExpectedPayment = $totalExpectedPaymentTmp  - $totalUpfrontPayment;
		$totalRoi = !empty($totalBudgetSpent) 
			? ($totalUpfrontPayment - $totalBudgetSpent)/$totalBudgetSpent : 0;
		
		$totalRoIPercent = $totalRoi * 100;
		
		return array (
			'cpa' => number_format($cpa),
			'total_budget_spent' => number_format($totalBudgetSpent),
			'prospected_leads' => number_format($totalLeadsForCpa),
			'upfront_payments' => number_format($totalUpfrontPayment),
			'expected_payments' => number_format($totalExpectedPayment),
			'total_roi' => $totalRoi,
			'roi_percentage' => $totalRoIPercent,
			'status_count' => $statuses
		);	
	}
	private function getClientStatus($clientId, $sDate, $eDate) {
		return $this->_ObjClientLandingPageWebformData
			->getLeadStatusCountByDate(array (
				'clientId' => $clientId, 
				'sDate' => $sDate, 'eDate' => $eDate
			));	
	}
	
	
	private function getBudgets($sDate, $eDate) {
		$curl = "http://aglkuber.co.in/Lmsall/get-Budget/userName/inbound@adglobal360.com/password/inboundagl@2015/sKeys/1r2a3k4s5h6s7i8n9h10/returnType/success/roleId/2/clientId/92/sDate/".date("Y-m-d", strtotime($sDate))."/eDate/".date("Y-m-d", strtotime($eDate));
		$response = file_get_contents($curl);		
		return json_decode($response, true);		
	}
	
	function sendRoiReportAction(){
	
	//print_R($_POST);exit;
		
		$clientId = $this->_ns->Adv8Clientid;
		$senemailreport = $_REQUEST['senemailreport'];
		
		
		if($_REQUEST['sDate']){ 
			$sDate = $_REQUEST['sDate']." 00:00:00";
			$this->_ns->sDate = $sDate;
		}
		
		if($_REQUEST['eDate']){ 
			$eDate = $_REQUEST['eDate']." 23:59:59";
			$this->_ns->eDate = $eDate;
		}
		
		if(!empty($this->_ns->sDate)){
			$sDate = $this->_ns->sDate;
		}
		if(!empty($this->_ns->eDate)){
			$eDate = $this->_ns->eDate;
		}
		
		if(empty($sDate)){
			$sDate = date("Y-m-01 00:00:00");
			$this->_ns->sDate = $sDate;
		}
		if(empty($eDate)){
			$eDate = date("Y-m-t 23:59:59");
			$this->_ns->eDate = $eDate;
			
		}
	
		//$sDate = '2016-10-01';
		//$eDate = '2016-10-15';
		
		//$sendemailreport = $this->_request->getparam('sendemailreport');
		
		$arryLp = array('7689767120' => "102", '2216140289' => "134", '9705768780' => "101", '8964334480'=> "286", '2246167387' => "103", "3214748169" => "415" , "Application Dvelopment" => "3294567030");
		
		
		$curl = "http://aglkuber.co.in/Lmsall/get-Budget/userName/inbound@adglobal360.com/password/inboundagl@2015/sKeys/1r2a3k4s5h6s7i8n9h10/returnType/success/roleId/2/clientId/92/sDate/".date("Y-m-d", strtotime($sDate))."/eDate/".date("Y-m-d", strtotime($eDate));
		$response = file_get_contents($curl);
		
		$mesVal =  json_decode($response, true);

		$budgetArray = array();
		$totalBudgetSpent = 0;
		
		if ($mesVal['CODE'] != 'C-103') {
			foreach ($mesVal as $s) {
				$budgetArray[$arryLp[$s['PUBLISHER_ACCOUNT_ID']]] = $s['budget'];
				$totalBudgetSpent = $totalBudgetSpent +  $s['budget'];
			}
		}
		$sParams['client_id'] = $this->_ns->Adv8Clientid;
		$InfoLeadStatus = $this->_ObjInfoLeadStatus->chkLeadNm($sParams);
		
        $arrayStatus = array();
        foreach ($InfoLeadStatus as $s) {
            $arrayStatus[$s['id']] = $s['lead_status'];
        }

        $leadStatusTotalReport = array();
		
		$statusReportArray = $this->_ObjClientLandingPageWebformData->getLeadStatusCountByDate(array('clientId' => $this->_ns->Adv8Clientid, 'sDate' => $sDate, 'eDate' => $eDate));
		
		$leadStatusReport = array();
		$totalLeadsForCpa= 0;
		$totalLeadsForCpa= 0;
        if (empty($statusReportArray)) {
            $leadStatusReport = array();
        } else {
            foreach ($statusReportArray as $lData) {
				if($lData['status'] == 8 || $lData['status'] == 2){
					$totalLeadsForCpa = $totalLeadsForCpa +  $lData['count'];
				}
				
                $leadStatusReport[$arrayStatus[$lData['status']].'_'.$lData['status']] = $lData['count'];
				$leadStatusTotalReport[$lData['status']] = $lData['count'];
            }
        }

//print_R($leadStatusReport);exit;
		if(!empty($totalLeadsForCpa)){
			$cpa = $totalBudgetSpent / $totalLeadsForCpa;
		}else{
			$cpa = 0;
		}
		
		$totalUpfrontPayment = 0;
		
		$closedWonBudgetArray = $this->_ObjClientLandingPageWebformData->getBudgetDetailByStatus(array('clientId' => $this->_ns->Adv8Clientid, 'sDate' => $sDate, 'eDate' => $eDate, 'leadStatus' => '8'));
		if (!empty($closedWonBudgetArray['0']['budget'])) {
			$totalUpfrontPayment = $closedWonBudgetArray['0']['budget'];
		}
		
		$totalExpectedPaymentTmp = 0;
		
		$totalLeadStauBudgetArray = $this->_ObjClientLandingPageWebformData->getBudgetDetail(array('clientId' => $this->_ns->Adv8Clientid, 'sDate' => $sDate, 'eDate' => $eDate, 'leadStatus' => '2,8'));
		
		//print_R($totalLeadStauBudgetArray);exit;
		
		if (!empty($totalLeadStauBudgetArray['0']['budget'])) {
			$totalExpectedPaymentTmp = $totalLeadStauBudgetArray['0']['budget'];
		} 
		
		
		$totalExpectedPayment = $totalExpectedPaymentTmp  - $totalUpfrontPayment;
		if(!empty($totalBudgetSpent)){
			$totalRoI = ($totalUpfrontPayment - $totalBudgetSpent)/$totalBudgetSpent;
		}else{
			$totalRoI = 0;
		}
		
		
		
		
		$totalRoIPercent = $totalRoI * 100; 
		 $html = '<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>

</head>

<body><p style="font:12px Arial, Helvetica, sans-serif;">Hi All,</p>
<p style="font:12px Arial, Helvetica, sans-serif;">Please find the CPA  & ROI Report :</p><table width="450px" border="1" cellpadding="0" cellspacing="0" style="color:#fff; border-collapse:collapse; border:1px solid #cccccc; font:12px Arial, Helvetica, sans-serif;">
  <tr>
    <td colspan="2" align="center" bgcolor="#6fa8dc" style="text-decoration:underline; padding:10px; font-weight:bold; font-size:14px;">CPA &amp; ROI Report</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">CPA</td>
    <td align="center" bgcolor="#f2f2f2" style="padding:10px; color:#000000;"><span class="WebRupee">&#x20B9;</span> '.number_format($cpa).'/-</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">Total Budget Spent</td>
    <td align="center" bgcolor="#f2f2f2" style="padding:10px; color:#000000;"><span class="WebRupee">&#x20B9;</span> '.number_format($totalBudgetSpent).'/-</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">Prospect (Closed Won + Hot Leads)</td>
    <td align="center" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">'.$totalLeadsForCpa.'</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">Total AGL Revenue (Upfront)</td>
    <td align="center" bgcolor="#f2f2f2" style="padding:10px; color:#000000;"><span class="WebRupee">&#x20B9;</span> '.number_format($totalUpfrontPayment).'/-</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">Total Expected Payments</td>
    <td align="center" bgcolor="#f2f2f2" style="padding:10px; color:#000000;"><span class="WebRupee">&#x20B9;</span> '.number_format($totalExpectedPayment).'/-</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">Total ROI</td>
    <td align="center" bgcolor="#f2f2f2" style="padding:10px; color:#000000;"><span class="WebRupee">&#x20B9;</span> '.round($totalRoI, 2).'/-</td>
  </tr>
  <tr>
    <td align="left" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">ROI (%)</td>
    <td align="center" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">'.round($totalRoIPercent, 2).'%</td>
  </tr>
</table>
<table>
<tr><td>&nbsp;</td></tr>
</table>';
										
		$html .= '<table width="450px" border="1" cellpadding="0" cellspacing="0" style="color:#fff; border-collapse:collapse; border:1px solid #cccccc; font:12px Arial, Helvetica, sans-serif;">
  <tr>
    <td colspan="2" align="center" bgcolor="#6fa8dc" style="text-decoration:underline; padding:10px; font-weight:bold; font-size:14px;">Status Wise Report</td>
  </tr>';								
										
		$totalLead = 0;
        if (!empty($leadStatusReport)) {
         
            foreach ($leadStatusReport as $k => $v) {
				$totalLead = $totalLead + $v;
				
				$arrSearch = explode("_", $k);
                $html .= '<tr>
    <td align="left" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">'.$arrSearch[0].'</td>
    <td align="center" bgcolor="#f2f2f2" style="padding:10px; color:#000000;">'.$v.'</td>
  </tr>';
            }
			$html .= '<tr>
    <td align="left" bgcolor="#6fa8dc" style="padding:10px; color:#ffffff;"><strong>Total Leads</strong></td>
    <td align="center" bgcolor="#6fa8dc" style="padding:10px; color:#000000;">'.$totalLead.'</td>
  </tr>
</table>';
			
        } 

        $finalHtml = $html;
		
		$field = array("id", "landing_page_name");
		$where = array("client_id"=>$clientId,"status"=>"1");
		$Allllp = $this->_ObjClientLandingPage->listLPs($field, $where); 
		
		
		$headerArray = array();
        //$cUrlCount2 = $Common->getBrodcasterUrl() . 'Lmsall/get-Lead-Status-Count-By-Date-By-Owner/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/roleId/' . $roleId . '/clientId/' . $ns->CLIENT_ID . '/fDate/' . $ns->fDate . '/tDate/' . $ns->tDate . '/groupBy/LP_ID';
		
		$landingPageWiseArray = $this->_ObjClientLandingPageWebformData->getLeadByStatusByOwnerLp(array('groupBy' => 'landing_page_id', 'clientId' => $clientId, 'sDate' => $sDate, 'eDate' => $eDate));
		
		
		
        if(!empty($landingPageWiseArray)){
			foreach($landingPageWiseArray as $k=>$vv){
				$lpReport[$vv['landing_page_id']]['status'][$vv['status']] = $vv['count'];
				$headerArray[$vv['status']] = $vv['status'];
				
			}
		}
		
		unset($headerArray[2]);
		unset($headerArray[8]);
		
		$countheaderArray = count($headerArray) + 8;
		
		
		
		foreach($Allllp as $kkk=>$vvv){
		
			$lpReport[$vvv['id']]['budget'] = isset($budgetArray[$vvv['id']])?$budgetArray[$vvv['id']]:'0';
			
			$lpReport[$vvv['id']]['name'] = $vvv['landing_page_name'];
			
			if(isset($lpReport[$vvv['id']]['status'])){
				$lpReport[$vvv['id']]['total'] = array_sum($lpReport[$vvv['id']]['status']);
			}else{
				$lpReport[$vvv['id']]['total'] = 0;
			}
			
			
			//$cUrl = $Common->getBrodcasterUrl() . 'Lmsall/get-Budget-Detail/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientId/' . $ns->CLIENT_ID . '/fDate/' . $ns->fDate . '/tDate/' . $ns->tDate . '/leadStatus/28/lpId/' . $vvv['ID'];
			
			$mesValAgain = $this->_ObjClientLandingPageWebformData->getBudgetDetailByStatus(array('clientId' => $clientId, 'sDate' => $sDate, 'eDate' => $eDate, 'leadStatus' => '8', 'lpId' => $vvv['id']));
			
			

            
			if(!empty($mesValAgain['0']['budget'])){
				$upfront =  $mesValAgain['0']['budget'];
			}else{
				$upfront = 0;
			}
			
			$lpReport[$vvv['id']]['upfront'] = $upfront;
			
			//$cUrl = $Common->getBrodcasterUrl() . 'Lmsall/get-Budget-Detail-New/userName/' . $userName . '/password/' . $password . '/sKeys/' . $sKeys . '/returnType/' . $returnType . '/clientId/' . $ns->CLIENT_ID . '/fDate/' . $ns->fDate . '/tDate/' . $ns->tDate . '/lpId/' . $vvv['ID'];

			
			$mesValAgain = $this->_ObjClientLandingPageWebformData->getBudgetDetail(array('clientId' => $this->_ns->Adv8Clientid, 'sDate' => $sDate, 'eDate' => $eDate, 'leadStatus' => '2,8', 'lpId' => $vvv['id']));

			$expectedbudget = 0;
			if(!empty($mesValAgain['0']['budget'])){
				$expectedbudget = $mesValAgain['0']['budget'];
			}
					
			$lpReport[$vvv['id']]['expected'] = $expectedbudget;
			
			if(!empty($lpReport[$vvv['id']]['budget'])){
				$lpReport[$vvv['id']]['roi'] = ($lpReport[$vvv['id']]['upfront'] - $lpReport[$vvv['id']]['budget'])* 100/$lpReport[$vvv['id']]['budget'];
			}else{
				$lpReport[$vvv['id']]['roi'] = 0;
			}
			
		
		}
			
		$price = array();
		foreach ($lpReport as $key => $row)
		{
			$price[$key] = $row['budget'];
		}
		array_multisort($price, SORT_DESC, $lpReport);
		
		/*echo '<pre>';
		print_r($lpReport);
		die;*/
		
		
		
		
		
		$html = '<table>
<tr><td>&nbsp;</td></tr>
</table><table width="100%" border="1" cellspacing="0" cellpadding="0" style="color:#fff; border-collapse:collapse; border:1px solid #cccccc; font:12px Arial, Helvetica, sans-serif;">
  <tr>
    <td colspan="'.$countheaderArray.'" bgcolor="#6fa8dc" align="center" style="text-decoration:underline; padding:10px; font-weight:bold; font-size:14px;">Landing Page / Region Wise Report</td>
  </tr>';
  
	$html .= '<tr>
    <td align="center" bgcolor="#3d85c6" style="padding:10px; border:1px solid #cccccc;"><strong>Budget Spent (<span class="WebRupee">&#x20B9;</span>)</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="padding:10px; border:1px solid #cccccc;"><strong>Landing pages</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="padding:10px; border:1px solid #cccccc;"><strong>Total Leads</strong></td>';
    foreach($headerArray as $key=>$status){ 
		$html .=  
		'<td align="center" bgcolor="#3d85c6" style="padding:10px;  border:1px solid #cccccc;"><strong>'.$arrayStatus[$status].'</strong></td>';
	}
    $html .= '<td  align="center" bgcolor="#3d85c6" style="padding:10px; border:1px solid #cccccc;"><strong>Closed Won</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="padding:10px; border:1px solid #cccccc;"><strong>Hot</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="padding:10px; border:1px solid #cccccc;"><strong>Upfront Realised (<span class="WebRupee">&#x20B9;</span>)</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="border:1px solid #cccccc;"><strong>Total Expected Deal Size (<span class="WebRupee">&#x20B9;</span>)</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="border:1px solid #cccccc;"><strong>ROI (%)</strong></td>
  </tr>';
  
  
  $totalLeads = 0;
  $totalBudget = 0;
  $totalClosed = 0;
  $totalHot = 0;
  $totalUpfront = 0;
  $totalExpected = 0;
  
  foreach($lpReport as $k=>$v){
		  
		 if($v['total'] == "0" && ($v['budget'] == "0" || $v['budget'] == "0.00")){
			continue;
		 }
		
		 $totalLeads = $totalLeads + $v['total'];
		 
		 
		 $totalBudget = $totalBudget + $v['budget'];
		 
		
		  
		 $html .= '<tr>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.number_format($v['budget']).'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$v['name'].'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$v['total'].'</td>';
		 foreach($headerArray as $key=>$status){ 
			if(isset($v['status'][$status])) {
				$sts = $v['status'][$status];
				}else{
				$sts = 0;
				}
				
				
				
				$html .=  '<td  align="center" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$sts.'</td>';
				
				//$html .=  '<td  align="center" style="color:#000000; padding:10px;">'.$sts.'</td>';
		}
		$hot = 0;
		$closed = 0;
		if(isset($v['status']['2'])) {
			$hot = $v['status']['2'];
		}
		if(isset($v['status']['8'])) {
			$closed = $v['status']['8'];
		}
		
		$totalClosed = $totalClosed + $closed;
		$totalHot = $totalHot + $hot;
		$totalUpfront = $totalUpfront + $v['upfront'];
		$totalExpected = $totalExpected + $v['expected'];

		
		$html .=  '<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$closed.'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$hot.'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.number_format($v['upfront']).'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.number_format($v['expected']).'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.round($v['roi'], 2).'</td>
	  </tr>';
	  
  }
  

  
  $html .= '<tr>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;"><strong>'.number_format($totalBudget).'</strong></td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">Total</td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.$totalLeads.'</td>';
    foreach($headerArray as $key=>$status){ 
		if(isset($leadStatusTotalReport[$status])){
			$html .= '<td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.$leadStatusTotalReport[$status].'</td>';
		}else{
			$html .= '<td  align="center" bgcolor="#6fa8dc" style="padding:10px;">0</td>';
		}
	}
    $html .= '<td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.$totalClosed.'</td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.$totalHot.'</td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.number_format($totalUpfront).'</td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.number_format($totalExpected).'</td>
	<td  align="center" bgcolor="#6fa8dc" style="padding:10px;">&nbsp;</td>
  </tr>
</table>';
       
	   $finalHtml .= $html;
    
			
		$headerArray = array();
		
        $paramArray = array();
		$paramArray['clientId'] = $clientId;
		$UsersOfClients = $this->_ObjUsers->getUsers($paramArray);
		foreach($UsersOfClients as $keyuser=>$userval){
			$UsersOfClientsArray[$userval['id']] = $userval['user_email'];
		}
		
		
		$mesVal3 = $this->_ObjClientLandingPageWebformData->getLeadByStatusByOwnerLp(array('groupBy' => 'owner_id', 'clientId' => $clientId, 'sDate' => $sDate, 'eDate' => $eDate));

        foreach($mesVal3 as $k=>$vv){
			$ownerReport[$vv['owner_id']]['status'][$vv['status']] = $vv['count'];
			
			if(!isset($ownerReport[$vv['owner_id']]['total'])){
				$ownerReport[$vv['owner_id']]['total'] = 0;
			}
			
			$ownerReport[$vv['owner_id']]['total'] = $ownerReport[$vv['owner_id']]['total']  + $vv['count'];
			$headerArray[$vv['status']] = $vv['status'];
			$ownerReport[$vv['owner_id']]['name'] = $UsersOfClientsArray[$vv['owner_id']];
			
			$mesValAgain = $this->_ObjClientLandingPageWebformData->getBudgetDetailByStatus(array('clientId' => $clientId, 'sDate' => $sDate, 'eDate' => $eDate, 'leadStatus' => '8', 'ownerId' => $vv['owner_id']));
			
			

            
			if(!empty($mesValAgain['0']['budget'])){
				$upfront =  $mesValAgain['0']['budget'];
			}else{
				$upfront = 0;
			}
			$ownerReport[$vv['owner_id']]['upfront'] = $upfront;
			
			$mesValAgain = $this->_ObjClientLandingPageWebformData->getBudgetDetail(array('clientId' => $this->_ns->Adv8Clientid, 'sDate' => $sDate, 'eDate' => $eDate, 'leadStatus' => '2,8', 'ownerId' => $vv['owner_id']));

						
           
			$expectedbudget = 0;
			if(!empty($mesValAgain['0']['budget'])){
				$expectedbudget = $mesValAgain['0']['budget'];
			}
					
			
			$ownerReport[$vv['owner_id']]['expected'] = $expectedbudget;
			
			
			
			
		}
		
		//print_r($ownerReport);exit;
		unset($headerArray[2]);
		unset($headerArray[8]);
		
		$countheaderArray = count($headerArray) + 8;
		
		
		

		
	
		
		
		

		$html = '<table>
<tr><td>&nbsp;</td></tr>
</table><table width="100%" border="1" cellspacing="0" cellpadding="0" style="color:#fff; border-collapse:collapse; border:1px solid #cccccc; font:12px Arial, Helvetica, sans-serif;">
  <tr>
    <td colspan="'.$countheaderArray.'" bgcolor="#6fa8dc" align="center" style="text-decoration:underline; padding:10px; font-weight:bold; font-size:14px;">Owner Wise Report</td>
  </tr>';
  
	$html .= '<tr>
    
    <td  align="center" bgcolor="#3d85c6" style="padding:10px;border:1px solid #cccccc;"><strong>Owners </strong></td>
    <td  align="center" bgcolor="#3d85c6" style="padding:10px;border:1px solid #cccccc;"><strong>Total Leads</strong></td>';
    foreach($headerArray as $key=>$status){ 
		$html .=  '<td  align="center" bgcolor="#3d85c6" style="padding:10px;border:1px solid #cccccc;"><strong>'.$arrayStatus[$status].'</strong></td>';
	}
    $html .= '<td  align="center" bgcolor="#3d85c6" style="padding:10px;border:1px solid #cccccc;"><strong>Closed Won</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="padding:10px;border:1px solid #cccccc;"><strong>Hot</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="padding:10px;border:1px solid #cccccc;"><strong>Upfront Realised (<span class="WebRupee">&#x20B9;</span>)</strong></td>
    <td  align="center" bgcolor="#3d85c6" style="border:1px solid #cccccc;"><strong>Total Expected Deal Size (<span class="WebRupee">&#x20B9;</span>)</strong></td>
    
  </tr>';
  
  
  $totalLeads = 0;
  $totalBudget = 0;
  $totalClosed = 0;
  $totalHot = 0;
  $totalUpfront = 0;
  $totalExpected = 0;
  //print_R($ownerReport);exit;
  foreach($ownerReport as $k=>$v){
		  
		  if($v['total'] == "0"){
			continue;
		  }
		
		 $totalLeads = $totalLeads + $v['total'];
		 $totalBudget = $totalBudget + $v['budget'];
		 
		 
		  
		 $html .= '<tr>
		
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$v['name'].'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$v['total'].'</td>';
		 foreach($headerArray as $key=>$status){ 
			if(isset($v['status'][$status])) {
				$sts = $v['status'][$status];
				}else{
				$sts = 0;
				}
			$html .=  '<td  align="center" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$sts.'</td>';
		}
		$hot = 0;
		$closed = 0;
		if(isset($v['status']['2'])) {
			$hot = $v['status']['2'];
		}
		if(isset($v['status']['8'])) {
			$closed = $v['status']['8'];
		}
		
		$totalClosed = $totalClosed + $closed;
		$totalHot = $totalHot + $hot;
		$totalUpfront = $totalUpfront + $v['upfront'];
		$totalExpected = $totalExpected + $v['expected'];

		
		$html .=  '<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$closed.'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.$hot.'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.number_format($v['upfront']).'</td>
		<td  align="center" bgcolor="#f2f2f2" style="color:#000000; padding:10px;border:1px solid #cccccc;">'.number_format($v['expected']).'</td>
		
	  </tr>';
	  
  }
  

  
  $html .= '<tr>
   
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">Total</td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.$totalLeads.'</td>';
    foreach($headerArray as $key=>$status){ 
		if(isset($leadStatusTotalReport[$status])){
			$html .= '<td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.$leadStatusTotalReport[$status].'</td>';
		}else{
			$html .= '<td  align="center" bgcolor="#6fa8dc" style="padding:10px;">0</td>';
		}
	}
    $html .= '<td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.$totalClosed.'</td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.$totalHot.'</td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.number_format($totalUpfront).'</td>
    <td  align="center" bgcolor="#6fa8dc" style="padding:10px;">'.number_format($totalExpected).'</td>
	
  </tr>
</table>';

$html .= '<br />
<p style="font:12px Arial, Helvetica, sans-serif;"><b>Please Note:</b></p>
<ul style="line-height:20px; font:12px Arial, Helvetica, sans-serif;"><li>CPA: (Total Cost of Campaign) / (Total Number of Sales Closures + Total Number of Hot Leads)</li>
<li>Total Expected Payments: Total Deal Size (Closed Won + Hot Lead ) -  Total AGL Revenue (Upfront)</li>
<li>Total ROI:  (Total AGL Money Generated from Inbound Leads from the Region- Total Budget Spent in the Region in the Same Duration) / (Total Budget Spent in the Region in the Same Duration)</li>
<li>ROI  (%)  (Total AGL Money Generated from Inbound Leads from the Region- Total Budget Spent in the Region in the Same Duration) / (Total Budget Spent in the Region in the Same Duration) *100</li>
</ul>

<br />





-<br />
<p style="font:12px Arial, Helvetica, sans-serif;"><strong>Best Regards,</strong><br />
Moumita Nag<br />
Inbound Sales Manager</p></body></html>';
	   $finalHtml .= $html;
 
        echo $finalHtml;
		
		$ffarmateddate = date("jS-M-Y", strtotime($sDate));
        $efarmateddate = date("jS-M-Y", strtotime($eDate));

		
        $subject = 'CPA Report & ROI Report date from ' . $ffarmateddate . " to " . $efarmateddate;
		
		$bccArray = array('shruti.kakkar@adglobal360.com');
		$this->_ObjCommon->sendEmail($senemailreport, $subject, $finalHtml, $bccArray);
		
	}
	
}

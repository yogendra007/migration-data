<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zdend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Cms\Controller\Webforms;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Services\Model\Campaigns\Campaigns;
use Services\Model\Campaigns\ClientAudiCampaigns;
use Services\Model\Clients\Client;
use Services\Model\Users;
use Services\Model\EmailTemplateImages;
use Services\Model\ClientBusinessUnit;
use Services\Model\ClientBusinessUnitPublisher;
use Services\Model\Webforms\ClientLandingPage;
use Services\Model\Webforms\CampaignWebforms;
use Services\Model\Webforms\ClientLandingPageWebform;

class WebformsController extends AbstractActionController
{
	public $_view;
	public $_ObjClientAudiCampaigns;
    public $_ObjClient;
    public $_ObjCampaignWebforms;
    public $_ObjClientPublisher;
	public $_ObjClientLandingPage;
	public $_ObjClientLandingPageWebform;
	public $_ObjUsers;
	public $_ns;
	public $_agencyId;
    public $_ObjClientBusinessUnit;
    public $_ObjEmailTemplateImages;
	function __construct(){
		$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
		$this->_view=new ViewModel();
		$this->_ObjClientAudiCampaigns = new ClientAudiCampaigns($adapter);
		$this->_ObjClient= new Client($adapter);
		$this->_ObjClientPublisher= new ClientBusinessUnitPublisher($adapter);
        $this->_ObjClientBusinessUnit = new ClientBusinessUnit($adapter);
        $this->_ObjClientLandingPage = new ClientLandingPage($adapter);
        $this->_ObjClientLandingPageWebform = new ClientLandingPageWebform($adapter);
        $this->_ObjCampaignWebforms = new CampaignWebforms($adapter);
		$this->_ObjUsers= new Users($adapter);
		$this->_ObjEmailTemplateImages= new EmailTemplateImages($adapter);
		
		$this->_ns = new Container('Adv8360');
		$this->_agencyId=trim($this->_ns->Adv8Agencyid);
	}

    public function indexAction()
    {	
        $clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('webfrm_clientId'));
		if(empty($clientId)){
			$clientId = $_REQUEST['cId'];
		}
        $buId = $this->Xssplugin()->escape($this->getRequest()->getPost('webfrm_buId'));
		if(empty($buId)){
			$buId = $_REQUEST['buId'];
		}
		
		$lpId = $this->Xssplugin()->escape($this->getRequest()->getPost('webfrm_lpId'));
		if(empty($lpId)){
			$lpId = $_REQUEST['lpId'];
		}
		
		//echo $buId;
		//exit;
		$fields = array('*');
		
		if(!empty($lpId)){
			$where = array('client_id'=>$clientId , 'business_unit_id'=>$buId , 'landing_page_id'=>$lpId, 'status'=>'1');
		}else{
			$where = array('client_id'=>$clientId , 'business_unit_id'=>$buId , 'status'=>'1');
		}
		
		$listWebforms = $this->_ObjCampaignWebforms->getWebformList($fields,$where);
		//print_R($listWebforms);exit;
		foreach($listWebforms as $k => $v){
			$parmasFollow['userId'] = $v['lead_owner'];
			$uarr = $this->_ObjUsers->getUserDetail($parmasFollow);
			$v['owner_name']  = $uarr[0]['user_name'];
			if($v['form_type'] == 'Self'){
			
				$v['webformScript']  = "<script src='http://stagingagldashboard.adv8.co/common/js/webform_self.js'></script>
				<script>WEBFORM.init(['<FORM_NAME>',$v[id]]);
				WEBFORM.loadForm();</script>";
			}else{
				$v['webformScript']  = '';
			}
			
			$listWebformsArray[$k] = $v;
		}
		$this->_view->listWebforms = $listWebformsArray;
		$this->_view->buId = $buId;
		
		//echo $hdn_referurl = '/campaigns?client_id='.$clientId;exit;
		$this->_view->hdn_referurl = '/campaigns/index?cId='.$clientId;
        return $this->_view;
    }
	
	public function createAction() {
	
		$agencyId = $this->_ns->Adv8Agencyid;
		$clientData = $this->_ObjClient->getClientList($agencyId);
		//print_R($clientData);exit;
        
		
		$LeadOwners = $this->_ObjUsers->getLeadOwners($this->_ns->Adv8Clientid, array());
		$this->_view->clientData = $clientData;
		$this->_view->LeadOwners = $LeadOwners;
		
		$LeadNotification = $this->_ObjUsers->userListByClient($agencyId, $client_id);
		$this->_view->LeadNotification = $LeadNotification;
		
		
	
		$this->_view->setTemplate('/cms/webforms/create');
		return $this->_view;
		
    }
	
	public function createWebformsAction() {
		//$client_id = $this->_ns->Adv8Clientid;
		$buId = $this->params()->fromRoute('id');
		$dataParam['cuId'] = $buId;
		$detail = $this->_ObjClientBusinessUnit->getCampaignUnitById($buId);
		$client_id = $detail[0]['client_id'];
		
		$userId = $this->_ns->Adv8Uid;
		$this->_view->edit = 0;
		$data = array($client_id, $userId);
		$this->_view->createWebform = $data;
		$where=array('client_id'=>$client_id , 'status'=>'1' , 'business_unit_id'=>$buId);
		$fields=array('*');
		$listLps = $this->_ObjClientLandingPage->listLPs($fields,$where);
		$this->_view->listLps = $listLps;
		$LeadOwners = $this->_ObjUsers->userListByClient($this->_ns->Adv8Agencyid,$client_id);
		$this->_view->LeadOwners = $LeadOwners;
		$this->_view->buId = $buId;
		$this->_view->hdn_referurl = '/webforms/index?cId='.$client_id.'&buId='.$buId;
		$this->_view->setTemplate('/cms/webforms/create-webform');
		return $this->_view;
	}
	
	public function updateWebformAction(){
	
		$wFrmId = $this->params()->fromRoute('id');
		
		
		$mandatoryfields = $this->Xssplugin()->escape($this->getRequest()->getPost('mandatoryfields'));
		if($mandatoryfields == 1){
			$where=array('id'=>$wFrmId);
			
			unset($_POST['mandatoryfields']);
			unset($_POST['submit']);
			$fieldtoshow = implode(',',$_POST);
			$dataArray = array('map_form_fields'=>$fieldtoshow);
			$addDashboardFields = $this->_ObjCampaignWebforms->updateWebformFields($dataArray,$where);
		
		}
		$where=array('id'=>$wFrmId);
		$fields=array('*');
		$webformData = $this->_ObjCampaignWebforms->editWebformList($fields,$where);
		
		$landingPageId = $webformData[0]['landing_page_id'];
		$webform_self_identifier_temp = $webformData[0]['webform_self_identifier'];
		$webform_self_fields = trim($webformData[0]['webform_self_fields']);
		$webform_dashboard_fields = trim($webformData[0]['webform_dashboard_fields']);
		
		$client_id = trim($webformData[0]['client_id']);
		$buId = trim($webformData[0]['business_unit_id']);
		
		
		$map_form_fields = trim($webformData[0]['map_form_fields']);
		
		
		$where1=array('id'=>$landingPageId);
		$fields1=array('*');
		$lpData = $this->_ObjClientLandingPage->getLandingPageDataById($landingPageId);
		$landing_page_url = $lpData[0]["landing_page_url"];
		
		$webform_self_fields_arrray = array();
		
		if(!empty($webform_self_fields)){
			$webform_self_fields_arrray = explode(",", $webform_self_fields);
		}
		
		$webform_dashboard_fields_array = array();
		if(!empty($webform_dashboard_fields)){
			$webform_dashboard_fields_array = explode(",", $webform_dashboard_fields);
		}
		
		$map_form_fields_array = array();
		if(!empty($map_form_fields)){
			$map_form_fields_array = explode(",", $map_form_fields);
		}
		$i = 0;
		
		$xml = new \DOMDocument(); 
		

		//$htmlinput = file_get_contents("http://aglkuber.co.in/test.php");
		//$landing_page_url = 'http://aglkuber.co.in/test.php';
		$fromErrorMsg = '';
		if(!empty($landing_page_url)){
			$htmlinput = file_get_contents($landing_page_url);
			
			
			@$xml->loadHTML($htmlinput);
			
			if(empty($webform_self_identifier_temp)){
				$forms = $xml->getElementsByTagName('form');
			}else{
			    $webform_self_identifier_array = explode("___", $webform_self_identifier_temp);
				
				$webform_self_identifier = $webform_self_identifier_array[0];
				
				$xpath = new \DOMXpath($xml);
				//$forms = $xpath->query('//form[@name="Ashoka"]');
				
				$var = "//form[@name=\"$webform_self_identifier\"]";
				
				$forms = $xpath->query($var);
			}
			if(!empty($forms)){
				$webfornameArray = array();
				foreach ($forms as $form) {
					
					$formName =  $form->getAttribute("name");
					$webformFieldsDetails[$i]['canbeselected'] = 1;
					
					$tempformName = '';
					if(empty($formName)){
						$tempformName = 'Webform with no name attribute';
						
					}else{
						$tempformName = $formName;
						$webfornameArray[] = $formName;
					}
					
					$webformFieldsDetails[$i]['name'] = trim($formName);
					$webformFieldsDetails[$i]['tempformName'] = $tempformName;
					
					$inputs = $form->getElementsByTagName('input');
						
					foreach ($inputs as $input) {
						$inputName = trim($input->getAttribute('name'));
					
						switch($input->getAttribute('type')){
							case 'checkbox':
							
							$inputName = str_replace(array('[',']'),'',$input->getAttribute('name'));
							
							break;
							
							
					
						}
						
						$checke = '';
						if (in_array($inputName, $webform_self_fields_arrray)){
						  $checke = 'checked';
						}
						$webformFieldsDetails[$i]['fields'][$inputName] = $checke;
						
						//$inputValue = $input->getAttribute('value');
					}
					
					$inputs = $form->getElementsByTagName('textarea');
					foreach ($inputs as $input) {
						$inputName = trim($input->getAttribute('name')); 
						$checke = '';
						if (in_array($inputName, $webform_self_fields_arrray)){
						  $checke = 'checked';
						}
						$webformFieldsDetails[$i]['fields'][$inputName] = $checke;
						//$inputValue = $input->getAttribute('value');
					}
					
					$inputs = $form->getElementsByTagName('select');
					foreach ($inputs as $input) {
						$inputName = trim($input->getAttribute('name')); 
						$checke = '';
						if (in_array($inputName, $webform_self_fields_arrray)){
						  $checke = 'checked';
						}
						$webformFieldsDetails[$i]['fields'][$inputName] = $checke;
						//$inputValue = $input->getAttribute('value');
					}
					
					$i++;
					
				}
			}
			
			
			
			$countwebform = count($webformFieldsDetails); 
			
			if($countwebform > 1){
				$webform_self_fields_arrray = array();
			}else{
				foreach($webformFieldsDetails as $k=>$v){
				
					foreach($v['fields'] as $kk=>$vv){
					
						if (in_array($kk, $map_form_fields_array)){
							continue;
						}
						
						$checke = '';
						if (in_array($kk, $webform_dashboard_fields_array)){
							$checke = 'checked';
						}
					
						$webform_self_fields_arrray_final[$kk] = $checke;
					}				
				}
			
			}
		}else{
		$fromErrorMsg = 'No Landing pagge url found please map lp url first';
		}
		if(empty($webformFieldsDetails)){
		$fromErrorMsg = 'No form found - '.$landing_page_url;
		}
		$webfornameCountArray = array_count_values($webfornameArray);
		//print_R($webform_self_fields_arrray_final);exit;
			
		$LeadOwners = $this->_ObjUsers->userListByClient($this->_ns->Adv8Agencyid,$client_id);
		$fieldsImgs = array('*');
		$whereImgs = array('webform_id'=>$wFrmId , 'status'=>'1');
		$imageIdArray = $this->_ObjEmailTemplateImages->fetchImages($fieldsImgs,$whereImgs);
		$this->_view->imageIdArray = $imageIdArray;
		$this->_view->LeadOwners = $LeadOwners;
		$this->_view->webformData = $webformData[0];
		$this->_view->edit = 1;
		$this->_view->wFrmId = $wFrmId;
		$this->_view->webformFieldsDetails = $webformFieldsDetails;
		$this->_view->webform_self_identifier = $webform_self_identifier;
		$this->_view->webform_self_fields_arrray = $webform_self_fields_arrray;
		$this->_view->webform_dashboard_fields_array = $webform_dashboard_fields_array;
		$this->_view->map_form_fields_array = $map_form_fields_array;
		$this->_view->webform_self_fields_arrray_final = $webform_self_fields_arrray_final;
		$this->_view->countwebform = $countwebform;
		$this->_view->fromErrorMsg = $fromErrorMsg;
		$this->_view->webfornameCountArray = $webfornameCountArray;
		$this->_view->client_id = $client_id;
		
		$this->_view->hdn_referurl = '/webforms/index?cId='.$client_id.'&buId='.$buId;
		
		
		$this->_view->setTemplate('/cms/webforms/create-webform');
		return $this->_view;
	}
	
	public function editWebformAction(){
		$loginId = $this->_ns->Adv8Uid;
		//$client_id = $this->_ns->Adv8Clientid;
		$buId = $this->params()->fromRoute('id');
		//print_R($_POST);exit;
		
		$client_id = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
		$lp_id = $this->Xssplugin()->escape($this->getRequest()->getPost('landing_pages'));
		$wFrmId = $this->Xssplugin()->escape($this->getRequest()->getPost('wFrmId'));
		$wName = $this->Xssplugin()->escape($this->getRequest()->getPost('wName'));
		$form_type = $this->Xssplugin()->escape($this->getRequest()->getPost('form_type'));
		$thank_you_email_alert = $this->Xssplugin()->escape($this->getRequest()->getPost('thank_you_email_alert'));
		$thank_you_page_url = $this->Xssplugin()->escape($this->getRequest()->getPost('thank_you_page_url'));
		$lead_owner = $this->Xssplugin()->escape($this->getRequest()->getPost('lead_owner'));
		$request = $this->getRequest();
		
		
				
				
				
		$validateFile = 0;
		if(!empty($_FILES['file']['name'])) {
			$files =  $request->getFiles()->toArray();
			$httpadapter = new \Zend\File\Transfer\Adapter\Http();
			$extension = new \Zend\Validator\File\Extension(array('extension' => array('html')));
			$httpadapter->setValidators(array($extension), $files['file'][0]['name']);
			
			if($httpadapter->isValid()) {
				$validateFile = 1;
			}
		}
		

		
		$dataArray = array('web_form_name'=>$wName,'form_type'=>$form_type,'thank_you_email_alert'=>$thank_you_email_alert,'thank_you_page_url'=>$thank_you_page_url, 'lead_owner'=>$lead_owner);
		
		//add webform
		if(!empty($wFrmId)){

			$where = array('id' => $wFrmId);
			$saveWebform = $wFrmId;
			$editWebformData = $this->_ObjCampaignWebforms->updateWebformList($dataArray,$where);
			$this->_view->editWebformData = $editWebformData; 
			$finalUrl =  $this->redirect()->toUrl('/webforms/updateWebform/'.$wFrmId);
			
			
		}else{
		
			$saveData = array('client_id' => $client_id, 'business_unit_id' => $buId, 'landing_page_id' => $lp_id, 'web_form_name' => $wName,'form_type' => $form_type, 'thank_you_email_alert'=>$thank_you_email_alert, 'thank_you_page_url'=>$thank_you_page_url, 'lead_owner'=>$lead_owner, 'status' => '1' );
			$saveWebform = $this->_ObjCampaignWebforms->addWebfrm($saveData);
			//$saveWebform = 143;
		
			//exit;
			$this->_view->saveWebform = $saveWebform;
			$finalUrl = $this->redirect()->toUrl('/webforms/index?cId='.$client_id.'&buId='.$buId);
			
			
		}
		//echo $validateFile;
		if($validateFile == 1){
		
			$dir = '/var/www/vhosts/adv8.co/stagingagldashboard/application/views/scripts/webforms/thanks/'.$client_id;
			if (!file_exists($dir)) {
				mkdir($dir, 0777);
			}
		
			$ext = pathinfo($files['file'][0]['name'], PATHINFO_EXTENSION);
			
			$newNameOfFile = $saveWebform. '.' . $ext;
			
			//$newNameOfFile = '385.html';
			$pathOfThnkyouEmailTemplate = '/var/www/vhosts/adv8.co/stagingagldashboard/application/views/scripts/webforms/thanks/'.$client_id.'/'.$newNameOfFile;
			if (file_exists($pathOfThnkyouEmailTemplate)) {
				 $newNameOfFileAgain = date('YmdHis').'_'.$newNameOfFile;
				 $pathOfThnkyouEmailTemplate1 = '/var/www/vhosts/adv8.co/stagingagldashboard/application/views/scripts/webforms/thanks/'.$client_id.'/'.$newNameOfFileAgain;
				 rename($pathOfThnkyouEmailTemplate, $pathOfThnkyouEmailTemplate1);
				
			}
			
			
			$httpadapter->addFilter('File\Rename', array(
				 'target' => $dir . '/' . $newNameOfFile,
			));

	
			$httpadapter->setDestination($dir);
			if($httpadapter->receive($files['file'][0]['name'])) {
				//$newfile = $httpadapter->getFileName();
				//print_R($newfile);
				$file1 = $httpadapter->getFilter('File\Rename')->getFile();
				$target = $file1[0]['target'];
				
			}
			
			
			//File uplod 
			
			
			if(!empty($_FILES['wfImages']['name'])) {
			
				$allowedExts = array("gif", "jpeg", "jpg", "png", "JPG");
				$error_uploads = 0;
				$total_uploads = array();
				$upload_path = '/var/www/vhosts/adv8.co/stagingagldashboard/common/images/thankyou/'.$client_id;
				
				if (!file_exists($upload_path)) {
					mkdir($upload_path, 0777);
				}
					
				foreach($_FILES['wfImages']['name'] as $key => $value) {
					$temp = explode(".", $_FILES['wfImages']['name'][$key]);
					$extension = end($temp);
					if ($_FILES["files"]["type"][$key] != "image/gif"
					&& $_FILES["files"]["type"][$key] != "image/jpeg"
					&& $_FILES["files"]["type"][$key] != "image/jpg"
					&& $_FILES["files"]["type"][$key] != "image/pjpeg"
					&& $_FILES["files"]["type"][$key] != "image/x-png"
					&& $_FILES["files"]["type"][$key] != "image/png"
					&& !in_array($extension, $allowedExts)) {
						$error_uploads++;
						continue;
					}
					$file_name = $_FILES["wfImages"]['name'][$key];
		
					if(move_uploaded_file($_FILES["wfImages"]['tmp_name'][$key], $upload_path."/".$file_name)) {
						$total_uploads[] = $file_name;
						
					}else{
						$error_uploads++;
					}
					echo "<pre>"; print_r($total_uploads);
					//exit;
	
				}
			}
		}
		if(!empty($total_uploads)){
			foreach($total_uploads as $tupld){
				$imgArr = array('webform_id'=>$saveWebform , 'image_name'=>$tupld , 'status'=>'1');
				$eml_img = $this->_ObjEmailTemplateImages->imageInsert($imgArr);
			}
		}
		//exit;
		return $finalUrl;
		exit;
	}
	
	public function delWebformAction(){
		$wFrmId = $this->Xssplugin()->escape($this->getRequest()->getPost('wFrmId'));
		$fields = array('status'=>'0');
		$where = array('id'=>$wFrmId);
		$delWebformData = $this->_ObjCampaignWebforms->delWebform($fields,$where);
		$result['error'] = 0;
		$result['wFrmId'] = $wFrmId;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
		
	}
	
	public function saveFieldsDataAction(){
		$wFrmId = $this->params()->fromRoute('id');
		$webformname = $this->Xssplugin()->escape($this->getRequest()->getPost('webformname'));
		$fieldnames = implode(',',$_POST['fieldname']);
		$where=array('id'=>$wFrmId);
		$dataArray = array('webform_self_identifier'=>$webformname,'webform_self_fields'=>$fieldnames);
		$updateWebformFields = $this->_ObjCampaignWebforms->updateWebformFields($dataArray,$where);
		return $this->redirect()->toUrl('/webforms/updateWebform/'.$wFrmId);
		exit;
	}
	
	public function saveDshbrdFldsAction(){
		$wFrmId = $this->Xssplugin()->escape($this->getRequest()->getPost('hdnWbfId'));
		$where=array('id'=>$wFrmId);
		if(!empty($_POST['fieldtoshow'])){
			$fieldtoshow = implode(',',$_POST['fieldtoshow']);
			$dataArray = array('webform_dashboard_fields'=>$fieldtoshow);
		}else{
			unset($_POST['hdnWbfId']);
			$fieldtoshow = implode(',',$_POST);
			
			$dataArray = array('map_form_fields'=>$fieldtoshow);
		}
		
		$addDashboardFields = $this->_ObjCampaignWebforms->updateWebformFields($dataArray,$where);
		$result['error'] = 0;
		$result['wFrmId'] = $wFrmId;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function delTemplateImagesAction(){
		$imgId = $this->Xssplugin()->escape($this->getRequest()->getPost('imgId'));
		$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
		$imageName = $this->Xssplugin()->escape($this->getRequest()->getPost('imageName'));
		
		$fields = array('status'=>'0');
		$where = array('id'=>$imgId);
		$delImageData = $this->_ObjEmailTemplateImages->delTemplateImages($fields,$where);
		
		$path = '/var/www/vhosts/adv8.co/stagingagldashboard/common/images/thankyou/'.$clientId.'/'.$imageName;
		
		if (file_exists($path)) {
			unlink($path);
		}
		
		$result['error'] = 0;
		$result['imgId'] = $imgId;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
		
	}
	
}
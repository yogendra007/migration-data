<?php

/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zdend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Cms\Controller\Billing;

use Zend\Session\Container;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Services\Model\Clients\Client;
use Services\Model\Billing\ClientInvoices;
use Services\Model\Users;
use Services\Model\AagencyClientUserMapping;
use Services\Model\InfoGroupHead;
use Services\Model\Role\InfoUserRole;
require('html2pdf/html2pdf.class.php');

class InvoiceController extends AbstractActionController {

    public $_view;
    public $_ObjClient;
    public $_ObjUsers;
    public $_ns;
    public $_agencyId;
    public $_ObjInvoice;
    public $_ObjMapping;
    public $_ObjGroupHead;
    public $_ObjInfoUserRole;

    function __construct() {

	$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
	$this->_view = new ViewModel();
	$this->_ObjClient = new Client($adapter);
	$this->_ObjUsers = new Users($adapter);
	$this->_ObjInvoice = new ClientInvoices($adapter);
	$this->_ObjMapping = new AagencyClientUserMapping($adapter);
	$this->_ObjGroupHead = new InfoGroupHead($adapter);
	$this->_ObjInfoUserRole = new InfoUserRole($adapter);
	$this->_ns = new Container('Adv8360');
	
	$this->_agencyId = trim($this->_ns->Adv8Agencyid);
    }

    public function listAction() {
	
	$params = array();
	$agencyId = $this->_agencyId;
	$agencyClientId = $this->_ns->Adv8Clientid;
	$userId = $this->_ns->Adv8Uid;
	$userRole = $this->_ns->Adv8Roleid;

	$searchinvoiceNumber = $this->Xssplugin()->escape($this->getRequest()->getPost('searchinvoiceNumber'));
	$serchClientId = $this->Xssplugin()->escape($this->getRequest()->getPost('serchClientId'));
	$searchfDate = $this->Xssplugin()->escape($this->getRequest()->getPost('searchfDate'));
	$searchtDate = $this->Xssplugin()->escape($this->getRequest()->getPost('searchtDate'));
	$searchiStatus = $this->Xssplugin()->escape($this->getRequest()->getPost('searchiStatus'));

	$params = array();
	switch ($userRole) {
	    case '1':
	    case '19':
	    case '3':
	    case '23':
	    case '2':
		$params['agencyId'] = $agencyId;
		$responseClient = $this->_ObjClient->getClients($params);
		break;
	    default:
		$params['userId'] = $userId;
		$responseClient = $this->_ObjClient->getClientListByCm($params);
		if (empty($responseClient)) {
		    $params = array();
		    $params['createdBy'] = $userId;
		    $responseClient = $this->_ObjClient->getClients($params);
		}
		break;
	}

	$clientList = array();
	if (!empty($responseClient)) {
	    foreach ($responseClient as $key => $client) {
		$clientIdArray[] = $client['id'];
		$clientList[$client['id']] = $client['company_name'];
	    }
	}

	$params = array();
	switch ($userRole) {
	    case '1':
	    case '19':
	    case '3':
	    case '23':
	    case '2':
		$params['agencyId'] = $agencyId;
		break;
	    default:
		$params['agencyId'] = $agencyId;
		$params['clientIds'] = $clientIdArray;
		break;
	}

	$params['invoiceNumber'] = $searchinvoiceNumber;
	$params['clientId'] = $serchClientId;
	$params['fDate'] = $searchfDate;
	$params['tDate'] = $searchtDate;
	$params['iStatus'] = $searchiStatus;


	$invoiceList = $this->_ObjInvoice->getInvoices($params);
	
	$invoiceStatus = array("1" => "Created", "2" => "Approved", "3" => "Disapproved", "4" => "Sent", "5" => "Payment Request", "6" => "Paid", "7" => "Cancel");


	$msg = "";
	$styleMsg = "display:none";
	
	
	if ($this->_ns->msg != '') {
	   
	    $msg = $this->_ns->msg;
	    $this->_ns->msg = "";
	    $styleMsg = "display:block";
	}

	$quarterList = array("1" => "1 Quarter", "2" => "2 Quarter", "3" => "3 Quarter", "4" => "4 Quarter");
	$curMonth = date("m", time());
	$curQuarter = ceil($curMonth / 3);

	$this->_view->msg = $msg;
	$this->_view->ns = $this->_ns;
	$this->_view->styleMsg = $styleMsg;

	$this->_view->invoiceList = $invoiceList;
	$this->_view->clientList = $clientList;
	$this->_view->invoiceStatus = $invoiceStatus;
	$this->_view->title = "Invoice List";
	$this->_view->userRole = $userRole;

	$this->_view->searchinvoiceNumber = $searchinvoiceNumber;
	$this->_view->serchClientId = $serchClientId;
	$this->_view->searchfDate = $searchfDate;
	$this->_view->searchtDate = $searchtDate;
	$this->_view->searchiStatus = $searchiStatus;
	$this->_view->curQuarter = $curQuarter;
	$this->_view->quarterList = $quarterList;

	return $this->_view;
    }

    public function searchInvoiceAction() {

	$agencyId = $this->_agencyId;
	$agencyClientId = $this->_ns->Adv8Clientid;
	$userId = $this->_ns->Adv8Uid;
	$userRole = $this->_ns->Adv8Roleid;


	$invoiceNumber = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceNumber'));
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
	$fDate = $this->Xssplugin()->escape($this->getRequest()->getPost('fDate'));
	$tDate = $this->Xssplugin()->escape($this->getRequest()->getPost('tDate'));
	$iStatus = $this->Xssplugin()->escape($this->getRequest()->getPost('iStatus'));



	$params = array();
	switch ($userRole) {
	    case '1':
	    case '2':
	    case '8':
	    case '9':
		$params['agencyId'] = $agencyId;
		$responseClient = $Client->getClients($params);
		break;
	    case '4':
	    case '5':
		$params['userId'] = $userId;
		$responseClient = $Client->getClientListByCm($params);
		break;
	    case '10':
		$params['createdBy'] = $userId;
		$responseClient = $Client->getClients($params);
		break;
	}


	$invoiceStatus = array("1" => "Created", "2" => "Approved", "3" => "Disapproved", "4" => "Sent", "5" => "Payment Request", "6" => "Paid", "7" => "Cancel");

	$jsonResponseClient = json_encode($responseClient);
	$clientListArray = json_decode($jsonResponseClient, true);
	$clientList = array();
	if (!empty($clientListArray)) {
	    foreach ($clientListArray as $key => $client) {
		$clientList[$client['id']] = $client['company_name'];
	    }
	}

	$params = array();
	$params['invoiceNumber'] = $invoiceNumber;
	$params['clientId'] = $clientId;
	$params['fDate'] = $fDate;
	$params['tDate'] = $tDate;
	$params['iStatus'] = $iStatus;
	$params['agencyId'] = $agencyId;

	if ($userRole == 2) {
	    $response = $Invoice->getInvoices($params);
	} else {
	    $params['userId'] = $userId;
	    $response = $Invoice->getInvoices($params);
	}

	if (!empty($response)) {
	    $arr['error'] = 0;
	    $i = 0;
	    foreach ($response as $key => $val) {
		$data[$i]['clientId'] = $val->agency_client_id;
		$data[$i]['clientName'] = $clientList[$val->agency_client_id];
		$data[$i]['ProformaId'] = $val->proforma_invoice_id;
		if (!empty($val->invoice_created_at)) {
		    $data[$i]['actualId'] = $val->tax_invoice_id;
		} else {
		    $data[$i]['actualId'] = "";
		}
		$data[$i]['invoiceDate'] = date('jS-M-Y', strtotime($val->created_at));
		if (!empty($val->invoice_created_at)) {
		    $data[$i]['taxInvoiceDate'] = date('jS-M-Y', strtotime($val->invoice_created_at));
		} else {
		    $data[$i]['taxInvoiceDate'] = "";
		}
		$data[$i]['totalAmount'] = $val->total_amount;
		$data[$i]['paidAmount'] = $val->received_amount;
		$data[$i]['dueAmount'] = $val->due_amount;
		$data[$i]['invoiceStatus'] = $invoiceStatus[$val->invoice_status];
		$data[$i]['invoiceStatusId'] = $val->invoice_status;

		if (!empty($val->payment_expected_date)) {
		    $data[$i]['expectedDate'] = date('jS-M-Y', strtotime($val->payment_expected_date));
		    $data[$i]['expectedPayentDate'] = date('jS-M-Y', strtotime($val->payment_expected_date));
		} else {
		    $data[$i]['expectedDate'] = "";
		    $data[$i]['expectedPayentDate'] = "";
		}
		if (!empty($val->invoice_due_date)) {
		    $data[$i]['dueDate'] = date('jS-M-Y', strtotime($val->invoice_due_date));
		} else {
		    $data[$i]['dueDate'] = "";
		}

		$data[$i]['invoiceId'] = $val->id;
		$data[$i]['userRole'] = $userRole;

		$i++;
	    }

	    $arr['data'] = $data;
	} else {
	    $arr['error'] = 1;
	    $arr['data'] = array();
	}

	echo json_encode($arr);

	die();
    }

    public function editProformaAction() {

	$id = $this->_ns->Adv8Uid;
	$agencyId = $this->_agencyId;

	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));
	$params['agencyId'] = $agencyId;
	$responseServices = $this->_ObjInvoice->getAgencyServices($params);

	foreach ($responseServices as $key => $val) {
	    $serviceArray[$val['id']] = $val['short_name'];
	}

	$params = array();
	$params['invoiceId'] = $invoiceId;
	$responseInvoice = $this->_ObjInvoice->getInvoices($params);
	$invoiceDe = $responseInvoice[0];

	$params = array();
	$params['invoiceId'] = $invoiceId;
	$response = $this->_ObjInvoice->getInvoiceDetails($params);

	$params = array();
	$responsePublishers = $this->_ObjInvoice->getPublishers();
	foreach ($responsePublishers as $key => $val) {
	    $publisherArray[$val['id']] = $val['publisher_name'];
	}
	$firstTimePpc = 1;
	$firstTimeNonPpc = 1;

	if (!empty($response)) {

	    $arr['error'] = 0;
	    $i = 1;
	    $j = 1;
	    $total = 0;
	    $html = "";

	    foreach ($response as $key => $val) {

		if ($val['agency_service_id'] == 2) {

		    if ($firstTimePpc == 1) {
			$firstTimePpc = 2;
			$html .= '<h3 class="modal-title">PPC</h3><div id="ppc" style="height:400px">';
		    }
		    $html .= '<input type="hidden" name="invoiceDetailId" id="invoiceDetailId_' . $i . '" value="' . $val['id'] . '">';
		    $html .= '<div class="row">
                    	<div class="col-md-6 col-sm-6">
                        	<div class="form-group">
                            	<label class="control-label">Service Name</label>
                                <label class="formLabel2">Pay Per Click(PPC)</label>
                            </div>
                        </div>

                    	<div class="col-md-6 col-sm-6">
                        	<div class="form-group">
                            	<label class="control-label" for="pubName">Publisher Name</label>
                                <select class="form-control publisherName_PPC" id="pubName_' . $i . '">';
		    foreach ($publisherArray as $pid => $pname) {
			if ($val['publisher_id'] == $pid) {
			    $html .= '<option value="' . $pid . '" selected>' . $pname . '</option>';
			} else {
			    $html .= '<option value="' . $pid . '">' . $pname . '</option>';
			}
		    }

		    $html .= '</select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                    	<div class="col-md-6 col-sm-6">
                        	<div class="form-group">
                            	<label class="control-label" for="punDesc">Publisher Description</label>
								<textarea class="form-control autogrow description_PPC" id="pubDesc_' . $i . '">' . $val['service_description'] . '</textarea>
                            </div>
                        </div>

                    	<div class="col-md-6 col-sm-6">
                        	<div class="form-group">
                            	<label class="control-label" for="advBudgt">Advertising Budget Amount</label>
             					<input type="text" class="form-control advBudget_PPC" name="advBudgt" id="advBudgt_' . $i . '" value="' . $val['publisher_budget'] . '" autocomplete="off" oncopy="return false" oncut="return false" onpaste="return false" onkeypress="return isNumber(event)">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                    	<div class="col-md-6 col-sm-6">
                        	<div class="form-group">
                            	<label class="control-label" for="aglCharges">Agl Cahrges</label>
								<div class="input-group">
                                	<div class="input-group-addon">%</div>
             						<input type="text" class="form-control aglCharges_PPC" name="aglCharges" id="aglCharges_' . $i . '" value="' . $val['agency_charges_percentage'] . '" autocomplete="off" oncopy="return false" oncut="return false" onpaste="return false" onkeypress="return isNumber(event)">
                                </div>
                            </div>
                        </div>

                    	<div class="col-md-6 col-sm-6">
                        	<div class="form-group">
                            	<label class="control-label" for="amnt">Amount</label>
             					<input type="text" class="form-control amount_PPC" name="amnt" id="amnt_' . $i . '" value="' . $val['service_amount'] . '" autocomplete="off" oncopy="return false" oncut="return false" onpaste="return false" disabled="disabled">
                            </div>
                        </div>
                    </div>';
		}
		$i++;
	    }
	    $html .= '</div>';
	    foreach ($response as $key => $val) {
		if ($val['agency_service_id'] != 2) {
		    if ($firstTimeNonPpc == 1) {
			$firstTimeNonPpc = 2;
			$html .= '<h3 class="modal-title">Non PPC</h3><div id="nonppc">';
		    }
		    $html .= '<input type="hidden" name="invoiceDetailId" id="invoiceDetailId_' . $j . '" value="' . $val['id'] . '">';
		    $html .= '<div class="row">
							<div class="col-md-6 col-sm-6">
								<div class="form-group">
									<label class="control-label" for="servName">Service Name</label>
									<select class="form-control service_Non" id="servName_' . $j . '">';
		    foreach ($serviceArray as $sid => $sname) {
			if ($val['agency_service_id'] == $sid) {
			    $html .= '<option value="' . $sid . '" selected >' . $sname . '</option>';
			} else {
			    $html .= '<option value="' . $sid . '">' . $sname . '</option>';
			}
		    }
		    $html .= '</select>
                            </div>
                        </div>

                    	<div class="col-md-6 col-sm-6">
                        	<div class="form-group">
                            	<label class="control-label" for="servDesc">Service Description</label>
								<textarea class="form-control autogrow descriptn_Non" id="servDesc_' . $j . '">' . $val['service_description'] . '</textarea>
                            </div>
                        </div>

                    </div>

                    <div class="row">
                    	<div class="col-md-6 col-sm-6">
                        	<div class="form-group">
                            	<label class="control-label" for="nonPpcAmnt">Amount</label>
                                <input type="text" class="form-control amnt_Non" name="nonPpcAmnt" id="nonPpcAmnt_' . $j . '" value="' . $val['service_amount'] . '" autocomplete="off" oncopy="return false" oncut="return false" onpaste="return false" onkeypress="return isNumber(event)">
                            </div>
                        </div>
                    </div>';
		    $html .= '<hr style="margin-top:5px">';
		}
		$j++;
	    }
	    $html .= '</div>';
	} else {
	    $html = "No data found";
	}

	echo $html;

	die();
    }

    public function changeInvoiceStatusAction() {

	$id = $this->_ns->Adv8Uid;
	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));
	$invoiceStatus = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceStatus'));

	$params = array();
	$params['invoiceId'] = $invoiceId;
	$params['invoiceStatus'] = $invoiceStatus;
	$params['approvedBy'] = $id;
	$response = $this->_ObjInvoice->changeInvoiceStatus($params);

	if ($invoiceStatus == 2) {
	    $invoiceStatusText = "Approved";
	    $subject = "Proforma Invoice Approved";
	} else if ($invoiceStatus == 3) {
	    $invoiceStatusText = "Disapproved";
	    $subject = "Proforma Invoice Disapproved";
	}



	if (!empty($invoiceStatusText)) {
	    $bodyText = "A 'Proforma Invoice' has been " . $invoiceStatusText . ".";
	    $this->_ns->msg = $subject;

	    $params = array();
	    $params['invoiceId'] = $invoiceId;
	    $invoiceDetail = $this->_ObjInvoice->getInvoices($params);

	    $params = array();
	    $clientId = $invoiceDetail[0]['agency_client_id'];
	    $agencyId = $invoiceDetail[0]['agency_id'];

	    $params['clientId'] = $clientId;
	    $responseClient = $this->_ObjClient->getClientDetailsById($params);

	    $htmlForEmail = $this->_view->setTerminal(true)->setTemplate('cms/invoice/email-create.phtml')->setVariables(array('invoiceDetail' => $invoiceDetail, 'responseClient' => $responseClient, 'bodyText' => $bodyText, "Proforma" => "1"));

	    $htmlForEmail = $this->getServiceLocator()->get('viewrenderer')->render($htmlForEmail);


	    if ($_SERVER['HTTP_HOST'] == 'test.adv8zf2.kuber.in') {
		$sentMailEnable = 0;
	    } else {
		$sentMailEnable = 1;
	    }

	    /* sent email Module */
	    $sentEmailArray = $this->getEmailsIdForSentEmail($clientId, $agencyId);
	    /* sent email Module */



	    /* $mail = new Zend_Mail();
	      $mail->setType(Zend_Mime::MULTIPART_RELATED);
	      $mail->setBodyHtml($htmlForEmail);
	      $mail->setFrom("admin@adv8.co");
	      foreach($sentEmailArray as $kemail=>$email){
	      //$mail->addTo(trim($email));
	      }
	      $mail->addTo('shrutikakkar26@gmail.com');
	      $mail->addBcc('vishnu.dass@adglobal360.com');
	      $mail->addBcc('chirag.mendiratta@adglobal360.info');
	      $mail->setSubject($subject);
	      if($sentMailEnable == 1){
	      $mail->send();
	      } */
	}

	echo json_encode($response);

	die();
    }

    public function editProformaSubmitAction() {

	$id = $this->_ns->Adv8Uid;
	$data = $_POST;
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientName'));
	$invoiceStatus = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceStatus'));

	$params = array();
	$params['clientId'] = $clientId;
	$responseClient = $this->_ObjClient->getClientDetailsById($params);

	$comapnyName = '';
	if (!empty($responseClient)) {
	    foreach ($responseClient as $kk => $vv) {
		$agencyId = $vv['agency_id'];
		$comapnyName = $vv['company_name'];
	    }
	}

	$data['agencyId'] = $agencyId;
	$data['clientId'] = $clientId;
	$data['modifiedBy'] = $id;
	$data['approvedBy'] = $id;
	$response = $this->_ObjInvoice->editProformaSubmit($data);

	/* generate pdf */
	if ($response['error'] == 0) {
	    $params = array();
	    $params['invoiceId'] = $data['invoiceId'];
	    $invoiceDetail = $this->_ObjInvoice->getInvoices($params);

	    $invoiceServiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);

	    $html = $this->_view->setTerminal(true)->setTemplate('cms/invoice/proforma.phtml')->setVariables(array('invoiceDetail' => $invoiceDetail, 'responseClient' => $responseClient, 'invoiceServiceDetail' => $invoiceServiceDetail, "proforma" => "1"));

	    $html = $this->getServiceLocator()->get('viewrenderer')->render($html);


	    $folderPath = "public/assets/Proforma/" . $clientId . '/';

	    $res = $this->saveInvoiceProforma($folderPath, $html, $data['invoiceId'], $clientId); //assets/invoices/1/5-20150423122732.pdf
	    $path = $res['path'];

	    if ($invoiceStatus == 2) {
		$invoiceStatusText = "Approved";
		$subject = "Proforma Invoice Approved";
	    } else if ($invoiceStatus == 3) {
		$invoiceStatusText = "Disapproved";
		$subject = "Proforma Invoice Disapproved";
	    } else if ($invoiceStatus == 0) {
		$subject = "Proforma Invoice has been edited";
		$invoiceStatusText = "";
	    }

	    if (!empty($invoiceStatusText)) {
		$bodyText = "A 'Proforma Invoice' has been edited and " . $invoiceStatusText;
	    } else {
		$bodyText = "A 'Proforma Invoice' has been edited";
	    }

	    $this->_ns->msg = $bodyText;

	    $htmlForEmail = $this->_view->setTerminal(true)->setTemplate('cms/invoice/email-create.phtml')->setVariables(array('invoiceDetail' => $invoiceDetail, 'responseClient' => $responseClient, 'bodyText' => $bodyText, "Proforma" => "1"));

	    $htmlForEmail = $this->getServiceLocator()->get('viewrenderer')->render($htmlForEmail);

	    if ($_SERVER['HTTP_HOST'] == 'test.adv8zf2.kuber.in') {
		$sentMailEnable = 0;
	    } else {
		$sentMailEnable = 1;
	    }


	    /* sent email Module */
	    $sentEmailArray = $this->getEmailsIdForSentEmail($clientId, $agencyId);


	    /* $mail = new Zend_Mail();
	      $mail->setType(Zend_Mime::MULTIPART_RELATED);
	      $mail->setBodyHtml($htmlForEmail);
	      $mail->setFrom("admin@adv8.co");
	      foreach ($sentEmailArray as $kemail => $email) {
	      //$mail->addTo(trim($email));
	      }
	      $mail->addTo('shrutikakkar26@gmail.com');
	      $mail->addBcc('vishnu.dass@adglobal360.com');
	      $mail->addBcc('chirag.mendiratta@adglobal360.info');
	      $mail->setSubject($subject);
	      if ($sentMailEnable == 1) {
	      $mail->send();
	      } */
	}
	echo json_encode($response);
	die();
    }

    public function getEmailLogDetailAction() {

	$clientEmailStr = '';
	$emaildetails = array();
	$sentEmailArray = array();

	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));

	$params = array();
	$params['userRole'] = "3";
	$params['clientId'] = $clientId;


	$responseSuperUser = $this->_ObjUsers->getUserDetail($params);  //client email
	if (!empty($responseSuperUser)) {
	    foreach ($responseSuperUser as $key => $vuser) {
		$sentEmailArray[] = $vuser['user_email'];
	    }
	}


	$params = array();
	$params['clientId'] = $clientId;
	$responseUser = $this->_ObjMapping->getUsersMappingWithClient($params);

	if (!empty($responseUser)) {
	    foreach ($responseUser as $key => $vuser) {
		$clientOwnerId = $vuser['user_id'];
		$clientOwnerEmail = $vuser['user_email'];
		$clientOwnerRole = $vuser['user_role'];
	    }
	    //all shared invoive memebres
	    $sentEmailArray[] = $clientOwnerEmail;
	}


	if (!empty($sentEmailArray)) {
	    $clientEmailStr = implode(", ", $sentEmailArray);
	}


	$params = array();
	$params['clientId'] = $clientId;
	$params['invoiceId'] = $invoiceId;
	$responseEmail = $this->_ObjInvoice->getEmailLogDetail($params);

	if (!empty($responseEmail)) {
	    $i = 0;
	    foreach ($responseEmail as $key => $emaildetail) {
		$emaildetails[$i]['emails'] = $emaildetail['email'];
		$emaildetails[$i]['sentOn'] = date('jS-M-Y', strtotime($emaildetail['created_at']));
		$i++;
	    }

	    $error = 0;
	} else {
	    $error = 1;
	}
	$error = 0;
	$arr['error'] = $error;
	$arr['data'] = $emaildetails;
	$arr['clientEmailStr'] = $clientEmailStr;

	echo json_encode($arr);
	die();
    }

    public function getPaymentDateLogDetailAction() {
	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));
	$emaildetails = array();
	$params = array();
	$params['invoiceId'] = $invoiceId;
	$responseEmail = $this->_ObjInvoice->getPaymentDateLogDetail($params);

	if (!empty($responseEmail)) {
	    $i = 0;
	    foreach ($responseEmail as $key => $emaildetail) {
		$emaildetails[$i]['paymentDate'] = $emaildetail['payment_expected_date'];
		$emaildetails[$i]['updatedOn'] = date('jS-M-Y', strtotime($emaildetail['created_at']));
		$i++;
	    }

	    $error = 0;
	} else {
	    $error = 1;
	}
	$error = 0;
	$arr['error'] = $error;
	$arr['data'] = $emaildetails;
	echo json_encode($arr);
	die();
    }

    public function sentEmailSubmitAction() {
	$error = false;
	$userId = $this->_ns->Adv8Uid;
	$emailUser = $this->_ns->Adv8Emailid;
	$userName = $this->_ns->Adv8Username;

	$clientemails = $this->Xssplugin()->escape($this->getRequest()->getPost('clientemails'));
	$emails = explode(",", $clientemails);
	$clientemailsstr = implode(", ", $emails);

	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
	$invoicetype = $this->Xssplugin()->escape($this->getRequest()->getPost('invoicetype'));




	$params = array();
	$params['clientId'] = $clientId;
	$responseClient = $this->_ObjClient->getClientDetailsById($params);
	$comapnyName = '';
	if (!empty($responseClient)) {
	    foreach ($responseClient as $kk => $vv) {
		$comapnyName = $vv['company_name'];
	    }
	}

	$params = array();
	$params['invoiceId'] = $invoiceId;
	$invoiceDetail = $this->ObjInvoice->getInvoices($params);

	$params = array();
	$params['invoiceId'] = $invoiceId;
	$invoiceServiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);



	if ($invoicetype == 2) {
	    $text = "Invoice";
	    $Proforma = "0";
	} else {
	    $text = "Proforma";
	    $Proforma = "1";
	}



	$htmlForEmail = $this->_view->setTerminal(true)->setTemplate('cms/invoice/email-create.phtml')->setVariables(array('invoiceDetail' => $invoiceDetail, 'responseClient' => $responseClient, 'eMail' => $emailUser, 'userName' => $userName, "Proforma" => $Proforma));

	$htmlForEmail = $this->getServiceLocator()->get('viewrenderer')->render($htmlForEmail);

	$path = 'public/assets/' . $text . '/' . $clientId . '/' . 'IN_' . $invoiceId . '.pdf';

	//$path = 'assets/invoices/'.$clientId.'/TaxInvoice/'.$invoiceId.".pdf";

	$pdfContent = file_get_contents($path);

	if ($_SERVER['HTTP_HOST'] == 'test.adv8zf2.kuber.in') {
	    $sentMailEnable = 0;
	} else {
	    $sentMailEnable = 1;
	}

	/* $mail = new Zend_Mail();
	  $mail->setType(Zend_Mime::MULTIPART_RELATED);
	  $mail->setBodyHtml($htmlForEmail);
	  $mail->setFrom("admin@adv8.co");
	  foreach ($emails as $email) {
	  $mail->addTo(trim($email));
	  }
	  $mail->addBcc('shrutikakkar26@gmail.com');
	  $mail->addBcc('chirag.mendiratta@adglobal360.info');
	  $mail->addBcc('vishnu.dass@adglobal360.com');
	  $mail->setSubject('Invoice');
	  $mail->type = 'application/pdf';
	  $file = $mail->createAttachment($pdfContent);
	  $file->filename = $comapnyName . '.pdf';
	  if($sentMailEnable == 1){
	  //$mail->send();
	  } */

	$params = array();
	$params['clientemails'] = $clientemailsstr;
	$params['invoiceId'] = $invoiceId;
	$params['createdBy'] = $userId;
	$params['clientId'] = $clientId;

	$responseInsert = $this->_ObjInvoice->insertEmailLog($params);

	$arr['error'] = $error ? "1" : "0";
	$arr['msg'] = "success";

	echo json_encode($arr);
	die();
    }

    public function deleteInvoiceByIdAction() {
	$error = false;
	$agencyClientId = $this->_ns->Adv8Clientid;
	$agencyId = $this->_ns->Adv8Agencyid;




	$status = $this->Xssplugin()->escape($this->getRequest()->getPost('status'));
	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));


	$params = array();
	$params['status'] = $status;
	$params['invoiceId'] = $invoiceId;

	$responseInsert = $this->_ObjInvoice->deleteInvoiceById($params);
	echo json_encode($responseInsert);
	die();
    }

    public function getInvoiceDetailsAction() {

	$id = $this->_ns->Adv8Uid;
	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));
	$agencyId = $this->_ns->Adv8Agencyid;

	$params['agencyId'] = $agencyId;
	$responseServices = $this->_ObjInvoice->getAgencyServices($params);

	foreach ($responseServices as $key => $val) {
	    $serviceArray[$val['id']] = $val['short_name'];
	}

	$params = array();
	$params['invoiceId'] = $invoiceId;
	$responseInvoice = $this->_ObjInvoice->getInvoices($params);
	$invoiceDe = $responseInvoice[0];

	$params = array();
	$params['invoiceId'] = $invoiceId;
	$response = $this->_ObjInvoice->getInvoiceDetails($params);

	$params = array();
	$responsePublishers = $this->_ObjInvoice->getPublishers();
	foreach ($responsePublishers as $key => $val) {
	    $publisherArray[$val['id']] = $val['publisher_name'];
	}


	if (!empty($response)) {
	    $arr['error'] = 0;
	    $i = 0;
	    $total = 0;
	    $currency = "Rs.";
	    $taxInvoiceNumber = "";
	    $resInvoice = $this->_ObjInvoice->getTaxInvoiceNumber();
	    if (!empty($resInvoice)) {
		foreach ($resInvoice as $kinvoie => $vinvoice) {
		    $taxInvoiceNumber = $vinvoice['tax_invoice_id'];
		}

		$invoiceNumberArray = explode("/", $taxInvoiceNumber);
		$innumber = (int) $invoiceNumberArray['2'];

		$incremnetdTaxInvoiceNumber = $innumber + 1;
		switch (count($incremnetdTaxInvoiceNumber)) {
		    case 1:
			$incremnetdTaxInvoiceNumber = "00" . $incremnetdTaxInvoiceNumber;
			break;
		    case 2:
			$incremnetdTaxInvoiceNumber = "0" . $incremnetdTaxInvoiceNumber;
			break;
		}
	    }
	    $fromYear = date('y') - 1;

	    $newTaxInvoiceNumber = "AGL/" . $fromYear . "-" . date("y") . "/" . $incremnetdTaxInvoiceNumber;

	    foreach ($response as $key => $val) {
		$total = $total + $val['service_amount'];
		$data[$i]['serviceName'] = $serviceArray[$val['agency_service_id']];
		$data[$i]['serviceAmount'] = $currency . number_format($val['service_amount']);
		$data[$i]['publishrBudget'] = $currency . number_format($val['publisher_budget']);
		$data[$i]['agencyCharges'] = $currency . number_format($val['agency_charges']);
		if (!empty($val['publisher_id'])) {
		    $data[$i]['publisher'] = $publisherArray[$val['publisher_id']];
		} else {
		    $data[$i]['publisher'] = '';
		}
		$i++;
	    }

	    $arr['data'] = $data;
	    $arr['subTotal'] = $currency . number_format($total);
	    $arr['total'] = $currency . number_format($invoiceDe['total_amount']);
	    $arr['serviceTax'] = $currency . number_format($invoiceDe['servicetax_amount']);
	    $arr['taxInvoiceNumber'] = $newTaxInvoiceNumber;
	} else {
	    $arr['error'] = 1;
	    $arr['subTotal'] = 0;
	    $arr['total'] = 0;
	    $arr['serviceTax'] = 0;
	    $arr['data'] = array();
	}
	echo json_encode($arr);
	die();
    }

    public function createTaxInvoiceAction() {
	//session
	/*
	 * 
	 *  [_ControllerName] => Login
	  [_ActionName] => create-Tax-Invoice
	  [_ModuleName] => Cms
	  [Adv8Uid] => 48
	  [Adv8Clientid] => 0
	  [Adv8Agencyid] => 1
	  [Adv8Roleid] => 19
	  [Adv8Emailid] => agency@adglobal360.com
	  [Adv8Username] => Agency
	  [Adv8Rolename] =>
	  [Adv8Aclid] => 4
	 * 
	 */
	$user_role = $this->_ns->Adv8Roleid;

	$id = $this->_ns->Adv8Uid;

	$agencyClientId = $this->_ns->Adv8Clientid;
	$agencyId = $this->_ns->Adv8Agencyid;

	$taxInvoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('taxInvoiceId'));
	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));
	$remarks = $this->Xssplugin()->escape($this->getRequest()->getPost('remarks'));
	$paymentDate = $this->Xssplugin()->escape($this->getRequest()->getPost('paymentDate'));
	$quarter = $this->Xssplugin()->escape($this->getRequest()->getPost('quarter'));



	$params = array();

	$params['taxInvoiceId'] = $taxInvoiceId;
	$params['invoiceId'] = $invoiceId;
	$params['remarks'] = $remarks;
	$params['invoiceType'] = '2';
	$params['paymentDate'] = $paymentDate;
	$params['createdBy'] = $id;
	$params['quarter'] = $quarter;

	$responseInsert = $this->_ObjInvoice->createTaxInvoice($params);

	/* generate pdf */


	if ($responseInsert["error"] == 0) {
	    $this->_ns->msg = "Tax Invoice has been created Successfully";

	    $params = array();
	    $params['invoiceId'] = $invoiceId;
	    $invoiceDetail = $this->_ObjInvoice->getInvoices($params);


	    $invoiceServiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);

	    $params = array();
	    $clientId = $invoiceDetail[0]['agency_client_id'];
	    $agencyId = $invoiceDetail[0]['agency_id'];

	    $params['clientId'] = $clientId;
	    $responseClient = $this->_ObjClient->getClientDetailsById($params);




	    $html = $this->_view->setTerminal(true)->setTemplate('cms/invoice/proforma.phtml')->setVariables(array('invoiceDetail' => $invoiceDetail, 'responseClient' => $responseClient, 'invoiceServiceDetail' => $invoiceServiceDetail, "proforma" => 0));

	    $html = $this->getServiceLocator()->get('viewrenderer')->render($html);


	    $folderPath = "public/assets/Invoice/" . $clientId . "/";


	    $res = $this->saveInvoiceProforma($folderPath, $html, $invoiceId, $clientId);

	    $path = $res['path'];


	    $htmlForEmail = $this->_view->setTerminal(true)->setTemplate('cms/invoice/email-create.phtml')->setVariables(array('invoiceDetail' => $invoiceDetail, 'responseClient' => $responseClient, 'bodyText' => "A Tax invoice has been created.", "Proforma" => "0"));

	    $htmlForEmail = $this->getServiceLocator()->get('viewrenderer')->render($htmlForEmail);

	    if ($_SERVER['HTTP_HOST'] == 'test.adv8zf2.kuber.in') {
		$sentMailEnable = 0;
	    } else {
		$sentMailEnable = 1;
	    }

	    $sentEmailArray = $this->getEmailsIdForSentEmail($clientId, $agencyId);


	    /*  $mail = new Zend_Mail();
	      $mail->setType(Zend_Mime::MULTIPART_RELATED);
	      $mail->setBodyHtml($htmlForEmail);
	      $mail->setFrom("admin@adv8.co");
	      foreach ($sentEmailArray as $kemail => $email) {
	      //$mail->addTo(trim($email));
	      }
	      $mail->addTo('shrutikakkar26@gmail.com');
	      $mail->addBcc('vishnu.dass@adglobal360.com');
	      $mail->addBcc('chirag.mendiratta@adglobal360.info');
	      $mail->setSubject('Tax Invoice Created');
	      if ($sentMailEnable == 1) {
	      $mail->send();
	      } */

	    /* gsm token */
	    $params = array();
	    $params['userRole'] = "3";
	    $params['clientId'] = $clientId;
	    $responseSuperUser = $this->_ObjUsers->getUserDetail($params);  //client email
	    if (!empty($responseSuperUser)) {
		foreach ($responseSuperUser as $key => $v) {
		    if (!empty($v['gcm_token'])) {
			$gcmToken[] = $v['gcm_token'];
		    }
		}
	    }


	    if (!empty($gcmToken)) {

		$msg = "Invoice has been created of amount Rs. " . $invoiceDetail[0]['total_amount'] . " and invoice id is '" . $invoiceDetail[0]['tax_invoice_id'] . "'";
		;
		$msgArray = array(
		    'message' => $msg,
		    'title' => 'Invoice Created',
		    'subtitle' => '',
		    'vibrate' => 1,
		    'sound' => 1,
		    'largeIcon' => 'large_icon',
		    'smallIcon' => 'small_icon',
		    'type' => 'Invoice'
		);


		$msgArray[] = $msg;
		if (!empty($gcmToken)) {
		    foreach ($gcmToken as $k => $v) {
			if (!empty($v)) {
			    $rarray = explode(",", $v);
			    foreach ($rarray as $kk => $vv) {
				$registrationIdsArray[] = $vv;
			    }
			}
		    }
		}

		$data['registrationIds'] = $registrationIdsArray;
		$data['msg'] = $msgArray;
		//$cUrl = $Common->getBrodcasterUrl() . 'push-Notification/index/userEmail/';
		//$response = json_decode($Common->curlCallWithPost($cUrl, $data), true);
		//print_R($response);exit;
	    }
	}
	echo json_encode($responseInsert);

	die();
    }

    public function changePaymentExpectedDateAction() {
	$error = false;

	$userId = $this->_ns->Adv8Uid;

	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceId'));
	$expectedDate = $this->Xssplugin()->escape($this->getRequest()->getPost('expectedDate'));
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));


	$params = array();
	$params['paymentDate'] = $expectedDate;
	$params['invoiceId'] = $invoiceId;
	$params['createdBy'] = $userId;
	$params['clientId'] = $clientId;
	$responseInsert = $this->_ObjInvoice->insertPaymentDateLog($params);




	$params = array();
	$parmas['payment_expected_date'] = $expectedDate;
	$paramsBy['id'] = $invoiceId;
	$responseUpdate = $this->_ObjInvoice->updateRecord($parmas, $paramsBy);

	$arr['error'] = $error ? "1" : "0";
	$arr['msg'] = "success";

	echo json_encode($arr);
	die();
    }

    public function getEmailsIdForSentEmail($clientId, $agencyId) {
	/* sent email Module */

	$sentEmailArray = array();
	$params = array();
	$params['clientId'] = $clientId;
	$responseUser = $this->_ObjMapping->getUsersMappingWithClient($params);

	if (!empty($responseUser)) {
	    foreach ($responseUser as $key => $vuser) {
		$clientOwnerId = $vuser['user_id'];
		$clientOwnerEmail = $vuser['user_email'];
		$clientOwnerRole = $vuser['user_role'];
	    }
	    $sentEmailArray[] = $clientOwnerEmail;
	}


	/* get PMO */
	$params = array();
	$params['roleName'] = 'PMO';
	$responseRole = $this->_ObjInfoUserRole->getRoleIdByName($params);
	
	if (!empty($responseRole)) {
	    $rolePmo = $responseRole[0]['id'];
	} else {
	    $rolePmo = '4';
	}

	/* get Accounts */
	$params = array();
	$params['roleName'] = 'Account Manager';
	$responseRole = $this->_ObjInfoUserRole->getRoleIdByName($params);
	if (!empty($responseRole)) {
	    $roleAccount = $responseRole[0]['id'];
	} else {
	    $roleAccount = '23';
	}


	$params = array();
	$params['agencyId'] = $agencyId;
	$params['userRole'] = $rolePmo;
	$responsePmo = $this->_ObjUsers->getUserDetail($params);
	if (!empty($responsePmo)) {
	    foreach ($responsePmo as $key => $vuser) {
		$sentEmailArray[] = $vuser['user_email'];
	    }
	}

	/* get Account Email */
	$params = array();
	$params['agencyId'] = $agencyId;
	$params['userRole'] = $roleAccount;
	$responseAcount = $this->_ObjUsers->getUserDetail($params);
	if (!empty($responseAcount)) {
	    foreach ($responseAcount as $key => $vuser) {
		$sentEmailArray[] = $vuser['user_email'];
	    }
	}

	return $sentEmailArray;
	die();
    }

    public function saveInvoiceProforma($folderPath, $html, $invoiceId, $clientId) {
	if (!is_dir($folderPath)) {
	    mkdir($folderPath, 0777);
	    chmod($folderPath, 0777);
	}

	

	try {
	    $html2pdf = new \HTML2PDF('P', 'A4', 'en');

	    $html2pdf->writeHTML($html, isset($_GET['vuehtml']));
	    //$fileName = str_replace(array(" ","."),"_",$comapnyName ."-".$invoiceId). '.pdf';
	    $fileName = "IN_" . $invoiceId . '.pdf';
	    $path = $folderPath . $fileName;

	    if (file_exists($path)) {
		$extension = pathinfo($path, PATHINFO_EXTENSION);
		$filename = pathinfo($path, PATHINFO_FILENAME);
		$iterator = date('YmdHis');
		$new_filename = $filename . '-' . $iterator . '.' . $extension;
		rename($path, $folderPath . $new_filename);
	    }

	    $path = $folderPath . $fileName;
	    $html2pdf->Output($path, "F");
	} catch (HTML2PDF_exception $e) {
	    $error = true;
	    echo $e;
	    exit;
	}
	$arr['error'] = 0;
	$arr['path'] = $path;

	return $arr;
    }

    public function createProformaAction() {

	$userId = $this->_ns->Adv8Uid;
	$agencyClientId = $this->_ns->Adv8Clientid;
	$agencyId = $this->_ns->Adv8Agencyid;
	$userRole = $this->_ns->Adv8Roleid;

	$invoiceNumber = $this->Xssplugin()->escape($this->getRequest()->getPost('invoiceNumber'));
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
	$fDate = $this->Xssplugin()->escape($this->getRequest()->getPost('fDate'));
	$tDate = $this->Xssplugin()->escape($this->getRequest()->getPost('tDate'));
	$iStatus = $this->Xssplugin()->escape($this->getRequest()->getPost('iStatus'));

	$params = array();
	switch ($userRole) {
	    case '1':
	    case '19':
	    case '3':
	    case '23':
	    case '2':
		$params['agencyId'] = $agencyId;
		$responseClient = $this->_ObjClient->getClients($params);
		break;
	    default:
		$params['userId'] = $userId;
		$responseClient = $this->_ObjClient->getClientListByCm($params);
		if (empty($responseClient)) {
		    $params = array();
		    $params['createdBy'] = $userId;
		    $responseClient = $this->_ObjClient->getClients($params);
		}
		break;
	}



	$clientList = array();
	if (!empty($responseClient)) {
	    foreach ($responseClient as $key => $client) {
		$clientList[$client['id']] = $client['company_name'];
	    }
	}


	$params = array();
	$params['agencyId'] = $agencyId;
	$responseServices = $this->_ObjInvoice->getAgencyServices($params);
	foreach ($responseServices as $key => $val) {
	    $serviceArray[$val['id']] = $val['short_name'];
	}

	$params = array();
	$responsePublishers = $this->_ObjInvoice->getPublishers();
	foreach ($responsePublishers as $key => $val) {
	    $publisherArray[$val['id']] = $val['publisher_name'];
	}

	$msg = "";
	$styleMsg = "display:none";
	if ($this->_ns->msg != '') {
	    $msg = $this->_ns->msg;
	    $this->_ns->msg = "";
	    $styleMsg = "display:blck";
	}

	$this->_view->msg = $msg;
	$this->_view->styleMsg = $styleMsg;

	$invoiceStatus = array("0" => "PPC", "1" => "Non PPC", "2" => "Both");
	$this->_view->invoiceStatus = $invoiceStatus;
	$this->_view->clientList = $clientList;
	$this->_view->serviceArray = $serviceArray;
	$this->_view->publisherArray = $publisherArray;
	$this->_view->title = "Generate Proforma";
	return $this->_view;
    }

    public function createProformaSubmitAction() {
	$id = $this->_ns->Adv8Uid;
	$userId = $this->_ns->Adv8Uid;
	$agencyClientId = $this->_ns->Adv8Clientid;
	$agencyId = $this->_ns->Adv8Agencyid;
	$userRole = $this->_ns->Adv8Roleid;

	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientName'));
	$paymentExpectedDate = $this->Xssplugin()->escape($this->getRequest()->getPost('paymentExpectedDate'));
	$paymentStatus = $this->Xssplugin()->escape($this->getRequest()->getPost('paymentStatus'));

	$data = $_POST;

	$params = array();
	$params['clientId'] = $clientId;
	$responseClient = $this->_ObjClient->getClientDetailsById($params);

	if (!empty($responseClient)) {
	    foreach ($responseClient as $kk => $vv) {
		$agencyId = $vv['agency_id'];
	    }
	}
	$data['agencyId'] = $agencyId;
	$data['paymentStatus'] = $paymentStatus;

	$proformaInvoiceId = $this->_ObjInvoice->generateProformaId();
	$data['proformaInvoiceId'] = $proformaInvoiceId;
	$data['createdBy'] = $userId;

	$data['paymentExpectedDate'] = $paymentExpectedDate;
	$data['clientId'] = $clientId;
	$data['serviceTaxPercentage'] = '14';
	$data['remarks'] = 'NA';


	$response = $this->_ObjInvoice->createProformaSubmit($data);

	/* generate pdf */
	if ($response['error'] == 0) {

	    $this->_ns->msg = "Profora has been created Successfully";

	    $params = array();
	    $params['clientId'] = $clientId;
	    $responseClient = $this->_ObjClient->getClientDetailsById($params);

	    $comapnyName = '';
	    if (!empty($responseClient)) {
		foreach ($responseClient as $kk => $vv) {
		    $comapnyName = $vv['company_name'];
		}
	    }

	    $params = array();
	    $params['invoiceId'] = $response['invoiceId'];
	    $invoiceIdPdf = $params['invoiceId'];
	    $invoiceDetail = $this->_ObjInvoice->getInvoices($params);

	    $invoiceServiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);
	   

	    $html = $this->_view->setTerminal(true)->setTemplate('cms/invoice/proforma.phtml')->setVariables(array('invoiceDetail' => $invoiceDetail, 'responseClient' => $responseClient, 'invoiceServiceDetail' => $invoiceServiceDetail, "proforma" => "1"));

	    $html = $this->getServiceLocator()->get('viewrenderer')->render($html);


	    $folderPath = "public/assets/Proforma/" . $clientId . '/';
	    $res = $this->saveInvoiceProforma($folderPath, $html, $invoiceIdPdf, $clientId); //assets/invoices/1/5-20150423122732.pdf
	    $path = $res['path'];


	    $htmlForEmail = $this->_view->setTerminal(true)->setTemplate('cms/invoice/email-create.phtml')->setVariables(array('invoiceDetail' => $invoiceDetail, 'responseClient' => $responseClient, 'bodyText' => "A new 'Proforma Invoice' has been created.", "Proforma" => "1"));

	    $htmlForEmail = $this->getServiceLocator()->get('viewrenderer')->render($htmlForEmail);


	    if ($_SERVER['HTTP_HOST'] == 'test.adv8zf2.kuber.in') {
		$sentMailEnable = 0;
	    } else {
		$sentMailEnable = 1;
	    }

	    $sentEmailArray = $this->getEmailsIdForSentEmail($clientId, $agencyId);

	    /* $mail = new Zend_Mail();
	      $mail->setType(Zend_Mime::MULTIPART_RELATED);
	      $mail->setBodyHtml($htmlForEmail);
	      $mail->setFrom("admin@adv8.co");
	      foreach ($sentEmailArray as $k => $email) {
	      //$mail->addTo(trim($email));
	      }
	      $mail->addBcc('vishnu.dass@adglobal360.com');
	      $mail->addTo('shrutikakkar26@gmail.com');
	      $mail->addBcc('chirag.mendiratta@adglobal360.info');
	      $mail->setSubject('Proforma Invoice Created');
	      if ($sentMailEnable == 1) {
	      $mail->send();
	      } */
	}
	echo json_encode($response);
	die();
    }

    public function paymentAction() {
	$id = $this->_ns->Adv8Uid;
	$agencyClientId = $this->_ns->Adv8Clientid;
	$agencyId = $this->_ns->Adv8Agencyid;

	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getQuery('invoiceId'));

	if (empty($invoiceId)) {
	    die();
	}
	$params = array();
	$params['invoiceId'] = $invoiceId;
	$responseInvoiceArray = $this->_ObjInvoice->getInvoices($params);

	$invoiceDetail = $responseInvoiceArray[0];


	$params = array();
	$params['invoiceId'] = $invoiceId;
	$invoiceServiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);


	$params = array();
	$params['agencyId'] = $invoiceDetail['agency_id'];
	$responseServices = $this->_ObjInvoice->getAgencyServices($params);
	foreach ($responseServices as $key => $val) {
	    $serviceArray[$val['id']] = $val['short_name'];
	}

	$clientId = $invoiceDetail['agency_client_id'];
	$params = array();
	$params['clientId'] = $invoiceDetail['agency_client_id'];
	$responseClientArray = $this->_ObjClient->getClientDetailsById($params);
	$responseClient = $responseClientArray[0];

	$params = array();
	$params['userRole'] = "3";
	$params['clientId'] = $clientId;
	$responseSuperUser = $this->_ObjUsers->getUserDetail($params);  //client email
	if (!empty($responseSuperUser)) {
	    foreach ($responseSuperUser as $key => $vuser) {
		$clientEmaiilArray[] = $vuser['user_email'];
	    }
	}

	$clientEmailStr = '';
	if (!empty($clientEmaiilArray)) {
	    $clientEmailStr = implode(",", $clientEmaiilArray);
	}

	$sentEmailArray = $this->getEmailsIdForSentEmail($clientId, $agencyId);
	$cmEmailStr = '';
	if (!empty($sentEmailArray)) {
	    $cmEmailStr = implode(",", $sentEmailArray);
	}

	$responsePublishers = $this->_ObjInvoice->getPublishers();
	foreach ($responsePublishers as $key => $val) {
	    $publisherArray[$val['id']] = $val['publisher_name'];
	}

	$companyName = $responseClient['company_name'];

	$params = array();
	$params['invoiceId'] = $invoiceId;
	$payment = $this->_ObjInvoice->getPaymentByInvoiceId($params);

	$msg = "";
	$styleMsg = "display:none";
	if ($this->_ns->msg != '') {
	    $msg = $this->_ns->msg;
	    $this->_ns->msg = "";
	    $styleMsg = "display:blck";
	}

	$this->_view->msg = $msg;
	$this->_view->styleMsg = $styleMsg;



	$this->_view->companyName = $companyName;
	$this->_view->invoiceDetail = $invoiceDetail;
	$this->_view->invoiceServiceDetail = $invoiceServiceDetail;
	$this->_view->serviceArray = $serviceArray;
	$this->_view->payment = $payment;
	$this->_view->clientEmailStr = $clientEmailStr;
	$this->_view->cmEmailStr = $cmEmailStr;
	$this->_view->publisherArray = $publisherArray;
	$this->_view->title = "Payment";
	return $this->_view;
    }

    public function paymentSubmitAction() {

	$dataForEamil = $_POST;
	$clientId = $dataForEamil['clientId'];

	$id = $this->_ns->Adv8Uid;

	$agencyClientId = $this->_ns->Adv8Clientid;
	$agencyId = $this->_ns->Adv8Agencyid;
	$user_role = $this->_ns->Adv8Roleid;

	$invoiceId = $this->Xssplugin()->escape($this->getRequest()->getQuery('invoiceId'));
	$clientEmail = $this->Xssplugin()->escape($this->getRequest()->getQuery('clientEmail'));
	$cmEmail = $this->Xssplugin()->escape($this->getRequest()->getQuery('cmEmail'));

	$data = $_POST;
	$data['createdBy'] = $id;
	$responseInsert = $this->_ObjInvoice->paymentSubmit($data);
	$amountRecieved = $data['amountRecieved'];
	$actualInvId = $data['actualInvId'];

	$params = array();
	$params['clientId'] = $clientId;
	$responseClient = $this->_ObjClient->getClientDetailsById($params);


	if ($_SERVER['HTTP_HOST'] == 'test.adv8.co') {
	    $sentMailEnable = 0;
	} else {
	    $sentMailEnable = 1;
	}

	if ($responseInsert['error'] == 0) {
	    if (!empty($clientEmail)) {
		$clientEmailArray = explode(",", $clientEmail);

		$htmlForEmail = $this->_view->setTerminal(true)->setTemplate('cms/invoice/email-payment.phtml')->setVariables(array('dataForEamil' => $dataForEamil, 'responseClient' => $responseClient, 'bodyText' => "Payment has been received"));

		$htmlForEmail = $this->getServiceLocator()->get('viewrenderer')->render($htmlForEmail);

		$subject = "Payment Received";
		$mail = new Zend_Mail();
		$mail->setType(Zend_Mime::MULTIPART_RELATED);
		$mail->setBodyHtml($htmlForEmail);
		$mail->setFrom("admin@adv8.co");
		foreach ($clientEmailArray as $k => $val) {
		    $mail->addTo(trim($val));
		}
		$mail->addBcc('shrutikakkar26@gmail.com');
		$mail->addBcc('vishnu.dass@adglobal360.com');
		$mail->addBcc('chirag.mendiratta@adglobal360.info');
		$mail->setSubject($subject);
		if ($sentMailEnable == 1) {
		    $mail->send();
		}
	    }
	    if (!empty($cmEmail)) {
		$cmEmailArray = explode(",", $cmEmail);

		$htmlForEmail = $this->_view->setTerminal(true)->setTemplate('cms/invoice/email-cm-payment.phtml')->setVariables(array('dataForEamil' => $dataForEamil, 'responseClient' => $responseClient, 'bodyText' => "Payment has been received"));

		$htmlForEmail = $this->getServiceLocator()->get('viewrenderer')->render($htmlForEmail);

		$mail = new Zend_Mail();
		$mail->setType(Zend_Mime::MULTIPART_RELATED);
		$mail->setBodyHtml($htmlForEmail);
		$mail->setFrom("admin@adv8.co");
		foreach ($cmEmailArray as $k => $val) {
		    $mail->addTo(trim($val));
		}
		$mail->addBcc('shrutikakkar26@gmail.com');
		$mail->addBcc('vishnu.dass@adglobal360.com');
		$mail->addBcc('chirag.mendiratta@adglobal360.info');
		$mail->setSubject($subject);
		if ($sentMailEnable == 1) {
		    $mail->send();
		}
	    }
	}

	$this->_ns->msg = "Payment has been added Successfully";

	/* gsm token */
	$params = array();
	$params['userRole'] = "3";
	$params['clientId'] = $clientId;
	$responseSuperUser = $this->_ObjUsers->getUserDetail($params);  //client email
	if (!empty($responseSuperUser)) {
	    foreach ($responseSuperUser as $key => $v) {
		if (!empty($v['gcm_token'])) {
		    $gcmToken[] = $v['gcm_token'];
		}
	    }
	}

	if (!empty($gcmToken)) {
	    $amountRecieved = $data['amountRecieved'];
	    $actualInvId = $data['actualInvId'];

	    $msgGcm = "A Payment has been received of Rs. " . $amountRecieved . " against '" . $actualInvId . "'";
	    $msgArray = array(
		'message' => $msgGcm,
		'title' => 'Payment Received',
		'subtitle' => '',
		'vibrate' => 1,
		'sound' => 1,
		'largeIcon' => 'large_icon',
		'smallIcon' => 'small_icon',
		'type' => 'Payment'
	    );


	    $msgArray[] = $msgGcm;
	    if (!empty($gcmToken)) {
		foreach ($gcmToken as $k => $v) {
		    if (!empty($v)) {
			$rarray = explode(",", $v);
			foreach ($rarray as $kk => $vv) {
			    $registrationIdsArray[] = $vv;
			}
		    }
		}
	    }

	    $data['registrationIds'] = $registrationIdsArray;
	    $data['msg'] = $msgArray;
	    //$cUrl = $Common->getBrodcasterUrl() . 'push-Notification/index/userEmail/';
	    //$response = json_decode($Common->curlCallWithPost($cUrl, $data), true);
	    //print_R($response);exit;
	}
	echo json_encode($responseInsert);
	die();
    }

    public function reportAction() {
	$customPaging  = 0;
	$params = array();
	$agencyId = $this->_agencyId;
	$agencyClientId = $this->_ns->Adv8Clientid;
	$userId = $this->_ns->Adv8Uid;
	$userRole = $this->_ns->Adv8Roleid;

	$responseGroupHead = $this->_ObjGroupHead->getAllGroupHeadsDetail($params);
	
	foreach ($responseGroupHead as $k => $u) {
	    $groupHeadList[$u['user_id']] = $u['user_name'];
	}

	$paymentList = array("1" => "Upfront", "2" => "Post Payment");
	$clientTypeList = array("1" => "NBB", "2" => "Renewal", "3" => "Cross Selling");
	$invoiceTypeList = array("1" => "Proforma", "2" => "Tax Invoice");

	/* $params['regionId'] = '3';
	  $responseUser = $this->_ObjInvoice->getUsersByRegionId($params);
	  print_R($responseUser);exit;
	 */
	$params = array();
	$params['agencyId'] = $agencyId;
	$responseClient = $this->_ObjClient->getClients($params);

	$clientList = array();
	$salesOwnerList = array();
	if (!empty($responseClient)) {
	    foreach ($responseClient as $key => $client) {
		$clientIdArray[] = $client['id'];
		$params = array();
		$params['userId'] = $client['sales_owner'];
		$responseUser = $this->_ObjUsers->getParentAndUserDetail($params);
		$salesOwnerName = $responseUser['userDetail']['user_name'];
		$salesOwnerEmail = $responseUser['userDetail']['user_email'];
		$salesOwnerRole = $responseUser['userDetail']['user_role'];

		$salesOwnerList[$client['id']]['name'] = $salesOwnerName;
		$salesOwnerList[$client['id']]['salesownerid'] = $client['sales_owner'];
		$salesOwnerList[$client['id']]['email'] = $salesOwnerEmail;
		$salesOwnerList[$client['id']]['role'] = $salesOwnerRole;

		$clientList[$client['id']] = $client['company_name'];
	    }
	}

	$params = array();
	$params['agencyId'] = $agencyId;
	$responseAgency = $this->_ObjInvoice->getAgencyServices($params);
	$serviceList = array();
	if (!empty($responseAgency)) {
	    foreach ($responseAgency as $key => $service) {
		$serviceList[$service['id']] = $service['short_name'];
	    }
	}

	$params = array();
	$params['agencyId'] = $agencyId;
	$responsePublisher = $this->_ObjInvoice->getPublishers($params);
	$publisherList = array();
	if (!empty($responsePublisher)) {
	    foreach ($responsePublisher as $key => $publisher) {
		$publisherList[$publisher['id']] = $publisher['publisher_name'];
	    }
	}

	$params = array();
	$responseregin = $this->_ObjInvoice->getRegions($params);
	$regionList = array();
	if (!empty($responseregin)) {
	    foreach ($responseregin as $key => $region) {
		$regionList[$region['id']] = $region['name'];
	    }
	}

	$headerInvoiceServices = array();
	$totalPendingAmount = 0;
	$totalServiceAmount = 0;
	$totalAmount = 0;
	$totalSubAmount = 0;
	$totalAmountReceived = 0;
	$totalTds = 0;
	$totalAglCharges = 0;
	$totalAglChargesOthers = 0;
	$totalThirtyPendingAmount = 0;
	$totalSixtyPendingAmount = 0;
	$totalNintyPendingAmount = 0;
	$totalMoreNintyPendingAmount = 0;
	$headerAccountOwner = array();
	//$params['fDate'] = $fDate;
	//$params['tDate'] = $tDate;
	$params = array();

	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientName'));
	if (!empty($clientId)) {
	    $params['clientId'] = $clientId;
	}

	$clientType = $this->Xssplugin()->escape($this->getRequest()->getPost('clienttype'));
	if (!empty($clientType)) {
	    $params['clientType'] = $clientType;
	}


	$paymentStatus = $this->Xssplugin()->escape($this->getRequest()->getPost('paymentstatus'));
	if (!empty($paymentStatus)) {
	    $params['paymentStatus'] = $paymentStatus;
	}
	$searchInvoiceType = $this->Xssplugin()->escape($this->getRequest()->getPost('invicetype'));
	if (!empty($searchInvoiceType)) {
	    $params['invoiceType'] = $searchInvoiceType;
	}
	
	$searchQuarter = $this->Xssplugin()->escape($this->getRequest()->getPost('quarter'));
	if (!empty($searchQuarter)){
	    $params['quarter'] = $searchQuarter;
	}

	$fDate = $this->Xssplugin()->escape($this->getRequest()->getPost('fDate'));
	$tDate = $this->Xssplugin()->escape($this->getRequest()->getPost('tDate'));
	if (!empty($fDate)) {
	    $params['fDate'] = $fDate;
	    $params['tDate'] = $tDate;
	}

	$serchgrouphead = $this->Xssplugin()->escape($this->getRequest()->getPost('grouphead'));
	$serchregionid = $this->Xssplugin()->escape($this->getRequest()->getPost('region'));

	
	$params['agencyId'] = $agencyId;
	$params['customsearch'] = 1;
	$pagingInvoicCount = $this->_ObjInvoice->getInvoices($params);
	$rec_count = count($pagingInvoicCount); 
	
	$rec_limit = 5;
	if (isset($_GET['page'])) {
	    $page = $_GET{'page'} + 1;
	    $offset = $rec_limit * $page;
	} else {
	    $page = 0;
	    $offset = 0;
	}
	$left_rec = $rec_count - ($page * $rec_limit);
	
	
	$params = array();
	$params['agencyId'] = $agencyId;
	$params['customsearch'] = 1;
	$params['limit'] = $rec_limit;
	$params['offset'] = $offset;
	$responseInvoice = $this->_ObjInvoice->getInvoices($params);


	
	if (!empty($responseInvoice)) {
	    foreach ($responseInvoice as $key => $invoice) {
		$invoiceId = $invoice['id'];

		$params = array();
		$params['invoiceId'] = $invoiceId;
		$responseIvoiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);

		foreach ($responseIvoiceDetail as $k => $v) {
		    if ($v['agency_service_id'] == 2) {
			$headerInvoiceServices[$v['agency_service_id'] . "_" . $v['publisher_id']] = "PPC on " . $publisherList[$v['publisher_id']];
		    } else {
			$headerInvoiceServices[$v['agency_service_id'] . "_" . "0"] = $serviceList[$v['agency_service_id']];
		    }
		}

		$params = array();
		$tds = 0;
		$paymentDescription = "";
		$lastPaymentReceivedDate = '';
		$params['invoiceId'] = $invoiceId;
		$responseIvoicePayemnt = $this->_ObjInvoice->getPaymentDetail($params);
		if (!empty($responseIvoicePayemnt)) {
		    foreach ($responseIvoicePayemnt as $kPay => $vpay) {
			$tds = $tds + $vpay['tds'];
			$paymentDescription = $vpay['payment_mode_info'];
			$lastPaymentReceivedDate = $vpay['payment_received_date'];
		    }
		}

		$params = array();
		$params['userId'] = $invoice['created_by'];
		$responseUser = $this->_ObjUsers->getUserDetail($params);

		$invoiceOwner = $responseUser[0]['user_name'];

		if ($invoice['client_type'] == 1) {  //nbb  cliient
		    $params = array();
		    $params['userId'] = $salesOwnerList[$invoice['agency_client_id']]['salesownerid'];

		    $responseUser = $this->_ObjUsers->getGroupHeadDetail($params);
		    $groupHead = '';

		    $groupHead = $responseUser[0]['user_name'];
		    $groupHeadId = $responseUser[0]['id'];
		    $roleSales = $salesOwnerList[$invoice['agency_client_id']]['role'];
		    $returnKey = $this->getCustomRoles($roleSales);
		    $headerAccountOwner[$returnKey['headerKey']] = $returnKey['headerValue'];
		    $ownerArray = array();
		    $ownerArray[$returnKey['headerKey']] = $salesOwnerList[$invoice['agency_client_id']]['email'];
		} else {
		    $params = array();
		    $params['accountOwner'] = "1";
		    $params['clientId'] = $invoice['agency_client_id'];
		    $responseCm = $this->_ObjMapping->getUsersMappingWithClient($params);
		    $ownerArray = array();
		    $groupHead = '';
		    $groupHeadId = '';
		    if (!empty($responseCm)) {
			foreach ($responseCm as $kcm => $cm) {
			    $individualOwner = $cm['user_id'];
			    $roleSales = $cm['user_role'];
			    $returnKey = $this->getCustomRoles($roleSales);
			    $headerAccountOwner[$returnKey['headerKey']] = $returnKey['headerValue'];
			    $ownerArray[$returnKey['headerKey']] = $cm['user_email'];
			}


			$params = array();
			$params['userId'] = $individualOwner;
			$responseUser = $this->_ObjUsers->getGroupHeadDetail($params);


			$groupHead = $responseUser[0]['user_name'];
			$groupHeadId = $responseUser[0]['id'];
		    }
		}


		if (!empty($serchgrouphead)) {
		    if ($groupHeadId == $serchgrouphead) {
			
		    } else {
			continue;
		    }
		}


		/* get region */
		$params = array();
		$regionId = '';
		if (!empty($groupHeadId)) {
		    $params['userId'] = $groupHeadId;
		    $responseRegion = $this->_ObjUsers->getRegionByUserId($params);

		    if (!empty($responseRegion['regionDetail'])) {
			$regionId = $responseRegion['regionDetail']['region_id'];
		    }
		}


		if (!empty($serchregionid)) {
		    if ($serchregionid == $regionId) {
			
		    } else {
			continue;
		    }
		}

		$regionName = '';
		if (!empty($regionId)) {
		    $regionName = $regionList[$regionId];
		}

		$invoiceIdArray[] = $invoiceId;
		$finalArry['data'][$invoiceId]['accountOwner'] = $ownerArray;

		$finalArry['data'][$invoiceId]['groupHead'] = $groupHead;

		$finalArry['data'][$invoiceId]['id'] = $invoice['id'];
		$finalArry['data'][$invoiceId]['invoiceOwner'] = $invoiceOwner;

		$finalArry['data'][$invoiceId]['regionName'] = $regionName;
		$finalArry['data'][$invoiceId]['invoiceDate'] = $invoice['payment_expected_date'];
		$finalArry['data'][$invoiceId]['subAmount'] = $invoice['sub_amount'];


		$finalArry['data'][$invoiceId]['paymentStatus'] = $paymentList[$invoice['payment_status']];

		$finalArry['data'][$invoiceId]['clientType'] = $clientTypeList[$invoice['client_type']];

		$finalArry['data'][$invoiceId]['invoiceType'] = $invoiceTypeList[$invoice['invoice_type']];

		if ($invoice['invoice_type'] == 1) {
		    $invoiceType = "Proforma";
		    $invoiceCreateDate = $invoice['created_at'];
		    $finalArry['data'][$invoiceId]['invoiceNumber'] = $invoice['proforma_invoice_id'];
		} else {
		    $invoiceType = "Actual";
		    $invoiceCreateDate = $invoice['invoice_created_at'];
		    $finalArry['data'][$invoiceId]['invoiceNumber'] = $invoice['tax_invoice_id'];
		}

		$totalPendingAmount = $invoice['due_amount'] + $totalPendingAmount;
		$totalServiceAmount = $invoice['servicetax_amount'] + $totalServiceAmount;

		$totalAmount = $invoice['total_amount'] + $totalAmount;
		$totalSubAmount = $invoice['sub_amount'] + $totalSubAmount;
		
		$totalAmountReceived = $invoice['received_amount'] + $totalAmountReceived;

		$totalTds = $tds + $totalTds;


		$finalArry['data'][$invoiceId]['clientName'] = $clientList[$invoice['agency_client_id']];
		$finalArry['data'][$invoiceId]['serviceTax'] = $invoice['servicetax_amount'];
		$finalArry['data'][$invoiceId]['amount'] = $invoice['total_amount'];
		$finalArry['data'][$invoiceId]['tds'] = $tds;
		$finalArry['data'][$invoiceId]['amountReceived'] = $invoice['received_amount'] - $tds;
		$finalArry['data'][$invoiceId]['pendingAmount'] = $invoice['due_amount'];
		$finalArry['data'][$invoiceId]['paymentDescription'] = $paymentDescription;
		$finalArry['data'][$invoiceId]['dateOfClearing'] = $lastPaymentReceivedDate;

		$todayDate = date("Y-m-d");

		$date1 = date_create($invoiceCreateDate);
		$date2 = date_create($todayDate);
		$diff = date_diff($date1, $date2);
		//print_R($diff);exit;
		$pendingDays = $diff->days;

		$finalArry['data'][$invoiceId]['zeroToThirty'] = '0';
		$finalArry['data'][$invoiceId]['thirtyToSixty'] = '0';
		$finalArry['data'][$invoiceId]['sixtyToNinety'] = '0';
		$finalArry['data'][$invoiceId]['moreNinety'] = '0';

		if ($pendingDays >= 0 && $pendingDays <= 30) {
		    $finalArry['data'][$invoiceId]['zeroToThirty'] = $invoice['due_amount'];
		    $totalThirtyPendingAmount = $totalThirtyPendingAmount + $invoice['due_amount'];
		} else if ($pendingDays >= 31 && $pendingDays <= 60) {
		    $finalArry['data'][$invoiceId]['thirtyToSixty'] = $invoice['due_amount'];
		    $totalSixtyPendingAmount = $totalSixtyPendingAmount + $invoice['due_amount'];
		} else if ($pendingDays >= 61 && $pendingDays <= 90) {
		    $finalArry['data'][$invoiceId]['sixtyToNinety'] = $invoice['due_amount'];
		    $totalNintyPendingAmount = $totalNintyPendingAmount + $invoice['due_amount'];
		} else if ($pendingDays >= 91) {
		    $finalArry['data'][$invoiceId]['moreNinety'] = $invoice['due_amount'];
		    $totalMoreNintyPendingAmount = $totalMoreNintyPendingAmount + $invoice['due_amount'];
		} else {
		    $xx = 1;
		}
	    }
//agl_charges + service_amount
	    if (!empty($invoiceIdArray)) {
		
		foreach ($invoiceIdArray as $kinvoice => $valinvoiceid) {
		    $aglCharges = 0;
		    $serviceAmount = 0;
		    $params = array();
		    $params['invoiceId'] = $valinvoiceid;
		    $responseIvoiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);
		    
		    foreach ($responseIvoiceDetail as $k => $v) {
			$dynamicKey = $v['agency_service_id'] . "_" . $v['publisher_id'];
			
			//if service exits two time
			if(isset($finalArry['data'][$valinvoiceid]['serviceArray'][$dynamicKey])){
			    $tempCalculation = $finalArry['data'][$valinvoiceid]['serviceArray'][$dynamicKey];
			}else{
			    $tempCalculation = 0;
			}
			
			
			$aglCharges = $v['agency_charges'] + $aglCharges;
			
			//echo $v['publisher_id']."<br/>";
			if(!empty($v['publisher_id'])){
			    $finalArry['data'][$valinvoiceid]['serviceArray'][$dynamicKey] = $tempCalculation + $v['publisher_budget'];
			}else{
			    $finalArry['data'][$valinvoiceid]['serviceArray'][$dynamicKey] = $tempCalculation + $v['service_amount'];
			   $serviceAmount = $v['service_amount'] + $serviceAmount;  
			}

			if (empty($finalArry['total']['serviceTotal'][$dynamicKey])) {
			    $finalArry['total']['serviceTotal'][$dynamicKey] = 0;
			}
			$finalArry['total']['serviceTotal'][$dynamicKey] = $finalArry['total']['serviceTotal'][$dynamicKey] + $v['service_amount'];
		    }
		    
		    $finalArry['data'][$valinvoiceid]['aglCharges'] = $aglCharges;
		    
		    $finalArry['data'][$valinvoiceid]['aglChargesOther'] = $serviceAmount + $aglCharges;
		    
		    $totalAglCharges = $totalAglCharges + $aglCharges;
		    $totalAglChargesOthers = $totalAglChargesOthers + $serviceAmount + $aglCharges;
		}
	    }

	    $finalArry['total']['totalPendingAmount'] = $totalPendingAmount;
	    $finalArry['total']['totalServiceAmount'] = $totalServiceAmount;
	    $finalArry['total']['totalAmount'] = $totalAmount;
	    $finalArry['total']['totalSubAmount'] = $totalSubAmount;
	    
	    $finalArry['total']['totalTds'] = $totalTds;
	    $finalArry['total']['totalAmountReceived'] = $totalAmountReceived - $totalTds;
	    $finalArry['total']['totalAglCharges'] = $totalAglCharges;
	    $finalArry['total']['totalAglChargesOthers'] = $totalAglChargesOthers;
	    $finalArry['total']['totalThirtyPendingAmount'] = $totalThirtyPendingAmount;
	    $finalArry['total']['totalSixtyPendingAmount'] = $totalSixtyPendingAmount;
	    $finalArry['total']['totalNintyPendingAmount'] = $totalNintyPendingAmount;
	    $finalArry['total']['totalMoreNintyPendingAmount'] = $totalMoreNintyPendingAmount;
	}

	if (empty($invoiceIdArray)) {
	    $finalArry = array();
	}

	if($customPaging == 1){
	    count($finalArry['data']);
	}
	
	$quarterList = array("1" => "1 Quarter", "2" => "2 Quarter", "3" => "3 Quarter", "4" => "4 Quarter");
	//$curMonth = date("m", time());
	//$curQuarter = ceil($curMonth / 3);
	
	$excelDownloadUrl = '/billing/invoice/excel-Download?clientName=' . $clientId . '&clienttype=' . $clientType . '&paymentstatus=' . $paymentStatus . '&invicetype=' . $searchInvoiceType . '&fDate=' . $fDate . '&tDate=' . $tDate . '&grouphead=' . $serchgrouphead . '&region=' . $serchgrouphead;

	$this->_view->title = "Invoice List";
	$this->_view->finalArry = $finalArry;
	$this->_view->headerInvoiceServices = $headerInvoiceServices;
	$this->_view->userRole = $userRole;
	$this->_view->page = $page;
	$this->_view->left_rec = $left_rec;
	$this->_view->rec_limit = $rec_limit;
	$this->_view->clientList = $clientList;
	$this->_view->groupHeadList = $groupHeadList;
	$this->_view->regionList = $regionList;
	$this->_view->clientTypeList = $clientTypeList;
	$this->_view->paymentList = $paymentList;
	$this->_view->invoiceTypeList = $invoiceTypeList;
	$this->_view->clientName = $clientId;
	$this->_view->clienttype = $clientType;
	$this->_view->paymentstatus = $paymentStatus;
	$this->_view->invicetype = $searchInvoiceType;
	$this->_view->grouphead = $serchgrouphead;
	$this->_view->region = $serchregionid;
	$this->_view->fDate = $fDate;
	$this->_view->tDate = $tDate;
	$this->_view->quarterList = $quarterList;
	
	$this->_view->searchQuarter = $searchQuarter;
	
	$this->_view->excelDownloadUrl = $excelDownloadUrl;
	$this->_view->headerAccountOwner = $headerAccountOwner;
	
	
	return $this->_view;
    }

    function getCustomRoles($roleSales) {
	$headerKey = '';
	$headerValue = '';
	switch ($roleSales) {
	    case 10:
	    case 22:
		$headerKey = '1';
		$headerValue = 'Group Head';
		break;
	    case 23:
	    case 25:
		$headerKey = '2';
		$headerValue = 'Senior Account Manger';
		break;
	    case 9:
	    case 27:
	    case 32:
		$headerKey = '3';
		$headerValue = 'Account Manger';
		break;
	    case 26:
	    case 28:
	    case 37:
		$headerKey = '4';
		$headerValue = 'Associate Account Manger';
		break;
	    case 38:
	    case 31:
		$headerKey = '5';
		$headerValue = 'Sub Associate Account Manger';
		break;
	}
	
	$return['headerKey'] = $headerKey;
	$return['headerValue'] = $headerValue;
	return $return;
    }

    function excelDownloadAction() {

	$params = array();
	$agencyId = $this->_agencyId;
	$agencyClientId = $this->_ns->Adv8Clientid;
	$userId = $this->_ns->Adv8Uid;
	$userRole = $this->_ns->Adv8Roleid;

	$responseGroupHead = $this->_ObjGroupHead->getAllGroupHeadsDetail($params);
	foreach ($responseGroupHead as $k => $u) {
	    $groupHeadList[$u['user_id']] = $u['user_name'];
	}

	$paymentList = array("1" => "Upfront", "2" => "Post Payment");
	$clientTypeList = array("1" => "NBB", "2" => "Renewal", "3" => "Cross Selling");
	$invoiceTypeList = array("1" => "Proforma", "2" => "Tax Invoice");

	/* $params['regionId'] = '3';
	  $responseUser = $this->_ObjInvoice->getUsersByRegionId($params);
	  print_R($responseUser);exit;
	 */
	$params = array();
	$params['agencyId'] = $agencyId;
	$responseClient = $this->_ObjClient->getClients($params);

	$clientList = array();
	$salesOwnerList = array();
	if (!empty($responseClient)) {
	    foreach ($responseClient as $key => $client) {
		$clientIdArray[] = $client['id'];
		$params = array();
		$params['userId'] = $client['sales_owner'];
		$responseUser = $this->_ObjUsers->getParentAndUserDetail($params);
		$salesOwnerName = $responseUser['userDetail']['user_name'];
		$salesOwnerEmail = $responseUser['userDetail']['user_email'];
		$salesOwnerRole = $responseUser['userDetail']['user_role'];

		$salesOwnerList[$client['id']]['name'] = $salesOwnerName;
		$salesOwnerList[$client['id']]['salesownerid'] = $client['sales_owner'];
		$salesOwnerList[$client['id']]['email'] = $salesOwnerEmail;
		$salesOwnerList[$client['id']]['role'] = $salesOwnerRole;

		$clientList[$client['id']] = $client['company_name'];
	    }
	}

	$params = array();
	$params['agencyId'] = $agencyId;
	$responseAgency = $this->_ObjInvoice->getAgencyServices($params);
	$serviceList = array();
	if (!empty($responseAgency)) {
	    foreach ($responseAgency as $key => $service) {
		$serviceList[$service['id']] = $service['short_name'];
	    }
	}

	$params = array();
	$params['agencyId'] = $agencyId;
	$responsePublisher = $this->_ObjInvoice->getPublishers($params);
	$publisherList = array();
	if (!empty($responsePublisher)) {
	    foreach ($responsePublisher as $key => $publisher) {
		$publisherList[$publisher['id']] = $publisher['publisher_name'];
	    }
	}

	$params = array();
	$responseregin = $this->_ObjInvoice->getRegions($params);
	$regionList = array();
	if (!empty($responseregin)) {
	    foreach ($responseregin as $key => $region) {
		$regionList[$region['id']] = $region['name'];
	    }
	}

	$headerInvoiceServices = array();
	$totalPendingAmount = 0;
	$totalServiceAmount = 0;
	$totalAmount = 0;
	$totalAmountReceived = 0;
	$totalTds = 0;
	$totalAglCharges = 0;

	$totalThirtyPendingAmount = 0;
	$totalSixtyPendingAmount = 0;
	$totalNintyPendingAmount = 0;
	$totalMoreNintyPendingAmount = 0;

	//$params['fDate'] = $fDate;
	//$params['tDate'] = $tDate;
	$params = array();

	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientName'));
	if (!empty($clientId)) {
	    $params['clientId'] = $clientId;
	}

	$clientType = $this->Xssplugin()->escape($this->getRequest()->getPost('clienttype'));
	if (!empty($clientType)) {
	    $params['clientType'] = $clientType;
	}


	$paymentStatus = $this->Xssplugin()->escape($this->getRequest()->getPost('paymentstatus'));
	if (!empty($paymentStatus)) {
	    $params['paymentStatus'] = $paymentStatus;
	}
	$searchInvoiceType = $this->Xssplugin()->escape($this->getRequest()->getPost('invicetype'));
	if (!empty($searchInvoiceType)) {
	    $params['invoiceType'] = $searchInvoiceType;
	}

	$fDate = $this->Xssplugin()->escape($this->getRequest()->getPost('fDate'));
	$tDate = $this->Xssplugin()->escape($this->getRequest()->getPost('tDate'));
	if (!empty($fDate)) {
	    $params['fDate'] = $fDate;
	    $params['tDate'] = $tDate;
	}

	$serchgrouphead = $this->Xssplugin()->escape($this->getRequest()->getPost('grouphead'));
	$serchregionid = $this->Xssplugin()->escape($this->getRequest()->getPost('region'));

	$params['agencyId'] = $agencyId;
	$params['customsearch'] = 1;

	$responseInvoice = $this->_ObjInvoice->getInvoices($params);

	if (!empty($responseInvoice)) {
	    foreach ($responseInvoice as $key => $invoice) {
		$invoiceId = $invoice['id'];

		$params = array();
		$params['invoiceId'] = $invoiceId;
		$responseIvoiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);

		foreach ($responseIvoiceDetail as $k => $v) {
		    if ($v['agency_service_id'] == 2) {
			$headerInvoiceServices[$v['agency_service_id'] . "_" . $v['publisher_id']] = "PPC on " . $publisherList[$v['publisher_id']];
		    } else {
			$headerInvoiceServices[$v['agency_service_id'] . "_" . "0"] = $serviceList[$v['agency_service_id']];
		    }
		}

		$params = array();
		$tds = 0;
		$paymentDescription = "";
		$lastPaymentReceivedDate = '';
		$params['invoiceId'] = $invoiceId;
		$responseIvoicePayemnt = $this->_ObjInvoice->getPaymentDetail($params);
		if (!empty($responseIvoicePayemnt)) {
		    foreach ($responseIvoicePayemnt as $kPay => $vpay) {
			$tds = $tds + $vpay['tds'];
			$paymentDescription = $vpay['payment_mode_info'];
			$lastPaymentReceivedDate = $vpay['payment_received_date'];
		    }
		}

		$params = array();
		$params['userId'] = $invoice['created_by'];
		$responseUser = $this->_ObjUsers->getUserDetail($params);

		$invoiceOwner = $responseUser[0]['user_name'];

		if ($invoice['client_type'] == 1) {  //nbb  cliient
		    $params = array();
		    $params['userId'] = $salesOwnerList[$invoice['agency_client_id']]['salesownerid'];

		    $responseUser = $this->_ObjUsers->getGroupHeadDetail($params);
		    $groupHead = '';

		    $groupHead = $responseUser[0]['user_name'];
		    $groupHeadId = $responseUser[0]['id'];
		    $roleSales = $salesOwnerList[$invoice['agency_client_id']]['role'];
		    $returnKey = $this->getCustomRoles($roleSales);
		    $headerAccountOwner[$returnKey['headerKey']] = $returnKey['headerValue'];
		    $ownerArray = array();
		    $ownerArray[$returnKey['headerKey']] = $salesOwnerList[$invoice['agency_client_id']]['email'];
		} else {
		    $params = array();
		    $params['accountOwner'] = "1";
		    $params['clientId'] = $invoice['agency_client_id'];
		    $responseCm = $this->_ObjMapping->getUsersMappingWithClient($params);

		    $ownerArray = array();
		    $groupHead = '';
		    $groupHeadId = '';
		    if (!empty($responseCm)) {
			foreach ($responseCm as $kcm => $cm) {
			    $individualOwner = $cm['user_id'];
			    $roleSales = $cm['user_role'];
			    $returnKey = $this->getCustomRoles($roleSales);
			    $headerAccountOwner[$returnKey['headerKey']] = $returnKey['headerValue'];
			    $ownerArray[$returnKey['headerKey']] = $cm['user_email'];
			}


			$params = array();
			$params['userId'] = $individualOwner;
			$responseUser = $this->_ObjUsers->getGroupHeadDetail($params);


			$groupHead = $responseUser[0]['user_name'];
			$groupHeadId = $responseUser[0]['id'];
		    }
		}


		if (!empty($serchgrouphead)) {
		    if ($groupHeadId == $serchgrouphead) {
			
		    } else {
			continue;
		    }
		}


		/* get region */
		$params = array();
		$regionId = '';
		if (!empty($groupHeadId)) {
		    $params['userId'] = $groupHeadId;
		    $responseRegion = $this->_ObjUsers->getRegionByUserId($params);

		    if (!empty($responseRegion['regionDetail'])) {
			$regionId = $responseRegion['regionDetail']['region_id'];
		    }
		}


		if (!empty($serchregionid)) {
		    if ($serchregionid == $regionId) {
			
		    } else {
			continue;
		    }
		}

		$regionName = '';
		if (!empty($regionId)) {
		    $regionName = $regionList[$regionId];
		}

		$invoiceIdArray[] = $invoiceId;
		$finalArry['data'][$invoiceId]['accountOwner'] = $ownerArray;

		$finalArry['data'][$invoiceId]['groupHead'] = $groupHead;

		$finalArry['data'][$invoiceId]['id'] = $invoice['id'];
		$finalArry['data'][$invoiceId]['invoiceOwner'] = $invoiceOwner;

		$finalArry['data'][$invoiceId]['regionName'] = $regionName;
		$finalArry['data'][$invoiceId]['invoiceDate'] = $invoice['payment_expected_date'];


		$finalArry['data'][$invoiceId]['paymentStatus'] = $paymentList[$invoice['payment_status']];

		$finalArry['data'][$invoiceId]['clientType'] = $clientTypeList[$invoice['client_type']];

		$finalArry['data'][$invoiceId]['invoiceType'] = $invoiceTypeList[$invoice['invoice_type']];

		if ($invoice['invoice_type'] == 1) {
		    $invoiceType = "Proforma";
		    $invoiceCreateDate = $invoice['created_at'];
		    $finalArry['data'][$invoiceId]['invoiceNumber'] = $invoice['proforma_invoice_id'];
		} else {
		    $invoiceType = "Actual";
		    $invoiceCreateDate = $invoice['invoice_created_at'];
		    $finalArry['data'][$invoiceId]['invoiceNumber'] = $invoice['tax_invoice_id'];
		}

		$totalPendingAmount = $invoice['due_amount'] + $totalPendingAmount;
		$totalServiceAmount = $invoice['servicetax_amount'] + $totalServiceAmount;

		$totalAmount = $invoice['total_amount'] + $totalAmount;
		$totalAmountReceived = $invoice['received_amount'] + $totalAmountReceived;

		$totalTds = $tds + $totalTds;


		$finalArry['data'][$invoiceId]['clientName'] = $clientList[$invoice['agency_client_id']];
		$finalArry['data'][$invoiceId]['serviceTax'] = $invoice['servicetax_amount'];
		$finalArry['data'][$invoiceId]['amount'] = $invoice['total_amount'];
		$finalArry['data'][$invoiceId]['tds'] = $tds;
		$finalArry['data'][$invoiceId]['amountReceived'] = $invoice['received_amount'] - $tds;
		$finalArry['data'][$invoiceId]['pendingAmount'] = $invoice['due_amount'];
		$finalArry['data'][$invoiceId]['paymentDescription'] = $paymentDescription;
		$finalArry['data'][$invoiceId]['dateOfClearing'] = $lastPaymentReceivedDate;

		$todayDate = date("Y-m-d");

		$date1 = date_create($invoiceCreateDate);
		$date2 = date_create($todayDate);
		$diff = date_diff($date1, $date2);
		//print_R($diff);exit;
		$pendingDays = $diff->days;

		$finalArry['data'][$invoiceId]['zeroToThirty'] = '0';
		$finalArry['data'][$invoiceId]['thirtyToSixty'] = '0';
		$finalArry['data'][$invoiceId]['sixtyToNinety'] = '0';
		$finalArry['data'][$invoiceId]['moreNinety'] = '0';

		if ($pendingDays >= 0 && $pendingDays <= 30) {
		    $finalArry['data'][$invoiceId]['zeroToThirty'] = $invoice['due_amount'];
		    $totalThirtyPendingAmount = $totalThirtyPendingAmount + $invoice['due_amount'];
		} else if ($pendingDays >= 31 && $pendingDays <= 60) {
		    $finalArry['data'][$invoiceId]['thirtyToSixty'] = $invoice['due_amount'];
		    $totalSixtyPendingAmount = $totalSixtyPendingAmount + $invoice['due_amount'];
		} else if ($pendingDays >= 61 && $pendingDays <= 90) {
		    $finalArry['data'][$invoiceId]['sixtyToNinety'] = $invoice['due_amount'];
		    $totalNintyPendingAmount = $totalNintyPendingAmount + $invoice['due_amount'];
		} else if ($pendingDays >= 91) {
		    $finalArry['data'][$invoiceId]['moreNinety'] = $invoice['due_amount'];
		    $totalMoreNintyPendingAmount = $totalMoreNintyPendingAmount + $invoice['due_amount'];
		} else {
		    $xx = 1;
		}
	    }

	    if (!empty($invoiceIdArray)) {
		foreach ($invoiceIdArray as $kinvoice => $valinvoiceid) {
		    $aglCharges = 0;
		    $serviceAmount = 0;
		    $params = array();
		    $params['invoiceId'] = $valinvoiceid;
		    $responseIvoiceDetail = $this->_ObjInvoice->getInvoiceDetails($params);
		    
		    foreach ($responseIvoiceDetail as $k => $v) {
			$dynamicKey = $v['agency_service_id'] . "_" . $v['publisher_id'];
			
			//if service exits two time
			if(isset($finalArry['data'][$valinvoiceid]['serviceArray'][$dynamicKey])){
			    $tempCalculation = $finalArry['data'][$valinvoiceid]['serviceArray'][$dynamicKey];
			}else{
			    $tempCalculation = 0;
			}
			
			$finalArry['data'][$valinvoiceid]['serviceArray'][$dynamicKey] = $tempCalculation + $v['service_amount'];
			$aglCharges = $v['agency_charges'] + $aglCharges;
			
			//echo $v['publisher_id']."<br/>";
			if(isset($v['publisher_id'])){
			    
			}else{
			   $serviceAmount = $v['service_amount'] + $serviceAmount;  
			}

			if (empty($finalArry['total']['serviceTotal'][$dynamicKey])) {
			    $finalArry['total']['serviceTotal'][$dynamicKey] = 0;
			}
			$finalArry['total']['serviceTotal'][$dynamicKey] = $finalArry['total']['serviceTotal'][$dynamicKey] + $v['service_amount'];
		    }
		    
		    $finalArry['data'][$valinvoiceid]['aglCharges'] = $aglCharges;
		    
		    $finalArry['data'][$valinvoiceid]['aglChargesOther'] = $serviceAmount + $aglCharges;
		    
		    $totalAglCharges = $totalAglCharges + $aglCharges;
		}
	    }

	    $finalArry['total']['totalPendingAmount'] = $totalPendingAmount;
	    $finalArry['total']['totalServiceAmount'] = $totalServiceAmount;
	    $finalArry['total']['totalAmount'] = $totalAmount;
	    $finalArry['total']['totalTds'] = $totalTds;
	    $finalArry['total']['totalAmountReceived'] = $totalAmountReceived - $totalTds;
	    $finalArry['total']['totalAglCharges'] = $totalAglCharges;
	    $finalArry['total']['totalThirtyPendingAmount'] = $totalThirtyPendingAmount;
	    $finalArry['total']['totalSixtyPendingAmount'] = $totalSixtyPendingAmount;
	    $finalArry['total']['totalNintyPendingAmount'] = $totalNintyPendingAmount;
	    $finalArry['total']['totalMoreNintyPendingAmount'] = $totalMoreNintyPendingAmount;
	}

	if (empty($invoiceIdArray)) {
	    $finalArry = array();
	}

	$csv_output = '';
	$csv_output .= "Id\t";
	$csv_output .= "Group Head\t";
	$csv_output .= "Region Name\t";
	$csv_output .= "Invoice Owner\t";

	foreach ($headerAccountOwner as $khead => $head) {
	    $csv_output .= '"' . $head . '"' . "\t";
	}

	$csv_output .= "Payment Status\t";
	$csv_output .= "Client Type\t";
	$csv_output .= "Date\t";
	$csv_output .= "Invoice Number\t";
	$csv_output .= "Status\t";
	$csv_output .= "Client Name\t";


	foreach ($headerInvoiceServices as $k => $h) {
	    $csv_output .= '"' . $h . '"' . "\t";
	}
	$csv_output .= "Agl Charges\t";
	$csv_output .= "Service Tax\t";
	$csv_output .= "Agl Charges Other\t";
	$csv_output .= "Total\t";
	$csv_output .= "TDS\t";
	$csv_output .= "Amount Received\t";
	$csv_output .= "Desc\t";
	$csv_output .= "Date Of Clearing\t";
	$csv_output .= "Pending Amount\t";
	$csv_output .= "0-30\t";
	$csv_output .= "31-60\t";
	$csv_output .= "61-90\t";
	$csv_output .= ">90\t";

	$csv_output .= "\n";

	foreach ($finalArry['data'] as $k => $idetail) {
	    $csv_output .= '"' . $idetail['id'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['groupHead'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['regionName'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['invoiceOwner'] . '"' . "\t";
	    foreach ($headerAccountOwner as $khead => $head) {
		if (isset($idetail['accountOwner'][$khead])) {
		    $csv_output .= '"' . $idetail['accountOwner'][$khead] . '"' . "\t";
		} else {
		    $csv_output .= '""' . "\t";
		}
	    }

	    $csv_output .= '"' . $idetail['paymentStatus'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['clientType'] . '"' . "\t";
	    $csv_output .= '"' . date("jS-M-Y", strtotime($idetail['invoiceDate'])) . '"' . "\t";
	    $csv_output .= '"' . $idetail['invoiceNumber'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['invoiceType'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['clientName'] . '"' . "\t";

	    foreach ($headerInvoiceServices as $kk => $serv) {
		if (isset($idetail['serviceArray'][$kk])) {
		    $csv_output .= '"' . $idetail['serviceArray'][$kk] . '"' . "\t";
		} else {
		    $csv_output .= '""' . "\t";
		}
	    }
	    $csv_output .= '"' . $idetail['aglCharges'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['serviceTax'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['aglChargesOther'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['amount'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['tds'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['amountReceived'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['paymentDescription'] . '"' . "\t";
	    $csv_output .= '"' . date("jS-M-Y", strtotime($idetail['dateOfClearing'])) . '"' . "\t";
	    $csv_output .= '"' . $idetail['pendingAmount'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['zeroToThirty'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['thirtyToSixty'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['sixtyToNinety'] . '"' . "\t";
	    $csv_output .= '"' . $idetail['moreNinety'] . '"' . "\t";
	    $csv_output .= "\n";
	}


	$file = 'invoice_report_';
	$filename = $file . "_" . date("Y-m-d_H-i", time());
	header("Content-type: application/vnd.ms-excel");
	header("Content-disposition: xls" . date("Y-m-d") . ".xls");
	header("Content-disposition: filename=" . $filename . ".xls");
	print $csv_output;

	die();
    }

}

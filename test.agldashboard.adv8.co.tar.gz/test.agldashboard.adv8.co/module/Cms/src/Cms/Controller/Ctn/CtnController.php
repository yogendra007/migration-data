<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zdend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Cms\Controller\Ctn;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Services\Model\Campaigns\Campaigns;
use Services\Model\Campaigns\ClientAudiCampaigns;
use Services\Model\Clients\Client;
use Services\Model\Users;
use Services\Model\ClientBusinessUnit;
use Services\Model\ClientBusinessUnitPublisher;
use Services\Model\Webforms\ClientLandingPage;
use Services\Model\Webforms\CampaignWebforms;
use Services\Model\Webforms\ClientLandingPageWebform;
use Services\Model\Webforms\InfoLeadStatus;
use Services\Model\ClientLandingPageCtn;

class CtnController extends AbstractActionController
{
	public $_view;
	public $_ObjClientAudiCampaigns;
    public $_ObjClient;
    public $_ObjCampaignWebforms;
    public $_ObjClientPublisher;
	public $_ObjClientLandingPage;
	public $_ObjClientLandingPageWebform;
	public $_ObjUsers;
	public $_ns;
	public $_agencyId;
	public $_ObjInfoLeadStatus;
    public $_ObjClientBusinessUnit;
	function __construct(){
		$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
		$this->_view=new ViewModel();
		$this->_ObjClientAudiCampaigns = new ClientAudiCampaigns($adapter);
		$this->_ObjClient= new Client($adapter);
		$this->_ObjClientPublisher= new ClientBusinessUnitPublisher($adapter);
        $this->_ObjClientBusinessUnit = new ClientBusinessUnit($adapter);
        $this->_ObjClientLandingPage = new ClientLandingPage($adapter);
        $this->_ObjClientLandingPageWebform = new ClientLandingPageWebform($adapter);
        $this->_ObjCampaignWebforms = new CampaignWebforms($adapter);
		$this->_ObjInfoLeadStatus = new InfoLeadStatus($adapter);
		$this->_ObjClientLandingPageCtn = new ClientLandingPageCtn($adapter);
		$this->_ObjUsers= new Users($adapter);
		
		$this->_ns = new Container('Adv8360');
		$this->_agencyId=trim($this->_ns->Adv8Agencyid);
	}

    public function indexAction()
    {	
	   $clientId = $_REQUEST['cId'];
	   if(empty($clientId)){
       $clientId = $this->_ns->Adv8Clientid;
	   }
	   
	   $Adv8Roleid = $this->_ns->Adv8Roleid;
	   $clientData = $this->_ObjClient->getClientList($agencyId);
       $this->_view->clientData = $clientData;
	   $this->_view->Adv8Roleid = $Adv8Roleid; 
	   $this->_view->Adv8Clientid = $clientId;
	   $this->_view->timeZones = $this->getTimezones(); 
	   return $this->_view;
    }

	public function listCtnAction(){
		$cId = $this->Xssplugin()->escape($this->getRequest()->getPost('cId'));
		if(empty($cId)){
			$cId = $this->_ns->Adv8Clientid;
		}
		$fields = array('*');
		$where = array('client_id'=>$cId , 'status'=>'1');
		$ctnList = $this->_ObjClientLandingPageCtn->getDetail($fields,$where);
		if(empty($ctnList)){
			$html = '<tr class="odd gradeX"  align="center"><td colspan="3">No Record Found</td></tr>';
		}else{
			$html= "";
			foreach($ctnList as $cList){
			
				$fieldsWb = array('*');
				$whereWb = array('id'=>$cList['webform_id']);
				$wb_result = $this->_ObjClientLandingPageWebform->getWbNm($fieldsWb,$whereWb);
				
				$html .= '<tr class="odd gradeX" id="tr_'.$cList['id'].'">
						<td class="center">'.$cList['call_tracking_number'].'</td>
						<td class="center">'.$wb_result[0]['web_form_name'].'</td>';
						if(!empty($cList['call_tracking_widget'])) { 
							$html .= '<td class="center"><textarea name="widget" style="width: 487px; height: 104px;" >'.base64_decode($cList['call_tracking_widget']).'</textarea></td>';
							
						}else{
							$html .= '<td class="center"></td>';
						}						
						$html .= '<td class="center">
							<a href="javascript:void(0);" class="btn btn-default btn-sm btn-icon1 icon-left1 globalBtn editCtn" data-toggle="tooltip" data-placement="top" onclick="return editCtn('.$cList['id'].');" title="Edit"><i class="entypo-pencil"></i></a>
							<a href="javascript:void(0);" data-id="" onclick="delCtn('.$cList['id'].');" class="btn btn-danger btn-sm btn-icon1 icon-left1 delete_ctn" data-toggle="tooltip" data-placement="top" title="Delete"><i class="entypo-cancel"></i></a>
						</td>
					</tr>';
			}
		}
		echo $html;
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function getBuAction(){
		$cId = $this->Xssplugin()->escape($this->getRequest()->getPost('cId'));
		$cresult = $this->_ObjClientBusinessUnit->getCampaignsList($cId);
		$result['error'] = 0;
		$result['ctnBu'] = $cresult;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function getLpAction(){
		$buId = $this->Xssplugin()->escape($this->getRequest()->getPost('buId'));
		$bresult = $this->_ObjClientLandingPage->getLpList($buId);
		$result['error'] = 0;
		$result['ctnLp'] = $bresult;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function getWbAction(){
		$buId = $this->Xssplugin()->escape($this->getRequest()->getPost('buId'));
		$cId = $this->Xssplugin()->escape($this->getRequest()->getPost('cId'));
		$lpId = $this->Xssplugin()->escape($this->getRequest()->getPost('lpId'));
		$fields=array('*');
		$where=array('client_id'=>$cId , 'business_unit_id'=>$buId , 'landing_page_id'=>$lpId);
		$wbData = $this->_ObjClientLandingPageWebform->listWbs($fields,$where);
		$result['error'] = 0;
		$result['ctnWb'] = $wbData;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function saveCtnAction(){
	//echo "l";exit;
		$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
		/*if(empty($clientId)){
			$clientId = $this->_ns->Adv8Clientid;
		}*/
		$ctnId = $this->Xssplugin()->escape($this->getRequest()->getPost('ctnId'));
		$ctnNum = $this->Xssplugin()->escape($this->getRequest()->getPost('ctnNum'));
		$ctnBu = $this->Xssplugin()->escape($this->getRequest()->getPost('ctnBu'));
		$ctnLp = $this->Xssplugin()->escape($this->getRequest()->getPost('ctnLp'));
		$ctnWb = $this->Xssplugin()->escape($this->getRequest()->getPost('ctnWb'));
		$fwd_num = $this->Xssplugin()->escape($this->getRequest()->getPost('fwd_num'));
		$dply_num = $this->Xssplugin()->escape($this->getRequest()->getPost('dply_num'));
		$email_alert = $this->Xssplugin()->escape($this->getRequest()->getPost('email_alert'));
		$sms_alert = $this->Xssplugin()->escape($this->getRequest()->getPost('sms_alert'));
		$alert_email_id = $this->Xssplugin()->escape($this->getRequest()->getPost('alert_email_id'));
		$alert_sms_number = $this->Xssplugin()->escape($this->getRequest()->getPost('alert_sms_number'));
		$service_from = $this->Xssplugin()->escape($this->getRequest()->getPost('service_from'));
		$service_to = $this->Xssplugin()->escape($this->getRequest()->getPost('service_to'));
		$enbl_trckng = $this->Xssplugin()->escape($this->getRequest()->getPost('enbl_trckng'));
		$timeZoneId = $this->Xssplugin()->escape($this->getRequest()->getPost('time_zone'));
		
		$url = 'http://115.112.58.97/api/insert_update_forwarding.php';

		$curlData = array (
			'call_tracking_number' => $ctnNum,
			'forwading_no' => $fwd_num,
			'display_no' => $dply_num,
			'calltracking_startdate' => $service_from,
			'calltracking_expirydate' => $service_to,
			'alert_email_id' => $alert_email_id,
			'alert_mobile_no' => $alert_sms_number,
			'email_alert'	=>$email_alert,
			'sms_alert'=>$sms_alert,
			'call_timezone' => $this->getTimeZoneById($timeZoneId),
			'status' => 1,
			'calltracking_status' => $enbl_trckng
			//'call_order_id' =>
			//'call_tracking_package' =>
			//'call_tracking_package_value' =>
			//'total_call_tracking_minutes' =>
			//'modified_by' =>
		);

		$key = '8574154263589145';
		$value = $ctnWb;
		$encid = $key . '-' . $value;
		$encid = base64_encode($encid);

		$calltrackscript = '';
		$calltrackscript .= '<script type="text/javascript"> ';
		$calltrackscript .= 'var domain = window.location.host; ';
		$calltrackscript .= 'var wid = "' . $encid . '"; ';
		$calltrackscript .= "document.write('<scr'+'ipt type=";
		$calltrackscript .= '"text/JavaScript" src="http://agldashboard.adv8.co/ctn/getCallTrackNo?domain=';
		$calltrackscript .= "' + domain + '&wid=' + wid +'";
		$calltrackscript .= '"><';
		$calltrackscript .= "' + '/scr' + 'ipt>');";
		$calltrackscript .= '</script>';
		$script = base64_encode($calltrackscript);
		
		if(empty($ctnId)){
		
			
			
		
			$dataArr = array('client_id'=>$clientId,'business_unit_id'=>$ctnBu,'lp_id'=>$ctnLp,'webform_id'=>$ctnWb,'call_tracking_number'=>$ctnNum,'forwarding_number'=>$fwd_num,'display_number'=>$dply_num,'timezone'=>$timeZoneId,'email_alert'=>$email_alert,'sms_alert'=>$sms_alert,'alert_email_id'=>$alert_email_id,'alert_sms_number'=>$alert_sms_number,'status'=>'1','service_from'=>$service_from,'service_to'=>$service_to,'enable_tracking'=>$enbl_trckng, "call_tracking_widget"=>$script);


			$curlData['isNew'] = 1;
			
			
			$url .= '?' .http_build_query($curlData);
			$result = json_decode(file_get_contents($url), true);
			if($result['response_status'] === 'success') {
				$saveData = $this->_ObjClientLandingPageCtn->saveDataCtn($dataArr);
				$msg = 'saved';
			} else {
				if(isset($result['response_message'])) {
					$msg = 'Contact to admin : ' . $result['response_message'] . ' Response Code : ' . $result['response_code']; 
				} else {
					$msg = 'unsaved';
				}
				
			}
			
			/*$this->_view->setTemplate('/cms/ctn/index?msg='$msg);
			return $this->_view;
			exit;*/
			echo $msg; die;
			
		}else{
		

			$fields = array('call_tracking_number'=>$ctnNum,'forwarding_number'=>$fwd_num,'display_number'=>$dply_num,'timezone'=>$timeZoneId,'email_alert'=>$email_alert,'sms_alert'=>$sms_alert,'alert_email_id'=>$alert_email_id,'alert_sms_number'=>$alert_sms_number,'status'=>'1','service_from'=>$service_from,'service_to'=>$service_to,'enable_tracking'=>$enbl_trckng, 'timezone' => $timeZoneId, "call_tracking_widget"=>$script);
			$where = array('id'=>$ctnId);

			$curlData['isNew'] = 0;
			
			$url .= '?' .http_build_query($curlData);
			$result = json_decode(file_get_contents($url), true);
			
			$result['response_status'] = 'success';
			
			if($result['response_status'] === 'success') {
				$updateData = $this->_ObjClientLandingPageCtn->updateCtn($fields,$where);
				$msg = 'updated';
				/*$this->_view->setTemplate('/cms/ctn/index?msg='$msg);
				return $this->_view;
				exit;*/
			} else {
				if(isset($result['response_message'])) {
					$msg = 'Contact to admin : ' . $result['response_message'] . ' Response Code : ' . $result['response_code']; 
				} else {
					$msg = 'not updated!';
				}				
			}

			
			echo $msg; die;
		}
		
	}
	
	public function editCtnAction(){
		$ctnId = $this->Xssplugin()->escape($this->getRequest()->getPost('ctnId'));
		$where=array('id'=>$ctnId);
		$fields=array('*');
		$ctnData = $this->_ObjClientLandingPageCtn->editCtn($fields,$where);
		$cId = $ctnData[0]['client_id'];
		$cresult = $this->_ObjClientBusinessUnit->getCampaignsList($cId);
		$buId = $ctnData[0]['business_unit_id'];
		$lpId = $ctnData[0]['lp_id'];
		$bresult = $this->_ObjClientLandingPage->getLpList($buId);
		
		$fieldss = array('web_form_name', 'id');
		$wheree = array('landing_page_id' => $ctnData[0]['lp_id']);
		$wresult = $this->_ObjClientLandingPageWebform->listWbs($fieldss,$wheree);
		
		$result['error'] = 0;
		$result['ctnId'] = $ctnData[0]['id'];
		$result['ctnNum'] = $ctnData[0]['call_tracking_number'];
		$result['fwd_num'] = $ctnData[0]['forwarding_number'];
		$result['dply_num'] = $ctnData[0]['display_number'];
		$result['eml_alrt'] = $ctnData[0]['email_alert'];
		$result['sms_alrt'] = $ctnData[0]['sms_alert'];
		$result['time_zone'] = $ctnData[0]['timezone'];
		$result['alert_email_id'] = $ctnData[0]['alert_email_id'];
		$result['alert_sms_number'] = $ctnData[0]['alert_sms_number'];
		$result['serv_frm'] = date('Y-m-d', strtotime($ctnData[0]['service_from']));
		$result['serv_to'] = date('Y-m-d', strtotime($ctnData[0]['service_to']));
		$result['enbl_trckng'] = $ctnData[0]['enable_tracking'];
		$result['bId'] = $buId;
		$result['lId'] = $lpId;
		$result['data_ctn'] = $ctnData[0];
		$result['ctnBu'] = $cresult;
		$result['ctnLp'] = $bresult;
		$result['ctnWf'] = $wresult;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}
	
	public function delCtnAction(){
		$ctnId = $this->Xssplugin()->escape($this->getRequest()->getPost('ctnId'));
		$fields = array('status'=>'0');
		$where = array('id'=>$ctnId);
		$delstatusData = $this->_ObjClientLandingPageCtn->delCtn($fields,$where);
		$result['error'] = 0;
		$result['ctnId'] = $ctnId;
		echo json_encode($result);
		$this->_view->setTerminal(true);
        exit;
	}

	public function getTimeZoneById($id) {
		$timezoneArray = $this->getTimezones();
		return isset($timezoneArray[$id]) ? $timezoneArray[$id] : $timezoneArray[1];		
	}
	
	public function getCallTrackNoAction(){
		$wid = $_REQUEST['wid'];
		$domain = $_REQUEST['domain'];
		$key = '8574154263589145';
		
		$wid = base64_decode($wid);
		$wid = explode("-", $wid);

		if ($wid[0] == $key) {
			$wid = trim($wid[1]);
		}

		$fields = array('*');
		$where = array('webform_id'=>$wid , 'status'=>'1', 'enable_tracking'=>'1');
		$response = $this->_ObjClientLandingPageCtn->getDetail($fields,$where);
		
		if (!empty($response)) {
			$exp_date = $response[0]['service_to'];
			
			$todays_date = date("Y-m-d");

			$today = strtotime($todays_date);
			$expiration_date = strtotime($exp_date);

			$formElements = "";

			$js1 = "";
			$js1 .= "<script type=";
			$js1 .= '"text/JavaScript" src="http://agldashboard.adv8.co/public/js/keywordtracking_iadv8.js"></script>';

			$html = '<input type="hidden" id="trackingnumber" value="' . $response[0]['call_tracking_number'] . '" />';
			$html1 = '<input type="hidden" id="ipaddress" value="" />';

			$formElements = $js1 . $html . $html1;
			if ($expiration_date > $today) {
				echo "document.write('" . $formElements . $response[0]['display_number'] . "');";
			} else {
				echo "document.write('" . $formElements . $response[0]['forwarding_number'] . "');";
			}
			
		}else{
			echo "document.write('Weak signal strength ....');";	
				
		}
        exit;
	}
	
	
	
	public function getTimezones() {
		return array (
			'1' => 'IST',
			'2' => 'SST',
			'3' => 'EST',
			'4' => 'ART',
			'5' => 'CLT'
		);
	}

}
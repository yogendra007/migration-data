<?php namespace Application\Controller\Shoppingfeeds;
use Zend\Session\Container;
use Zend\View\Model\ViewModel;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController;
class FeedController extends AbstractActionController {
    function __construct() {
		$this->_view=new ViewModel();
		$adapter = new DbAdapter(unserialize(SHOPPING_AD_ARRAY));
		$this->_db = $adapter;
		$this->_ns = new Container('Adv8360');
				
    }
	function quickAction(){
		$statement=$this->_db->query("select count(*) as hits,request_date,client_id  from `v2_feed_log` where
		 client_id='".trim($this->_ns->Adv8Clientid)."'  group by date_format(`request_date`,'%Y-%m-%d') order by id DESC limit 10");
		$res = $statement->execute();
		$resArray=array();
		foreach($res as $row){
			$resArray[]=$row;
		}
		$this->_view->resArray=$resArray;
		
		return $this->_view;
		
	}
	function indexAction(){
	$statement=$this->_db->query("SELECT `id`, 
	`client_id`, 
	`merchant_id`, 
	`filter_feed_count`, 
	`error_feed_count`, 
	`all_feed_count`, 
	`diagnostic_count`, 
	`diagnostic_policy_violation_count`, 
	`feed_upload_date`
	FROM 	`v1_feed_log`  WHERE	client_id='".trim($this->_ns->Adv8Clientid)."' ORDER BY `feed_upload_date` DESC ");
		
		$res = $statement->execute();
		$this->_view->logs=$res;
		$resArray=array();
		
		foreach($res as $row){
			$resArray[]=$row;
		}
		$this->_view->resArray=$resArray;
		
		return $this->_view;
	}
	function fullfeedAction(){
	error_reporting(E_ALL);
	ini_set('display_errors', '1');
	$cid=trim($this->getRequest()->getQuery('cid'));
	$cdate=trim($this->getRequest()->getQuery('cdate'));
	 $getFile="SELECT `file_name` FROM `single_feed_log` WHERE DATE_FORMAT(`uploaded_date`,'%Y-%m-%d')='".date('Y-m-d',strtotime($cdate))."' 
	 && client_id='".trim($cid)."'  limit 1";
	$statement=$this->_db->query($getFile);
	$res = $statement->execute();
	$file_name="";
	foreach($res as $row){
		$file_name=$row['file_name'];
	}
	if($file_name=="") {
	echo "Error: Feed not downloaded";	
	}else{
	$file_name="DataFeed_".date('Y-m-d',strtotime($cdate))."_org_".$cid.".txt";
	$file="public/feed/".trim($file_name);	
	$name='Full_Data_Feed_'.date('Y-m-d',strtotime($cdate)).'.txt';	
	$this->output_file($file,$name,'');
	}
		die();
	}
	function errorfeedAction(){
	//error_reporting(E_ALL);
	//ini_set('display_errors', '1');
	$field=array('client_id','created_date','json_feed_data');
	$cid=trim($this->getRequest()->getQuery('cid'));
	$cdate=trim($this->getRequest()->getQuery('cdate'));
		$error_st=$this->_db->query("SELECT json_feed_data	FROM 	`feed_data_error`  WHERE DATE_FORMAT(`created_date`,'%Y-%m-%d')='".date('Y-m-d',strtotime($cdate))."' && client_id='".trim($cid)."'  limit 1	");
		$res = $error_st->execute();
		$error_head=array();
		foreach($res as $row){
		$head=(array)json_decode(trim($row['json_feed_data']));
		
		$error_head=array_keys($head);
	   }
	$sql_f=implode(",",$field);
		$this->pro("SELECT 
		json_feed_data
	FROM 	`feed_data_error`  WHERE DATE_FORMAT(`created_date`,'%Y-%m-%d')='".date('Y-m-d',strtotime($cdate))."' 
	 && client_id='".trim($cid)."'",$error_head);
			
		die();
	}
	function filterfeedAction(){
	$cdate=trim($this->getRequest()->getQuery('cdate'));
	$cid=trim($this->getRequest()->getQuery('cid'));
	 $getFile="SELECT `file_name` FROM `single_feed_log` WHERE DATE_FORMAT(`uploaded_date`,'%Y-%m-%d')='".date('Y-m-d',strtotime($cdate))."' && client_id='".trim($cid)."' limit 1";
	$statement=$this->_db->query($getFile);
	$res = $statement->execute();
	$file_name="";
	foreach($res as $row){
		$file_name=$row['file_name'];
	}
	if($file_name=="") {
	echo "Error: Feed not downloaded";	
	}else{
	$file="public/feed/".trim($file_name);	
	$name='Filtered_Data_Feed_'.date('Y-m-d',strtotime($cdate)).'.txt';	
	$this->output_file($file,$name,'');
	}
		
		die();
	}
	function quickfeedAction(){
  $field=array('request_date','request','response');
	$cid=trim($this->getRequest()->getQuery('cid'));
	$cdate=trim($this->getRequest()->getQuery('cdate'));
		$error_st=$this->_db->query("SELECT json_feed_data	FROM 	`feed_data_error`  WHERE DATE_FORMAT(`created_date`,'%Y-%m-%d')='".date('Y-m-d',strtotime($cdate))."' && client_id='".trim($cid)."'  limit 1	");
		$res = $error_st->execute();
		$error_head=array();
		foreach($res as $row){
		$head=(array)json_decode(trim($row['json_feed_data']));
		
		$error_head=array_keys($head);
	   }
	$sql_f=implode(",",$field);
	 $select="SELECT `request_date`,`request`,`response` FROM 
	 `v2_feed_log`  WHERE DATE_FORMAT(`request_date`,'%Y-%m-%d')='".date('Y-m-d',strtotime($cdate))."' && client_id='".trim($cid)."'";
	
	$data="";
	$line = '';
	$statement=$this->_db->query($select);
	$res = $statement->execute();
	$resArray=array();
	$header= implode('	',$field);
	foreach($res as $row){
		//$row=(array)json_decode(trim($row['request_date']));
		$line= implode('	',$row);
		$data .= trim( $line ) . "\n";		
	}   
	$data=trim($data);
	//$data = str_replace( "\r" , "" , $data );
	if ( $data == "" )
	{
		$data = "\n(0) Records Found!\n";                        
	}
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=quick_Date_Feed.xls");
	header("Pragma: no-cache");
	header("Expires: 0");
	print "$header\n$data";
	die();
}


function pro($select,$field){
//$export = mysql_query ( $select ) or die ( "Sql error : " . mysql_error( ) );
//$fields = mysql_num_fields ( $export );

/*for ( $i = 0; $i < $fields; $i++ )
{
    $header .= mysql_field_name( $export , $i ) . "\t";
}
*/
$data="";
$line = '';
	$statement=$this->_db->query($select);
	$res = $statement->execute();
	$resArray=array();
	$header= implode('	',$field);
	foreach($res as $row){
		$row=(array)json_decode(trim($row['json_feed_data']));
		$line= implode('	',$row);
		$data .= trim( $line ) . "\n";
		
	}
    

$data = str_replace( "\r" , "" , $data );


if ( $data == "" )
{
    $data = "\n(0) Records Found!\n";                        
}

header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=Error_Date_Feed.xls");
header("Pragma: no-cache");
header("Expires: 0");
print "$header\n$data";
//print "$data";
	
}
	
function output_file($file, $name, $mime_type='')
{
 if(!is_readable($file)) die('File not found or inaccessible!');
 $size = filesize($file);
 $name = rawurldecode($name);
 $known_mime_types=array(
    "htm" => "text/html",
    "exe" => "application/octet-stream",
    "zip" => "application/zip",
    "doc" => "application/msword",
    "jpg" => "image/jpg",
    "php" => "text/plain",
    "xls" => "application/vnd.ms-excel",
    "ppt" => "application/vnd.ms-powerpoint",
    "gif" => "image/gif",
    "pdf" => "application/pdf",
    "txt" => "text/plain",
    "html"=> "text/html",
    "png" => "image/png",
    "jpeg"=> "image/jpg"
 );
 
 if($mime_type==''){
     $file_extension = strtolower(substr(strrchr($file,"."),1));
     if(array_key_exists($file_extension, $known_mime_types)){
        $mime_type=$known_mime_types[$file_extension];
     } else {
        $mime_type="application/force-download";
     };
 };
 
 //turn off output buffering to decrease cpu usage
 @ob_end_clean(); 
 
 // required for IE, otherwise Content-Disposition may be ignored
 if(ini_get('zlib.output_compression'))
 ini_set('zlib.output_compression', 'Off');
 header('Content-Type: ' . $mime_type);
 header('Content-Disposition: attachment; filename="'.$name.'"');
 header("Content-Transfer-Encoding: binary");
 header('Accept-Ranges: bytes');
 
 // multipart-download and download resuming support
 if(isset($_SERVER['HTTP_RANGE']))
 {
    list($a, $range) = explode("=",$_SERVER['HTTP_RANGE'],2);
    list($range) = explode(",",$range,2);
    list($range, $range_end) = explode("-", $range);
    $range=intval($range);
    if(!$range_end) {
        $range_end=$size-1;
    } else {
        $range_end=intval($range_end);
    }

    $new_length = $range_end-$range+1;
    header("HTTP/1.1 206 Partial Content");
    header("Content-Length: $new_length");
    header("Content-Range: bytes $range-$range_end/$size");
 } else {
    $new_length=$size;
    header("Content-Length: ".$size);
 }
 
 /* Will output the file itself */
 $chunksize = 1*(1024*1024); //you may want to change this
 $bytes_send = 0;
 if ($file = fopen($file, 'r'))
 {
    if(isset($_SERVER['HTTP_RANGE']))
    fseek($file, $range);
 
    while(!feof($file) && 
        (!connection_aborted()) && 
        ($bytes_send<$new_length)
          )
    {
        $buffer = fread($file, $chunksize);
        echo($buffer); 
        flush();
        $bytes_send += strlen($buffer);
    }
 fclose($file);
 } else
 //If no permissiion
 die('Error - can not open file.');
 //die
die();
}
}


<?php

namespace Application\Controller\Oauth;

use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Services\Model\Oauth\OauthClientGcidMapping;
use Services\Model\ClientBusinessUnit;
use Services\Model\ClientBusinessUnitPublisher;
use Services\Model\Analytics\AnalyticsProperty;
use Services\Model\ClientBusinessUnitAnalyticsMapping;

class indexController extends AbstractActionController {

    public $_view;
    protected $_ns;
    private $_ObjAclPrivilege;
    private $_ObjBusinessUnit;
    private $_ObjBusinessUnitPublisher;
    private $_ObjAnalyticsProperty;
    private $_ObjClientBusinessUnitAnalyticsMapping;

    function __construct() {

	$this->_ns = new Container('Adv8360');
	$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
	$this->_view = new ViewModel();
	$this->_ObjOauthMapping = new OauthClientGcidMapping($adapter);
	$this->_ObjBusinessUnit = new ClientBusinessUnit($adapter);
	$this->_ObjBusinessUnitPublisher = new ClientBusinessUnitPublisher($adapter);
	$this->_ObjAnalyticsProperty = new AnalyticsProperty($adapter);
	$this->_ObjClientBusinessUnitAnalyticsMapping = new ClientBusinessUnitAnalyticsMapping($adapter);
	$this->_view->setTerminal(true);
    }

    public function decode($value, $skey) {
	if (!$value) {
	    return false;
	}
	$value = $value . '-' . $skey;
	$crypttext = base64_decode($value);
	return trim($crypttext);
    }

    public function indexAction() {
	$error = false;
	$errorMsg  = ""; 
	$skey = "SuPerEncKey2010";
	$gcidArray = array();
	$encodedTableId = $this->Xssplugin()->escape($this->getRequest()->getQuery('t'));
	
	$encodedClientId = $this->Xssplugin()->escape($this->getRequest()->getQuery('c'));
	$encodedGcidId = $this->Xssplugin()->escape($this->getRequest()->getQuery('g'));

	$decodeTableId = $this->decode($encodedTableId, $skey);
	$decodeTableIdarr = explode("-", $decodeTableId);
	$tableId = $decodeTableIdarr[0];
	
	$decodeClientId = $this->decode($encodedClientId, $skey);
	$decodeTableIdarr = explode("-", $decodeClientId);
	
	$cId = $decodeTableIdarr[0];
	
	$decodeGcidId = $this->decode($encodedGcidId, $skey);
	$decodeTableIdarr = explode("-", $decodeGcidId);
	$gcId = $decodeTableIdarr[0];
	
	$pId = 1;
	
	$params['clientId'] = $cId;
	$params['publisherId'] = $pId;
	$netRess = $this->_ObjBusinessUnit->getCampaignUnitsMapping($params);

	if (empty($netRess)) {
	    $url = "http://adwordsv1502.aglkuber.in/examples/AdWords/v201502/AccountManagement/GetAccountHierarchy.php?gcid=" . $gcId . "&cid=" . $cId;

	    $jsongcids = file_get_contents($url);
	    $gcidArray = json_decode($jsongcids, true);

	    /*$params['tableId'] = $tableId;
	    $detailArray = $this->_ObjOauthMapping->getData($params);
	    if (!empty($detailArray)) {
		foreach ($detailArray as $k => $v) {
		    $clientId = $v['agency_client_id'];
		    $gcidArray[] = $v['gcid'];
		}
	    }*/

	    //$this->layout('layout/singleuser');
	   $error = false; 
	   
	}else{
	    $error = true;
	    $errorMsg  = "Link has been expired"; 
	}
	 $this->_view->gcidArray = $gcidArray;
	 $this->_view->clientId = $cId;
	 $this->_view->error = $error;
	 $this->_view->errorMsg = $errorMsg;
	 return $this->_view;
	    
    }

    public function mapGcidsAction() {
	
	$gcidstr = '';
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));

	$fromDate = date("Y-m-d");
	$toDate = date("Y-m-d", strtotime("+30 day"));

	$sendData['companyName'] = $clientId;
	$sendData['publisher'][0] = "google";
	$sendData['googleDate'] = $fromDate . ',' . $toDate;
	$sendData['mapped_flag'] = "1";
	
	if (!empty($_POST['gcids'])) {
	    $gcidstr = implode(",", $_POST['gcids']);
	    foreach ($_POST['gcids'] as $k => $v) {
		$sendData['businessUnit'] = "Campaign-" . $v;
		$sendData['google'] = $v;
		$res = $this->_ObjBusinessUnit->add($sendData);
	    }
	    $msg = 'AdWords account mapped successfully. You can see the last 7 days data in our App(Insight) after 1 hour.';
	} else {
	    $msg = 'No gcids mapped';
	}

	$this->_view->msg = $msg;
	$this->_view->gcidstr = $gcidstr;
	return $this->_view;
    }

    public function analyticsAction() {
	$error  = false;; 
	$errorMsg = '';
	$skey = "SuPerEncKey2010";
	$gcidArray = array();
	$encodedTableId = $this->Xssplugin()->escape($this->getRequest()->getQuery('t'));

	$decodeTableId = $this->decode($encodedTableId, $skey);
	$decodeTableIdarr = explode("-", $decodeTableId);
	$clientId = $decodeTableIdarr[0];

	$params = array();
	$params['clientId'] = $clientId;
	$netRess = $this->_ObjBusinessUnit->getCampaignUnitsAnalyticsMapping($params);

	if (empty($netRess)) {	    
	    $detailArray = $this->_ObjAnalyticsProperty->getwebsiteUrl($clientId);

	    if (!empty($detailArray)) {
		foreach ($detailArray as $k => $v) {
		    $clientId = $v['client_id'];
		    $pArray[$v['view_Profile_id']] = $v['websiteUrl'];
		}
	    }
	}else{
	   $error  = true; 
	   $errorMsg  = "Link has been expired"; 
	}
	
	//$this->layout('layout/singleuser');
	$this->_view->pArray = $pArray;
	$this->_view->clientId = $clientId;
	$this->_view->error = $error;
	$this->_view->errorMsg = $errorMsg;
	return $this->_view;
    }

    public function mapAccountsAction() { //analytics
	$error = false;
	$accountStr = '';
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));

	$fromDate = date("Y-m-d");
	$toDate = date("Y-m-d", strtotime("+30 day"));
	
	if (!empty($_POST['accountids'])) {
	    foreach ($_POST['accountids'] as $k => $v) {
		$campaignUnit = "Campaign-" . $v;
		$accountStr .= $accountStr;
		$dataArrayFirst = array('client_id' => $clientId, 'business_unit_name' => $campaignUnit);
		$businessUnitId = $this->_ObjBusinessUnit->createBusinessUnit($dataArrayFirst);
		$googleProfileId = $v;
		$analyticsData = $this->_ObjAnalyticsProperty->getwebsiteUrl($clientId, $googleProfileId);
	
		if (!empty($analyticsData)) {
		    $dataArraySecond = array('client_id' => $clientId, 'business_unit_id' => $businessUnitId, 'account_id' => $analyticsData[0]['account_id'], 'profile_id' => $v, 'domain_name' => $analyticsData[0]['websiteUrl'], 'service_from' => $fromDate, 'service_to' => $toDate, 'status' => '1');

		    $res = $this->_ObjClientBusinessUnitAnalyticsMapping->add($dataArraySecond);
		    $msg = 'Google Analytics account mapped successfully. You can see the last 7 days data in our App(Insight) in next 10 minutes partially, for full data it will take up to 1 - 2  hours.';
		} else {
		    $error = true;
		    $msg = 'No profileId found';
		}
	    }
	    
	} else {
	    $msg = 'No domain mapped';
	}
	$this->_view->msg = $msg;
	$this->_view->accountStr = $accountStr;
	$this->_view->error = $error;
	return $this->_view;
    }
}
<?php Namespace Services\Model\Webforms;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class InfoLeadStatus{
	protected $_db;
	protected $_table;
	protected $_adapter;
	public $_ObjCmnfunctions;

	function __construct($adapter) {
		
		$this->_table='adv8_info_lead_status';
		$this->_db= $adapter;
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		$this->_sql = new Sql($adapter);

	}
	public function getDetail($fields,$where){ 
		return $objreturn = $this->_ObjCmnfunctions->sql_fetchall($fields,$where,'','','',false);	
	}
	
	public function editLStatus($fields,$where){
		return $this->_ObjCmnfunctions->sql_fetchall($fields,$where,'','','',false);
	}
	
	 public function chkLeadNm($params){
	 //echo "<pre>"; print_r($params); die('model');
		$select = $this->_sql->select();
		$select->from(array('a' => $this->_table))
			   ->columns(array('id', 'lead_status','status', 'client_id'));  
		$select->where->addPredicate(new Predicate\Expression('a.status = ?', '1'));
		if(!empty($params['stop_followup'])){
			$select->where->addPredicate(new Predicate\Expression('a.stop_followup = ?', $params['stop_followup']));
		}
		if(!empty($params['lead_status'])){
			$select->where->addPredicate(new Predicate\Expression('a.lead_status = ?', $params['lead_status']));
		}
		$select->where->addPredicate(new Predicate\Expression("( a.client_id = " . $params['client_id'] . " ||  a.client_id = 0 )"));
		$statement = $this->_ObjCmnfunctions->prepareStatement($select,false);
		return $statement;
	} 
	
	public function delLStatus($fields,$where){
		return  $this->_ObjCmnfunctions->sql_update($fields,$where);
	}
	
	public function updtLStatus($fields,$where){
		return  $this->_ObjCmnfunctions->sql_update($fields,$where);
	}
	
	public function addLStatus($stsArray){
		return  $this->_ObjCmnfunctions->sql_save($stsArray);
	}
}
<?php Namespace Services\Model\Webforms;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;
use Services\Model\Webforms\LeadWebDataFollowup;
use Services\Common\Common;
use Zend\Session\Container;

class ClientLandingPageWebformData{
	protected $_db;
	protected $_table;
	protected $_adapter;
	public $_ObjCmnfunctions;
	protected $_ObjLeadWebDataFollowup;
    private $Common;
	function __construct($adapter) {
		
		$this->_table='adv8_client_landing_page_webform_data';
		$this->_db= $adapter;
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		$this->_sql = new Sql($adapter);
		$this->_ObjLeadWebDataFollowup=new LeadWebDataFollowup($adapter);
         $this->Common=new Common();
		$this->_ns = new Container('Adv8360');
		 
	}
	
	function AdvanceFilter($param){
	$param['is_deleted'] = '0';
	$select = $this->_sql->select();
	$select->from(array('a'=>$this->_table))
		   ->columns(array('webform_data_id','webform_id','business_unit_id','landing_page_id','lead_type','fields_data'))
		   ->join(array('b'=>'adv8_client_landing_page'),'a.landing_page_id=b.id',array('id','landing_page_name'),'inner')
		   ->join(array('c'=>'adv8_client_business_unit'),'a.business_unit_id=c.id',array('business_unit_name'),'inner')  
  		   ->join(array('d'=>'adv8_users'),' a.owner_id=d.id',array('user_name','uid'=>'id'),'inner')
		   ->join(array('e'=>'adv8_info_lead_status'),'a.status=e.id',array('lead_status','sid'=>'id'),'inner');
			$ides=explode(',',$this->_ns->Child_User_Id);
			$select->where->in('a.owner_id',$ides);
		   $select->where->addPredicate(new Predicate\Expression('a.client_id = ?', trim($param['cid'])));
		   $select->where->addPredicate(new Predicate\Expression('a.is_deleted = ?', trim($param['is_deleted'])));
		   //$select->group('a.webform_data_id');
		$arr = $this->_ObjCmnfunctions->prepareStatement($select,false);
		//echo "<pre>";
		//print_r($arr);
		return $arr;
	}
	function getDetails($param){
		$is_deleted = '0';
	if(isset($param['webform_id']))
		$webform_id=trim($param['webform_id']);
		$select = $this->_sql->select();
		$select->from(array('a'=>$this->_table))
			   ->columns(array('ctn', 'calling', 'fields_data','submitted_on','webform_id','webform_data_id','landing_page_id','business_unit_id','client_id', 'utm_source','utm_medium','utm_campaignname','utm_adgroupname','utm_adgroupid','utm_keyword','utm_website','utm_geo','utm_bannername','utm_adtextid','utm_websitecategory','utm_form_source_url','utm_type', 'otp_verified', 'lead_sharing_id', 'lead_type', 'duplicate'))
			   ->join(array('b'=>'adv8_info_lead_status'),'a.status=b.id',array('status_label'=>'lead_status','status_id'=>'id'),'inner')
			   ->join(array('c'=>'adv8_users'),'a.owner_id=c.id',array('user_name','uid'=>'id'),'inner')  
			   ->join(array('e'=>'adv8_client_landing_page_webform'),'e.id=a.webform_id',array('id', 'map_form_fields', 'webform_self_fields'),'inner')
			   ->join(array('d'=>'adv8_client_landing_page'),'d.id=e.landing_page_id',array('landing_page_name','landing_page_url'),'inner');

			   
			   
		if(isset($param['webform_id']))
		   $select->where->addPredicate(new Predicate\Expression('a.webform_id = ?', trim($webform_id)));
		if(isset($param['webform_data_id']))
		   $select->where->addPredicate(new Predicate\Expression('a.webform_data_id = ?', trim($param['webform_data_id'])));
		
			$select->where->addPredicate(new Predicate\Expression('a.is_deleted = ?', trim($is_deleted)));
		return $this->_ObjCmnfunctions->prepareStatement($select,false);								
	}
	
	function fetch_webform_data($fields,$where){
		return $this->_ObjCmnfunctions->sql_fetchall($fields,$where,'','','',false);		
	}
	function get_webform_id($webform_data_id){
	$select = $this->_sql->select();
	$select->from(array('a'=>$this->_table))
		   ->columns(array('webform_id'))
		   ->where->addPredicate(new Predicate\Expression('a.webform_data_id = ?', trim($webform_data_id)));
		   $select->limit(1);
	$res=$this->_ObjCmnfunctions->prepareStatement($select);						
	return $res[0]['webform_id'];
	}
	function update($data,$where) {
		//print_R($where);
		return  $this->_ObjCmnfunctions->sql_update($data,$where);
	}

	function save($data) {
		return  $this->_ObjCmnfunctions->sql_save($data);
	}

	
	function SubshowFormData($params,$rows){
		$data=array();
		foreach ($rows as $key=>$value){
		$select = $this->_sql->select();
		$select->from(array('a'=>$this->_table))
		   ->join(array('b'=>'adv8_users'),'a.owner_id=b.id',array('user_name'),'inner')
		   ->join(array('c'=>'adv8_info_lead_status'),'a.status=c.id',array('lead_status'),'inner');
			$select->where->addPredicate(new Predicate\Expression('webform_id = ?', trim($rows[$key]['id'])));
            if(isset($params['leadStatus']))
			$select->where->addPredicate(new Predicate\Expression('leadStatus = ?', trim($params['leadStatus'])));				
			if(isset($params['search']))
			$select->where->like('fields_data','%'.trim($params['search']).'%');								
            $select->order('submitted_on DESC'); 
			$rows1=$this->_ObjCmnfunctions->prepareStatement($select);			
			if(sizeof($rows1)>0){
			  foreach ($rows1 as $k =>$v) {
                $d =  array();
                $d['business_unit_name']  = $value['business_unit_name'];
                $followup = $this->_ObjLeadWebDataFollowup->getFolloups(trim($v['webform_data_id']),1);
                if($followup){
                     $d['last_followup']  = date("M d, Y",strtotime($followup[0]['created_at']));
                     $d['next_followup']  = date("M d, Y",strtotime($followup[0]['email_reminder_date']));
                } else {
                    $d['last_followup']  = 'N/A';
                    $d['next_followup']  = 'N/A';
                }

                $d['owner']= $v['user_name'];
                $d['lead_id'] = $v['webform_data_id'];
                $d['submitted_on']= date("M d, Y g:i A",strtotime($v['submitted_on']));
                $d['lead_age']=  $this->Common->getDateDiffFromNow($v['submitted_on']);
                $d['lead_status']= $v['lead_status'];
                $fields_data = json_decode($v['fields_data'], false);
                $d['Name']= $fields_data->Name;
                $d['Email']= $fields_data->Email;
                $d['Phone']= $fields_data->Phone;
                $d['IP']= $v['ip'];
                $d['lead_type']= "Web";
                $data[] = $d;
            } 
			}
			
		}
		 return $data;
	}
	
	public function getCountByCallType($param) {
	

		$select = $this->_sql->select();
		$select->from($this->_table);
		$ides=$this->_ns->Child_User_Id;
		$field = array('count' => new \Zend\Db\Sql\Expression('COUNT(webform_data_id)'), 'owner_id', 'lead_type');
		$select->columns($field);
		
		$idesAtrray = explode(",", $ides);
		$select->where->in('owner_id',$idesAtrray);
		
		if (!empty($param['ownerId'])){
			$select->where->addPredicate(new Predicate\Expression('owner_id = ?', trim($param['ownerId'])));
		}
		
		if (!empty($param['sDate']) && !empty($param['eDate'])){
			$select->where->between('submitted_on', $param['sDate'], $param['eDate']);
		}
		
		$select->group(array('owner_id','lead_type'));
		
		
		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);
		return $res;
		
    }
	
	public function getLeadStatusCountByDate($param) {
	

		$select = $this->_sql->select();
		$select->from($this->_table);

		$field = array('count' => new \Zend\Db\Sql\Expression('COUNT(webform_data_id)'), 'status');
		$select->columns($field);
		
		$select->join(array('ails' => 'adv8_info_lead_status'), 'ails.id= '.$this->_table.'.status', array('lead_status'), 'inner');
		
		
		
		$select->where->addPredicate(new Predicate\Expression($this->_table.'.client_id = ?', trim($param['clientId'])));
		//$select->where->addPredicate(new Predicate\Expression('ails.status <> ?', 0));
		
		
		if (!empty($param['sDate']) && !empty($param['eDate'])){
			$select->where->between('submitted_on', $param['sDate'], $param['eDate']);
		}
		
		$select->group(array('status'));
		
		
		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);
		
		return $res;
		
    }
	
	
	public function deleteLead(){
		$select = $this->_sql->select();
		$update = $sql->update( 'credit_details');
		$update->set( array('CREDITS' => $credits) );
		$update->where( array( 'CONTACT_ID' => $contact_id ) );
	}
	
	public function getleaddetails($param) {
		$response = array();
		$select = $this->_sql->select();
		$select->from($this->_table);
		$field = array('webform_data_id','ctn','forwarding','calling','call_duration','call_time','recording','submitted_on');
		$select->columns($field);
		
		if(!empty($param['call_tracking_no'])){
			$select->where->addPredicate(new Predicate\Expression('ctn = ?', trim($param['call_tracking_no'])));
		}
		if(!empty($param['client_id'])){
			$select->where->addPredicate(new Predicate\Expression('client_id = ?', trim($param['client_id'])));
		}
		if(!empty($param['lead_type'])){
			$select->where->addPredicate(new Predicate\Expression('lead_type = ?', $param['lead_type']));
		}

		if (!empty($param['from_date']) && !empty($param['to_date'])){
			$select->where->between('submitted_on', $param['from_date'], $param['to_date']);
		}
		$select->where->addPredicate(new Predicate\Expression('is_deleted = ?', 0));
		
		
		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);			
		
		return $res;	
    }
	
	public function getBudgetDetailByStatus($param) {

		if($param['leadStatus'] == 2){ //hot
			$subField = 'expected_payment';
	   }else if($param['leadStatus'] == 8){
			$subField = 'upfront_payment';
	   }
	   
	   
		$response = array();
		$select = $this->_sql->select();
		$select->from($this->_table);
		
		$field = array('budget' => new \Zend\Db\Sql\Expression("sum($subField)"));
		$select->columns($field);
		
		if(!empty($param['ownerId'])){
			$select->where->addPredicate(new Predicate\Expression('owner_id = ?', trim($param['ownerId'])));
		}
		if(!empty($param['lpId'])){
			$select->where->addPredicate(new Predicate\Expression('landing_page_id = ?', trim($param['lpId'])));
		}
		
		if (!empty($param['sDate']) && !empty($param['eDate'])){
			$select->where->between('submitted_on', $param['sDate'], $param['eDate']);
		}
		
		if(!empty($param['clientId'])){
			$select->where->addPredicate(new Predicate\Expression('client_id = ?', trim($param['clientId'])));
		}
		
		$select->where->addPredicate(new Predicate\Expression('is_deleted = ?', 0));
		
		
		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);			
		
		return $res;	
    }
	
	public function getBudgetDetail($param) {
		$response = array();
		$select = $this->_sql->select();
		$select->from($this->_table);
		
		$field = array('budget' => new \Zend\Db\Sql\Expression("sum(expected_payment)"));
		$select->columns($field);
		
		if(!empty($param['ownerId'])){
			$select->where->addPredicate(new Predicate\Expression('owner_id = ?', trim($param['ownerId'])));
		}
		if(!empty($param['lpId'])){
			$select->where->addPredicate(new Predicate\Expression('landing_page_id = ?', trim($param['lpId'])));
		}
		
		if (!empty($param['sDate']) && !empty($param['eDate'])){
			$select->where->between('submitted_on', $param['sDate'], $param['eDate']);
		}
		
		if(!empty($param['clientId'])){
			$select->where->addPredicate(new Predicate\Expression('client_id = ?', trim($param['clientId'])));
		}
		
		$idesAtrray = explode(",", $param['leadStatus']);
		$select->where->in('status',$idesAtrray);
		
		
		$select->where->addPredicate(new Predicate\Expression('is_deleted = ?', 0));
		
		
		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);			
		
		return $res;	
    }
	
	public function getLeadByStatusByOwnerLp($param) {
		$select = $this->_sql->select();
		$select->from($this->_table);
		
		$field = array(
			'count' => new \Zend\Db\Sql\Expression('COUNT(webform_data_id)'), 
			'status', 
			$param["groupBy"]			
		);
		
		if(!empty($param['fields']) && is_array($param['fields'])) { 
			foreach($param['fields'] as $fieldName) {
				$field[] = $fieldName;
			}
		}
		
		$select->columns($field);
		
		if(!empty($param['clientId'])){
			$select->where->addPredicate(new Predicate\Expression($this->_table.'.client_id = ?', trim($param['clientId'])));
		}
		
		if (!empty($param['sDate']) && !empty($param['eDate'])){
			$select->where->between('submitted_on', $param['sDate'], $param['eDate']);
		}
		if (!empty($param['join'])) {
			$select->join(array('ails' => 'adv8_info_lead_status'), 'ails.id= '.$this->_table.'.status', array('lead_status'), 'left');
		}
		
		if(!empty($param['join_landing_page'])) {
			$select->join(array('aclp' => 'adv8_client_landing_page'), 'aclp.id= '.$this->_table.'.landing_page_id', array('landing_page_name'), 'left');
		}
		
		if(!empty($param['join_owner'])) {
			$select->join(array('au' => 'adv8_users'), 'au.id= '.$this->_table.'.owner_id', array('user_email'), 'inner');			
		}
		
		$select->group(array($param["groupBy"],'status'));
		
		$select->where->addPredicate(new Predicate\Expression('is_deleted = ?', 0));
		
		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);
		
		return $res;
		
    }
	
}

<?php

Namespace Services\Model\Webforms;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Zend\Session\Container;
use Services\Model\Dbnfun;

class LeadWebDataFollowup {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {

	$this->_table = 'adv8_lead_web_data_followup';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
	$this->_ns = new Container('Adv8360');
    }

    function addFolloups($data) {
	$sql = "update adv8_client_landing_page_webform_data set status = (select id from adv8_info_lead_status where lead_status = '$data[status]') where webform_data_id = '$data[lead_id]'";
	$statement = $this->_db->query($sql);
	$Res = $statement->execute();

	return $this->_ObjCmnfunctions->sql_save($data);
    }

    function updateFolloups($data, $where) {
	return $this->_ObjCmnfunctions->sql_update($data, $where);
    }

    function get_Follow_Up($param) {
	$select = $this->_sql->select();
	$select->from($this->_table)
		->columns(array('comments', 'email_reminder', 'email_reminder_date', 'sms_reminder', 'timezone_created_date', 'owner_id', 'status', 'email_reminder_date', 'upfront_payment','expected_payment','expected_payment_date'));
	if (isset($param['last']))
	    $select->where->addPredicate(new Predicate\Expression("DATE_FORMAT(`email_reminder_date`,'%m-%d-%Y') < ?", date('m-d-Y')));
	if (isset($param['next']))
	    $select->where->addPredicate(new Predicate\Expression("DATE_FORMAT(`email_reminder_date`,'%m-%d-%Y') >= ?", date('m-d-Y')));

	$select->where->addPredicate(new Predicate\Expression('lead_id = ?', trim($param['lead_id'])));
	$select->order(new Predicate\Expression("DATE_FORMAT(`email_reminder_date`,'%m-%d-%Y') DESC"));
	if (isset($param['last']))
	    $select->limit(1);
	$res = $this->_ObjCmnfunctions->prepareStatement($select, false);
	return $res;
    }

    // SELECT * FROM `adv8_lead_web_data_followup` WHERE  DATE_FORMAT(`created_at`,'%m-%d-%Y')>=DATE_FORMAT(NOW(),'%m-%d-%Y')
    public function getFolloups($lead_id, $limit = 'All', $groupby = false) {
	$select = $this->_sql->select();
	if (!$groupby) {
	    $select->from($this->_table)
	    //  ->columns(array('id','call_lead_id','comments','email_reminder','email_reminder_date','sms_reminder','sms_reminder_date','created_at'))
	    ->where->addPredicate(new Predicate\Expression('lead_id = ?', trim($lead_id)));
	    if ($limit != 'All') {
		$select->order('created_at DESC');
		$select->limit(trim($limit));
	    } else {
		$select->order('created_at desc');
	    }
	} else {
	    $select->from(array('a' => $this->_table))
		    ->columns(array('description' => 'comments', 'status', 'date' => new Expression("DATE_FORMAT(created_at, '%M %d, %Y')"), 'time' => new Expression("DATE_FORMAT(created_at, '%h:%i %p')")))
		    ->join(array('b' => 'adv8_users'), 'a.owner_id=b.id', array('owner' => 'user_name'))
	    ->where->addPredicate(new Predicate\Expression('a.lead_id = ?', trim($lead_id)));
	    $select->order('a.created_at desc');
	}
	$res = $this->_ObjCmnfunctions->prepareStatement($select, false);
	return $res;
    }


    // SELECT * FROM `adv8_lead_web_data_followup` WHERE  DATE_FORMAT(`created_at`,'%m-%d-%Y')>=DATE_FORMAT(NOW(),'%m-%d-%Y')
    public function getAllFollowups($client_id) {

    	$select = $this->_sql->select('');
		$select->from(array('a' => $this->_table));
		$select->columns(array('id', 'lead_id','status', 'comments', 'owner_id','email_reminder_date','created_at'));
		/*$select->columns(
				array('id', 'lead_id','status', 'comments', 'owner_id','email_reminder_date','created_at'));*/
		
		$select->join(array('b' => 'adv8_client_landing_page_webform_data'), 
						'a.id=b.webform_data_id',
						array('webform_id'));
						
	    $select->where->addPredicate(new Predicate\Expression('b.client_id = ?', trim($client_id)));

		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);
		return $res;
    }

    public function getLatestFollowUps($param) {
	//$sql = "SELECT lead_id,comments,email_reminder,email_reminder_date,sms_reminder,sms_reminder_date,created_at,owner_id,STATUS FROM (SELECT lead_id,comments,email_reminder,email_reminder_date,sms_reminder,sms_reminder_date,created_at,owner_id,STATUS FROM adv8_lead_web_data_followup GROUP BY lead_id ORDER BY id DESC) AS tab WHERE email_reminder = 1 ORDER BY email_reminder_date DESC ";
	
	$ides=$this->_ns->Child_User_Id;
	
			
	//$sql = "SELECT lead_id,comments,email_reminder,email_reminder_date,sms_reminder,sms_reminder_date,created_at,owner_id,`status` FROM (SELECT lead_id,comments,email_reminder,email_reminder_date,sms_reminder,sms_reminder_date,created_at,owner_id,STATUS FROM adv8_lead_web_data_followup where owner_id in (".$ides.") and ((email_reminder_date >= '".$param['sDate']."' and email_reminder_date <= '".$param['eDate']."') || (sms_reminder_date >= '".$param['sDate']."' and sms_reminder_date <= '".$param['eDate']."')) GROUP BY lead_id ORDER BY id DESC) AS tab ORDER BY email_reminder_date DESC ";
	
      $sql = "SELECT lead_id,comments,email_reminder,email_reminder_date,sms_reminder,sms_reminder_date,created_at,owner_id, `status` FROM (SELECT lead_id,comments,email_reminder,email_reminder_date,sms_reminder,sms_reminder_date, created_at,owner_id,STATUS FROM adv8_lead_web_data_followup  ORDER BY email_reminder_date DESC ) AS tab  GROUP BY lead_id HAVING owner_id in (".$ides.") and date(email_reminder_date) >= '".$param['sDate']."' and date(email_reminder_date) <= '".$param['eDate']."' ORDER BY email_reminder_date ASC"; 
	
			
	$res = $this->_ObjCmnfunctions->query($sql, false);
	
	
	return $res;
    }
	
	public function getAllFollowUpOfClient($param) {
		$ides=$this->_ns->Child_User_Id;
		$select = $this->_sql->select();
		$select->from($this->_table);
		$select->columns(array('id', 'lead_id','status', 'comments', 'owner_id','email_reminder_date','created_at'));
		
		$idesAtrray = explode(",", $ides);
		$select->where->in('owner_id',$idesAtrray);
		
		if (!empty($param['ownerId'])){
			$select->where->addPredicate(new Predicate\Expression('owner_id = ?', trim($param['ownerId'])));
		}
		
		if (!empty($param['sDate']) && !empty($param['eDate'])){
			$select->where->between('created_at', $param['sDate'], $param['eDate']);
		}
		
		$select->order('created_at desc');
		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);
		return $res;
		
    }
	
	public function getCountGroupByOwner($param) {
		$ides=$this->_ns->Child_User_Id;
		$select = $this->_sql->select();
		$select->from($this->_table);
		
		$field = array('count' => new \Zend\Db\Sql\Expression('COUNT(id)'), 'owner_id');
		
		$select->columns($field);
		
		
		
		$idesAtrray = explode(",", $ides);
		$select->where->in('owner_id',$idesAtrray);
		
		if (!empty($param['ownerId'])){
			$select->where->addPredicate(new Predicate\Expression('owner_id = ?', trim($param['ownerId'])));
		}
		
		if (!empty($param['sDate']) && !empty($param['eDate'])){
			$select->where->between('created_at', $param['sDate'], $param['eDate']);
		}
		$select->group('owner_id');
		$res = $this->_ObjCmnfunctions->prepareStatement($select, false);
		return $res;
		
    }
	
}
<?php

/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zdend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Cms\Controller\Lms;

use Zend\Session\Container;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Services\Model\Clients\Client;
use Services\Model\Users;
use Services\Model\ClientBusinessUnit;
use Services\Model\Webforms\ClientLandingPage;
use Services\Model\Webforms\ClientLandingPageWebformData;
use Services\Model\Webforms\ClientLandingPageWebform;
use Services\Model\Webforms\ShardaStudents;
use Services\Model\Webforms\LeadWebDataFollowup;
use Services\Model\Webforms\InfoLeadStatus;
use Zend\Http\Headers;
use Zend\Paginator\Paginator;
use Zend\Paginator\Adapter\ArrayAdapter;

class LmsController extends AbstractActionController {

    public $_view;
    public $_ObjClient;
    public $_ObjUsers;
    public $_ns;
    public $_agencyId;
    public $_ObjClientBusinessUnit;
    public $_ObjClientLandingPage;
    protected $_ObjClientLandingPageWebformData;
    protected $_ObjClientLandingPageWebform;
    protected $_ObjLeadWebDataFollowup;
    protected $_ObjInfoLeadStatus;
    protected $_ObjShardaStudents;

    function __construct() {

	//ini_set('display_errors', '1');echo "f";exit;
	$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
	$this->_view = new ViewModel();
	$this->_ObjClient = new Client($adapter);
	$this->_ObjClientLandingPage = new ClientLandingPage($adapter);
	$this->_ObjUsers = new Users($adapter);
	$this->_ns = new Container('Adv8360');
	$this->_ObjClientBusinessUnit = new ClientBusinessUnit($adapter);
	$this->_ObjClientLandingPageWebformData = new ClientLandingPageWebformData($adapter);
	$this->_agencyId = trim($this->_ns->Adv8Agencyid);
	$this->_ObjClientLandingPageWebform = new ClientLandingPageWebform($adapter);
	$this->_ObjLeadWebDataFollowup = new LeadWebDataFollowup($adapter);
	$this->_ObjInfoLeadStatus = new InfoLeadStatus($adapter);
	$this->_ObjShardaStudents = new ShardaStudents($adapter);
    }

    public function plistAction() {
	// Session Agency Id Name Space
	$agencyId = $this->_agencyId;

	// Client List 
	$clientData = $this->_ObjClient->getClientList($agencyId);
	$this->_view->clientData = $clientData;
	return $this->_view;
    }

    function dashboardAction() {
	//die("maintance downtime");
	//$this->_ns->Adv8Clientid=1;
	//$CampaignsList=$this->_ObjClientBusinessUnit->getCampaignsList($this->_ns->Adv8Clientid,array('id','business_unit_name'));
	
	if($_REQUEST['sDate']){ 
	    $sDate = $_REQUEST['sDate']." 00:00:00";
	    $this->_ns->sDate = $sDate;
	}
	
	if($_REQUEST['eDate']){ 
	    $eDate = $_REQUEST['eDate']." 23:59:59";
	    $this->_ns->eDate = $eDate;
	}
	
	if(!empty($this->_ns->sDate)){
	    $sDate = $this->_ns->sDate;
	}
	if(!empty($this->_ns->eDate)){
	    $eDate = $this->_ns->eDate;
	}
	
	if(empty($sDate)){
	    $sDate = date("Y-m-01 00:00:00");
	    $this->_ns->sDate = $sDate;
	}
	if(empty($eDate)){
	    $eDate = date("Y-m-t 23:59:59");
	    $this->_ns->eDate = $eDate;
	    
	}
	
	
	$CampaignsList = $this->_ObjClientBusinessUnit->getCampaignUnitsSummery($this->_ns->Adv8Clientid,'','','','',$sDate, $eDate);

	$status_summery = $this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_status($this->_ns->Adv8Clientid, '','','', '', $sDate, $eDate);

	$acl_role = $this->getRequest()->getPost('hdn_acl_role');
	$this->_view->acl_role = $acl_role;

	$owner_summery = $this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_lead_owner($this->_ns->Adv8Clientid, $acl_role, '', '', '','', $sDate, $eDate);



	$product_summery = $this->_ObjClientLandingPageWebform->getCampaignUnitsSummery_by_product($this->_ns->Adv8Clientid, '', '', '', '', $sDate, $eDate);
	$lead_history = $this->_ObjClientLandingPageWebform->getLeadHistory($this->_ns->Adv8Clientid);


	//print_r($lead_history);
	$this->_view->owner_summery = $owner_summery;
	$this->_view->CampaignsList = $CampaignsList;
	$this->_view->status_summery = $status_summery;
	$this->_view->product_summery = $product_summery;
	$this->_view->lead_history = $lead_history;
	
	$this->_view->sDate = $sDate;
	$this->_view->eDate = $eDate;
	//print_r($this->_view);
	return $this->_view;
    }

    function updateleadstatusajaxAction() {
	$status_id = $this->Xssplugin()->escape($this->getRequest()->getPost('status_id'));
	$lead_id = $this->Xssplugin()->escape($this->getRequest()->getPost('lead_id'));
	$this->_ObjClientLandingPageWebformData->update(array('status' => $status_id), array('webform_data_id' => $lead_id));
	die;
    }

    function addfollowupAction() {
	//print_R($_POST);exit;
	$lead_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webformdata_id'));
	if ($lead_id > 0) {
	    $comments = $this->Xssplugin()->escape($this->getRequest()->getPost('follow_lead_desc'));
	    $follow_lead_status = $this->Xssplugin()->escape($this->getRequest()->getPost('follow_lead_status'));
	    $date = $this->Xssplugin()->escape($this->getRequest()->getPost('follow_lead_date'));
	    $time = $this->Xssplugin()->escape($this->getRequest()->getPost('follow_lead_time'));
	    $email_reminder_date = date('Y-m-d', strtotime($date)) . " " . date('H:i:s', strtotime($time));
	    $email_reminder = $this->Xssplugin()->escape($this->getRequest()->getPost('email_reminder'));
	    if($email_reminder == 'on'){
		$email_reminder = 1;
	    }else{
		$email_reminder = 0;
	    }
	    
	    $owner_id = $this->_ns->Adv8Uid;
	    $this->_ObjLeadWebDataFollowup->addFolloups(array('lead_id' => $lead_id, 'comments' => $comments, 'email_reminder_date' => $email_reminder_date, 'owner_id' => $owner_id, 'status' => $follow_lead_status, 'email_reminder' => $email_reminder));
	    $this->_view->hdn_webformdata_id = $lead_id;
	}
	return $this->_view;
    }

    function updateleadownerajaxAction() {
	$webform_id = $this->Xssplugin()->escape($this->getRequest()->getPost('webform_id'));
	$u_id = $this->Xssplugin()->escape($this->getRequest()->getPost('u_id'));
	$this->_ObjClientLandingPageWebformData->update(array('owner_id' => $u_id), array('webform_data_id' => $webform_id));
	die;
    }

    function detailsAction() {

	$hdn_webformdata_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webformdata_id'));
	$hdn_referfollowup = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_referfollowup'));

	$param['webform_data_id'] = trim($hdn_webformdata_id);
	$webform = $this->_ObjClientLandingPageWebformData->getDetails($param);
	//print_r($param); exit;
	$Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webformdata_id), 'next' => true));
	$PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webformdata_id), 'last' => true));
	$Followups = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webformdata_id)));
	//print_r($Followups);
	$LeadOwners = $this->_ObjUsers->getLeadOwners($this->_ns->Adv8Clientid, array());
	$parentOwnerId = $this->_ns->Adv8Uid;
	$LeadOwners1 = $this->_ObjUsers->getOwnersChild($parentOwnerId);
	$this->_view->LeadOwners = $LeadOwners1;
	
	$paramArray = array();
	$paramArray['clientId'] = $this->_ns->Adv8Clientid;
	
	$UsersOfClients = $this->_ObjUsers->getUsers($paramArray);
	
	$this->_view->UsersOfClients = $UsersOfClients;

	$this->_view->setTemplate('/cms/lms/moredetails');
	$InfoLeadStatus = $this->_ObjInfoLeadStatus->getDetail(array('id', 'lead_status'), array('status' => 1));
	$this->_view->hdn_webformdata_id = $hdn_webformdata_id;
	$this->_view->InfoLeadStatus = $InfoLeadStatus;
	$this->_view->webform = $webform;
	$this->_view->PreFollowup = $PreFollowup;
	$this->_view->Followup = $Followup;
	$this->_view->Followups = $Followups;
	$this->_view->hdn_referfollowup = $hdn_referfollowup;
	return $this->_view;
    }

    function listAction() { //echo "f";exit;
	//print_R($_SESSION);exit;
	if($_REQUEST['sDate']){ 
	    $sDate = $_REQUEST['sDate']." 00:00:00";
	    $this->_ns->sDate = $sDate;
	}
	
	if($_REQUEST['eDate']){ 
	    $eDate = $_REQUEST['eDate']." 23:59:59";
	    $this->_ns->eDate = $eDate;
	}
	
	if(!empty($this->_ns->sDate)){
	    $sDate = $this->_ns->sDate;
	}
	if(!empty($this->_ns->eDate)){
	    $eDate = $this->_ns->eDate;
	}
	
	if(empty($sDate)){
	    $sDate = date("Y-m-01 00:00:00");
	    $this->_ns->sDate = $sDate;
	}
	if(empty($eDate)){
	    $eDate = date("Y-m-t 23:59:59");
	    $this->_ns->eDate = $eDate;
	    
	}
	
	
	$this->_ns->excel_data_field = array();
	$all_src = trim($this->getRequest()->getPost('all_src'));
	
	//$all_src = 'Doors & Frames';
	
	$hdn_webform_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webform_id'));
	$hdn_unit_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_unit_id'));
	$hdn_flg = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_flg'));
	$info_status = $this->Xssplugin()->escape($this->getRequest()->getPost('info_status'));
	$owner_id = $this->Xssplugin()->escape($this->getRequest()->getPost('owner_id'));
	$Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'next' => true));
	$PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'last' => true));
	$this->_view->PreFollowup = $PreFollowup;
	$this->_view->Followup = $Followup;
	$this->_view->hdn_unit_id = $hdn_unit_id;
	$this->_view->info_status = $info_status;
	$this->_view->owner_id = $owner_id;
	$this->_view->hdn_flg = $hdn_flg;

	$cpage = $this->Xssplugin()->escape($this->getRequest()->getPost('paginator'), '1');
	$this->_view->cpage = $cpage;

	$param['cid'] = $this->_ns->Adv8Clientid;

	$arra = $this->_ObjClientLandingPageWebformData->AdvanceFilter($param);

	$this->_view->setTemplate('/cms/lms/details');
	$this->_view->FilterData = $arra;
	###########################################
	$this->_view->hdn_webform_id = $hdn_webform_id;
	$this->_view->hdn_unit_id = $hdn_unit_id;
	// $this->_ObjClientLandingPageWebformData->fetch_webform_data(array(),$where)
	$param['client_id'] = trim($this->_ns->Adv8Clientid);

	//if($hdn_flg==1)
	$param['business_unit_id'] = trim($hdn_unit_id);
	//if($hdn_flg==2)
	$param['info_status'] = $info_status;
	//if($hdn_flg==3)
	$param['owner_id'] = $owner_id;

	/// REPORT FILTER ///////////
	if ($hdn_unit_id)
	    $param['business_unit_id'] = $hdn_unit_id;
	if ($info_status)
	    $param['info_status'] = $info_status;
	if ($owner_id)
	    $param['owner_id'] = $owner_id;

	//print_r($param);
	/// END REPORT FILTER //////////
	$cu_checkbox = $this->getRequest()->getPost('cu_checkbox');
	$lp_checkbox = $this->getRequest()->getPost('lp_checkbox');
	$owner_checkbox = $this->getRequest()->getPost('owner_checkbox');
	$status_checkbox = $this->getRequest()->getPost('status_checkbox');
	$leadtype_checkbox = $this->getRequest()->getPost('leadtype_checkbox');
	$createdby_checkbox = $this->getRequest()->getPost('createdby_checkbox');
	if ($this->getRequest()->isPost()) {
	    $Condation['cu'] = $cu_checkbox;
	    $Condation['lp'] = $lp_checkbox;
	    $Condation['owner'] = $owner_checkbox;
	    $Condation['lead_status'] = $status_checkbox;
	    $Condation['lead_type'] = $leadtype_checkbox;
		$Condation['created_by'] = $createdby_checkbox;
	    
	    $this->_ns->CondationCheckBoxArray = $Condation;
	    $this->_ns->all_src = $all_src;
	    $this->_ns->page = $cpage;
	} else {
	    
	}
	$this->_view->checkbox_array = $this->_ns->CondationCheckBoxArray;
	$webform = $this->_ObjClientLandingPageWebform->get_lead_detail($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src, $sDate, $eDate);
	//print_R($webform);exit;
	//print_R($webform);exit;
	$this->_ns->_LeadArray = $webform;
	$this->_view->all_src = $this->_ns->all_src;
//		$webform=$this->_ObjClientLandingPageWebformData->getDetails($param);
	$this->_view->webform = $webform;

	$paginator = new Paginator(new ArrayAdapter($webform));
	$paginator->setCurrentPageNumber($this->_ns->page)
		->setItemCountPerPage(4);

	$this->_view->paginator = $paginator;
	
	$this->_view->sDate = $sDate;
	$this->_view->eDate = $eDate;
	
	return $this->_view;
    }

    function listfollowupbkpAction() {
	$this->_ns->excel_data_field = array();
	$all_src = $this->Xssplugin()->escape($this->getRequest()->getPost('all_src'));
	$hdn_webform_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webform_id'));
	$hdn_unit_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_unit_id'));
	$hdn_flg = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_flg'));
	$info_status = $this->Xssplugin()->escape($this->getRequest()->getPost('info_status'));
	$owner_id = $this->Xssplugin()->escape($this->getRequest()->getPost('owner_id'));
	$Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'next' => true));
	$PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'last' => true));
	$this->_view->PreFollowup = $PreFollowup;
	$this->_view->Followup = $Followup;
	$this->_view->hdn_unit_id = $hdn_unit_id;
	$this->_view->info_status = $info_status;
	$this->_view->owner_id = $owner_id;
	$this->_view->hdn_flg = $hdn_flg;

	$cpage = $this->Xssplugin()->escape($this->getRequest()->getPost('paginator'), '1');
	$this->_view->cpage = $cpage;

	$param['cid'] = $this->_ns->Adv8Clientid;

	$arra = $this->_ObjClientLandingPageWebformData->AdvanceFilter($param);

	//$this->_view->setTemplate('/cms/lms/followup');
	$this->_view->FilterData = $arra;
	###########################################
	$this->_view->hdn_webform_id = $hdn_webform_id;
	$this->_view->hdn_unit_id = $hdn_unit_id;
	// $this->_ObjClientLandingPageWebformData->fetch_webform_data(array(),$where)
	$param['client_id'] = trim($this->_ns->Adv8Clientid);

	//if($hdn_flg==1)
	$param['business_unit_id'] = trim($hdn_unit_id);
	//if($hdn_flg==2)
	$param['info_status'] = $info_status;
	//if($hdn_flg==3)
	$param['owner_id'] = $owner_id;

	/// REPORT FILTER ///////////
	if ($hdn_unit_id)
	    $param['business_unit_id'] = $hdn_unit_id;
	if ($info_status)
	    $param['info_status'] = $info_status;
	if ($owner_id)
	    $param['owner_id'] = $owner_id;

	//print_r($param);
	/// END REPORT FILTER //////////
	$cu_checkbox = $this->getRequest()->getPost('cu_checkbox');
	$lp_checkbox = $this->getRequest()->getPost('lp_checkbox');
	$owner_checkbox = $this->getRequest()->getPost('owner_checkbox');
	$status_checkbox = $this->getRequest()->getPost('status_checkbox');
	if ($this->getRequest()->isPost()) {
	    $Condation['cu'] = $cu_checkbox;
	    $Condation['lp'] = $lp_checkbox;
	    $Condation['owner'] = $owner_checkbox;
	    $Condation['lead_status'] = $status_checkbox;
	    $this->_ns->CondationCheckBoxArray = $Condation;
	    $this->_ns->all_src = $all_src;
	    $this->_ns->page = $cpage;
	} else {
	    
	}
	$this->_view->checkbox_array = $this->_ns->CondationCheckBoxArray;
	$webform = $this->_ObjClientLandingPageWebform->get_lead_detail($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src);
	//print_R($webform);exit;
	//echo"d";exit;
	$statusArray = array('4', '5', '6', '7', '12', '14', '15', '16');
	$webformArray = array();
	$followUpArray = array();
	$followUpArray = array();
	foreach ($webform as $k => $v) {
	    if (in_array($v['status'], $statusArray)) {
		continue;
	    }
	    $FollowupArray = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($v['webform_data_id'])));
	    if (empty($FollowupArray)) {
		continue;
	    }

	    if (date('Y-m-d', strtotime($FollowupArray[0]['email_reminder_date'])) == '1970-01-01') {
		//echo date('Y-m-d',strtotime($FollowupArray[0]['email_reminder_date']));
		//echo "f";exit;
		continue;
	    }
	    $v['email_reminder_date'] = $FollowupArray[0]['email_reminder_date'];
	    if (isset($FollowupArray[1]['email_reminder_date'])) {
		$followUpPreArray[$v['webform_data_id']] = $FollowupArray[1]['email_reminder_date'];
	    } else {
		$followUpPreArray[$v['webform_data_id']] = '';
	    }
	    /* }else{
	      $v['email_reminder_date'] = '';
	      } */
	    $webformArray[$k] = $v;
	}


	if (!empty($webformArray)) {
	    foreach ($webformArray as $key => $row) {
		$volume[$key] = $row['email_reminder_date'];
		$followUpArray[$row['webform_data_id']] = $row['email_reminder_date'];
	    }
	    array_multisort($volume, SORT_DESC, $webformArray);
	}
	print_R($webformArray);
	exit;

	$this->_ns->_LeadArray = $webformArray;
	$this->_view->all_src = $this->_ns->all_src;
//		$webform=$this->_ObjClientLandingPageWebformData->getDetails($param);
	$this->_view->webform = $webformArray;
	$this->_view->followUpArray = $followUpArray;
	$this->_view->followUpPreArray = $followUpPreArray;

	$paginator = new Paginator(new ArrayAdapter($webformArray));
	$paginator->setCurrentPageNumber($this->_ns->page)
		->setItemCountPerPage(4);

	$this->_view->paginator = $paginator;
	return $this->_view;
    }

    function listfollowupAction() {

	$sDate = $this->Xssplugin()->escape($this->getRequest()->getPost('sDate'));
	$eDate = $this->Xssplugin()->escape($this->getRequest()->getPost('eDate'));

	if (empty($sDate)) {
	    $sDate = date('Y-m-d', strtotime('-30 days'));
	}

	if (empty($eDate)) {
	    $eDate = date("Y-m-t");
	}

	$this->_ns->excel_data_field = array();
	$all_src = $this->Xssplugin()->escape($this->getRequest()->getPost('all_src'));
	$hdn_webform_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webform_id'));
	$hdn_unit_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_unit_id'));
	$hdn_flg = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_flg'));
	$info_status = $this->Xssplugin()->escape($this->getRequest()->getPost('info_status'));
	$owner_id = $this->Xssplugin()->escape($this->getRequest()->getPost('owner_id'));
	$Followup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'next' => true));
	$PreFollowup = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($hdn_webform_id), 'last' => true));
	$this->_view->PreFollowup = $PreFollowup;
	$this->_view->Followup = $Followup;
	$this->_view->hdn_unit_id = $hdn_unit_id;
	$this->_view->info_status = $info_status;
	$this->_view->owner_id = $owner_id;
	$this->_view->hdn_flg = $hdn_flg;

	$cpage = $this->Xssplugin()->escape($this->getRequest()->getPost('paginator'), '1');
	$this->_view->cpage = $cpage;

	$param['cid'] = $this->_ns->Adv8Clientid;

	$arra = $this->_ObjClientLandingPageWebformData->AdvanceFilter($param);

	//$this->_view->setTemplate('/cms/lms/followup');
	$this->_view->FilterData = $arra;
	###########################################
	$this->_view->hdn_webform_id = $hdn_webform_id;
	$this->_view->hdn_unit_id = $hdn_unit_id;
	// $this->_ObjClientLandingPageWebformData->fetch_webform_data(array(),$where)
	$param['client_id'] = trim($this->_ns->Adv8Clientid);

	//if($hdn_flg==1)
	$param['business_unit_id'] = trim($hdn_unit_id);
	//if($hdn_flg==2)
	$param['info_status'] = $info_status;
	//if($hdn_flg==3)
	$param['owner_id'] = $owner_id;

	/// REPORT FILTER ///////////
	if ($hdn_unit_id)
	    $param['business_unit_id'] = $hdn_unit_id;
	if ($info_status)
	    $param['info_status'] = $info_status;
	if ($owner_id)
	    $param['owner_id'] = $owner_id;

	//print_r($param);
	/// END REPORT FILTER //////////
	$cu_checkbox = $this->getRequest()->getPost('cu_checkbox');
	$lp_checkbox = $this->getRequest()->getPost('lp_checkbox');
	$owner_checkbox = $this->getRequest()->getPost('owner_checkbox');
	$status_checkbox = $this->getRequest()->getPost('status_checkbox');
	if ($this->getRequest()->isPost()) {
	    $Condation['cu'] = $cu_checkbox;
	    $Condation['lp'] = $lp_checkbox;
	    $Condation['owner'] = $owner_checkbox;
	    $Condation['lead_status'] = $status_checkbox;
	    $this->_ns->CondationCheckBoxArray = $Condation;
	    $this->_ns->all_src = $all_src;
	    $this->_ns->page = $cpage;
	} else {
	    
	}
	$this->_view->checkbox_array = $this->_ns->CondationCheckBoxArray;

	//$webform = $this->_ObjClientLandingPageWebform->get_lead_detail($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src);



	$paramsfollowup = array();
	$paramsfollowup['groupBy'] = true;
	$paramsfollowup['sDate'] = $sDate;
	$paramsfollowup['eDate'] = $eDate;

	$allLatestFollowup = $this->_ObjLeadWebDataFollowup->getLatestFollowUps($paramsfollowup);



	$statusArray = array('4', '5', '6', '7', '12', '14', '15', '16', '10', '9');
	//$statusArray = array('Rejected', 'Junk', 'Duplicate', 'Trash', 'Closed', 'Paid')Closed Lost;

	$webformArray = array();
	$fullFollowupArray = array();
	$followUpPreArray = array();
	//print_r($allLatestFollowup);
	foreach ($allLatestFollowup as $k => $v) {
	    /* if (in_array($v['status'], $statusArray)) {
	      continue;
	      } */
	    $param['webform_data_id'] = $v['lead_id'];

	    $webformDetail = $this->_ObjClientLandingPageWebform->get_lead_detail_new($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src);
	    ;
	    //print_R($webformDetail);exit;

	    if (empty($webformDetail)) {
		continue;
	    }

	    if (in_array($webformDetail[0]['status_id'], $statusArray)) {
		continue;
	    }


	    $fullFollowupArray = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($v['lead_id'])));
	    if (isset($fullFollowupArray[1]['email_reminder_date'])) {
		//PRINT_R($fullFollowupArray);exit;
		$followUpPreArray[$v['lead_id']] = $fullFollowupArray[1]['email_reminder_date'];
	    } else {
		$followUpPreArray[$v['lead_id']] = '';
	    }

	    $tempArray = $webformDetail[0];
	    $tempArray['email_reminder_date'] = $v['email_reminder_date'];
	    $webformArray[] = $tempArray;
	    //print_R($webformArray);exit;
	}

	$this->_ns->_LeadArray = $webformArray;
	$this->_view->all_src = $this->_ns->all_src;
//		$webform=$this->_ObjClientLandingPageWebformData->getDetails($param);
	$this->_view->webform = $webformArray;
	$this->_view->followUpArray = $followUpArray;
	$this->_view->followUpPreArray = $followUpPreArray;

	$this->_view->eDate = $eDate;
	$this->_view->sDate = $sDate;

	$paginator = new Paginator(new ArrayAdapter($webformArray));
	$paginator->setCurrentPageNumber($this->_ns->page)
		->setItemCountPerPage(4);

	$this->_view->paginator = $paginator;
	return $this->_view;
    }

    public function exportxlsAction() {
    	//ini_set("display_errors",1 );
	$excel_data_field = $this->_ns->excel_data_field;
	
	$clientId = trim($this->_ns->Adv8Clientid);
	
	
	//print_R($excel_data_field);exit;
	unset($excel_data_field['submit']);
	unset($excel_data_field['datesee']);
	unset($excel_data_field['dateme']);
	unset($excel_data_field['utm adtextId']);
	unset($excel_data_field['utm adgroupId']);
	unset($excel_data_field['utm adgroupId']);
	unset($excel_data_field['utm form source url']);
	unset($excel_data_field['utm websitecategory']);
	unset($excel_data_field['captcha']);
	unset($excel_data_field['session user id']);

	unset($excel_data_field['owner']);
	unset($excel_data_field['star']);
	unset($excel_data_field['type']);
	unset($excel_data_field['utm bannername']);
	unset($excel_data_field['fb user id']);
	unset($excel_data_field['lp url']);
	
	if($clientId == 144){
	    $excel_data_field['dateofbirth'] = 'dateofbirth';
	    $excel_data_field['gender'] = 'gender';
	    $excel_data_field['address'] = 'address';
	    $excel_data_field['city'] = 'city';
	    $excel_data_field['country'] = 'country';
	   
	    $excel_data_field['SUATID'] = 'SUATID';
	    $excel_data_field['ORDERID'] = 'ORDERID';
	    $excel_data_field['TXNAMOUNT'] = 'TXNAMOUNT';
	    $excel_data_field['TXNID'] = 'TXNID';
	    $excel_data_field['BANKTXNID'] = 'BANKTXNID';
	    $excel_data_field['RESPCODE'] = 'RESPCODE';
	    $excel_data_field['RESPMSG'] = 'RESPMSG';
	    $excel_data_field['STATUS'] = 'STATUS';
	    $excel_data_field['TXNDATE'] = 'TXNDATE';
	    $excel_data_field['GATEWAYNAME'] = 'GATEWAYNAME';
	    $excel_data_field['BANKNAME'] = 'BANKNAME';
	    $excel_data_field['PAYMENTMODE'] = 'PAYMENTMODE';
	}

	$excel_data_field['status_label'] = 'status_label';
	$excel_data_field['user_name'] = 'user_name';
	$excel_data_field['landing_page_url'] = 'landing_page_url';

	$excel_data_field['ctn'] = 'ctn';
	$excel_data_field['calling'] = 'calling';
	$excel_data_field['recording'] = 'recording';


	$excel_data_field['utm_source'] = 'utm_source';
	$excel_data_field['utm_medium'] = 'utm_medium';
	$excel_data_field['utm_campaignname'] = 'utm_campaignname';
	$excel_data_field['utm_adgroupname'] = 'utm_adgroupname';
	$excel_data_field['utm_adgroupid'] = 'utm_adgroupid';
	$excel_data_field['utm_keyword'] = 'utm_keyword';
	$excel_data_field['utm_website'] = 'utm_website';
	$excel_data_field['utm_geo'] = 'utm_geo';
	$excel_data_field['utm_adtextid'] = 'utm_adtextid';
	$excel_data_field['utm_bannername'] = 'utm_bannername';

	$excel_data_field['utm_websitecategory'] = 'utm_websitecategory';
	$excel_data_field['utm_form_source_url'] = 'utm_form_source_url';
	$excel_data_field['utm_type'] = 'utm_type';





	$excel_data_field['submitted_on'] = 'submitted_on';

	$excel_data_field['last_comment'] = 'last_comment';


	set_time_limit(0);
	/* $Condation['cu']=array();
	  $Condation['lp']=array();
	  $Condation['owner']=array();
	  $Condation['lead_status']=array();
	  $param['client_id']=trim($this->_ns->Adv8Clientid);
	  $data=$this->_ObjClientLandingPageWebform->get_lead_detail($param,$Condation,'');
	 */
	$data = $this->_ns->_LeadArray;
	//print_R($data);exit;
	$filename = "public/report.xls";
	$realPath = realpath($filename);
	if (false === $realPath) {
	    touch($filename);
	    chmod($filename, 0777);
	}
	$filename = realpath($filename);
	$handle = fopen($filename, "w");
	$finalData = array();
	$head_tab = array();
	foreach ($excel_data_field as $hk => $hv) {
	    $head_tab[] = utf8_decode($hv);
	}
	$finalData[] = $head_tab;
	//print_r($finalData);
	// die;

	foreach ($data AS $row) {
	    $datafield = array();
	    $fields_data = (array) json_decode($row['fields_data']);



	    foreach ($excel_data_field as $fk => $fv) {
		$value = " ";
		if ($fv == "status_label") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "user_name") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "calling") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "recording") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "ctn") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "landing_page_url") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_source") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_medium") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_campaignname") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_adgroupname") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_adgroupid") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_keyword") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_website") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_geo") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_adtextid") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_bannername") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_websitecategory") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_form_source_url") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "utm_type") {
		    $value = $row[trim($fv)];
		} elseif ($fv == "submitted_on") {
		    $value = $row[trim($fv)];
		}elseif ($fv == "last_comment") {
		    $value = $row[trim($fv)];
		}elseif (isset($fields_data[trim($fv)])) {
		   
		    if($clientId == 144){
			if($fields_data['courses']=='') $fields_data['courses'] = $fields_data['course'];
			if($fields_data['course']!='') unset($fields_data['course']);
			
			if($fields_data['origin']=='') $fields_data['origin'] = $fields_data['ORIGIN'];
			if($fields_data['ORIGIN']!='') unset($fields_data['ORIGIN']);
		    }   
		    if (is_array($fields_data[trim($fv)]) || is_object($fields_data[trim($fv)]) ){
				$value = utf8_decode(implode(',', $fields_data[trim($fv)]). " 	");
		    }
		    else{
				$value = utf8_decode($fields_data[trim($fv)] . " 	");
			}

		}
		
		$datafield[] = $value;
	    }
	    //print_r($datafield);

	    /*
	      $datafield[]=utf8_decode( $row['status_label'] );
	      $datafield[]=utf8_decode( $row['user_name'] );
	      $datafield[]=utf8_decode( $row['landing_page_url'] );
	      $datafield[]=utf8_decode( $row['submitted_on'] );
	     */
	    $finalData[] = $datafield;
	}
	
	foreach ($finalData AS $finalRow) {
	
	    /*if(isset($excel_data_field["SUATID"])){
		
		print_R($finalRow);
		exit;
		$phone = trim($finalRow["5"]);
		$suat_id = trim($finalRow["9"]);
		//echo "Phone--".$phone;
		//echo "Suat-Id--".$suat_id;
		$where['phone'] = $phone;
		$filelds[] = 'suat_id';
		
		//print_R($finalRow);
		
		if(empty($suat_id)){
		   $fullFollowupArray = $this->_ObjShardaStudents->getDetail($where, $filelds);
		   if(!empty($fullFollowupArray)){
			$finalRow["10"] = $fullFollowupArray[0]['suat_id'];
		   }
		}
	    }*/
	    fputcsv($handle, $finalRow, "\t");
	}

	fclose($handle);
	$myfile = $filename;

	$response = new \Zend\Http\Response\Stream();
	$response->setStream(fopen($myfile, 'r')); //read file which you want to download as xls
	$response->setStatusCode(200);
	$headers = new \Zend\Http\Headers();
	$headers->addHeaderLine("Content-Type: application/vnd.ms-excel; charset=UTF-8")
		->addHeaderLine('Content-Disposition', 'attachment; filename=LeadReport.xls')
		->addHeaderLine("Content-Transfer-Encoding: binary")
		->addHeaderLine('Content-Length', filesize($myfile));
	$response->setHeaders($headers);

	return $response;
	die;
    }
	
	public function exportFollowupAction(){
		$sDate = $this->Xssplugin()->escape($this->getRequest()->getPost('sDateFlwp'));
		$eDate = $this->Xssplugin()->escape($this->getRequest()->getPost('eDateFlwp'));
		$client_id = $this->_ns->Adv8Clientid;
		$params = array();
		$params['sDate'] = $sDate;
		$params['eDate'] = $eDate;
		$data = $this->_ObjLeadWebDataFollowup->getLatestFollowUps($params);
		$statusArray = array('4', '5', '6', '7', '12', '14', '15', '16', '10');
		$webformArray = array();
		$fullFollowupArray = array();
		$followUpPreArray = array();
		foreach ($data as $k => $v) {
		    /* if (in_array($v['status'], $statusArray)) {
		      continue;
		      } */
		    $param['webform_data_id'] = $v['lead_id'];

		    $webformDetail = $this->_ObjClientLandingPageWebform->get_lead_detail_new($param, $this->_ns->CondationCheckBoxArray, $this->_ns->all_src);
		    ;
		    //print_R($webformDetail);exit;

		    if (empty($webformDetail)) {
			continue;
		    }

		    if (in_array($webformDetail[0]['status_id'], $statusArray)) {
			continue;
		    }


		    $fullFollowupArray = $this->_ObjLeadWebDataFollowup->get_Follow_Up(array('lead_id' => trim($v['lead_id'])));
		    if (isset($fullFollowupArray[1]['email_reminder_date'])) {
			//PRINT_R($fullFollowupArray);exit;
			$followUpPreArray[$v['lead_id']] = $fullFollowupArray[1]['email_reminder_date'];
		    } else {
			$followUpPreArray[$v['lead_id']] = '';
		    }

		    $tempArray = $webformDetail[0];
		   
		    $tempArray['email_reminder_date'] = $v['email_reminder_date'];

		    $flwpParam = array();
		    $flwpParam['userId'] = $tempArray['owner_id'];
		    $owner_name_array = $this->_ObjUsers->getUserDetail($flwpParam);
		    $owner_name = $owner_name_array[0]['user_name'];
		 	
		    $fields_data = json_decode($tempArray['fields_data'],true);
		    $fields_data['comments'] = $v['comments'];
		    $fields_data['owner_name'] = $owner_name;
		    $fields_data['landing_page_name'] = $tempArray['landing_page_name'];

		    unset($fields_data['lp url']);
		    unset($fields_data['utm adtextId']);
		    unset($fields_data['utm adgroupId']);
		    unset($fields_data['form type']);
		    unset($fields_data['form type']);
		    $webformArray[] = $fields_data;

		}
		  
		//echo json_encode($data);
		$this->_view->setTerminal(true);
		$filename = "Followups".date("Y-m-d H:i:s").'.xls';
		header("Content-type: application/vnd.ms-excel; name='excel'");
		header("Content-Disposition: attachment; filename=exportfile.xls");
		header("Pragma: no-cache");
		header("Expires: 0");
		$sep = "\t";
		
		$k = 0;
		foreach($webformArray as $row){
			
			//print_r($row); die;
			//unset($row['fields_data']);
			if($k<1){
				echo "Name" . "\t";
				echo "Email" . "\t";
				echo "Phone" . "\t";
				echo "Query" . "\t";
				echo "Comments" . "\t";
				echo "Owner Name" . "\t";
				echo "Landing Page Name" . "\t";
				print("\n"); 
			}
			$schema_insert = "";
			foreach($row as $col=>$val){
				if(!isset($val))
					$schema_insert .= "NULL".$sep;
				elseif ($val != "")
					$schema_insert .= "$val".$sep;
				else
					$schema_insert .= "".$sep;
			}
			$schema_insert = str_replace($sep."$", "", $schema_insert);
			$schema_insert = preg_replace("/\r\n|\n\r|\n|\r/", " ", $schema_insert);
			$schema_insert .= "\t";
			print(trim($schema_insert));
			print "\n";
			
			$k++;
		} 
		exit;
	}

    public function lmsListAjaxAction() {
	$agencyId = $this->_agencyId;
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('companyId'));
	$result = $this->_ObjClientLandingPage->getLmsList($clientId);
	echo json_encode($result);
	$this->_view->setTerminal(true);
	exit;
    }

    public function getCampaignByClientAjaxAction() {

	$agencyId = $this->_agencyId;
	$clientId = $this->Xssplugin()->escape($this->getRequest()->getPost('companyId'));
	$result = $this->_ObjClientBusinessUnit->getCampaignListByClientList($clientId);
	echo json_encode($result);
	$this->_view->setTerminal(true);
	exit;
    }

    public function addAction() {
	$agencyId = $this->_agencyId;
	$data = $_POST;
	$dataArrayFirst = array('client_id' => $data['companyName'], 'business_unit_id' => $data['Business_unit'], 'landing_page_name' => $data['LPname'], 'landing_page_url' => $data['url']);
	$result = $this->_ObjClientLandingPage->addLms($dataArrayFirst);
	return $this->redirect()->toUrl('/lms/list');
    }

    public function addnewleadAction() {
	$clientId = trim($this->_ns->Adv8Clientid);
	$campaignUniltList = $this->_ObjClientBusinessUnit->getCampaignsList($clientId, $filelds = array('id', 'business_unit_name'));
	
	$data['clientId'] = $clientId;
	$ownerList = $this->_ObjUsers->getUserDetail($data);
	
	$this->_view->campaignUniltList = $campaignUniltList;
	$this->_view->ownerList = $ownerList;
	$this->_view->clientId = $clientId;
	return $this->_view;
    }

    function getLandingPageByCampaignUnitAction() {
	$data['cuId'] = $this->getRequest()->getPost('cuId');
	$landingPageList = $this->_ObjClientLandingPage->getLandingPageList($data, $fields = array('id', 'landing_page_name'));
	echo json_encode($landingPageList);
	$this->_view->setTerminal(true);
	die;
    }

    function getWebFormByLandingPageAction() {
	
	$data['lpId'] = $this->getRequest()->getPost('lpId');
	$webformList = $this->_ObjClientLandingPageWebform->getWebFormList($data, $fields = array('id', 'web_form_name'));
	echo json_encode($webformList);
	$this->_view->setTerminal(true);
	die;
    }

    public function getLandingPageDataByIdAction() {
	$landingId = $this->Xssplugin()->escape($this->getRequest()->getPost('landingId'));
	$result = $this->_ObjClientLandingPage->getLandingPageDataById($landingId);
	echo json_encode($result);
	$this->_view->setTerminal(true);
	exit;
    }
    
    public function addNewLeadSaveAction() {
	$error = false;
	$msg = '';
	$fieldsDataArray = array();
	
	foreach($_POST['requirements'] as $k=>$v){
	    if(!empty($v['fieldname']) && !empty($v['fieldvalue'])){
		$fieldsDataArray[$v['fieldname']] = $v['fieldvalue'];
	    }
	}
	
	if(!empty($fieldsDataArray)){
	    $data['client_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('clientId'));
	    $data['business_unit_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('campaign_unit'));
	    $data['landing_page_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('lp'));
	    $data['webform_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('webform'));
	    $data['submitted_on'] = $this->Xssplugin()->escape($this->getRequest()->getPost('submittedOn'));
	    $data['owner_id'] = $this->Xssplugin()->escape($this->getRequest()->getPost('owner'));
	    $data['fields_data'] = json_encode($fieldsDataArray);
	    $data['duplicate'] = 0;

	    $this->_ObjClientLandingPageWebformData->save($data);
	    $msg = 'Successfully Inserted';
	}else{
	    $error = true;
	    $msg = 'Field Value cannot be empty';
	}
	
	$arr['error'] = $error?1:0;
	$arr['msg'] = $msg;
	//print_R($data);
	echo json_encode($arr);
	$this->_view->setTerminal(true);
	die();
    }

    public function getProductGraphAction() {
	$this->_view->setTerminal(true);
	exit;
    }

    public function getStatusGraphAction() {
	$this->_view->setTerminal(true);
	exit;
    }

    public function getOwnerGraphAction() {
	$this->_view->setTerminal(true);
	exit;
    }

    public function getCampaignUnitGraphAction() {
	$this->_view->setTerminal(true);
	exit;
    }
    
     public function saveLeadShareUserAction() {
	 
	$partials_lead_share = $this->Xssplugin()->escape($this->getRequest()->getPost('partials_lead_share'));
	$hdn_webformdata_id = $this->Xssplugin()->escape($this->getRequest()->getPost('hdn_webformdata_id'));
	
	
	$this->_ObjClientLandingPageWebformData->update(array('lead_sharing_id' => $partials_lead_share), array('webform_data_id' => $hdn_webformdata_id));
	
	$result['error'] = false;
	
	echo json_encode($result);
	$this->_view->setTerminal(true);
	exit;
    }
	
	public function addConvertLeadAction(){
		echo ""; print_r($_POST); exit;
	}

}
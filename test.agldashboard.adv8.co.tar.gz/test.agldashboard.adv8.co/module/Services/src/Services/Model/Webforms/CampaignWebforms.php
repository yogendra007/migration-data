<?php 
Namespace Services\Model\Webforms;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Services\Model\Dbnfun;

class CampaignWebforms{
	protected $_db;
	protected $_table;
	public $_ObjCmnfunctions;
	public $_sql;
	
	function __construct($adapter) {
		$this->_table='adv8_client_landing_page_webform';
		$this->_db= $adapter;
		$this->_sql = new Sql($adapter);
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		
	}
	
	function getWebformList($fields,$where){
		return $this->_ObjCmnfunctions->sql_fetchall($fields,$where,'','','',false);
    }
	
	function editWebformList($fields,$where){
		return $this->_ObjCmnfunctions->sql_fetchall($fields,$where,'','','',false);
	}
	
	function updateWebformList($dataArray,$where){
		return  $this->_ObjCmnfunctions->sql_update($dataArray,$where);
	}
	
	function delWebform($fields,$where){
		return  $this->_ObjCmnfunctions->sql_update($fields,$where);
	}
	
	function addWebfrm($dataArrayFirst){
		return $lastId = $this->_ObjCmnfunctions->sql_save($dataArrayFirst);
	}
	
	function updateWebformFields($dataArray,$where){
		//echo "<pre>"; print_r($dataArray); die(' asda');
		return  $this->_ObjCmnfunctions->sql_update($dataArray,$where);
	}
	
	/*function addDashboardFields($dataArray,$where){
		//echo "<pre>"; print_r($dataArray); die(' asda');
		return  $this->_ObjCmnfunctions->sql_update($dataArray,$where);
	}*/
}
?>
<?php Namespace Services\Model\Role;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Services\Model\Dbnfun;
use Zend\Session\Container;

class AclPrivilege{
	protected $_db;
	protected $_ns;
	protected $_table;
	protected $_adapter;
	public $_ObjCmnfunctions;
	public $_ObjCatalog_project_keys;
	function __construct($adapter) {		
		$this->_table='adv8_acl_privilege';
		$this->_ns = new Container('Adv8360');
		$this->_db= $adapter;
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		$this->_sql = new Sql($adapter);
	}
	function getPrivilege($role_id,$type="A"){		
		$role_id=trim($role_id);
		$select = $this->_sql->select();
		$select->from($this->_table);
		$select->columns(array('k'=>new \Zend\Db\Sql\Expression('CONCAT(`controllers`,"_",`actions`)'),'is_allow'));		
		$select->quantifier('DISTINCT');
		$select->where->addPredicate(new Predicate\Expression('role_id = ?', trim($role_id)));
		$select->where->addPredicate(new Predicate\Expression('type = ?', trim($type)));
		$select->where->addPredicate(new Predicate\Expression('agency_client_id = ?', trim($this->_ns->Adv8Clientid)));
		return $this->_ObjCmnfunctions->prepareStatement($select,false);									

	}
	function is_allow($controller,$action,$type){
		$where=array('controllers'=>'All','actions'=>'All','type'=>$type,'agency_client_id'=>$this->_ns->Adv8Clientid,'role_id'=>$this->_ns->Adv8Aclid);
		$allow=$this->_ObjCmnfunctions->sql_fetchall(array('is_allow'),$where,true,'','',false);									
		$access='N';
		if(sizeof($allow)>0){
			$access=trim($allow[0]['is_allow']);
		}else{
			
			$where=array('controllers'=>trim($controller),'actions'=>trim($action),'type'=>$type,'agency_id'=>$this->_ns->Adv8Agencyid,'role_id'=>$this->_ns->Adv8Aclid);
			$allow=$this->_ObjCmnfunctions->sql_fetchall(array('is_allow'),$where,true,'','',false);									
			if(sizeof($allow)>0){
				$access=trim($allow[0]['is_allow']);
			}	
		}
		
		return $access;
	}
	function DelPrivilege($role_id,$type="A",$agency_id){		
		$role_id=trim($role_id);
		$where=array('role_id'=>trim($role_id),'type'=>trim($type),'agency_id'=>$agency_id,'agency_client_id'=>$this->_ns->Adv8Clientid);
		return $this->_ObjCmnfunctions->sql_delete($where);									
	}
	function AddPrivilege($role_id,$controller="All",$action="All",$client_id,$agency_id,$user_id,$type="A"){		
	//'agency_client_id'=>$client_id
		$data=array('role_id'=>$role_id,'controllers'=>$controller,'actions'=>$action,'agency_client_id'=>$client_id,'agency_id'=>$agency_id,'is_allow'=>'Y','created_by_user_id'=>$user_id,'type'=>trim($type));
		return $this->_ObjCmnfunctions->sql_save($data);
	}
}
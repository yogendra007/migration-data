<?php

Namespace Services\Model;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class GoogleAdgroupPerformanceReport {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {

	$this->_table = 'adv8_google_adgroup_performance_report';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
    }

    public function getAdgroupData($data) {
	$res = array();
	$gcid = explode(",", $data['gcidStr']);

	$select = $this->_sql->select();
	$select->from($this->_table);
	
	$select->columns(array('adgroup_id', 'adgroup_name', 'currency', 'clicks', 'impressions', 'cost', 'avg_cpc', 'avg_position', 'campaign_id', 'gcid', 'converted_clicks', 'campaign_name', 'adgroup_state'));
	$select->where->in('gcid', $gcid);

	$select->where->addPredicate(new Predicate\Expression('day >= ?', trim($data['fDate'])));
	$select->where->addPredicate(new Predicate\Expression('day <= ?', trim($data['tDate'])));
		

	if($data['sortBy']!=''){
	    $sortBy = trim($data['sortBy']) ." ".trim($data['orderBy']);
	    $select->order($sortBy);
	}
		
	if (!empty($data['limit'])) {
	    if (!empty($data['offset'])) {
		$select->offset(trim($data['offset']));
		$select->limit(trim($data['limit']));
	    } else {
		$select->limit(trim($data['limit']));
	    }
	}
	return $this->_ObjCmnfunctions->prepareStatement($select);
	
    }
    
    public function getDefaultValues($data) {
	$where = new Where();
	$gcid = explode(",", $data['gcidStr']);
	$where->in('gcid', $gcid);
	$field = array('currency');
	$res = $this->_ObjCmnfunctions->sql_fetch_all($field, $where, true);
	$currency = "";
	foreach ($res as $rows) {
	    $currency = $rows['currency'];
	}
	return $currency;
    }

}


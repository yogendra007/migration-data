<?php
Namespace Services\Model;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class InfoGroupHead {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {
	$this->_table = 'adv8_team_user_mapping';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
    }

    public function getAllGroupHeads($parmas) {
	$select = $this->_sql->select();
	$select->from('adv8_info_group_head');
	$field = array('user_id', 'id');
	$select->columns($field);
	if(!empty($parmas['userId'])){
	    $select->where->addPredicate(new Predicate\Expression('user_id = ?', $parmas['userId']));
	}
	$select->where->addPredicate(new Predicate\Expression('status = ?', '1'));
	return $res = $this->_ObjCmnfunctions->prepareStatement($select);
    }
    
     public function getAllGroupHeadsDetail($parmas) {
	 
	$select = $this->_sql->select();
	$select->from(array('cm' => 'adv8_info_group_head'))->columns(array('user_id'))
		->join(array('u' => 'adv8_users'), 'cm.user_id = u.id', array('user_name'), 'inner');

	$select->where->addPredicate(new Predicate\Expression('cm.status = ?', '1'))
	->where->addPredicate(new Predicate\Expression('u.status = ?', '1'));

	if(!empty($parmas['userId'])){
	    $select->where->addPredicate(new Predicate\Expression('user_id = ?', $parmas['userId']));
	}
	
	return $res = $this->_ObjCmnfunctions->prepareStatement($select);
    }
}
<?php Namespace Services\Model;
use Services\Model\Users;
use Services\Model\Dbnfun;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
class Catalogprojectkeys{
	protected $_db;
	protected $_table;
	protected $_adapter;
	public $_cmnfunctions;
	function __construct($adapter) {
		$this->_table='adv8_catalog_project_keys';
		$this->_cmnfunctions=new Dbnfun($adapter,$this->_table);
	}
	function save($data){
		return $this->_cmnfunctions->sql_save($data);
	}	
	public function getAppsKeysArray($sKeys) {
		$where = new Where();
		$field=array('COUNT'=>new \Zend\Db\Sql\Expression('COUNT(*)'));
	//	$where->addPredicate(new Predicate\Expression('keys = ?', trim($sKeys)));
		$CountFound=$this->_cmnfunctions->sql_fetch_all($field,$where);
		$res=0;
		foreach ($CountFound as $row) {
			$res=$row['COUNT'];
		}
		return trim($res);		
   }
	
}	
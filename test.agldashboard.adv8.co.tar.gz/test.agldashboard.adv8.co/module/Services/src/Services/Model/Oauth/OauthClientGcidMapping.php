<?php
Namespace Services\Model\Oauth;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class OauthClientGcidMapping {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {
	$this->_table = 'oauth_client_gcid_mapping';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
    }

    public function getData($parmas) {
	$select = $this->_sql->select();
	$select->from($this->_table);
	$field = array('id', 'gcid', 'agency_client_id');
	$select->columns($field);
	$select->where->addPredicate(new Predicate\Expression('client_refresh_tokens_id = ?', $parmas['tableId']));
	
	return $res = $this->_ObjCmnfunctions->prepareStatement($select);
    }

}
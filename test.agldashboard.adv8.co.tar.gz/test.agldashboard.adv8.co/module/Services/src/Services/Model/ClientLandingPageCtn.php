<?php Namespace Services\Model;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class ClientLandingPageCtn{
	protected $_db;
	protected $_table;
	protected $_adapter;
	public $_ObjCmnfunctions;

	function __construct($adapter) {
		
		$this->_table='adv8_client_landing_page_ctn';
		$this->_db= $adapter;
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		$this->_sql = new Sql($adapter);

	}
	
	public function getDetail($fields,$where){
		return $objreturn = $this->_ObjCmnfunctions->sql_fetchall($fields,$where,'','','',false);
	}
	
	public function editCtn($fields,$where){
		return $this->_ObjCmnfunctions->sql_fetchall($fields,$where,'','','',false);
	}
	
	public function saveDataCtn($dataArr){
		return  $this->_ObjCmnfunctions->sql_save($dataArr);
	}
	
	public function updateCtn($fields,$where){
		return  $this->_ObjCmnfunctions->sql_update($fields,$where);
	}
	
	public function delCtn($fields,$where){
		return  $this->_ObjCmnfunctions->sql_update($fields,$where);
	}
	public function updateNumber($params) {
    	try {
    		
    		$update = $this->_sql->update();
			$update->table($this->_table);

			$update->set(array('forwarding_number' => $params['forwading_number']));
			
			$update->where(array (
							'call_tracking_number' => $params['call_tracking_no'],
							'client_id' => $params['client_id']
						));

			$statement 		= $this->_sql->prepareStatementForSqlObject($update);
			$effectedRows   = $statement->execute()->getAffectedRows();		
			return $effectedRows;
    	} catch(Exception $ex) {
    		return 0;
    	}    	
    }

    public function updateNumberInOldAgl($params) {
	    $_db = new \Zend\Db\Adapter\Adapter(array (
	    	'driver' => 'PdoMysql',
	        'host'     => '198.12.156.187',
	        'username' => 'advaitcustdb',
	        'password' => 'AI389imc739Dyexy8',
	        'dbname'   => 'advait_cust'
	    ));
	    try {

	    	$sql = new Sql($_db);
	    	$update = $sql->update();
			$update->table('cust_project_landing_page');

			$update->set(array('FORWARDING_NO' => $params['forwading_number']));

			$update->where(array ('CALL_TRACKING_NUMBER' => $params['call_tracking_no']));

			$statement = $sql->prepareStatementForSqlObject($update);
			$effectedRows   = $statement->execute()->getAffectedRows();			
			return $effectedRows;

	    } catch (Exception $ex) {
	    	//print_r($ex->getMessage());
	    }
	    
    }

}
?>

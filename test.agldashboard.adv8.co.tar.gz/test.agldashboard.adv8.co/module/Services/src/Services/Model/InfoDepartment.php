<?php Namespace Services\Model;
use Zend\Session\Container;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Services\Model\Dbnfun;


class InfoDepartment{
	protected $_db;
	protected $_table;
	protected $_adapter;
	public $_ObjCmnfunctions;

	function __construct($adapter) {		
		$this->_table='adv8_info_department';
		$this->_db= $adapter;
		$this->_sql = new Sql($adapter);
		$this->_ns = new Container('Adv8360');
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		$this->_sql = new Sql($adapter);
	
	}
	function get_department(){
			return $role= $this->_ObjCmnfunctions->sql_fetchall(array('id','department'),array('status'=>'1','client_id'=>$this->_ns->TAdv8Clientid));
	}
	
}
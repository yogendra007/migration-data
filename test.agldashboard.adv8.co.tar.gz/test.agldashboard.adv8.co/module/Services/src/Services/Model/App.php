<?php Namespace Services\Model;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;
use Services\Model\Catalogprojectkeys;

class Users{
	protected $_db;
	protected $_table;
	protected $_adapter;
	public $_ObjCmnfunctions;
	public $_ObjCatalog_project_keys;
	function __construct($adapter) {
		
		$this->_table='adv8_users';
		$this->_db= $adapter;
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		$this->_sql = new Sql($adapter);
		$this->_ObjCatalog_project_keys=new Catalogprojectkeys($adapter);
	}
function loag_auth($userEmail,$password){	
	$authAdapter = new AuthAdapter($this->_db);
	$authAdapter->setTableName($this->_table)
		->setIdentityColumn('user_email')
		->setCredentialColumn('user_password');
	$authAdapter->setIdentity($userEmail)
		->setCredential($password);		
	return $authAdapter;	 	
		 
}
  function login($userEmail,$password,$sKeys) {
	  
		$netRess = array();
		$userEmail = trim($userEmail);
        $password = trim($password);
        $sKeys = trim($sKeys);
         $sChecker = $this->_ObjCatalog_project_keys->getAppsKeysArray($sKeys);
        if ($sChecker == 1) {
           $authAdapter=$this->loag_auth($userEmail,$password);
		   $result = $authAdapter->authenticate($authAdapter);	
            /**
             * Check Login success or not
             */
            if ($result->isValid()) {
				$columnsToReturn = array('id','agency_client_id','agency_id','user_email','user_name','user_email','user_role','status','user_password');
				$netRess1 =$authAdapter->getResultRowObject($columnsToReturn);
                //$netRess1 =  $this->getLoggedInUserDetails($userEmail, $password);
                $netRess = (array) $netRess1;
				
                if ($netRess['status'] == 0) {
                    /**
                     * Unactive Status
                     */
                    $error = true;
                    $msg = "Unauthorized Access";
                    $systemmessage = "user is not active";
					$netRess  = array();
                    //$result = $Login->deActive();
                    
                } else {
                    /**
                     * print success request
                     */
                    $error = false;
                    $msg = "Success";

                }
            } else {
                /**
                 * wrong password and username
                 */
                $error = true;
                $msg = "Username and password combination is wrong";
                $systemmessage = "Username and password combination is wrong";
                
            }
        } else {
            //Unsecure skeys
            $error = true;
			$msg = "Unauthorized Access";
			$systemmessage = "Security key is not valid";
        }
        
		if(!$error){
			$error = false;
			$msg = "Success";
		}
		
		$arr['error'] = $error?1:0;
		$arr['message'] =  $msg;
		if(!empty($systemmessage)){
			$arr['systemMessage'] =  $systemmessage;
		}
		$arr['data'] =  $netRess;
		
		$jsonResponse = json_encode($arr);
		return  $jsonResponse;
		
    }	
	function update($data,$where){
		return $this->_ObjCmnfunctions->sql_update($data,$where);
		
	}
	function save($data){
		return $this->_ObjCmnfunctions->sql_save($data);
	}	
	
	public function userList($agencyId,$clientId='') {
		$select = $this->_sql->select();
		$select->from(array('ag'=>$this->_table),array('agency_id','user_department','user_role','agency_client_id','user_role','user_name','user_email','user_password','user_mobile_number','status'))
				->join(array('rl'=>'adv8_info_role'),'ag.user_role = rl.id ',array('role_name'));		
				$select->where(new Predicate\Expression('ag.agency_client_id != ?', '0'),Predicate\PredicateSet::OP_AND);
				$select->where(array("ag.agency_id"=>trim($agencyId)),Predicate\PredicateSet::OP_AND);
				if(!empty($clientId))
				{				
					$select->where(array("ag.agency_client_id"=>trim($clientId)),Predicate\PredicateSet::OP_AND);
				}
		$statement = $this->_sql->prepareStatementForSqlObject($select);
		$Res = $statement->execute();
		$MasterRes=array();
		foreach($Res as $row){
			$MasterRes[]=$row;
		}
		return $MasterRes;	
	}
	public function userListByClient($agencyId,$clientId) { 		
		$select = $this->_sql->select();
		$select->from(array('ag'=>$this->_table),array('id','agency_id','agency_client_id','user_role','user_name','user_email'))
				->join(array('rl'=>'adv8_info_role'),'ag.user_role = rl.id ',array('role_name'));					
				$select->where(array("ag.agency_id"=>trim($agencyId)),Predicate\PredicateSet::OP_AND);
				$select->where(array("ag.agency_client_id"=>trim($clientId)),Predicate\PredicateSet::OP_AND);
				
		$statement = $this->_sql->prepareStatementForSqlObject($select);
		$Res = $statement->execute();
		$Rec=array();
		foreach($Res as $row){
			$Rec[]=$row;
		}
		return $Rec;	
    }
	
}	
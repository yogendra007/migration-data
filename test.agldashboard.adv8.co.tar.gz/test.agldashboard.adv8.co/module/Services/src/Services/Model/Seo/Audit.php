<?php Namespace Services\Model\Seo;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Services\Model\Dbnfun;
use Zend\Db\Sql\Expression;


class Audit{
	protected $_db;
	protected $_table;
	public $_ObjCmnfunctions;
	public $_sql;
	
	
	function __construct($adapter) {
		$this->_table='adv8_seo_project_audit';
		$this->_db= $adapter;
		$this->_sql = new Sql($adapter);
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
	}

	function add($dataArray) {
		
		 $this->_ObjCmnfunctions->sql_save($dataArray);

	}

	public function getAuditDetailsById($pId) {
		$select = $this->_sql->select();
		$select->from($this->_table);
		$select->where(array("p_id"=>trim($pId)));
		$select->order('created_at DESC');
		$select->limit(1);
		$statement = $this->_ObjCmnfunctions->prepareStatement($select);
		return $statement;
				
	}

	public function getAuditDateReport($clientId){
		$select = $this->_sql->select();
		$select->from(array('P_A'=>$this->_table))
		->columns(array('audit_date'=>new Expression('DATE_FORMAT(P_A.created_at, "%M %d, %Y" )')))
		->join(array('S_P'=>'adv8_seo_projects'),'P_A.p_id = S_P.p_id',array(),'inner');
		$select->where(array("S_P.client_id"=>trim($clientId)))
		->order('P_A.created_at DESC')
		->limit(1);
		$statement = $this->_ObjCmnfunctions->prepareStatement($select);
		return $statement[0];
	}

	
	

}



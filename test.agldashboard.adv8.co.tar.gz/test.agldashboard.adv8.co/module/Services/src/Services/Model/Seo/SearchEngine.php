<?php Namespace Services\Model\Seo;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Expression;
use  Zend\Db\Sql\Where;
use Services\Model\Dbnfun;


class SearchEngine{
	protected $_db;
	protected $_table;
	public $_ObjCmnfunctions;
	public $_sql;
	
	
	function __construct($adapter) {
		$this->_table='adv8_search_engine_code';
		$this->_db= $adapter;
		$this->_sql = new Sql($adapter);
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
	}

	function getSearchEngine() {
		$select = $this->_sql->select();
		$select->from($this->_table);
		$select->columns(array('SEARCH_ENGINE'));
		$select->quantifier('DISTINCT');
		$statement = $this->_ObjCmnfunctions->prepareStatement($select);
		return $statement;
	}

	function getCountryAjax($search_engine_value) {
		$select = $this->_sql->select();
		$select->from($this->_table);
		$select->columns(array('COUNTRY'));
		$select->quantifier('DISTINCT');
		$select->where(array("SEARCH_ENGINE"=>$search_engine_value));
		$statement = $this->_ObjCmnfunctions->prepareStatement($select);
		return $statement;
	}

	function getCityAjax($search_engine_value,$country) {
		$select = $this->_sql->select();
		$select->from($this->_table);
		$select->columns(array('CITY','SE_ID'));
		$select->where(array("SEARCH_ENGINE"=>$search_engine_value));
		$select->where(array("COUNTRY"=>$country));
		$statement = $this->_ObjCmnfunctions->prepareStatement($select);
		return $statement;
	}

	function getAddedSearchEngine($pId) {
		$select = $this->_sql->select();
		$select->from(array('S_E'=>$this->_table),array('COUNTRY','SEARCH_ENGINE','CITY','SE_ID'))
		->join(array('api'=>'adv8_seo_project_api'),'S_E.SE_ID = api.search_engine_id',array('api_id','p_id'),'inner');
		$select->where(array("api.p_id"=>trim($pId)));
		$statement = $this->_ObjCmnfunctions->prepareStatement($select);
		return $statement;
	}


	public function graphSeoKeywordAjax($data) {
		
		$keyword_rankwatch_id = $data['keyword_rankwatch_id'];
		$seId = $data['seId'];
		$select = $this->_sql->select();
		$select->from(array('S_E'=>$this->_table)) //CONCAT_WS('-',b.SEARCH_ENGINE,b.COUNTRY,b.CITY)
		->columns(array('SEARCH_ENGINE_NAME'=> new Expression("CONCAT_WS('-',SEARCH_ENGINE,COUNTRY,CITY)")))
		->join(array('K_R'=>'adv8_keyword_rank'),'S_E.SE_ID = K_R.search_engine_id',array('current_rank','added_on'=>new Expression('DATE_FORMAT(created_at, "%d %M" )')),'inner');
		$select->where(array("K_R.keyword_rankwatch_id"=>trim($keyword_rankwatch_id)));
		$statement = $this->_ObjCmnfunctions->prepareStatement($select);
		$search_engine_array = array();
		foreach ($statement as $key => $value) {
			$search_engine_array[$value['SEARCH_ENGINE_NAME']][] = array('current_rank' => $value['current_rank'],'added_on' => $value['added_on']);

		}
		return $search_engine_array;
	}

	public function getSearchEngineByIntialRank($pId) {
		$select = $this->_sql->select();
		$select->from(array('S_E'=>$this->_table))
		->columns(array('SEARCH_ENGINE_NAME'=> new Expression("CONCAT_WS('-',SEARCH_ENGINE,COUNTRY,CITY)"),'SE_ID'))
		->join(array('P_A'=>'adv8_seo_project_api'),'S_E.SE_ID = P_A.search_engine_id',array(),'inner');
		$select->where(array("P_A.p_id"=>trim($pId)));
		$statement = $this->_ObjCmnfunctions->prepareStatement($select);
		return $statement;
	}

	
	

}



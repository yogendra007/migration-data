<?php

Namespace Services\Model;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;
use Zend\Session\Container;
use Services\Model\ClientBusinessUnitPublisher;

class ClientBusinessUnit {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;
    public $_ObjCatalog_project_keys;
    public $_ObjClientBusinessUnitPublisher;

    function __construct($adapter) {

	$this->_table = 'adv8_client_business_unit';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
	$this->_ObjClientBusinessUnitPublisher = new ClientBusinessUnitPublisher($adapter);
	$this->_ns = new Container('Adv8360');
    }

    function update_ClientBusinessUnit($field, $where) {
	$this->_ObjCmnfunctions->sql_update($field, $where);
    }

    function getCampaignUnitById($campaignUnitId) {
	$field = array('business_unit_name', 'business_unit_id' => 'id', 'client_id');
	$where = array('id' => trim($campaignUnitId));
	return $this->_ObjCmnfunctions->sql_fetchall($field, $where);
    }

    function getCampaignUnitsSummery($cid,$campaignId='',$product='',$status='',$userId='', $sDate='', $eDate='' , $is_deleted = '0') {
		$select = $this->_sql->select();
		$select->from(array('a' => $this->_table))
			->columns(array('id', 'business_unit_name'))
			->join(array('b' => 'adv8_client_landing_page_webform'), 'a.id=b.business_unit_id ', array('business_unit_id', 'webform_id' => 'id'), 'inner')
			->join(array('c' => 'adv8_client_landing_page_webform_data'), 'c.webform_id=b.id ', array('COUNT' => new \Zend\Db\Sql\Expression('COUNT(webform_id)'), 'webform_data_id'), 'inner');
		//	$select->where->addPredicate(new Predicate\Expression('d.user_role >= ?', trim($this->_ns->Adv8Roleid)));		
		$ides = explode(',', $this->_ns->Child_User_Id);
		//$select->where->in('c.owner_id', $ides);
		
		$select->where->addPredicate(new Predicate\Expression("( c.owner_id in (" . $this->_ns->Child_User_Id . ") ||  FIND_IN_SET(".$this->_ns->Adv8Uid.", c.lead_sharing_id) )"));
		
		$select->where->between('c.submitted_on', $sDate, $eDate);
		$select->where->addPredicate(new Predicate\Expression('c.is_deleted = ?', trim($is_deleted)));
		$select->where->addPredicate(new Predicate\Expression('a.client_id = ?', trim($cid)));
		if($campaignId) $select->where(array('c.business_unit_id' => $campaignId));

		$select->group(array('a.id'));
		$statement = $this->_ObjCmnfunctions->prepareStatement($select,false);
		return $statement;
    }

    public function getCampaignUnits($data) {
	$field = array('id', 'business_unit_name');
	$where->addPredicate(new Predicate\Expression('business_unit_id = ?', trim($data['cuId'])));
	if (!empty($data['status'])) {
	    if ($data['status'] == 2) {
		$data['status'] = 0;
	    }
	    $where->addPredicate(new Predicate\Expression('status = ?', trim($data['status'])));
	}
	$where->addPredicate(new Predicate\Expression('client_id = ?', trim($data['cId'])));
	return $this->_ObjCmnfunctions->sql_fetch_all($field, $where);
    }

    public function getCampaignsList($clientId, $filelds = array()) {

	if (sizeof($filelds) > 0)
	    $filelds = $filelds;
	else
	    $filelds = array('buId' => 'id', 'business_unit_name');
	//$where = new Where();
	$select = $this->_sql->select();
	$select->from($this->_table);
	$select->columns($filelds);
	$select->where(array('client_id' => $clientId));
	$select->where(array('status' => '1'));
	$statement = $this->_ObjCmnfunctions->prepareStatement($select, false);
	return $statement;
    }

    public function add($data) {
	
	//print_r($data);
	$dataArrayFirst = array('client_id' => $data['companyName'], 'business_unit_name' => $data['businessUnit']);
	$businessUnitId = $this->_ObjCmnfunctions->sql_save($dataArrayFirst);
	
	if(empty($data['mapped_flag'])){
	    $mapped_flag = 0;
	}else{
	    $mapped_flag = $data['mapped_flag']; 
	}
	foreach ($data['publisher'] as $publishers) {
	    if ($publishers == 'google') {
		$publisherData = '1';
		$publisher_account_id = $data['google'];
		$googleDate = explode(',', $data['googleDate']);
		$service_from = $googleDate[0];
		$service_to = $googleDate[1];
	    } elseif ($publishers == 'fb') {
		$publisherData = '2';
		$publisher_account_id = $data['fb'];
		$fbDate = explode(',', $data['fbDate']);
		$service_from = $fbDate[0];
		$service_to = $fbDate[1];
	    } elseif ($publishers == 'bing') {
		$publisherData = '3';
		$publisher_account_id = $data['bing'];
		$bingDate = explode(',', $data['bingDate']);
		$service_from = $bingDate[0];
		$service_to = $bingDate[1];
	    }
	    $dataArraySecond = array('client_id' => $data['companyName'], 'business_unit_id' => $businessUnitId,
		'publisher_id' => $publisherData, 'publisher_account_id' => $publisher_account_id, 'service_from' => $service_from, 'service_to' => $service_to, 'status' => '1','mapped_flag'=>$mapped_flag);
	    $buPub = $this->_ObjClientBusinessUnitPublisher->add($dataArraySecond);
	}

	return $businessUnitId;
    }
	
	public function upCamp($field,$where){
		return $this->_ObjCmnfunctions->sql_update($field,$where);
	}
    
    public function createBusinessUnit($data) {
	$businessUnitId = $this->_ObjCmnfunctions->sql_save($data);
	return $businessUnitId;
    }
    
    
    
    public function getCampaignListByClientList($clientId) {

	$where = new Where();
	$select = $this->_sql->select();
	$select->from($this->_table)
		->columns(array('buId' => 'id', 'business_unit_name','created_at'))
		->where(array('client_id' => $clientId))
		->where(array('status' => '1'));
	$statement = $this->_ObjCmnfunctions->prepareStatement($select);
	return $statement;
    }
    
    function getCampaignUnitsMapping($data) {
	$select = $this->_sql->select();
	$select->from(array('a' => $this->_table))
		->columns(array('id', 'business_unit_name','created_at'))
		->join(array('b' => 'adv8_client_business_unit_publisher'), 'a.id=b.business_unit_id', array('publisher_account_id'), 'inner')
	->where->addPredicate(new Predicate\Expression('a.status = ?', '1'))
	->where->addPredicate(new Predicate\Expression('b.status = ?', '1'));
	if (!empty($data['clientId'])) {
	   $select->where(array('a.client_id' => $data['clientId']));
	}
	if (!empty($data['publisherId'])) {
	   $select->where(array('b.publisher_id' => $data['publisherId']));
	}
	if (!empty($data['businessUnitId'])) {
	   $select->where(array('a.id' => $data['businessUnitId']));
	}
	return $this->_ObjCmnfunctions->prepareStatement($select);
    }
    
    function getCampaignUnitsAnalyticsMapping($data) {
	$select = $this->_sql->select();
	$select->from(array('a' => $this->_table))
		->columns(array('id', 'business_unit_name','created_at'))
		->join(array('b' => 'adv8_client_business_unit_analytics_mapping'), 'a.id=b.business_unit_id', array('profile_id'), 'inner')
	->where->addPredicate(new Predicate\Expression('a.status = ?', '1'))
	->where->addPredicate(new Predicate\Expression('b.status = ?', '1'));
	if (!empty($data['clientId'])) {
	   $select->where(array('a.client_id' => $data['clientId']));
	}
	if (!empty($data['businessUnitId'])) {
	   $select->where(array('a.id' => $data['businessUnitId']));
	}
	return $this->_ObjCmnfunctions->prepareStatement($select);
    }
    
    function getCampaignUnitsDetail($data) {

	$select = $this->_sql->select();
	$select->from(array('a' => $this->_table))
		->columns(array('id', 'business_unit_name','created_at'))
		->join(array('b' => 'adv8_client_business_unit_publisher'), 'a.id=b.business_unit_id', array('publisher_account_id','publisher_id'), 'left')
		->join(array('c' => 'adv8_client_business_unit_analytics_mapping'), 'a.id=c.business_unit_id', array('profile_id','domain_name'), 'left')
	->where->addPredicate(new Predicate\Expression('a.status = ?', '1'));
	if (!empty($data['clientId'])) {
	   $select->where(array('a.client_id' => $data['clientId']));
	}
	
	return $this->_ObjCmnfunctions->prepareStatement($select);
    }
	
	function updateSingleCampaign($data) {
		$select = $this->_sql->select();
		$select->from(array('a' => $this->_table))
			->columns(array('id', 'business_unit_name','created_at'))
			->join(array('b' => 'adv8_client_business_unit_publisher'), 'a.id=b.business_unit_id', array('publisher_account_id','publisher_id','service_from','service_to'), 'left')
			->where->addPredicate(new Predicate\Expression('a.status = ?', '1'));
			if (!empty($data['business_unit_id'])) {
			   $select->where(array('a.id' => $data['business_unit_id'] , 'a.client_id' => $data['clientId']));
			}
		
		return $this->_ObjCmnfunctions->prepareStatement($select);
    }
	
	function delCampaign($field,$where) {
		return $this->_ObjCmnfunctions->sql_update($field,$where);
    }
    
  
}


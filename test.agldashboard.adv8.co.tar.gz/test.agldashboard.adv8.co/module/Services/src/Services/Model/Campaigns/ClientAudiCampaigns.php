<?php 
Namespace Services\Model\Campaigns;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Services\Model\Dbnfun;

class ClientAudiCampaigns{
	protected $_db;
	protected $_table;
	public $_ObjCmnfunctions;
	public $_sql;
	
	function __construct($adapter) {
		$this->_table='adv8_client_audi_campaign';
		$this->_db= $adapter;
		$this->_sql = new Sql($adapter);
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		
	}
	
	function addAudiCampaigns($campaignData){
		return  $this->_ObjCmnfunctions->sql_save($campaignData);
	}
	
	function getCampaignList($params){
		$status = $params['status'];
		$client_id = $params['client_id'];
		$field = array('*');
		$select = $this->_sql->select();
		$select->from($this->_table);
		$select->columns($field);
		$select->where->addPredicate(new Predicate\Expression('client_id = ?', $client_id));
		$select->where->addPredicate(new Predicate\Expression('status = ?', $status));
		$select->order('created_at ASC');
		return $this->_ObjCmnfunctions->prepareStatement($select,false);
	}
	
	function getCampaignListByDatesSts($params){
		//echo "<pre>"; print_r($params); die('model 2');
		$sDate = $params['sDate'];
		$eDate = $params['eDate'];
		$status = $params['stsBr'];
		$client_id = $params['client_id'];
		$field = array('*');
		$select = $this->_sql->select();
		$select->from($this->_table);
		$select->columns($field);
		$select->where->addPredicate(new Predicate\Expression('client_id = ?', $client_id));
		$select->where->addPredicate(new Predicate\Expression('status = ?', $status));
		$select->where->addPredicate( new Predicate\Expression("date(created_at) BETWEEN '".$sDate."' AND '".$eDate."' "));
		$select->order('created_at ASC');
		return $this->_ObjCmnfunctions->prepareStatement($select,false);
	}
	
	function editCampaignList($fields,$where){
		return $this->_ObjCmnfunctions->sql_fetchall($fields,$where,'','','',false);
	}
	
	function updateAudiCampaigns($campaignData,$where){
		return  $this->_ObjCmnfunctions->sql_update($campaignData,$where);
	}
}
?>
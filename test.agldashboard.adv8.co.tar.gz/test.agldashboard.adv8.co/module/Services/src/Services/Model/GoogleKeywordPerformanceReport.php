<?php

Namespace Services\Model;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class GoogleKeywordPerformanceReport {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {

	$this->_table = 'adv8_google_keyword_performance_report';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
    }

    public function getKeywordData($data) {

	$gcid = explode(",", $data['gcidStr']);
	$keyarray = explode(",", $data['kewordIdsStr']);

	$select = $this->_sql->select();

	$sortBy = $data['sortBy'];

	$field = array('id', 'keyword_id', 'keyword_name', 'match_type', $sortBy => new \Zend\Db\Sql\Expression('SUM(' . $sortBy . ')'));

	$select->from($this->_table);
	$select->columns($field);
	$select->where->in('gcid', $gcid)
	->where->addPredicate(new Predicate\Expression('day >= ?', trim($data['fDate'])))
	->where->addPredicate(new Predicate\Expression('day <= ?', trim($data['tDate'])));

	if (!empty($data['kewordIdsStr'])) {
	    $select->where->in('keyword_id', $keyarray);
	}

	if (trim($data['sortBy']) != '') {
	    $sortBy = trim($data['sortBy']) . " " . trim($data['orderBy']);
	    $select->order($sortBy);
	}
	if (!empty($data['limit'])) {
	    $select->limit(trim($data['limit']));
	}

	$select->group(array('keyword_id', 'match_type'));
	return $this->_ObjCmnfunctions->prepareStatement($select);
    }

    public function getKeywordDetail($data) {
	$gcid = explode(",", $data['gcidStr']);
	$keyarray = explode(",", $data['kewordIdsStr']);
	$select = $this->_sql->select();
	$select->from(array('kpr' => $this->_table))
		->columns(array('adgroup_id', 'currency', 'id', 'match_type', 'keyword_id', 'keyword_name', 'keyword_id', 'clicks' => new \Zend\Db\Sql\Expression('SUM(clicks)'), 'impressions' => new \Zend\Db\Sql\Expression('SUM(impressions)'),
		    'converted_clicks' => new \Zend\Db\Sql\Expression('SUM(converted_clicks)'), 'cost_per_conversion' => new \Zend\Db\Sql\Expression('SUM(cost_per_conversion)'), 'cost' => new \Zend\Db\Sql\Expression('SUM(cost)')))
		->join(array('cm' => 'adv8_client_business_unit_publisher'), 'kpr.gcid = cm.publisher_account_id', array('publisher_account_id'), 'left');

	$select->join(array('bu' => 'adv8_client_business_unit'), 'cm.business_unit_id = bu.id', array('businessunitid' => 'id', 'business_unit_name'), 'inner');
	$select->group(array('kpr.keyword_id', 'kpr.adgroup_id'));
	$select->where->in('kpr.gcid', $gcid)
	->where->addPredicate(new Predicate\Expression('kpr.day >= ?', trim($data['fDate'])))
	->where->addPredicate(new Predicate\Expression('kpr.day <= ?', trim($data['tDate'])));


	$sortBy = '';
	if (trim($data['sortBy']) != '') {
	    $sortBy = trim($data['sortBy']) . " " . trim($data['orderBy']);
	    $select->order($sortBy);
	}
	if (!empty($data['limit'])) {
	    if (!empty($data['offset'])) {
		$select->offset(trim($data['offset']));
		$select->limit(trim($data['limit']));
	    } else {
		$select->limit(trim($data['limit']));
	    }
	}

	return $this->_ObjCmnfunctions->prepareStatement($select);
    }

    public function getKeywordDetailGroupByKeyword($data) {
	//only group by cantang keyword_id and adgroup_id
	$gcid = explode(",", $data['gcidStr']);
	$keyarray = explode(",", $data['kewordIdsStr']);
	$select = $this->_sql->select();
	$select->from(array('kpr' => $this->_table))
		->columns(array('adgroup_id', 'currency', 'id', 'match_type', 'keyword_id', 'keyword_name', 'keyword_id', 'clicks' => new \Zend\Db\Sql\Expression('SUM(clicks)'), 'impressions' => new \Zend\Db\Sql\Expression('SUM(impressions)'),
		    'converted_clicks' => new \Zend\Db\Sql\Expression('SUM(converted_clicks)'), 'cost_per_conversion' => new \Zend\Db\Sql\Expression('SUM(cost_per_conversion)'), 'cost' => new \Zend\Db\Sql\Expression('SUM(cost)')))
		->join(array('cm' => 'adv8_client_business_unit_publisher'), 'kpr.gcid = cm.publisher_account_id', array('publisher_account_id'), 'left');

	$select->join(array('bu' => 'adv8_client_business_unit'), 'cm.business_unit_id = bu.id', array('businessunitid' => 'id', 'business_unit_name'), 'inner');
	$select->group('kpr.keyword_id');
	$select->where->in('kpr.gcid', $gcid)
	->where->addPredicate(new Predicate\Expression('kpr.day >= ?', trim($data['fDate'])))
	->where->addPredicate(new Predicate\Expression('kpr.day <= ?', trim($data['tDate'])));


	$sortBy = '';
	if (trim($data['sortBy']) != '') {
	    $sortBy = trim($data['sortBy']) . " " . trim($data['orderBy']);
	    $select->order($sortBy);
	}
	if (!empty($data['limit'])) {
	    if (!empty($data['offset'])) {
		$select->offset(trim($data['offset']));
		$select->limit(trim($data['limit']));
	    } else {
		$select->limit(trim($data['limit']));
	    }
	}

	return $this->_ObjCmnfunctions->prepareStatement($select);
    }

    public function getKeywordDetailGroupByKeywordAndMatchType($data) {
	//only group by cantang keyword_id and matchtype
	$gcid = explode(",", $data['gcidStr']);


	$select = $this->_sql->select();
	$select->from(array('kpr' => $this->_table))
		->columns(array('adgroup_id', 'currency', 'id', 'match_type', 'keyword_id', 'keyword_name', 'keyword_id', 'clicks' => new \Zend\Db\Sql\Expression('SUM(clicks)'), 'impressions' => new \Zend\Db\Sql\Expression('SUM(impressions)'),
		    'converted_clicks' => new \Zend\Db\Sql\Expression('SUM(converted_clicks)'), 'cost_per_conversion' => new \Zend\Db\Sql\Expression('SUM(cost_per_conversion)'), 'cost' => new \Zend\Db\Sql\Expression('SUM(cost)'), 'cost_per_converted_click' => new \Zend\Db\Sql\Expression('SUM(cost_per_converted_click)')))
		->join(array('cm' => 'adv8_client_business_unit_publisher'), 'kpr.gcid = cm.publisher_account_id', array('publisher_account_id'), 'left');

	$select->join(array('bu' => 'adv8_client_business_unit'), 'cm.business_unit_id = bu.id', array('businessunitid' => 'id', 'business_unit_name'), 'inner');
	$select->group(array('kpr.keyword_id', 'kpr.match_type'));
	$select->where->in('kpr.gcid', $gcid)
	->where->addPredicate(new Predicate\Expression('kpr.day >= ?', trim($data['fDate'])))
	->where->addPredicate(new Predicate\Expression('kpr.day <= ?', trim($data['tDate'])));

	if (!empty($data['kewordIdsStr'])) {
	    $keyarray = explode(",", $data['kewordIdsStr']);
	    $select->where->in('keyword_id', $keyarray);
	}

	$sortBy = '';
	if (trim($data['sortBy']) != '') {
	    $sortBy = trim($data['sortBy']) . " " . trim($data['orderBy']);
	    $select->order($sortBy);
	}
	if (!empty($data['limit'])) {
	    if (!empty($data['offset'])) {
		$select->offset(trim($data['offset']));
		$select->limit(trim($data['limit']));
	    } else {
		$select->limit(trim($data['limit']));
	    }
	}

	return $this->_ObjCmnfunctions->prepareStatement($select);
    }

    public function getDefaultValues($data) {
	$where = new Where();
	$gcid = explode(",", $data['gcidStr']);
	$where->in('gcid', $gcid);
	$field = array('currency');
	$res = $this->_ObjCmnfunctions->sql_fetch_all($field, $where, true);
	$currency = '';
	foreach ($res as $rows) {
	    $currency = $rows['currency'];
	}
	return $currency;
    }

}


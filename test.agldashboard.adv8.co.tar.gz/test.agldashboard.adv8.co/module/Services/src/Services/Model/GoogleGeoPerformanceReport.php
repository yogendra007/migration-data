<?php

Namespace Services\Model;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;
use Services\Model\Catalogprojectkeys;

class GoogleGeoPerformanceReport {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;
    public $_ObjCatalog_project_keys;

    function __construct($adapter) {
	$this->_table = 'adv8_google_geo_performance_report';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
	$this->_ObjCatalog_project_keys = new Catalogprojectkeys($adapter);
    }

    public function getGeoData($data) {

	$select = $this->_sql->select();
	if (empty($data['orderBy'])) {
	    $data['orderBy'] = 'desc';
	}
	$cityarray = explode(",", $data['cityIdsStr']);
	$where = new Where();

	$sortBy = "";
	if (trim($data['sortBy']) != "")
	    $sortBy = trim($data['sortBy']) . " " . trim($data['orderBy']);


	$field = array('id', 'city', 'currency', 'country', 'clicks' => new \Zend\Db\Sql\Expression('SUM(clicks)'),
	    'converted_clicks' => new \Zend\Db\Sql\Expression('SUM(converted_clicks)'), 'cost' => new \Zend\Db\Sql\Expression('SUM(cost)'), 'city_id');
	$select->from($this->_table);
	$select->columns($field);
	if (!empty($data['cityIdsStr'])) {
	    $select->where->in('city', $cityarray);
	}
	$select->where->addPredicate(new Predicate\Expression('day >= ?', trim($data['fDate'])));
	$select->where->addPredicate(new Predicate\Expression('day <= ?', trim($data['tDate'])));
	$select->group(array('city', 'country'));

	if ($sortBy != "")
	    $select->order($sortBy);
	if (!empty($data['limit'])) {
	    if (!empty($data['offset'])) {
		$select->offset(trim($data['offset']));
		$select->limit(trim($data['limit']));
	    } else {
		$select->limit(trim($data['limit']));
	    }
	}
	return $this->_ObjCmnfunctions->prepareStatement($select);
    }

    public function getGeoSummary($data) {
	$gcid = explode(",", $data['gcidStr']);
	$where = new Where();
	$field = array('currency', 'clicks' => new \Zend\Db\Sql\Expression('IFNULL(SUM(clicks),0)'), 'impressions' => new \Zend\Db\Sql\Expression('IFNULL(SUM(impressions),0)'),
	    'converted_clicks' => new \Zend\Db\Sql\Expression('IFNULL(SUM(converted_clicks),0)'), 'cost' => new \Zend\Db\Sql\Expression('IFNULL(SUM(cost),0)'));
	$where->in('gcid', $gcid);
	$where->addPredicate(new Predicate\Expression('day >= ?', trim($data['fDate'])));
	$where->addPredicate(new Predicate\Expression('day <= ?', trim($data['tDate'])));

	$ArrayFound = $this->_ObjCmnfunctions->sql_fetch_all($field, $where);
	$res = 0;
	foreach ($ArrayFound as $row) {
	    $res = $row;
	}
	return $res;
    }

    public function getGeoDetail($data) {
	$gcid = explode(",", $data['gcidStr']);

	$select = $this->_sql->select();
	$select->from(array('cpr' => $this->_table))
		->columns(array('currency', 'clicks' => new \Zend\Db\Sql\Expression('IFNULL(SUM(clicks),0)'), 'impressions' => new \Zend\Db\Sql\Expression('IFNULL(SUM(impressions),0)'), 'converted_clicks' => new \Zend\Db\Sql\Expression('IFNULL(SUM(converted_clicks),0'), 'cost_per_conversion' => new \Zend\Db\Sql\Expression('SUM(cost_per_conversion)'), 'cost' => new \Zend\Db\Sql\Expression('IFNULL(SUM(cost),0')))
		->join(array('cm' => 'adv8_client_business_unit_publisher'), 'cpr.gcid = cm.publisher_account_id', array('publisher_account_id', 'business_unit_id'), 'left');

	$select->join(array('bu' => 'adv8_client_business_unit'), 'cm.business_unit_id = bu.id', array('businessunitid' => 'id', 'business_unit_name'), 'inner');
	$select->group('cpr.gcid');
	$select->where->in('cpr.gcid', $gcid)
	->where->addPredicate(new Predicate\Expression('cpr.day >= ?', trim($data['fDate'])))
	->where->addPredicate(new Predicate\Expression('cpr.day <= ?', trim($data['tDate'])));
	return $this->_ObjCmnfunctions->prepareStatement($select);
    }

    public function getDefaultValues($data) {
	$where = new Where();
	$gcid = explode(",", $data['gcidStr']);
	$where->in('gcid', $gcid);
	$field = array('currency');
	$res = $this->_ObjCmnfunctions->sql_fetch_all($field, $where, true);
	$currency = '';
	foreach ($res as $rows) {
	    $currency = $rows['currency'];
	}
	return $currency;
    }

    public function getDataByCampaignId($data) {
	$where = new Where();
	$field = array('currency', 'clicks' => new \Zend\Db\Sql\Expression('IFNULL(SUM(clicks),0)'), 'impressions' => new \Zend\Db\Sql\Expression('IFNULL(SUM(impressions),0)'), 'converted_clicks' => new \Zend\Db\Sql\Expression('IFNULL(SUM(converted_clicks),0)'), 'cost' => new \Zend\Db\Sql\Expression('SUM(cost)'));

	$where->addPredicate(new Predicate\Expression('campaign_id = ?', trim($data['campaignId'])));
	$where->addPredicate(new Predicate\Expression('day >= ?', trim($data['fDate'])));
	$where->addPredicate(new Predicate\Expression('day <= ?', trim($data['tDate'])));

	$ArrayFound = $this->_ObjCmnfunctions->sql_fetch_all($field, $where);
	$res = 0;
	foreach ($ArrayFound as $row) {
	    $res = $row;
	}
	return $res;
    }

}


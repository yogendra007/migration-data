<?php

Namespace Services\Model;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class ClientBusinessUnitAnalyticsMapping {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {

	$this->_table = 'adv8_client_business_unit_analytics_mapping';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
    }

    public function add($data) {
	return $lastId = $this->_ObjCmnfunctions->sql_save($data);
    }
    
    /*public function addMapping($data) {
	if(!empty($data['publishersData'])){
	    foreach ($data['publishersData'] as $detail) {
		$dataArraySecond = array('client_id' => $data['clientId'], 'business_unit_id' => $detail['businessUnitId'],'publisher_id' => $detail['publisherId'], 'publisher_account_id' => $detail['accountId'], 'service_from' => $detail['fromDate'], 'service_to' => $detail['toDate'], 'status' => '1');
		$arr[] = $lastId = $this->_ObjCmnfunctions->sql_save($data);
	    }
	}
	return $arr;
    }*/
}


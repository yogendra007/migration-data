<?php
Namespace Services\Model;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class Notification {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {
		$this->_table = 'adv8_notifications';
		$this->_db = $adapter;
		$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
		$this->_sql = new Sql($adapter);
    }

    public function insert($fields) {
		$results =$this->_ObjCmnfunctions->sql_save($fields);
		return $results;
    }
	
	/*public function selectRoastDate($parmas){
		$select = $this->_sql->select();
		$select->from($this->_table);
		$field = array('user_id', 'leave_date', 'id');
		$select->columns($field);
		$select->where->addPredicate(new Predicate\Expression('user_id = ?', $parmas['uId']));
		$select->where->addPredicate(new Predicate\Expression('status = ?', '1'));
		return $res = $this->_ObjCmnfunctions->prepareStatement($select);
	}*/
	    
}
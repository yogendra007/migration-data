<?php Namespace Services\Model;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use  Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;
use Services\Model\ClientBusinessUnitPublisher;

class InfoStatus{
	protected $_db;
	protected $_table;
	protected $_adapter;
	public $_ObjCmnfunctions;
	function __construct($adapter) {
		$this->_table='adv8_info_status';
		$this->_db= $adapter;
		$this->_ObjCmnfunctions=new Dbnfun($adapter,$this->_table);
		$this->_sql = new Sql($adapter);
	}
   function getStatus(){
	$field=array('*');
    $where=array();
	return $this->_ObjCmnfunctions->sql_fetchall($field,$where,'','','',false);	
   }
	

}	
<?php
Namespace Services\Model;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class EmailTemplateImages {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {
		$this->_table = 'adv8_email_template_images';
		$this->_db = $adapter;
		$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
		$this->_sql = new Sql($adapter);
    }

    public function imageInsert($data) {
		//$results =$this->_ObjCmnfunctions->sql_save($data);
		return  $this->_ObjCmnfunctions->sql_save($data);
    }
	
	public function fetchImages($fieldsImgs,$whereImgs){
		return $objreturn = $this->_ObjCmnfunctions->sql_fetchall($fieldsImgs,$whereImgs,'','','',false);
	}
	
	public function delTemplateImages($fields,$where){
		return  $this->_ObjCmnfunctions->sql_update($fields,$where);
	}
	
	public function getImages($arr){
		$select = $this->_sql->select();
	    $select->from($this->_table)->columns(array("id","client_id","webform_id","image_name","status"));
		if(!empty($arr['cId'])){	
			$select->where->addPredicate(new Predicate\Expression('client_id = ?', trim($arr["cId"])));
		}
	    $select->where->addPredicate(new Predicate\Expression('status = ?', "1"));
		return $MasterRes = $this->_ObjCmnfunctions->prepareStatement($select, false);
		
	}
}

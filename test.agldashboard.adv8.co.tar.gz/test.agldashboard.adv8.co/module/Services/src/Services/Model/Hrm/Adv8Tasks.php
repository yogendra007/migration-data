<?php

Namespace Services\Model\Hrm;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Services\Model\Dbnfun;

class Adv8Tasks {

    protected $_db;
    protected $_table;
    public $_ObjCmnfunctions;
    public $_sql;


    function __construct($adapter) {
	$this->_table = 'adv8_tasks';
	$this->_db = $adapter;
	$this->_sql = new Sql($adapter);
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
    }

    function getTasks($params) {
	$select = $this->_sql->select();
	$field = array('ID', 'TASK_NAME');
	$select = $this->_sql->select();
	$select->from($this->_table);
	$select->columns($field);

	if (!empty($params['pId'])) {
	    $select->where->addPredicate(new Predicate\Expression('PROJECT_ID = ?', trim($params['pId'])));
	}

	return $res = $this->_ObjCmnfunctions->prepareStatement($select);
    }


}


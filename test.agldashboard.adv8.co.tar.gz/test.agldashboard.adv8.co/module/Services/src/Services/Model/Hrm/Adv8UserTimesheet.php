<?php

Namespace Services\Model\Hrm;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Services\Model\Dbnfun;
use Services\Model\Hrm\Adv8UserTimesheetApproval;


class Adv8UserTimesheet {

    protected $_db;
    protected $_table;
    public $_ObjCmnfunctions;
    public $_sql;
    public $_ObjAdv8UserTimesheetApproval;
    
    function __construct($adapter) {
	$this->_table = 'adv8_user_timesheet';
	$this->_db = $adapter;
	$this->_sql = new Sql($adapter);
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_ObjAdv8UserTimesheetApproval = new Adv8UserTimesheetApproval($adapter);
    }

    function getDetailedTaskList($data) {


	$select = $this->_sql->select();
	$field = array('ID', 'TASK_DESC', 'TASK_START_TIME', 'TASK_END_TIME', 'TASK_DURATION', 'TASK_TYPE', 'DATE', 'CREATED_AT', 'DAY' => new \Zend\Db\Sql\Expression('DAYNAME(Date)'), 'DOW' => new \Zend\Db\Sql\Expression('DAYOFWEEK(Date)'), 'DURATION_SECOND' => new \Zend\Db\Sql\Expression('TIME_TO_SEC(TASK_DURATION)'));



	$select->from(array('main' => $this->_table));
	$select->columns($field)
		->join(array('cl' => 'adv8_clients'), 'main.CLIENT_ID = cl.ID', array('COMPANY_NAME'), 'inner')
		->join(array('proj' => 'adv8_projects'), 'main.PROJECT_ID = proj.ID', array('PROJECT_NAME'), 'inner')
		->join(array('task' => 'adv8_tasks'), 'main.TASK_ID = task.ID', array('TASK_NAME'), 'inner')
		->join(array('app' => 'adv8_user_timesheet_approval'), new Predicate\Expression('app.SHEET_DATE = main.DATE and app.TIMESHEET_ID=main.ID'), array('APPROVAL_STATUS'), 'left');

	$select->where->addPredicate(new Predicate\Expression('DATE(main.DATE) >= ?', trim($data['fDate'])));
	$select->where->addPredicate(new Predicate\Expression('DATE(main.DATE) <= ?', trim($data['tDate'])));

	if ($data['pmo'] == 1) {
	    $select->where->addPredicate(new Predicate\Expression('main.INSERT_BY = ?', trim($data['uId'])));
	} else {
	    $select->where->addPredicate(new Predicate\Expression('main.user_id = ?', trim($data['uId'])));
	}

	$select->order('main.DATE DESC');

	$statement = $this->_ObjCmnfunctions->prepareStatement($select);

	return $statement;
    }

    function getTaskList_v2($data) {

	$select = $this->_sql->select();
	$field = array('TASK_DURATION' => new \Zend\Db\Sql\Expression('SEC_TO_TIME(SUM(TIME_TO_SEC(`TASK_DURATION`)))'), 'DATE');



	$select->from(array('main' => $this->_table));
	$select->columns($field);


	$select->where->addPredicate(new Predicate\Expression('DATE >= ?', trim($data['fDate'])));
	$select->where->addPredicate(new Predicate\Expression('DATE <= ?', trim($data['tDate'])));

	$select->where->addPredicate(new Predicate\Expression('user_id = ?', trim($data['uId'])));

	$select->group('DATE');
	$select->order('DATE DESC');

	if (!empty($data['limit'])) {
	    if (!empty($data['offset'])) {
		$select->offset(trim($data['offset']));
		$select->limit(trim($data['limit']));
	    } else {
		$select->limit(trim($data['limit']));
	    }
	}
	$statement = $this->_ObjCmnfunctions->prepareStatement($select);
	

	return $statement;
    }
    
    function getTaskList($data) {

	$select = $this->_sql->select();
	
	$field = array('TASK_DURATION' => new \Zend\Db\Sql\Expression('SUM(TIME_TO_SEC(`TASK_DURATION`))'), 'DATE');



	$select->from(array('a' => $this->_table));
	$select->columns($field)
		->join(array('ap' => 'adv8_user_timesheet_approval'), 'a.id = ap.timesheet_id',array('APPROVAL_STATUS'),'left');


	$select->where->addPredicate(new Predicate\Expression('DATE >= ?', trim($data['fDate'])));
	$select->where->addPredicate(new Predicate\Expression('DATE <= ?', trim($data['tDate'])));

	$select->where->addPredicate(new Predicate\Expression('a.user_id = ?', trim($data['uId'])));

	$select->group(array('DATE','APPROVAL_STATUS'));
	$select->order('DATE DESC');

	if (!empty($data['limit'])) {
	    if (!empty($data['offset'])) {
		$select->offset(trim($data['offset']));
		$select->limit(trim($data['limit']));
	    } else {
		$select->limit(trim($data['limit']));
	    }
	}
	$statement = $this->_ObjCmnfunctions->prepareStatement($select);
	

	return $statement;
    }

        
    function getTaskListOfUser($data) {

	$select = $this->_sql->select();
	
	$field = array('ID','CLIENT_ID','PROJECT_ID','TASK_ID','USER_ID','INSERT_BY','TASK_DESC','TASK_START_TIME','TASK_END_TIME','TASK_DURATION','TASK_TYPE','DATE','CREATED_AT');



	$select->from($this->_table);
	$select->columns($field);
		

	$select->where->addPredicate(new Predicate\Expression('DATE >= ?', trim($data['fDate'])));
	$select->where->addPredicate(new Predicate\Expression('DATE <= ?', trim($data['tDate'])));

	$select->where->addPredicate(new Predicate\Expression('user_id = ?', trim($data['uId'])));

	if (!empty($data['limit'])) {
	    if (!empty($data['offset'])) {
		$select->offset(trim($data['offset']));
		$select->limit(trim($data['limit']));
	    } else {
		$select->limit(trim($data['limit']));
	    }
	}
	
	$statement = $this->_ObjCmnfunctions->prepareStatement($select);
	
	return $statement;
    }
    
    function saveTask($params) {
	$error = false;
	$params['fDate'] = $params['date'];
	$params['tDate'] = $params['date'];

	$taskDetail = $this->_ObjAdv8UserTimesheetApproval->getTaskList($params);
	
	if (empty($taskDetail)) {
	    $sendData = array();
	    if (isset($params['insertBy'])) {
		$sendData['INSERT_BY'] = $params['insertBy'];
	    }
	    
	    
	    

	    $sendData['CLIENT_ID'] = $params['cId'];
	    $sendData['PROJECT_ID'] = $params['pId'];
	    $sendData['TASK_ID'] = $params['tId'];
	    $sendData['USER_ID'] = $params['uId'];

	    $sendData['TASK_DESC'] = $params['task_description'];
	    //$sendData['TASK_START_TIME'] = $params['task_start_time'];

	    //$sendData['TASK_END_TIME'] = $params['task_end_time'];
	    //$sendData['TASK_DURATION'] = new \Zend\Db\Sql\Expression('SEC_TO_TIME(TIME_TO_SEC(TASK_END_TIME) - TIME_TO_SEC(TASK_START_TIME))');
	    
	    $sendData['TASK_DURATION'] = $params['task_duration'];
	    
	    $sendData['TASK_TYPE'] = $params['task_type'];
	    $sendData['DATE'] = $params['date'];



	    $this->_ObjCmnfunctions->sql_save($sendData);
	    $msg = "Success";
	} else {
	    $error = true;
	    $msg = "Cannot submit task after sent to approval";
	}
	$arr['error'] = $error?1:0;
	$arr['msg'] = $msg;
	return $arr;
    }

}


<?php

Namespace Services\Model\Hrm;

use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Services\Model\Dbnfun;

class Adv8UserTimesheetApproval {

    protected $_db;
    protected $_table;
    public $_ObjCmnfunctions;
    public $_sql;

    function __construct($adapter) {
	$this->_table = 'adv8_user_timesheet_approval';
	$this->_db = $adapter;
	$this->_sql = new Sql($adapter);
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
    }

    function getTaskList($data) {
	$select = $this->_sql->select();
	$field = array('id');

	$select->from($this->_table);
	$select->columns($field);

	$select->where->addPredicate(new Predicate\Expression('SHEET_DATE >= ?', trim($data['fDate'])));
	$select->where->addPredicate(new Predicate\Expression('SHEET_DATE <= ?', trim($data['tDate'])));

	$select->where->addPredicate(new Predicate\Expression('user_id = ?', trim($data['uId'])));

	return $res = $this->_ObjCmnfunctions->prepareStatement($select);
    }

    function saveTaskFoApproval($params) {
	$error = false;

	$sendData = array();
	$sendData['USER_ID'] = $params['uId'];
	$sendData['TIMESHEET_APPROVAL_ID'] = $params['tmId']; //time sheet manager
	$sendData['CM_APPROVAL_ID'] = $params['cmId'];
	$sendData['SHEET_DATE'] = $params['sheetDate'];
	$sendData['TIMESHEET_ID'] = $params['tId'];

	$this->_ObjCmnfunctions->sql_save($sendData);
	$msg = "Success";

	$arr['error'] = $error ? 1 : 0;
	$arr['msg'] = $msg;
	return $arr;
    }

}


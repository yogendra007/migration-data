<?php
Namespace Services\Model;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Predicate;
use Zend\Db\Sql\Where;
use Zend\Authentication\Adapter\DbTable as AuthAdapter;
use Services\Model\Dbnfun;

class AagencyClientUserMapping {

    protected $_db;
    protected $_table;
    protected $_adapter;
    public $_ObjCmnfunctions;

    function __construct($adapter) {
	$this->_table = 'adv8_agency_client_user_mapping';
	$this->_db = $adapter;
	$this->_ObjCmnfunctions = new Dbnfun($adapter, $this->_table);
	$this->_sql = new Sql($adapter);
    }

    public function getUsersMappingWithClient($parmas) { //getCmManagersByClientId 
	$select = $this->_sql->select();
	$select->from(array('am' => $this->_table))
		->columns(array('user_id'))
		->join(array('a' => 'adv8_users'), 'am.user_id = a.id', array('user_email', 'user_role'), 'inner');
	$select->where->addPredicate(new Predicate\Expression('am.agency_client_id = ?', $parmas['clientId']))
	->where->addPredicate(new Predicate\Expression('am.status = ?', '1'));
	return $res = $this->_ObjCmnfunctions->prepareStatement($select);
    }
    
    public function addAccountOwner($params) {
	$this->_ObjCmnfunctions->sql_update(array("status" => '0'), array("agency_client_id" => $params['mappclientid']));
	$arrayUser = $params['requirements'];
	foreach ($arrayUser as $k => $v) {
	    $sendData['user_id'] = $v['user'];
	    $sendData['account_owner'] = $v['accountowner'];
	    $sendData['agency_client_id'] = $params['mappclientid'];
	    $sendData['agency_id'] = $params['mapagencyid'];
	    $this->_ObjCmnfunctions->sql_save($sendData);
	}
	$arr['error'] = 0;
	return $arr;
    }
    
}
<?php
namespace Services\Controller\Shopping;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Db\Sql\Sql;
use Services\Model\Users;

use Zend\Log\Logger;
use Zend\Log\Writer\AbstractWriter;
use Zend\Log\Filter\FilterInterface;
use Zend\Log\Formatter\FormatterInterface;
use Zend\Log\Writer\Stream;
class ApiController extends AbstractRestfulController {
    function __construct() {
		$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
		
    }	
    public function create($data) {	
		$matches = $this->getEvent()->getRouteMatch();
		$case = trim($matches->getParam('type', false));
		$access_token = trim($data['access_token']);
		$access_flg =json_encode(array('access_error'=>true));
		$access_error = json_decode($access_flg);
		$access_error->access_error=false;
	if (trim($access_error->access_error) == '') {	
	switch ($case) {
		case 'invoke';
		$this->invoke($data);
		break;
		case 'feed_update';
		$this->feed_update($data);
		break;
		case 'invoke_test_mode';
		$this->invoke_test_mode($data);
		break;
	    default:
		echo '{"error":0,"message":"' . $case . '::This service is not Recognized.")';
		break;
	}
	}
	else {
		$msg = $access_error->access_error;
		$arr['error'] = 1;
		$arr['message'] = $msg;
		$jsonResponse = json_encode($arr);
		echo $jsonResponse;		
	}
	die();
    }
	function invoke_test_mode($params){
   		date_default_timezone_set('Asia/Calcutta');
		$writer = new Stream('shopping.log');
		$logger = new Logger();
		$logger->addWriter($writer);
		$loagarray=array();
		$loagarray=$params;
		$loagarray['ip_address']=trim($_SERVER['REMOTE_ADDR']);
		$logger->info($loagarray);	
		include("shoppingapi/googleads-shopping-samples/python/v2_api_include.php");
		die;
	}
	function invoke($params){
		di("Removed");
		date_default_timezone_set('Asia/Calcutta');
		//error_reporting(E_ALL);
		//ini_set('display_errors', '1');
$master_array=array('access_token'=> 'access_token','merchant_id'=> 'merchant_id',
    'offerId' => 'offerId','title' => 'title','description' => 'description',
	'link' => 'link','imageLink' =>'imageLink',
    'availability' => 'availability',
    'condition' => 'condition',
    'googleProductCategory' => 'googleProductCategory',
    'price' => 'price',
    'currency' => 'currency',
    'brand' => 'brand',
    //'color' => 'color',
	//'customLevelZero' => 'customLevelZero',
    'productType' => 'productType');
	$not_found=array();
	$error_flg=false;
	foreach($master_array as $chk_k=>$chk_v){
		if(array_key_exists(trim($chk_k),$params)){
			
		}else{
			$not_found[]=trim($chk_k);
			$error_flg=true;
		}
	}
	if($error_flg){
		array_unshift($not_found,array('error'=>'Parameter missing'));
		$adapter = new DbAdapter(unserialize(SHOPPING_AD_ARRAY));
	$sql="insert into v2_feed_log VALUES
	('', 
	'0', 
	'', 
	'".date('Y-m-d H:i:s')."', 
	'".json_encode($params)."','".json_encode($not_found)."')";
	$statement=$adapter->query($sql);
	$Res = $statement->execute();
		
		echo json_encode($not_found);
	}else{
$blank_found=array();
	$error_flg=false;
	foreach($master_array as $chk_k=>$chk_v){
		if(trim($params[trim($chk_k)])==""){		
			$blank_found[]=trim($chk_k);
			$error_flg=true;
		}
	}
	if($error_flg){
		array_unshift($blank_found,array('error'=>'Parameter value is Blank'));
		$adapter = new DbAdapter(unserialize(SHOPPING_AD_ARRAY));
	$sql="insert into v2_feed_log VALUES
	('', 
	'0', 
	'".trim($params['merchant_id'])."', 
	'".date('Y-m-d H:i:s')."', 
	'".json_encode($params)."','".json_encode($blank_found)."')";
	$statement=$adapter->query($sql);
	$Res = $statement->execute();

		echo json_encode($blank_found);
	}else{		
		$dt=json_encode($params);
		$offerId=trim($params['offerId']);
		$title=trim($params['title']);
		$description=trim($params['description']);
		$link=trim($params['link']);
		$imageLink=trim($params['imageLink']);
		$availability=trim($params['availability']);
		$condition=trim($params['condition']);
		$googleProductCategory=trim($params['googleProductCategory']);
		$gtin=trim($params['gtin']);
		$gtin="0";
		$price=trim($params['price']);
		$currency=trim($params['currency']);
		$merchant_id=trim($params['merchant_id']);
		$brand=trim($params['brand']);
		$color=trim($params['color']);
		$productType=trim($params['productType']);
		$customLevelZero=trim($params['customLevelZero']);
		// chdir('shoppingapi/googleads-shopping-samples/python');
		//echo getcwd() . "\n";
		$writer = new Stream('shopping.log');
		$logger = new Logger();
		$logger->addWriter($writer);
		$loagarray=array();
		$loagarray=$params;
		$loagarray['ip_address']=trim($_SERVER['REMOTE_ADDR']);
		$logger->info($loagarray);	
				
/*		$writer = new Zend\Log\Writer\Stream('shopping.log');
		$logger = new Zend\Log\Logger();
		$logger->addWriter($writer);
		$logger->info($params);		
		*/
		include("shoppingapi/googleads-shopping-samples/python/test.php");
	}
	}
		die;
		$output = shell_exec("/usr/bin/python2.6 	test_p.py $merchant_id $offerId ". urlencode($title)." ".urlencode($description)." ".urlencode($link)." ".urlencode($imageLink)." ".urlencode($availability)." ".urlencode($condition)." ".urlencode($googleProductCategory)." ".urlencode($gtin)." ".urlencode($price)." ".urlencode($currency)." ".urlencode($brand)." ".urlencode($color)." ".urlencode($productType)." ".urlencode($customLevelZero));
		//$output = shell_exec("/usr/bin/python2.6 shoppingapi/googleads-shopping-samples/python/test_p.py 102809852");
		$jsonResponse = $output;
		echo $jsonResponse;		

		//die('sfdf');
	}
	
function feed_update($params){
	date_default_timezone_set('Asia/Calcutta');
	//error_reporting(E_ALL);
	//ini_set('display_errors', '1');
	$adapter = new DbAdapter(unserialize(SHOPPING_AD_ARRAY));
	$error_flg=false;
	$availability=trim($params['availability']);
	$merchant_id=trim($params['merchant_id']);
	$offerId=trim($params['offerId']);
	$access_token=trim($params['access_token']);
$get_master_feed="SELECT 	`id`,`expiration_date`,`merchant_id`,`client_id`,`file_id`,`title`,`category`,`brand`,`colour`,`description`,IF(google_product_category IS NULL OR google_product_category = '', 'None','None') AS google_product_category,
`product_type`,`link`,`image_link`,`additional_image_link`,`condition`,`price`,`custom label_zero`,`availability`,IFNULL(`size`,'NA') as size FROM 
 feed_data_processing WHERE file_id='".$offerId."' and dignose_status=0 ORDER BY id DESC LIMIT 1";
// $get_master_feed="SELECT `json_feed_data` FROM `feed_data_filter` WHERE file_id='".$offerId."' ORDER BY id DESC LIMIT 1";
	$statement=$adapter->query($get_master_feed);
	$ResRows = $statement->execute();	
	// $json_feed_data=array();
	$title="";
	foreach($ResRows as $rows){
		//$json_feed_data=json_decode(trim($rows['json_feed_data']));		
		$client_id=trim($rows['client_id']);
		$offerId=trim($rows['file_id']);
		$title=trim(htmlentities(trim($rows['title']), ENT_QUOTES, "UTF-8"));
		$description=trim(htmlentities(trim($rows['description']), ENT_QUOTES, "UTF-8"));
		$link=trim($rows['link']);
		$imageLink=trim($rows['image_link']);
		$availability=trim($availability);
		$condition=trim($rows['condition']);
		$googleProductCategory=trim($rows['google_product_category']);
		$gtin="0";
		$price=trim($rows['price']);
		$price_split=explode(" ",$price);
		$price=trim($price_split[1]);
		$currency=trim($price_split[0]);
		$merchant_id=trim($merchant_id);
		$brand=trim($rows['brand']);
		$color=trim($rows['colour']);
		$productType=trim($rows['product_type']);
		$customLevelZero=trim($rows['custom label_zero']);		
	    $expirationDate=trim($rows['expiration_date']);		
        $size=trim($rows['size']);		
		if($size=="")
			$size="NA";

	}
	$filter_chk_status="SELECT COUNT(*) as cnt FROM `v2_feed_log` WHERE DATE_FORMAT(`request_date`,'%y-%m-%d') 
	BETWEEN CURRENT_DATE AND CURRENT_DATE AND `file_id`='".$offerId."'  AND `availability`='".$availability."' ";

	$filter_chk_status="SELECT COUNT(*) as cnt FROM v2_feed_log WHERE id=(SELECT MAX(id) FROM `v2_feed_log` WHERE `file_id`='".$offerId."' and DATE_FORMAT(`request_date`,'%y-%m-%d') 
	BETWEEN CURRENT_DATE AND CURRENT_DATE)  AND `availability`='".$availability."' AND `response` LIKE '%Sucess%'";


	$filter_chk_status="SELECT COUNT(*) AS cnt FROM v2_feed_log WHERE id=(

SELECT MAX(id) FROM `v2_feed_log` WHERE `file_id`='".$offerId."' 
AND `response` LIKE '%Sucess%'
 AND 
DATE_FORMAT(`request_date`,'%y-%m-%d')  BETWEEN CURRENT_DATE AND CURRENT_DATE 
 

	)  AND `availability`='".$availability."' ";

	$chk_status=$adapter->query($filter_chk_status);
	$status_count = $chk_status->execute();	
	$status_cnt=0;
	foreach($status_count as $cnt){
			$status_cnt=trim($cnt['cnt']);
	}

	if($access_token==""){
		$error_flg=true;
		$error_params=array();
		$error_params=$params;
		array_unshift($error_params,array('error'=>'Access_token is blank'));				
	}
	else if($merchant_id==""){
		$error_flg=true;
		$error_params=array();
		$error_params=$params;
		array_unshift($error_params,array('error'=>'Merchant_id is blank'));				
	}
	else if($offerId==""){
		$error_flg=true;
		$error_params=array();
		$error_params=$params;
		array_unshift($error_params,array('error'=>'OfferId is blank'));				
	}
	else if($availability==""){
		$error_flg=true;
		$error_params=array();
		$error_params=$params;
		array_unshift($error_params,array('error'=>'Availability is blank'));			
	}
	else if($status_cnt>0){
		$error_flg=true;
		$error_params=array();
		$error_params=$params;
		array_unshift($error_params,array('error'=>'Same Availability status already updated'));			
	}
	if($title==""){
		$error_flg=true;
		$error_params=array();
		$error_params=$params;
		array_unshift($error_params,array('error'=>'Item not found or item has some policy violation.'));
	}
	if($error_flg){
		$adapter = new DbAdapter(unserialize(SHOPPING_AD_ARRAY));
	$sql="insert into v2_feed_log VALUES
	('',
	'".$availability."',
	'".$offerId."',
	'199', 
	'".trim($params['merchant_id'])."', 
	'".date('Y-m-d H:i:s')."', 
	'".json_encode($params)."','".json_encode($error_params)."')";
	$statement=$adapter->query($sql);
	$Res = $statement->execute();
		echo json_encode($error_params);
		die;
	}else{		
		// chdir('shoppingapi/googleads-shopping-samples/python');
		//echo getcwd() . "\n";
		$writer = new Stream('shopping.log');
		$logger = new Logger();
		$logger->addWriter($writer);
		$loagarray=array();
		$loagarray=$params;
		$loagarray['ip_address']=trim($_SERVER['REMOTE_ADDR']);
		$logger->info($loagarray);	
				
/*		$writer = new Zend\Log\Writer\Stream('shopping.log');
		$logger = new Zend\Log\Logger();
		$logger->addWriter($writer);
		$logger->info($params);		
		*/
		include("shoppingapi/googleads-shopping-samples/python/pro_feed_insert.php");
	
	}
		die;
		$output = shell_exec("/usr/bin/python2.6 	test_p.py $merchant_id $offerId ". urlencode($title)." ".urlencode($description)." ".urlencode($link)." ".urlencode($imageLink)." ".urlencode($availability)." ".urlencode($condition)." ".urlencode($googleProductCategory)." ".urlencode($gtin)." ".urlencode($price)." ".urlencode($currency)." ".urlencode($brand)." ".urlencode($color)." ".urlencode($productType)." ".urlencode($customLevelZero));
		//$output = shell_exec("/usr/bin/python2.6 shoppingapi/googleads-shopping-samples/python/test_p.py 102809852");
		$jsonResponse = $output;
		echo $jsonResponse;		

		//die('sfdf');
	}	
	
}

<?php

namespace Services\Controller\Hrm;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Db\Sql\Sql;
use Services\Model\Users;
use Services\Model\Hrm\Adv8Tasks;
use Services\Model\Hrm\Adv8UserTimesheet;

class TaskController extends AbstractRestfulController {

    public $_ObjUsers;
    public $_ObjAdv8UserTimesheet;

    function __construct() {

	$adapter = new DbAdapter(unserialize(DB_HRM_ARRAY));
	$adapter1 = new DbAdapter(unserialize(DB_AD_ARRAY));
	$this->_ObjUsers = new Users($adapter1);
	$this->_Objadv8Tasks = new Adv8Tasks($adapter);
	$this->_Objadv8UserTimesheet = new adv8UserTimesheet($adapter);
    }

    public function getList() {

	# code...
	die("getlist");
    }

    public function get($id) {
	die($id);
	# code...
    }

    public function create($data) {

	$matches = $this->getEvent()->getRouteMatch();
	$case = trim($matches->getParam('type', false));
	switch ($case) {
	    case 'get_tasks_by_project':
		$this->get_tasks_by_project($data);
		break;
	    case 'save_task':
		$this->save_task($data);
		break;
	    case 'get_detailed_task_list':
		$this->get_detailed_task_list($data);
		break;
	    default:
		echo '{"error":0,"message":"' . $case . '::This service is not Recognized.")';
		break;
	}
	//print_r($data);
	die();
	# code...
    }

    public function update($id, $data) {
	die("update");
	# code...
    }

    public function delete($id) {
	die("delete");
	# code...
    }

    function get_tasks_by_project($data) {

	$taskArray = array();
	$error = false;
	$access_token = trim($data['access_token']);
	$access_flg = $this->_ObjUsers->validate_access_token($access_token);
	$access_error = json_decode($access_flg);
	$access_error->access_error = '';
	if (trim($access_error->access_error) == '') {

	    $pId = trim($data['pId']);
	    if (!$error) {
		if (empty($pId)) {
		    $error = true;
		    $msg = "Project Id required";
		}
	    }

	    if (!$error) {
		$taskDetail = $this->_Objadv8Tasks->getTasks($data);
		if (!empty($taskDetail)) {
		    foreach ($taskDetail as $k => $v) {
			$taskArray[$k]['id'] = $v['ID'];
			$taskArray[$k]['task_name'] = $v['TASK_NAME'];
		    }
		} else {
		    $error = true;
		    $msg = 'No task Found';
		}
	    }
	} else {
	    $error = true;
	    $msg = $access_error->access_error;
	}

	if (!$error) {
	    $error = false;
	    $msg = "Success";
	}
	$arr['error'] = $error ? 1 : 0;
	$arr['message'] = $msg;
	if (!empty($systemmessage)) {
	    $arr['systemMessage'] = $systemmessage;
	}
	$arr['data'] = $taskArray;
	$jsonResponse = json_encode($arr);
	echo $jsonResponse;
    }

    function get_detailed_task_list($data) {
	$responseArray = array();
	$error = false;

	$access_token = trim($data['access_token']);
	$access_flg = $this->_ObjUsers->validate_access_token($access_token);
	$access_error = json_decode($access_flg);

	$access_error->access_error = '';
	if (trim($access_error->access_error) == '') {


	    $uId = trim($data['uId']);
	    $fromDate = trim($data['fDate']);
	    $toDate = trim($data['tDate']);
	    
	    $date = trim($data['date']);
	    
	    if (!$error) {
		if (empty($uId)) {
		    $error = true;
		    $msg = "User Id required";
		}
	    }
	    if (!$error) {
		if (empty($date)) {
		    $error = true;
		    $msg = "date required";
		}else{
		    $data['fDate'] = $date;
		    $data['tDate'] = $date;
		}
	    }
	    
	    if (!$error) {
		if (empty($data['fDate']) || empty($data['tDate'])) {
		    $error = true;
		    $msg = "All fields are required";
		}
	    }
	    if (empty($data['pmo'])) {
		$data['pmo'] = 0;
	    }
	    if (!$error) {
		$taskDetail = $this->_Objadv8UserTimesheet->getDetailedTaskList($data);
		$taskTpeArray = array("1" => "Billable", "2" => "Non Billable", "3" => "Mock UP");
		if (!empty($taskDetail)) {
		    foreach ($taskDetail as $k => $v) {
			$TASK_DURATION_HR_MM = explode(':', $v['TASK_DURATION']);
			$reorderArray[$v['DATE']][$k]['date'] = date('D, d M', strtotime($v['DATE']));
			$reorderArray[$v['DATE']][$k]['id'] = $v['ID'];

			$reorderArray[$v['DATE']][$k]['company_name'] = $v['COMPANY_NAME'];
			$reorderArray[$v['DATE']][$k]['project_name'] = $v['PROJECT_NAME'];
			$reorderArray[$v['DATE']][$k]['task_description'] = $v['TASK_DESC'];
			//$reorderArray[$v['DATE']][$k]['task_Start_time'] = date('H:i A', strtotime($v['DATE'] . ' ' . $v['TASK_START_TIME']));
			//$reorderArray[$v['DATE']][$k]['task_end_time'] = date('H:i A', strtotime($v['DATE'] . ' ' . $v['TASK_END_TIME']));
			$reorderArray[$v['DATE']][$k]['task_duration'] = $TASK_DURATION_HR_MM[0] . 'h ' . $TASK_DURATION_HR_MM[1] . 'm';
			$reorderArray[$v['DATE']][$k]['task_type'] = $taskTpeArray[$v['TASK_TYPE']];
			/*if (empty($v['APPROVAL_STATUS'])) {
			    $approvalStatus = 0;
			} else {
			    $approvalStatus = $v['APPROVAL_STATUS'];
			}
			$reorderArray[$v['DATE']][$k]['approval_status'] = $approvalStatus;*/
		    }

		    $s = array();
		    foreach ($reorderArray as $k => $v) {
			$s = array_merge($s, $v);

			//$responseArray['date'][$j] = date('D, d M', strtotime($k));
			$responseArray['taskDetail'] = $s;
		    }
		} else {
		    $error = true;
		    $msg = 'No data Found';
		}
	    }
	} else {
	    $error = true;
	    $msg = $access_error->access_error;
	}
	
	if (!$error) {
	    $error = false;
	    $msg = "Success";
	}
	$arr['error'] = $error ? 1 : 0;
	$arr['message'] = $msg;
	if (!empty($systemmessage)) {
	    $arr['systemMessage'] = $systemmessage;
	}
	$arr['data'] = $responseArray;
	$jsonResponse = json_encode($arr);
	echo $jsonResponse;
    }

    function save_task($data) {
	$taskArray = array();
	$error = false;
	$access_token = trim($data['access_token']);
	$access_flg = $this->_ObjUsers->validate_access_token($access_token);
	$access_error = json_decode($access_flg);
	$access_error->access_error = '';
	if (trim($access_error->access_error) == '') {



	    $cId = trim($data['cId']);
	    if (!$error) {
		if (empty($cId)) {
		    $error = true;
		    $msg = "Client Id required";
		}
	    }

	    $pId = trim($data['pId']);
	    if (!$error) {
		if (empty($pId)) {
		    $error = true;
		    $msg = "Project Id required";
		}
	    }


	    $tId = trim($data['tId']);
	    if (!$error) {
		if (empty($tId)) {
		    $error = true;
		    $msg = "Task Id required";
		}
	    }

	    $uId = trim($data['uId']);

	    if (!$error) {
		if (empty($uId)) {
		    $error = true;
		    $msg = "User Id required";
		}
	    }

	    $taskDescription = trim($data['task_description']);

	    /* if (!$error) {
	      if (empty($data['task_description']) || empty($data['task_start_time']) || empty($data['task_end_time']) || empty($data['task_type']) || empty($data['date'])) {
	      $error = true;
	      $msg = "All fields are required";
	      }
	      } */

	    if (!$error) {
		if (empty($data['task_description']) || empty($data['task_duration']) || empty($data['task_type']) || empty($data['date'])) {
		    $error = true;
		    $msg = "All fields are required";
		}
	    }

	    if (!$error) {
		$taskdurationformatted = explode(":", $data['task_duration']);
		$taskdurationhours = $taskdurationformatted[0];
		$taskdurationseconds = $taskdurationformatted[1];

		if (strlen($taskdurationhours) == 2) {
		    
		} else {
		    $taskdurationhours = '0' . $taskdurationhours;
		}

		if (strlen($taskdurationseconds) == 2) {
		    
		} else {
		    $taskdurationseconds = $taskdurationseconds . "0";
		}

		$task_duration = $taskdurationhours . ":" . $taskdurationseconds;

		$data['task_duration'] = $task_duration;
		//$taskTpeArray = array("1" => "Billable", "2" => "Non Billable", "3" => "Mock UP");

		$taskTpeArray = array("1", "Billable", "2", "Non Billable", "3", "Mock UP");
		if (!in_array($data['task_type'], $taskTpeArray)) {
		    $error = true;
		    $msg = "task type error";
		}
	    }

	    if (!$error) {
		$saveTask = $this->_Objadv8UserTimesheet->saveTask($data);
		$error = $saveTask['error'];
		$msg = $saveTask['msg'];
	    }
	} else {
	    $error = true;
	    $msg = $access_error->access_error;
	}

	if (!$error) {
	    $error = false;
	    $msg = "Success";
	}
	$arr['error'] = $error ? 1 : 0;
	$arr['message'] = $msg;
	if (!empty($systemmessage)) {
	    $arr['systemMessage'] = $systemmessage;
	}
	$arr['data'] = $taskArray;
	$jsonResponse = json_encode($arr);
	echo $jsonResponse;
    }

}
<?php namespace Services\Controller;
use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Db\Sql\Sql;
use Services\Model\Users;
use Services\Model\Billing\ClientInvoices;

class AppinvoiceController extends AbstractRestfulController
{
	public $_ObjUsers;
	public $_ObjAppPaidCampaign;	
	public $_ObjClientBusinessUnitPublisher;	
	public $_ObjClientBusinessUnit;		
	public $_ObjCommon;
	public $_ObjGoogleCampaignPerformanceDeviceReport;	
	function __construct() {
		$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));
		$this->_ObjUsers=new Users($adapter);
		$this->_ObjAppPaidInvoice=new ClientInvoices($adapter);
	}
    public function getList()
    {
        # code...
		die("getlist");
    }
 
    public function get($id)
    {
		die($id);
        # code...
    }
 
    public function create($data)
    {
		$matches = $this->getEvent()->getRouteMatch();
		$case      = trim($matches->getParam('type', false));
		switch($case){		
			case 'get_invoices_count':
			$this->get_invoices_count($data);
			break;
			case 'get_pending_invoice_detail':
			$this->get_pending_invoice_detail($data);
			break;
			case 'get_payment_detail':
			
			$this->get_payment_detail($data);
			break;
			case 'download_invoice':
			
			$this->download_invoice($data);
			break;
			case 'get_invoice_detail':
			
			$this->get_invoice_detail($data);
			break;
			default:
			echo '{"error":0,"message":"'.$case.'::This service is not Recognized.")';
			break;
		}
		//print_r($data);
		die();
        # code...
    }
    public function update($id, $data)
    {
		die("update");
        # code...
    }
    public function delete($id)
    {
		die("delete");
        # code...
    }	
	function get_invoices_count($data){
		$responseArray = array();
		$access_token = trim($data['access_token']);
		$access_flg=$this->_ObjUsers->validate_access_token($access_token);	
		$access_error = json_decode($access_flg);
		if (trim($access_error->access_error) == '') {
			$error = false;
			$cId = trim($data['cId']);
			$aId = trim($data['aId']);
			if(!$error){
				if(empty($cId)){
					$error = true;
					$systemmessage = "Client Id required";
					$msg = "Error Occured";
				}
			}
			
			if(!$error){
				$data['clientId'] = $cId;
				$outstandingInvoice = $this->_ObjAppPaidInvoice->getInvoiceCount($data);
				$paymnetDone = $this->_ObjAppPaidInvoice->getPaymentCount($data);
				$responseArray['outstanding'] = $outstandingInvoice;
				$responseArray['payment'] = $paymnetDone;

			}		
		}else{
            $error = true;
			$msg = $access_error->access_error;
		}
        if(!$error){
			$error = false;
			$msg = "Success";
		}
		$arr['error'] = $error?1:0;
		$arr['message'] =  $msg;
		if(!empty($systemmessage)){
			$arr['systemMessage'] =  $systemmessage;
		}
		$arr['data'] =  $responseArray;
		$jsonResponse = json_encode($arr);
		echo $jsonResponse;
		
	}
	
	function get_pending_invoice_detail($data){
		$responseArray = array();
		$access_token = trim($data['access_token']);
		$access_flg=$this->_ObjUsers->validate_access_token($access_token);	
		$access_error = json_decode($access_flg);
		if (trim($access_error->access_error) == '') {
			$error = false;
			$cId = trim($data['cId']);
			$aId = trim($data['aId']);
			if(!$error){
				if(empty($cId)){
					$error = true;
					$systemmessage = "Client Id required";
					$msg = "Error Occured";
				}
			}
			
			if(!$error){
				$data['clientId'] = $cId;
				$detail = $this->_ObjAppPaidInvoice->getPendingInvoiceDetail($data);
				
				if(!empty($detail)){
					foreach($detail as $k=>$v){
						$responseArray[$k]['invoiceNumber'] = $v['tax_invoice_id'];
						$responseArray[$k]['amount'] = $v['due_amount'];
						$responseArray[$k]['dueDate'] = date('jS M Y', strtotime($v['payment_expected_date']));
						$responseArray[$k]['invoieCreateDate'] = date('jS M', strtotime($v['invoice_created_at']));
						$responseArray[$k]['colour'] = "";
						$responseArray[$k]['invoiceId'] = $v['id'];
						$responseArray[$k]['pdfLink'] = "http://stagingagldashboard.adv8.co/assets/Invoice/".$v['agency_client_id']."/IN_".$v['id'].".pdf";
					}
				}
			}		
		}else{
            $error = true;
			$msg = $access_error->access_error;
		}
        if(!$error){
			$error = false;
			$msg = "Success";
		}
		$arr['error'] = $error?1:0;
		$arr['message'] =  $msg;
		if(!empty($systemmessage)){
			$arr['systemMessage'] =  $systemmessage;
		}
		$arr['data'] =  $responseArray;
		$jsonResponse = json_encode($arr);
		echo $jsonResponse;
		
	}
	
	function get_payment_detail($data){
		$responseArray = array();
		$access_token = trim($data['access_token']);
		$access_flg=$this->_ObjUsers->validate_access_token($access_token);	
		$access_error = json_decode($access_flg);
		if (trim($access_error->access_error) == '') {
			$error = false;
			$cId = trim($data['cId']);
			$invoiceId = trim($data['invoiceId']);
			$invoiceId = trim($data['invoiceId']);
			if(!$error){
				if(empty($cId)){
					$error = true;
					$systemmessage = "Client Id required";
					$msg = "Error Occured";
				}
			}
			
			if(!$error){
				$data['clientId'] = $cId;
				$data['taxInvoiceId'] = $invoiceId;
				$detail = $this->_ObjAppPaidInvoice->getPaymentDetail($data);
				
				if(!empty($detail)){
					foreach($detail as $k=>$v){
						$responseArray[$k]['invoiceNumber'] = $v['tax_invoice_id'];
						$responseArray[$k]['paidAmount'] = $v['received_amount'];
						$responseArray[$k]['paymentMode'] = $v['payment_mode'];
						$responseArray[$k]['amount'] = $v['due_amount'];
						$responseArray[$k]['paymentDate'] = date('jS M', strtotime($v['payment_received_date']));
						$responseArray[$k]['pdfLink'] = "http://stagingagldashboard.adv8.co/assets/Invoice/".$v['agency_client_id']."/IN_".$v['id'].".pdf";
					}
				}
			}		
		}else{
            $error = true;
			$msg = $access_error->access_error;
		}
        if(!$error){
			$error = false;
			$msg = "Success";
		}
		$arr['error'] = $error?1:0;
		$arr['message'] =  $msg;
		if(!empty($systemmessage)){
			$arr['systemMessage'] =  $systemmessage;
		}
		$arr['data'] =  $responseArray;
		$jsonResponse = json_encode($arr);
		echo $jsonResponse;
		
	}
	
	function download_invoice($data){
		$responseArray = array();
		$access_token = trim($data['access_token']);
		$access_flg=$this->_ObjUsers->validate_access_token($access_token);	
		$access_error = json_decode($access_flg);
		if (trim($access_error->access_error) != '') {
			$error = false;
			$clientId = trim($data['c']);
			$invoiceId = trim($data['i']);
			
			ignore_user_abort(true);
			set_time_limit(0); // disable the time limit for this script

			//$fullPath = getcwd().'/assets/'.$text.'/'.$decodeClientId.'/'.$decodeInvoiceId.'.pdf';
			$fullPath = 'http://stagingagldashboard.adv8.co/assets/'.$text.'/'.$clientId.'/'.$invoiceId.'.pdf';
			if ($fd = fopen ($fullPath, "r")) {
				$fsize = filesize($fullPath);
				$path_parts = pathinfo($fullPath);
				$ext = strtolower($path_parts["extension"]);
				switch ($ext) {
					case "pdf":
					header("Content-type: application/pdf");
					header("Content-Disposition: attachment; filename=\"".$path_parts["basename"]."\""); // use 'attachment' to force a file download
					break;
					// add more headers for other content types here
					default;
					header("Content-type: application/octet-stream");
					header("Content-Disposition: filename=\"".$path_parts["basename"]."\"");
					break;
			}
			header("Content-length: $fsize");
			header("Cache-control: private"); //use this to open files directly
			while(!feof($fd)) {
				$buffer = fread($fd, 2048);
				echo $buffer;
			}
			}else{
				echo "No Invoice has been found";
			}
				fclose ($fd);
				exit;
		}else{
			$error = true;
			echo $msg = $access_error->access_error;
			exit;
		}
	
	}
	
	function get_invoice_detail($data){
		$responseArray = array();
		$access_token = trim($data['access_token']);
		$access_flg=$this->_ObjUsers->validate_access_token($access_token);	
		$access_error = json_decode($access_flg);
		if (trim($access_error->access_error) == '') {
			$error = false;
			$invoiceId = trim($data['invoiceId']);
			if(!$error){
				if(empty($invoiceId)){
					$error = true;
					$systemmessage = "invoice Id required";
					$msg = "Error Occured";
				}
			}
			if(!$error){
				$resPublisherArray = $this->_ObjAppPaidInvoice->getPublishers();
				if(!empty($resPublisherArray)){
					foreach($resPublisherArray as $keypub=>$valpub){
						$publisherArray[$valpub['id']] = $valpub['publisher_name'];
					}
				}
				
				$detail = $this->_ObjAppPaidInvoice->getInvoiceDetails($data);
				
				if(!empty($detail)){
					foreach($detail as $k=>$v){
						
						$responseArray['detail'][$k]['agency_service_id'] = $v['agency_service_id'];
						$responseArray['detail'][$k]['publisher_id'] = $publisherArray[$v['publisher_id']];
						$responseArray['detail'][$k]['service_description'] = $v['service_description'];
						$responseArray['detail'][$k]['service_amount'] = $v['service_amount'];
						$responseArray['detail'][$k]['agency_charges'] = $v['agency_charges'];
						
					}
					
					$responseArray['subAmount']  = $v['sub_amount'];
					$responseArray['totalAmount']  = $v['total_amount'];
					$responseArray['serviceTax']  = $v['servicetax_amount'];
					
				
				}
			}
		}else{
            $error = true;
			$msg = $access_error->access_error;
		}
        if(!$error){
			$error = false;
			$msg = "Success";
		}
		$arr['error'] = $error?1:0;
		$arr['message'] =  $msg;
		if(!empty($systemmessage)){
			$arr['systemMessage'] =  $systemmessage;
		}
		$arr['data'] =  $responseArray;
		$jsonResponse = json_encode($arr);
		echo $jsonResponse;
		
	}

 
 

}

<?php

namespace Services\Controller\Oauth;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Db\Sql\Sql;
use Services\Model\Users;
use Services\Model\ClientBusinessUnit;
use Services\Common\Common;
use Services\Model\ClientRefreshTokens;

class AppOauthController extends AbstractRestfulController {

    public $_ObjUsers;
    public $_ObjAccount;
    public $_ObjClientBusinessUnit;
    public $_ObjCommon;
    

    function __construct() {
	$adapter = new DbAdapter(unserialize(DB_AD_ARRAY));

	$this->_ObjUsers = new Users($adapter);
	$this->_ObjAccount = new ClientRefreshTokens($adapter);
	
	
	$this->_ObjClientBusinessUnit = new ClientBusinessUnit($adapter);
	$this->_ObjCommon = new Common();
	
    }

    public function getList() {
	# code...
	die("getlist");
    }

    public function get($id) {
	die($id);
	# code...
    }

    public function create($data) {

	$matches = $this->getEvent()->getRouteMatch();
	$case = trim($matches->getParam('type', false));

	switch ($case) {
	    case 'precheck_paid_module':
		$this->precheck_paid_module($data);
		break;
	    default:
		echo '{"error":0,"message":"' . $case . '::This service is not Recognized.")';
		break;
	}
	
	# code...
    }

    public function update($id, $data) {
	die("update");
	# code...
    }

    public function delete($id) {
	die("delete");
	# code...
    }

    function precheck_paid_module($data) {
	$error = false;
	$gcidArray = array();
	$access_token = trim($data['access_token']);
	$access_flg = $this->_ObjUsers->validate_access_token($access_token);
	$access_error = json_decode($access_flg);
	$responseArray = array();
	if (trim($access_error->access_error) == ''){
	    $error = false;
	    $cId = trim($data['cId']);
	   
	    if (!$error) {
		if (empty($cId)) {
		    $error = true;
		    $msg = "Client Id required";
		}
	    }
	   
	    if (!$error) {
		$params = array();
		$params['clientId'] = $cId;
		$params['publisherId'] = "1";
		$netRess = $this->_ObjClientBusinessUnit->getCampaignUnitsMapping($params);
		$jsonnetRess = json_encode($netRess);
		$gcidData = json_decode($jsonnetRess, true);

		if (!empty($gcidData)) {
		    foreach ($gcidData as $k => $info) {
			$gcidArray[$k]['id'] = $info['publisher_account_id'];
			$gcidArray[$k]['publisherAccountId'] = $info['publisher_account_id'];
			$gcidArray[$k]['CampaignUnit'] = $info['business_unit_name'];
		    }
		}
		
		if (!empty($gcidData)) {
		    $arr['key'] = 1;
		    //file_get_contents()
		} else {
		    /* check for regeresh token generated */
		    $resuljson = file_get_contents("http://adwordsv1502.aglkuber.in/examples/AdWords/v201502/BasicOperations/CheckRefreshTokenGenerated.php?cId=" . $cId);

		    $resultarray = json_decode($resuljson, true);
		    $temperror = $resultarray['error'];
		    if ($temperror) {
			/* redirect to browser */
			$arr['key'] = 2;
			$gcidArrayAgain = 'http://adwordsv1502.aglkuber.in/examples/AdWords/Auth/GetRefreshToken_Client.php?state='.$cId;
		    } else {
			/* show pop up of gcids */
			$arr['key'] = 3;
			$sdata['cId'] = $cId;

			$detail = $this->_ObjAccount->getDetail($sdata);
			
			if (!empty($detail)) {
			    foreach ($detail as $k => $v) {
				if (!empty($v['gcid'])) {
				    $gcId = $v['gcid'];
				}
			    }
			}

			$gcidArrayAgain = array();
			if (!empty($gcId)) {
			    if (!$error) {
				$url = "http://adwordsv1502.aglkuber.in/examples/AdWords/v201502/AccountManagement/GetAccountHierarchy.php?gcid=" . $gcId . "&cid=" . $cId;

				$jsongcids = file_get_contents($url);
				$rim = json_decode($jsongcids, true);
				if (!empty($rim)) {
				    foreach ($rim as $kk => $vv) {
					$gcidArrayAgain[$kk] = $vv;
				    }
				}
			    }
			}else{
			    $error = true;
			    $msg = "Not adwords User";
			}
		    }
		}
	    }
	} else {
	    $error = true;
	    $msg = $access_error->access_error;
	}

	if (!$error) {
	    $error = false;
	    $msg = "Success";
	}

	$arr['error'] = $error ? 1 : 0;
	$arr['message'] = $msg;
	if (!empty($systemmessage)) {
	    $arr['systemMessage'] = $systemmessage;
	}
	$arr['data'] = $gcidArrayAgain;
	$jsonResponse = json_encode($arr);
	echo $jsonResponse;
	die();
    }

}

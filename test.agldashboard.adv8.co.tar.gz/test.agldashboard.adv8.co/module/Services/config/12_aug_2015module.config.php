<?php

return array(
    'controllers' => array(
	'invokables' => array(
	    'Services\Controller\User' => 'Services\Controller\UserController',
	    'Services\Controller\Apppaid' => 'Services\Controller\ApppaidController',
	    'Services\Controller\Appwidget' => 'Services\Controller\AppwidgetController',
	    'Services\Controller\Appgeo' => 'Services\Controller\AppgeoController',
	    'Services\Controller\Appinvoice' => 'Services\Controller\AppinvoiceController',
	    'Services\Controller\Appdevice' => 'Services\Controller\AppdeviceController',
	    'Services\Controller\Appkeyword' => 'Services\Controller\AppkeywordController',
	    'Services\Controller\Client' => 'Services\Controller\ClientController',
		'Services\Controller\Webforms' => 'Services\Controller\Webforms\WebformsController',
	    'Services\Controller\AppOauth' => 'Services\Controller\Oauth\AppOauthController',
		'Services\Controller\Analytics' => 'Services\Controller\Analytics\VisitorsController',		
		'Services\Controller\Analytics' => 'Services\Controller\Analytics\InsightsController',		
		
	),
    ),
    // The following section is new and should be added to your file
    'router' => array(
	'routes' => array(
	    'user' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service',
		    'defaults' => array(
			'controller' => 'Services\Controller\User',
		    ),
		), 'may_terminate' => true,
		'child_routes' => array(
		    'submethod' => array(
			'type' => 'segment',
			'options' => array(
			    'route' => '/user[/:type]',
			    'defaults' => array(
				'controller' => 'Services\Controller\User',
			    ),
			),
		    ),
		),
	    ),
	    'app-paid' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service',
		    'defaults' => array(
			'controller' => 'Services\Controller\User',
		    ),
		), 'may_terminate' => true,
		'child_routes' => array(
		    'Sub-app-paid' => array(
			'type' => 'segment',
			'options' => array(
			    'route' => '/paid/campaign[/:type]',
			    'defaults' => array(
				'controller' => 'Services\Controller\Apppaid',
			    ),
			),
		    ),
		),
	    ),
	    'app-widget' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service/paid/widget[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\Appwidget',
		    ),
		),
	    ),
	    'app-geo' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service/paid/geo[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\Appgeo',
		    ),
		),
	    ),
	    'app-client' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service/client[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\Client',
		    ),
		),
	    ),
	    'app-invoice' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service/invoice[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\Appinvoice',
		    ),
		),
	    ), 'app-device' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service/device[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\Appdevice',
		    ),
		),
	    ),
		'app-keyword' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service/keyword[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\Appkeyword',
		    ),
		),
	    ),
		'app-webform' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service/webforms[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\webforms',
		    ),
		),
	    ),

		'insights' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/analytics/insights[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\Analytics',
		    ),
		),
	    ),

	    'app-oauth' => array(
		'type' => 'segment',
		'options' => array(
		    'route' => '/service/oauth[/:type]',
		    'defaults' => array(
			'controller' => 'Services\Controller\AppOauth',
		    ),
		),
	    ),

		
	),
    ),
    'view_manager' => array(//Add this config
	'strategies' => array(
	    'ViewJsonStrategy',
	),
    ),
    'controller_plugins' => array(
	'invokables' => array(
	    'Myplugin' => 'services\Plugin\Myplugin',
	),
    ),
);

<?php
function insertDbiAdv8($lp_id, $call_tracking_number,$forwarding_number,$display_number,$call_tracking_orderID,$call_tracking_sdate,$call_tracking_expdate,$email_alert,$sms_alert,$email_alert_id,$sms_alert_number,$pack,$packValue,$packMinutes,$last_modified_date,$user_id,$allocatenumberManaullay,$calltracking_timestamp, $connection){
	// Query to insert into databse
	$status = 1;
	$query = "select * from adv8_client_landing_page_ctn where call_tracking_number = '" . $call_tracking_number . "' and enable_tracking = '1' and status = '1'";

	$result = mysql_query($query, $connection);
	if ($result) {
		$count = mysql_num_rows($result);
		if ($count > 0) {
			$ctnDetail = mysql_fetch_array($result);
			$id = $ctnDetail ["id"];
			
			$sqlGetDataInsert = "update adv8_client_landing_page_ctn set call_tracking_number='" . $call_tracking_number . "',forwarding_number='" . $forwarding_number . "',display_number='" . $display_number . "',service_from='" . $call_tracking_sdate . "', service_to='" . $call_tracking_expdate . "',email_alert='" . $email_alert . "',sms_alert='" . $sms_alert . "',alert_email_id='" . $email_alert_id . "',alert_sms_number='" . $sms_alert_number . "', timezone = '" . $calltracking_timestamp . "' where Id='" . $id . "'";
	
			$x = mysql_query($sqlGetDataInsert, $connection);
			
			if($x){
				$arr['status'] = 1;
				$arr['msg']  = 'Done';
			}else{
				$arr['status'] = 0;
				$arr['msg']  = 'ERROR';
			}
			
		}else{
			$arr['status'] = 1;
			$arr['msg']  = 'call tracking number not found';
			$arr['query']  = $query;
		}
	}
	return $arr;
}

if($_SERVER['HTTP_HOST'] == 'localhost'){  
	$host       = "localhost";
	$user       = "root";
	$pass       = "agl360";
	$db_name    = "advait_cust";  
}else{
	

	$host3       = "198.12.156.187";
	$user3       = "adv8zf2";
	$pass3       = "M1nX98@1,p6%#)V";
	$db_name3    = "adv8zf2";
	
}


$connection3 = mysql_connect($host3, $user3, $pass3) or die("Not connected, pls try again or user/password may be wrong");
$db3 =  mysql_select_db($db_name3, $connection3);



$id = $_REQUEST['lp_id'];
if(!empty($id)){

	$arrMy = insertDbiAdv8($_REQUEST['lp_id'],$_REQUEST['call_tracking_number'],$_REQUEST['forwarding_number'],$_REQUEST['display_number'],$_REQUEST['call_tracking_orderID'],$_REQUEST['call_tracking_sdate'],$_REQUEST['call_tracking_expdate'],$_REQUEST['email_alert'],$_REQUEST['sms_alert'],$_REQUEST['email_alert_id'],$_REQUEST['sms_alert_number'],$_REQUEST['pack'],$_REQUEST['packValue'],$_REQUEST['packMinutes'],$_REQUEST['last_modified_date'],$_REQUEST['user_id'],$_REQUEST['allocatenumberManaullay'],$_REQUEST['calltracking_timestamp'], $connection3);
	
	
	
}else{
	
	$arrMy['statusC'] = 0;
	$arrMy['msg'] = "No field found";
}

echo json_encode($arrMy);

?>
